import numpy as np
import cv2
import time
from crop import SlicePart

cap = cv2.VideoCapture("LineReal2.mp4")
imgList=[]
pointsList=[]


# create NumPy arrays from the boundaries
lower = np.array([0, 0, 0], dtype = "uint8")
upper = np.array([70, 70, 70], dtype = "uint8")

# Define the codec and create VideoWriter object
fourcc = cv2.cv.CV_FOURCC(*'XVID')
out = cv2.VideoWriter('LineReal3.avi',fourcc, 60.0, (640,360))

def centers(moments, x):
	if moments["m00"] == 0:
		return 0
	else:
		if x == 0:
			return int(moments["m10"]/moments["m00"])
		else:
			return int(moments["m01"]/moments["m00"])

while(True):
	# Capture frame-by-frame
	ret, frame = cap.read()

	#mask = cv2.inRange(frame, lower, upper)
	#frame = cv2.bitwise_and(frame, frame, mask = mask)
	#frame = cv2.bitwise_not(frame, frame, mask = mask)
	#frame = (255-frame)

	if ret == True:
		time_1 = time.clock()
                #frame = cv2.blur(frame,(10,10))
                for i in range(5):
                        imgList.append(SlicePart(frame, 4, i))
                for l in range(1,5):
                        im = imgList[l]

                        imgray = cv2.cvtColor(im,cv2.COLOR_BGR2GRAY)
                        ret, thresh = cv2.threshold(imgray,100,255,cv2.THRESH_BINARY_INV)

                        contours, hierarchy = cv2.findContours(thresh,cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)

                        height, width  = im.shape[:2]	
                        center = None

                        middleX = int(width/2)
                        middleY = int(height/2)
                                
                        if contours:
                                c = max(contours, key=cv2.contourArea)
                                
                                ((x, y), radius) = cv2.minEnclosingCircle(c)
                                M = cv2.moments(c)
                                cX = centers(M,0)
                                cY = centers(M,1)

                                #print(abs(cX-middleX))
                                pointsList.append([cX, cY+(int(height)*(l-1))])

                                #cv2.drawContours(im,contours,-1,(0,255,0),3)
                                #cv2.circle(im, (cX, middleY), 7, (255,255,255), -1)
                                #cv2.circle(im, (middleX, middleY), 7, (0,0,255), -1)

                                font = cv2.FONT_HERSHEY_SIMPLEX
                                #cv2.putText(im,str(middleX-cX),(cX+20, cY), font, 1,(175,175,175),2,cv2.CV_AA)


                #vis = np.concatenate((	np.concatenate((imgList[1], imgList[2]), axis=0), 
                #                                np.concatenate((imgList[3], imgList[4]), axis=0)), axis=0)
            
                print 'Time: ' + str((time.clock() - time_1)*1000) + 'ms'
                #cv2.polylines(vis, np.int32([pointsList]), 1, (255,0,0))

                # Display the resulting frame
                #out.write(vis)
                #cv2.imshow('frame',vis)
                del imgList[:]
                del pointsList[:]
                if cv2.waitKey(1) & 0xFF == ord('q'):
                        break	
	else:
		break

cap.release()
cv2.destroyAllWindows()
