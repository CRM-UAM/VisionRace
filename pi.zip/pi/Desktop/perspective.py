import numpy as np
import cv2
from scipy.interpolate import griddata
import time

LADO = 51
X = 0
Y = 0
DIV = 16
RESOLUTION = (240, 288)

def nothing(x):
    pass

img = cv2.imread('persp_camera.png')
cv2.namedWindow('image')

rows,cols,ch = img.shape
height, width  = img.shape[:2]
altura, anchura  = img.shape[:2]
height /= 2
width /= 2

#cv2.createTrackbar('Lado', 'image', 30, 100, nothing)
#cv2.createTrackbar('X', 'image', 1, 200, nothing)
#cv2.createTrackbar('Y', 'image', 1, 200, nothing)

#LADO = cv2.getTrackbarPos('Lado','image')
X = cv2.getTrackbarPos('X','image')
Y = cv2.getTrackbarPos('Y','image')

cX = width + X
cY = height + Y

pts1 = np.float32([[cX-66,cY-96],[cX-89,cY-12],[cX+90,cY-12],[cX+68,cY-96]])
pts2 = np.float32([[cX-LADO,cY-LADO],[cX-LADO,cY+LADO],[cX+LADO,cY+LADO],[cX+LADO,cY-LADO]])

M_Perspective = cv2.getPerspectiveTransform(pts1,pts2)

dst = cv2.warpPerspective(img,M_Perspective,RESOLUTION)

imgray = cv2.cvtColor(dst,cv2.COLOR_BGR2GRAY) #Convert to Gray Scale
ret, thresh = cv2.threshold(imgray,122,255,cv2.THRESH_BINARY_INV) #Get Threshold
            
altura, anchura  = img.shape[:2]
sl = altura / DIV

centers = []

#for i in range(DIV):
#    cv2.line(dst,(0,i*sl),(640,i*sl),(255,0,0),1)
#    for j in range(640):
#        if (j+1) < 640:
#            if abs(int(thresh[i*sl,j])-int(thresh[i*sl,j+1])) > 250:
#                centers.append([j, i*sl])
#                cv2.circle(dst, (j,i*sl), 2, (255,255,255), -1)
#        #cv2.circle(dst, ((centers[i+1][0]-centers[i][0])/2+centers[i][0], centers[i][1]), 2, (0,0,255), -1)


warped = None
##############################################
t1 = time.clock()
grid_x, grid_y = np.mgrid[0:287:288j, 0:239:240j]

source = np.array([[79,86],[66,136],[173,136],[161,86]])
#destination = np.array([[96,120],[96,166],[142,166],[142,120]])
#destination = np.array([[0,0],[287,0],[239,288],[0,288]])
destination = np.array([[0,0],[287,71],[287,164],[0, 239]])

grid_z = griddata(destination, source, (grid_x, grid_y), method='cubic')

map_x = np.append([], [ar[:,1] for ar in grid_z]).reshape(288,240)
map_y = np.append([], [ar[:,0] for ar in grid_z]).reshape(288,240)

dstMap1, dstMap2 = cv2.convertMaps(map_x.astype(np.float32), map_y.astype(np.float32), cv2.CV_16SC2)

print("Matrix Perspective: " + str((time.clock()-t1)*1000))
t1 = time.clock()
warped = cv2.remap(img, dstMap1, dstMap2,  cv2.INTER_LINEAR, warped, cv2.BORDER_REPLICATE)
print("Warp Perspective: " + str((time.clock()-t1)*1000))
cv2.imshow('warp', warped)

##############################################

cv2.imshow('image', dst)
#cv2.imwrite('edges.png',laplacian)

if cv2.waitKey(0) == 27:         # wait for ESC key to exit
    cv2.destroyAllWindows()
#if cv2.waitKey(1) & 0xFF == ord('q'):
#    break

