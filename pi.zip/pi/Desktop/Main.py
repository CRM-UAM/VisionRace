import cv2
import numpy as np
import subprocess as sp
import time
import atexit
import sys

from control_motores import *

def nothing(x):
    pass

arguments = sys.argv[1:]

if(len(arguments) == 0):
    print("Usage: Main.py <turn factor>")
    sys.exit()
    
Speed = 50

MotorsSetup()
BaseSpeed(-Speed)

frames = []

frames = [] # stores the video sequence for the demo
max_frames = 300

N_frames = 0
#cv2.namedWindow('Thresh Window')
#cv2.createTrackbar('Thresh', 'Thresh Window', 20, 200, nothing)

# Video capture parameters
(w, h) = (640,240)
bytesPerFrame = w * h
fps = 40 # setting to 250 will request the maximum framerate possible

lateral_search = 20 # number of pixels to search the line border
start_height = h - 5 # The first line sometimes might contain artifacts
start_left_margin = 100 # ignore the first 100 pixels

file = open("camera.cfg","r")
lines = file.readlines()

# "raspividyuv" is the command that provides camera frames in YUV format
#  "--output -" specifies stdout as the output
#  "--timeout 0" specifies continuous video
#  "--luma" discards chroma channels, only luminance is sent through the pipeline
# see "raspividyuv --help" for more information on the parameters
videoCmd = "raspividyuv -w "+str(w)+" -h "+str(h)+" --output - --timeout 0 -vs -ex antishake -vf -hf -vs -co "+str(int(lines[0])-100)+" -br "+lines[1]+" --framerate "+str(fps)+" --luma --nopreview -ISO "+lines[2]+" -ev "+str(int(lines[2])-10)
videoCmd = videoCmd.split() # Popen requires that each parameter is a separate string

threshValue = int(lines[4])
file.close()

cameraProcess = sp.Popen(videoCmd, stdout = sp.PIPE) # start the camera
atexit.register(cameraProcess.terminate) # this closes the camera process in case the python scripts exits unexpectedly

# wait for the first frame and discard it (only done to measure time more accurately)
rawStream = cameraProcess.stdout.read(bytesPerFrame)

print("Recording...")

no_points_count = 0

while True:
#for qwerty in xrange(500):
    cameraProcess.stdout.flush() # discard any frames that we were not able to process in time
    # Parse the raw stream into a numpy array
    frame = np.fromfile(cameraProcess.stdout, count=bytesPerFrame, dtype=np.uint8)
    if frame.size != bytesPerFrame:
        print("Error: Camera stream closed unexpectedly")
        break
    frame.shape = (h,w) # set the correct dimensions for the numpy array

    start_time = time.clock()

    frame_rgb = cv2.cvtColor(frame, cv2.COLOR_GRAY2RGB) # Drawing color points requires RGB image
    ret, thresh = cv2.threshold(frame, threshValue, 255, cv2.THRESH_BINARY)
    #canny = cv2.Canny(thresh, threshValue,200)

    start_height = h - 5
    
    signed_thresh = thresh[start_height].astype(np.int16)
    diff = np.diff(signed_thresh)   #The derivative of the start_height line
    #diff = diff[start_left_margin:] # ignore the first 100 values of the derivative
    point_list = []
    points = np.where(np.logical_or(diff > 200, diff < -200)) #maximums and minimums of derivative
    #if len(points[0])>1 and diff[points[0][0]] == 255:
        #points = np.delete(points, 0)

    cv2.line(frame_rgb,(0,start_height),(640,start_height),(0,255,0),1)

    if len(points) > 0 and len(points[0]) > 1:
        if GetSpeed() == 0:
            BaseSpeed(-Speed)
        middle = (points[0][0] + points[0][1]) / 2
        dif_points_x = abs(points[0][0] - points[0][1])-50
        print("DIF " + str(dif_points_x))
        cv2.circle(frame_rgb, (points[0][0], start_height), 2, (255,0,0), -1)
        cv2.circle(frame_rgb, (points[0][1], start_height), 2, (255,0,0), -1)
        cv2.circle(frame_rgb, (middle, start_height), 2, (0,0,255), -1)
        result = int((middle - 320)/int(sys.argv[1])) + (dif_points_x * -1.3)
        if (abs(result) > 100):
            result = 99 * (result/abs(result))
            print("CORRECTED!")
        print(result)
        Direction(result)
        if (start_height < (h-5)):
            start_height = h-5
    else:
        start_height -= 7
        no_points_count += 1
        frames.append(frame_rgb)        
        
    start_height = h - 50
    
    signed_thresh = thresh[start_height].astype(np.int16)
    diff = np.diff(signed_thresh)   #The derivative of the start_height line
    #diff = diff[start_left_margin:] # ignore the first 100 values of the derivative
    point_list = []
    points = np.where(np.logical_or(diff > 200, diff < -200)) #maximums and minimums of derivative
    #if len(points[0])>1 and diff[points[0][0]] == 255:
        #points = np.delete(points, 0)

    cv2.line(frame_rgb,(0,start_height),(640,start_height),(0,255,0),1)

    if len(points) > 0 and len(points[0]) > 1:
        middle_2 = (points[0][0] + points[0][1]) / 2
        cv2.circle(frame_rgb, (points[0][0], start_height), 2, (255,0,0), -1)
        cv2.circle(frame_rgb, (points[0][1], start_height), 2, (255,0,0), -1)
        cv2.circle(frame_rgb, (middle_2, start_height), 2, (0,0,255), -1)
        if (np.abs(middle_2-middle) > 20):
            Speed += 2
            print("BRAKE")
        else:
            Speed -= 2
            print("ACCEL")

        
    if (Speed > -50):
        Speed = -50
    if (Speed < -100):
        Speed = -100
    
    print("Speed: " + str(Speed))
    BaseSpeed(Speed)
    Direction(result)
    print("Loop took:", str((time.clock()- start_time) * 1000), 'ms')

    if no_points_count > 30:
        break
        
    #show the frame
    #cv2.imshow("Display Window", frame_rgb)
    #cv2.imshow("Thresh Window", thresh)
    #if cv2.waitKey(1) & 0xFF == ord('q'):
    #    break

cameraProcess.terminate() # stop the camera
cv2.destroyAllWindows()
MotorsStop()

print("Writing RGB frames to disk...")
out = cv2.VideoWriter("drive_test.avi", cv2.cv.CV_FOURCC(*"MJPG"), 1, (w,h))
for n in xrange(len(frames)):
    out.write(frames[n])
    
out.release()

print("Writing THRESH frames to disk...")
out_thresh = cv2.VideoWriter("drive_test_thresh.avi", cv2.cv.CV_FOURCC(*"MJPG"), 1, (w,h))
for n in xrange(len(frames)):
    ret_2, thresh_2 = cv2.threshold(frames[n], threshValue, 255, cv2.THRESH_BINARY)
    out_thresh.write(thresh_2)
    
out_thresh.release()
