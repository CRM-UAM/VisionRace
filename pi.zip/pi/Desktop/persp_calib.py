from control_motores import *

import time

MotorsSetup()
BaseSpeed(-10)
time.sleep(2)
MotorsStop()
