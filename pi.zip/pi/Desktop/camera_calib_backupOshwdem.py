import cv2
import numpy as np
import subprocess as sp
import time
import atexit
import sys

def nothing(x):
    pass

cv2.namedWindow('image')
cv2.namedWindow('thresh')

cv2.createTrackbar('Sharpness', 'image', 0, 200, nothing)
cv2.createTrackbar('Contrast', 'image', 0, 200, nothing)
cv2.createTrackbar('Brightness', 'image', 25, 100, nothing)
cv2.createTrackbar('ISO', 'image', 100, 800, nothing)
cv2.createTrackbar('EV', 'image', 0, 20, nothing)

cv2.createTrackbar('ThreshValue', 'thresh', 1, 200, nothing)

file = open("camera.cfg","r")

lines = file.readlines()

cv2.setTrackbarPos('Contrast','image', int(lines[0]))
cv2.setTrackbarPos('Brightness','image', int(lines[1]))
cv2.setTrackbarPos('ISO','image', int(lines[2]))
cv2.setTrackbarPos('EV','image', int(lines[3]))
cv2.setTrackbarPos('ThreshValue','thresh', int(lines[4]))

file.close()

sharpness = 0
contrast = 0
brightness = 0
iso = 0
ev = 0

# Video capture parameters
(w, h) = (640,240)
bytesPerFrame = w * h

# "raspividyuv" is the command that provides camera frames in YUV format
#  "--output -" specifies stdout as the output
#  "--timeout 0" specifies continuous video
#  "--luma" discards chroma channels, only luminance is sent through the pipeline
# see "raspividyuv --help" for more information on the parameters
videoCmd = "raspividyuv -w "+str(w)+" -h "+str(h)+" -o - -vf -hf --timeout 0 --luma"#-sh "+str(sharpness)+" -co "+str(contrast)+" -br "+str(brightness)+" -sa "+str(saturation)+" -ISO "+str(iso)+" -ev "+str(ev)
videoCmd = videoCmd.split() # Popen requires that each parameter is a separate string
cameraProcess = sp.Popen(videoCmd, stdout = sp.PIPE) # start the camera
atexit.register(cameraProcess.terminate) # this closes the camera process in case the python scripts exits unexpectedly

while True:
    sharpness_prev = sharpness
    contrast_prev = contrast
    brightness_prev = brightness
    iso_prev = iso
    ev_prev = ev

    sharpness = cv2.getTrackbarPos('Sharpness','image')
    contrast = cv2.getTrackbarPos('Contrast','image')
    brightness = cv2.getTrackbarPos('Brightness','image')
    iso = cv2.getTrackbarPos('ISO','image')
    ev = cv2.getTrackbarPos('EV','image')
    
    threshvalue = cv2.getTrackbarPos('ThreshValue','thresh')
    
    contrast -= 100
    sharpness -= 100
    ev -= 10
    
    if (sharpness_prev != sharpness or contrast_prev != contrast or brightness_prev != brightness or iso_prev != iso or ev_prev != ev):
        cameraProcess.terminate()
        videoCmd = "raspividyuv -w "+str(w)+" -h "+str(h)+" -o - --timeout 0 --luma --nopreview -ex snow -sh "+str(sharpness)+" -co "+str(contrast)+" -br "+str(brightness)+" -ISO "+str(iso)+" -ev "+str(ev)
        videoCmd = videoCmd.split() # Popen requires that each parameter is a separate string
        cameraProcess = sp.Popen(videoCmd, stdout = sp.PIPE) # start the camera
        atexit.register(cameraProcess.terminate) # this closes the camera process in case the python scripts exits unexpectedly
        print("REFRESH")
    
    cameraProcess.stdout.flush()
    
    frame = np.fromfile(cameraProcess.stdout, count=bytesPerFrame, dtype=np.uint8)
    if frame.size != bytesPerFrame:
        print("Error: Camera stream closed unexpectedly")
        break
    frame.shape = (h,w)
    
    frame_rgb = cv2.cvtColor(frame, cv2.COLOR_GRAY2RGB) # Drawing color points requires RGB image
    ret, thresh = cv2.threshold(frame, threshvalue, 255, cv2.THRESH_BINARY)
    
    cv2.imshow("image", frame)
    cv2.imshow("thresh", thresh)
    #cv2.imshow("derivativeX", cv2.Sobel(frame,cv2.CV_64F,1,0,ksize=5))
    #cv2.imshow("canny", cv2.Canny(thresh,threshvalue,200))
    if cv2.waitKey(100) & 0xFF == ord('q'):
        break
    
    file = open("camera.cfg","w") 
    
    file.write(str(contrast+100)+"\n") 
    file.write(str(brightness)+"\n") 
    file.write(str(iso)+"\n") 
    file.write(str(ev)+"\n")
    file.write(str(threshvalue)+"\n")
    
    file.close() 
 
cv2.destroyAllWindows()
