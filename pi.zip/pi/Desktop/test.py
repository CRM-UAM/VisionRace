from control_motores import *
import time

MotorsSetup()
BaseSpeed(10)
time.sleep(5)

Direction(50)
time.sleep(3)
Direction(-50)
time.sleep(3)

MotorsStop()
