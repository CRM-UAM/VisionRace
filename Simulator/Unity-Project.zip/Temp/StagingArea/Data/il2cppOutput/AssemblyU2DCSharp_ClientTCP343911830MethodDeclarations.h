﻿#pragma once

#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <stdint.h>
#include <assert.h>
#include <exception>

// ClientTCP
struct ClientTCP_t343911830;

#include "codegen/il2cpp-codegen.h"

// System.Void ClientTCP::.ctor()
extern "C"  void ClientTCP__ctor_m664495037 (ClientTCP_t343911830 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void ClientTCP::Start()
extern "C"  void ClientTCP_Start_m2597700317 (ClientTCP_t343911830 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void ClientTCP::Update()
extern "C"  void ClientTCP_Update_m3767610008 (ClientTCP_t343911830 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void ClientTCP::LateUpdate()
extern "C"  void ClientTCP_LateUpdate_m1851021468 (ClientTCP_t343911830 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void ClientTCP::OnPostRender()
extern "C"  void ClientTCP_OnPostRender_m1188910934 (ClientTCP_t343911830 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void ClientTCP::StartConnection()
extern "C"  void ClientTCP_StartConnection_m510890599 (ClientTCP_t343911830 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
