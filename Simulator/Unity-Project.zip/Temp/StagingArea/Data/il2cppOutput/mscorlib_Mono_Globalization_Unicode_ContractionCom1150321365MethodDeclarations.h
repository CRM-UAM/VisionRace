﻿#pragma once

#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <stdint.h>
#include <assert.h>
#include <exception>

// Mono.Globalization.Unicode.ContractionComparer
struct ContractionComparer_t1150321365;
// System.Object
struct Il2CppObject;

#include "codegen/il2cpp-codegen.h"
#include "mscorlib_System_Object2689449295.h"

// System.Void Mono.Globalization.Unicode.ContractionComparer::.ctor()
extern "C"  void ContractionComparer__ctor_m1987540192 (ContractionComparer_t1150321365 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void Mono.Globalization.Unicode.ContractionComparer::.cctor()
extern "C"  void ContractionComparer__cctor_m2385740575 (Il2CppObject * __this /* static, unused */, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Int32 Mono.Globalization.Unicode.ContractionComparer::Compare(System.Object,System.Object)
extern "C"  int32_t ContractionComparer_Compare_m314873025 (ContractionComparer_t1150321365 * __this, Il2CppObject * ___o10, Il2CppObject * ___o21, const MethodInfo* method) IL2CPP_METHOD_ATTR;
