﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <cstring>
#include <string.h>
#include <stdio.h>
#include <cmath>
#include <limits>
#include <assert.h>

// AsynchronousClient
struct AsynchronousClient_t317815987;
// System.IAsyncResult
struct IAsyncResult_t1999651008;
// System.Net.Sockets.Socket
struct Socket_t3821512045;
// System.String
struct String_t;
// ClientTCP
struct ClientTCP_t343911830;
// StateObject
struct StateObject_t1293687898;

#include "class-internals.h"
#include "codegen/il2cpp-codegen.h"
#include "mscorlib_System_Array3829468939.h"
#include "AssemblyU2DCSharp_U3CModuleU3E3783534214.h"
#include "AssemblyU2DCSharp_U3CModuleU3E3783534214MethodDeclarations.h"
#include "AssemblyU2DCSharp_AsynchronousClient317815987.h"
#include "AssemblyU2DCSharp_AsynchronousClient317815987MethodDeclarations.h"
#include "mscorlib_System_Void1841601450.h"
#include "mscorlib_System_Object2689449295MethodDeclarations.h"
#include "System_System_Net_Dns1335526197MethodDeclarations.h"
#include "System_System_Net_IPHostEntry994738509MethodDeclarations.h"
#include "System_System_Net_IPEndPoint2615413766MethodDeclarations.h"
#include "System_System_Net_Sockets_Socket3821512045MethodDeclarations.h"
#include "mscorlib_System_AsyncCallback163412349MethodDeclarations.h"
#include "mscorlib_System_Console2311202731MethodDeclarations.h"
#include "System_System_Net_IPHostEntry994738509.h"
#include "System_System_Net_IPAddress1399971723.h"
#include "System_System_Net_IPEndPoint2615413766.h"
#include "System_System_Net_Sockets_Socket3821512045.h"
#include "mscorlib_System_Exception1927440687.h"
#include "mscorlib_System_String2029220233.h"
#include "System_ArrayTypes.h"
#include "mscorlib_System_Int322071877448.h"
#include "System_System_Net_Sockets_AddressFamily303362630.h"
#include "System_System_Net_Sockets_SocketType1143498533.h"
#include "System_System_Net_Sockets_ProtocolType2178963134.h"
#include "mscorlib_System_AsyncCallback163412349.h"
#include "mscorlib_System_Object2689449295.h"
#include "mscorlib_System_IntPtr2504060609.h"
#include "System_System_Net_EndPoint4156119363.h"
#include "mscorlib_System_Threading_ManualResetEvent926074657.h"
#include "mscorlib_System_Threading_WaitHandle677569169MethodDeclarations.h"
#include "mscorlib_System_Threading_WaitHandle677569169.h"
#include "mscorlib_System_Boolean3825574718.h"
#include "System_System_Net_Sockets_SocketShutdown3247039417.h"
#include "mscorlib_System_Threading_EventWaitHandle2091316307MethodDeclarations.h"
#include "AssemblyU2DCSharp_StateObject1293687898MethodDeclarations.h"
#include "AssemblyU2DCSharp_StateObject1293687898.h"
#include "mscorlib_ArrayTypes.h"
#include "mscorlib_System_Byte3683104436.h"
#include "System_System_Net_Sockets_SocketFlags2353657790.h"
#include "mscorlib_System_Text_Encoding663144255MethodDeclarations.h"
#include "mscorlib_System_Text_StringBuilder1221177846MethodDeclarations.h"
#include "mscorlib_System_Text_StringBuilder1221177846.h"
#include "mscorlib_System_Text_Encoding663144255.h"
#include "mscorlib_System_Threading_ManualResetEvent926074657MethodDeclarations.h"
#include "mscorlib_System_String2029220233MethodDeclarations.h"
#include "AssemblyU2DCSharp_ClientTCP343911830.h"
#include "AssemblyU2DCSharp_ClientTCP343911830MethodDeclarations.h"
#include "UnityEngine_UnityEngine_MonoBehaviour1158329972MethodDeclarations.h"
#include "mscorlib_System_Single2076509932.h"
#include "System_System_Net_Sockets_TcpClient408947970MethodDeclarations.h"
#include "UnityEngine_UnityEngine_Screen786852042MethodDeclarations.h"
#include "UnityEngine_UnityEngine_Texture2D3542995729MethodDeclarations.h"
#include "UnityEngine_UI_UnityEngine_UI_InputField1631627530MethodDeclarations.h"
#include "UnityEngine_UnityEngine_Component3819376471MethodDeclarations.h"
#include "UnityEngine_UnityEngine_Transform3275118058MethodDeclarations.h"
#include "System_System_Net_Sockets_TcpClient408947970.h"
#include "UnityEngine_UnityEngine_Texture2D3542995729.h"
#include "UnityEngine_UnityEngine_TextureFormat1386130234.h"
#include "UnityEngine_UI_UnityEngine_UI_InputField1631627530.h"
#include "UnityEngine_UnityEngine_Transform3275118058.h"
#include "UnityEngine_UnityEngine_Vector32243707580.h"
#include "UnityEngine_UnityEngine_Vector32243707580MethodDeclarations.h"
#include "UnityEngine_UnityEngine_Time31991979MethodDeclarations.h"
#include "UnityEngine_UnityEngine_Input1785128008MethodDeclarations.h"
#include "UnityEngine_UnityEngine_Application354826772MethodDeclarations.h"
#include "UnityEngine_UnityEngine_Space4278750806.h"
#include "UnityEngine_UI_UnityEngine_UI_Text356221433.h"
#include "mscorlib_System_Single2076509932MethodDeclarations.h"
#include "UnityEngine_UI_UnityEngine_UI_Text356221433MethodDeclarations.h"
#include "UnityEngine_UI_UnityEngine_UI_Slider297367283.h"
#include "UnityEngine_UI_UnityEngine_UI_Slider297367283MethodDeclarations.h"
#include "UnityEngine_UnityEngine_KeyCode2283395152.h"
#include "UnityEngine_UnityEngine_Object1021602117MethodDeclarations.h"
#include "mscorlib_System_Int322071877448MethodDeclarations.h"
#include "UnityEngine_UnityEngine_GUIText2411476300MethodDeclarations.h"
#include "mscorlib_System_Text_ASCIIEncoding3022927988MethodDeclarations.h"
#include "mscorlib_System_IO_Stream3255436806.h"
#include "mscorlib_System_Text_ASCIIEncoding3022927988.h"
#include "UnityEngine_UnityEngine_Object1021602117.h"
#include "UnityEngine_UnityEngine_GUIText2411476300.h"
#include "mscorlib_System_Exception1927440687MethodDeclarations.h"
#include "System_System_Net_Sockets_NetworkStream581172200.h"
#include "mscorlib_System_IO_Stream3255436806MethodDeclarations.h"
#include "UnityEngine_UnityEngine_Rect3681755626.h"
#include "UnityEngine_UnityEngine_Rect3681755626MethodDeclarations.h"
#include "UnityEngine_UnityEngine_GameObject1756533147MethodDeclarations.h"
#include "UnityEngine_UnityEngine_GameObject1756533147.h"

#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
// System.Void AsynchronousClient::.ctor()
extern "C"  void AsynchronousClient__ctor_m1866306922 (AsynchronousClient_t317815987 * __this, const MethodInfo* method)
{
	{
		Object__ctor_m2551263788(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Void AsynchronousClient::StartClient()
extern Il2CppClass* Dns_t1335526197_il2cpp_TypeInfo_var;
extern Il2CppClass* IPEndPoint_t2615413766_il2cpp_TypeInfo_var;
extern Il2CppClass* Socket_t3821512045_il2cpp_TypeInfo_var;
extern Il2CppClass* AsyncCallback_t163412349_il2cpp_TypeInfo_var;
extern Il2CppClass* AsynchronousClient_t317815987_il2cpp_TypeInfo_var;
extern Il2CppClass* Console_t2311202731_il2cpp_TypeInfo_var;
extern Il2CppClass* Exception_t1927440687_il2cpp_TypeInfo_var;
extern const MethodInfo* AsynchronousClient_ConnectCallback_m2950626480_MethodInfo_var;
extern Il2CppCodeGenString* _stringLiteral994494093;
extern Il2CppCodeGenString* _stringLiteral3914967353;
extern Il2CppCodeGenString* _stringLiteral1158816804;
extern const uint32_t AsynchronousClient_StartClient_m2553350183_MetadataUsageId;
extern "C"  void AsynchronousClient_StartClient_m2553350183 (Il2CppObject * __this /* static, unused */, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AsynchronousClient_StartClient_m2553350183_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	IPHostEntry_t994738509 * V_0 = NULL;
	IPAddress_t1399971723 * V_1 = NULL;
	IPEndPoint_t2615413766 * V_2 = NULL;
	Socket_t3821512045 * V_3 = NULL;
	Exception_t1927440687 * V_4 = NULL;
	Exception_t1927440687 * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t1927440687 * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	int32_t __leave_target = 0;
	NO_UNUSED_WARNING (__leave_target);

IL_0000:
	try
	{ // begin try (depth: 1)
		IL2CPP_RUNTIME_CLASS_INIT(Dns_t1335526197_il2cpp_TypeInfo_var);
		IPHostEntry_t994738509 * L_0 = Dns_GetHostEntry_m705645829(NULL /*static, unused*/, _stringLiteral994494093, /*hidden argument*/NULL);
		V_0 = L_0;
		IPHostEntry_t994738509 * L_1 = V_0;
		IPAddressU5BU5D_t4087230954* L_2 = IPHostEntry_get_AddressList_m3789532398(L_1, /*hidden argument*/NULL);
		int32_t L_3 = 0;
		IPAddress_t1399971723 * L_4 = (L_2)->GetAtUnchecked(static_cast<il2cpp_array_size_t>(L_3));
		V_1 = L_4;
		IPAddress_t1399971723 * L_5 = V_1;
		IPEndPoint_t2615413766 * L_6 = (IPEndPoint_t2615413766 *)il2cpp_codegen_object_new(IPEndPoint_t2615413766_il2cpp_TypeInfo_var);
		IPEndPoint__ctor_m3477723888(L_6, L_5, ((int32_t)8001), /*hidden argument*/NULL);
		V_2 = L_6;
		Socket_t3821512045 * L_7 = (Socket_t3821512045 *)il2cpp_codegen_object_new(Socket_t3821512045_il2cpp_TypeInfo_var);
		Socket__ctor_m2624772808(L_7, 2, 1, 6, /*hidden argument*/NULL);
		V_3 = L_7;
		Socket_t3821512045 * L_8 = V_3;
		IPEndPoint_t2615413766 * L_9 = V_2;
		IntPtr_t L_10;
		L_10.set_m_value_0((void*)(void*)AsynchronousClient_ConnectCallback_m2950626480_MethodInfo_var);
		AsyncCallback_t163412349 * L_11 = (AsyncCallback_t163412349 *)il2cpp_codegen_object_new(AsyncCallback_t163412349_il2cpp_TypeInfo_var);
		AsyncCallback__ctor_m3071689932(L_11, NULL, L_10, /*hidden argument*/NULL);
		Socket_t3821512045 * L_12 = V_3;
		Socket_BeginConnect_m4216431197(L_8, L_9, L_11, L_12, /*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(AsynchronousClient_t317815987_il2cpp_TypeInfo_var);
		ManualResetEvent_t926074657 * L_13 = ((AsynchronousClient_t317815987_StaticFields*)AsynchronousClient_t317815987_il2cpp_TypeInfo_var->static_fields)->get_connectDone_1();
		VirtFuncInvoker0< bool >::Invoke(8 /* System.Boolean System.Threading.WaitHandle::WaitOne() */, L_13);
		Socket_t3821512045 * L_14 = V_3;
		AsynchronousClient_Send_m2116773511(NULL /*static, unused*/, L_14, _stringLiteral3914967353, /*hidden argument*/NULL);
		ManualResetEvent_t926074657 * L_15 = ((AsynchronousClient_t317815987_StaticFields*)AsynchronousClient_t317815987_il2cpp_TypeInfo_var->static_fields)->get_sendDone_2();
		VirtFuncInvoker0< bool >::Invoke(8 /* System.Boolean System.Threading.WaitHandle::WaitOne() */, L_15);
		Socket_t3821512045 * L_16 = V_3;
		AsynchronousClient_Receive_m1349460330(NULL /*static, unused*/, L_16, /*hidden argument*/NULL);
		ManualResetEvent_t926074657 * L_17 = ((AsynchronousClient_t317815987_StaticFields*)AsynchronousClient_t317815987_il2cpp_TypeInfo_var->static_fields)->get_receiveDone_3();
		VirtFuncInvoker0< bool >::Invoke(8 /* System.Boolean System.Threading.WaitHandle::WaitOne() */, L_17);
		String_t* L_18 = ((AsynchronousClient_t317815987_StaticFields*)AsynchronousClient_t317815987_il2cpp_TypeInfo_var->static_fields)->get_response_4();
		IL2CPP_RUNTIME_CLASS_INIT(Console_t2311202731_il2cpp_TypeInfo_var);
		Console_WriteLine_m3776981455(NULL /*static, unused*/, _stringLiteral1158816804, L_18, /*hidden argument*/NULL);
		Socket_t3821512045 * L_19 = V_3;
		Socket_Shutdown_m4200427980(L_19, 2, /*hidden argument*/NULL);
		Socket_t3821512045 * L_20 = V_3;
		Socket_Close_m1619676183(L_20, /*hidden argument*/NULL);
		goto IL_00a4;
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__exception_local = (Exception_t1927440687 *)e.ex;
		if(il2cpp_codegen_class_is_assignable_from (Exception_t1927440687_il2cpp_TypeInfo_var, e.ex->object.klass))
			goto CATCH_0091;
		throw e;
	}

CATCH_0091:
	{ // begin catch(System.Exception)
		V_4 = ((Exception_t1927440687 *)__exception_local);
		Exception_t1927440687 * L_21 = V_4;
		String_t* L_22 = VirtFuncInvoker0< String_t* >::Invoke(3 /* System.String System.Object::ToString() */, L_21);
		IL2CPP_RUNTIME_CLASS_INIT(Console_t2311202731_il2cpp_TypeInfo_var);
		Console_WriteLine_m3271989373(NULL /*static, unused*/, L_22, /*hidden argument*/NULL);
		goto IL_00a4;
	} // end catch (depth: 1)

IL_00a4:
	{
		return;
	}
}
// System.Void AsynchronousClient::ConnectCallback(System.IAsyncResult)
extern Il2CppClass* IAsyncResult_t1999651008_il2cpp_TypeInfo_var;
extern Il2CppClass* Socket_t3821512045_il2cpp_TypeInfo_var;
extern Il2CppClass* Console_t2311202731_il2cpp_TypeInfo_var;
extern Il2CppClass* AsynchronousClient_t317815987_il2cpp_TypeInfo_var;
extern Il2CppClass* Exception_t1927440687_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral1423614027;
extern const uint32_t AsynchronousClient_ConnectCallback_m2950626480_MetadataUsageId;
extern "C"  void AsynchronousClient_ConnectCallback_m2950626480 (Il2CppObject * __this /* static, unused */, Il2CppObject * ___ar0, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AsynchronousClient_ConnectCallback_m2950626480_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	Socket_t3821512045 * V_0 = NULL;
	Exception_t1927440687 * V_1 = NULL;
	Exception_t1927440687 * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t1927440687 * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	int32_t __leave_target = 0;
	NO_UNUSED_WARNING (__leave_target);

IL_0000:
	try
	{ // begin try (depth: 1)
		Il2CppObject * L_0 = ___ar0;
		Il2CppObject * L_1 = InterfaceFuncInvoker0< Il2CppObject * >::Invoke(0 /* System.Object System.IAsyncResult::get_AsyncState() */, IAsyncResult_t1999651008_il2cpp_TypeInfo_var, L_0);
		V_0 = ((Socket_t3821512045 *)CastclassClass(L_1, Socket_t3821512045_il2cpp_TypeInfo_var));
		Socket_t3821512045 * L_2 = V_0;
		Il2CppObject * L_3 = ___ar0;
		Socket_EndConnect_m85765861(L_2, L_3, /*hidden argument*/NULL);
		Socket_t3821512045 * L_4 = V_0;
		EndPoint_t4156119363 * L_5 = Socket_get_RemoteEndPoint_m584165021(L_4, /*hidden argument*/NULL);
		String_t* L_6 = VirtFuncInvoker0< String_t* >::Invoke(3 /* System.String System.Object::ToString() */, L_5);
		IL2CPP_RUNTIME_CLASS_INIT(Console_t2311202731_il2cpp_TypeInfo_var);
		Console_WriteLine_m3776981455(NULL /*static, unused*/, _stringLiteral1423614027, L_6, /*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(AsynchronousClient_t317815987_il2cpp_TypeInfo_var);
		ManualResetEvent_t926074657 * L_7 = ((AsynchronousClient_t317815987_StaticFields*)AsynchronousClient_t317815987_il2cpp_TypeInfo_var->static_fields)->get_connectDone_1();
		EventWaitHandle_Set_m2975776670(L_7, /*hidden argument*/NULL);
		goto IL_0049;
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__exception_local = (Exception_t1927440687 *)e.ex;
		if(il2cpp_codegen_class_is_assignable_from (Exception_t1927440687_il2cpp_TypeInfo_var, e.ex->object.klass))
			goto CATCH_0038;
		throw e;
	}

CATCH_0038:
	{ // begin catch(System.Exception)
		V_1 = ((Exception_t1927440687 *)__exception_local);
		Exception_t1927440687 * L_8 = V_1;
		String_t* L_9 = VirtFuncInvoker0< String_t* >::Invoke(3 /* System.String System.Object::ToString() */, L_8);
		IL2CPP_RUNTIME_CLASS_INIT(Console_t2311202731_il2cpp_TypeInfo_var);
		Console_WriteLine_m3271989373(NULL /*static, unused*/, L_9, /*hidden argument*/NULL);
		goto IL_0049;
	} // end catch (depth: 1)

IL_0049:
	{
		return;
	}
}
// System.Void AsynchronousClient::Receive(System.Net.Sockets.Socket)
extern Il2CppClass* StateObject_t1293687898_il2cpp_TypeInfo_var;
extern Il2CppClass* AsyncCallback_t163412349_il2cpp_TypeInfo_var;
extern Il2CppClass* Exception_t1927440687_il2cpp_TypeInfo_var;
extern Il2CppClass* Console_t2311202731_il2cpp_TypeInfo_var;
extern const MethodInfo* AsynchronousClient_ReceiveCallback_m1498010861_MethodInfo_var;
extern const uint32_t AsynchronousClient_Receive_m1349460330_MetadataUsageId;
extern "C"  void AsynchronousClient_Receive_m1349460330 (Il2CppObject * __this /* static, unused */, Socket_t3821512045 * ___client0, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AsynchronousClient_Receive_m1349460330_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	StateObject_t1293687898 * V_0 = NULL;
	Exception_t1927440687 * V_1 = NULL;
	Exception_t1927440687 * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t1927440687 * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	int32_t __leave_target = 0;
	NO_UNUSED_WARNING (__leave_target);

IL_0000:
	try
	{ // begin try (depth: 1)
		StateObject_t1293687898 * L_0 = (StateObject_t1293687898 *)il2cpp_codegen_object_new(StateObject_t1293687898_il2cpp_TypeInfo_var);
		StateObject__ctor_m1285744273(L_0, /*hidden argument*/NULL);
		V_0 = L_0;
		StateObject_t1293687898 * L_1 = V_0;
		Socket_t3821512045 * L_2 = ___client0;
		L_1->set_workSocket_0(L_2);
		Socket_t3821512045 * L_3 = ___client0;
		StateObject_t1293687898 * L_4 = V_0;
		ByteU5BU5D_t3397334013* L_5 = L_4->get_buffer_2();
		IntPtr_t L_6;
		L_6.set_m_value_0((void*)(void*)AsynchronousClient_ReceiveCallback_m1498010861_MethodInfo_var);
		AsyncCallback_t163412349 * L_7 = (AsyncCallback_t163412349 *)il2cpp_codegen_object_new(AsyncCallback_t163412349_il2cpp_TypeInfo_var);
		AsyncCallback__ctor_m3071689932(L_7, NULL, L_6, /*hidden argument*/NULL);
		StateObject_t1293687898 * L_8 = V_0;
		Socket_BeginReceive_m4000890230(L_3, L_5, 0, ((int32_t)256), 0, L_7, L_8, /*hidden argument*/NULL);
		goto IL_0044;
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__exception_local = (Exception_t1927440687 *)e.ex;
		if(il2cpp_codegen_class_is_assignable_from (Exception_t1927440687_il2cpp_TypeInfo_var, e.ex->object.klass))
			goto CATCH_0033;
		throw e;
	}

CATCH_0033:
	{ // begin catch(System.Exception)
		V_1 = ((Exception_t1927440687 *)__exception_local);
		Exception_t1927440687 * L_9 = V_1;
		String_t* L_10 = VirtFuncInvoker0< String_t* >::Invoke(3 /* System.String System.Object::ToString() */, L_9);
		IL2CPP_RUNTIME_CLASS_INIT(Console_t2311202731_il2cpp_TypeInfo_var);
		Console_WriteLine_m3271989373(NULL /*static, unused*/, L_10, /*hidden argument*/NULL);
		goto IL_0044;
	} // end catch (depth: 1)

IL_0044:
	{
		return;
	}
}
// System.Void AsynchronousClient::ReceiveCallback(System.IAsyncResult)
extern Il2CppClass* IAsyncResult_t1999651008_il2cpp_TypeInfo_var;
extern Il2CppClass* StateObject_t1293687898_il2cpp_TypeInfo_var;
extern Il2CppClass* Encoding_t663144255_il2cpp_TypeInfo_var;
extern Il2CppClass* AsyncCallback_t163412349_il2cpp_TypeInfo_var;
extern Il2CppClass* AsynchronousClient_t317815987_il2cpp_TypeInfo_var;
extern Il2CppClass* Exception_t1927440687_il2cpp_TypeInfo_var;
extern Il2CppClass* Console_t2311202731_il2cpp_TypeInfo_var;
extern const MethodInfo* AsynchronousClient_ReceiveCallback_m1498010861_MethodInfo_var;
extern const uint32_t AsynchronousClient_ReceiveCallback_m1498010861_MetadataUsageId;
extern "C"  void AsynchronousClient_ReceiveCallback_m1498010861 (Il2CppObject * __this /* static, unused */, Il2CppObject * ___ar0, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AsynchronousClient_ReceiveCallback_m1498010861_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	StateObject_t1293687898 * V_0 = NULL;
	Socket_t3821512045 * V_1 = NULL;
	int32_t V_2 = 0;
	Exception_t1927440687 * V_3 = NULL;
	Exception_t1927440687 * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t1927440687 * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	int32_t __leave_target = 0;
	NO_UNUSED_WARNING (__leave_target);

IL_0000:
	try
	{ // begin try (depth: 1)
		{
			Il2CppObject * L_0 = ___ar0;
			Il2CppObject * L_1 = InterfaceFuncInvoker0< Il2CppObject * >::Invoke(0 /* System.Object System.IAsyncResult::get_AsyncState() */, IAsyncResult_t1999651008_il2cpp_TypeInfo_var, L_0);
			V_0 = ((StateObject_t1293687898 *)CastclassClass(L_1, StateObject_t1293687898_il2cpp_TypeInfo_var));
			StateObject_t1293687898 * L_2 = V_0;
			Socket_t3821512045 * L_3 = L_2->get_workSocket_0();
			V_1 = L_3;
			Socket_t3821512045 * L_4 = V_1;
			Il2CppObject * L_5 = ___ar0;
			int32_t L_6 = Socket_EndReceive_m568791588(L_4, L_5, /*hidden argument*/NULL);
			V_2 = L_6;
			int32_t L_7 = V_2;
			if ((((int32_t)L_7) <= ((int32_t)0)))
			{
				goto IL_0066;
			}
		}

IL_0022:
		{
			StateObject_t1293687898 * L_8 = V_0;
			StringBuilder_t1221177846 * L_9 = L_8->get_sb_3();
			IL2CPP_RUNTIME_CLASS_INIT(Encoding_t663144255_il2cpp_TypeInfo_var);
			Encoding_t663144255 * L_10 = Encoding_get_ASCII_m2727409419(NULL /*static, unused*/, /*hidden argument*/NULL);
			StateObject_t1293687898 * L_11 = V_0;
			ByteU5BU5D_t3397334013* L_12 = L_11->get_buffer_2();
			int32_t L_13 = V_2;
			String_t* L_14 = VirtFuncInvoker3< String_t*, ByteU5BU5D_t3397334013*, int32_t, int32_t >::Invoke(21 /* System.String System.Text.Encoding::GetString(System.Byte[],System.Int32,System.Int32) */, L_10, L_12, 0, L_13);
			StringBuilder_Append_m3636508479(L_9, L_14, /*hidden argument*/NULL);
			Socket_t3821512045 * L_15 = V_1;
			StateObject_t1293687898 * L_16 = V_0;
			ByteU5BU5D_t3397334013* L_17 = L_16->get_buffer_2();
			IntPtr_t L_18;
			L_18.set_m_value_0((void*)(void*)AsynchronousClient_ReceiveCallback_m1498010861_MethodInfo_var);
			AsyncCallback_t163412349 * L_19 = (AsyncCallback_t163412349 *)il2cpp_codegen_object_new(AsyncCallback_t163412349_il2cpp_TypeInfo_var);
			AsyncCallback__ctor_m3071689932(L_19, NULL, L_18, /*hidden argument*/NULL);
			StateObject_t1293687898 * L_20 = V_0;
			Socket_BeginReceive_m4000890230(L_15, L_17, 0, ((int32_t)256), 0, L_19, L_20, /*hidden argument*/NULL);
			goto IL_0092;
		}

IL_0066:
		{
			StateObject_t1293687898 * L_21 = V_0;
			StringBuilder_t1221177846 * L_22 = L_21->get_sb_3();
			int32_t L_23 = StringBuilder_get_Length_m1608241323(L_22, /*hidden argument*/NULL);
			if ((((int32_t)L_23) <= ((int32_t)1)))
			{
				goto IL_0087;
			}
		}

IL_0077:
		{
			StateObject_t1293687898 * L_24 = V_0;
			StringBuilder_t1221177846 * L_25 = L_24->get_sb_3();
			String_t* L_26 = VirtFuncInvoker0< String_t* >::Invoke(3 /* System.String System.Object::ToString() */, L_25);
			IL2CPP_RUNTIME_CLASS_INIT(AsynchronousClient_t317815987_il2cpp_TypeInfo_var);
			((AsynchronousClient_t317815987_StaticFields*)AsynchronousClient_t317815987_il2cpp_TypeInfo_var->static_fields)->set_response_4(L_26);
		}

IL_0087:
		{
			IL2CPP_RUNTIME_CLASS_INIT(AsynchronousClient_t317815987_il2cpp_TypeInfo_var);
			ManualResetEvent_t926074657 * L_27 = ((AsynchronousClient_t317815987_StaticFields*)AsynchronousClient_t317815987_il2cpp_TypeInfo_var->static_fields)->get_receiveDone_3();
			EventWaitHandle_Set_m2975776670(L_27, /*hidden argument*/NULL);
		}

IL_0092:
		{
			goto IL_00a8;
		}
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__exception_local = (Exception_t1927440687 *)e.ex;
		if(il2cpp_codegen_class_is_assignable_from (Exception_t1927440687_il2cpp_TypeInfo_var, e.ex->object.klass))
			goto CATCH_0097;
		throw e;
	}

CATCH_0097:
	{ // begin catch(System.Exception)
		V_3 = ((Exception_t1927440687 *)__exception_local);
		Exception_t1927440687 * L_28 = V_3;
		String_t* L_29 = VirtFuncInvoker0< String_t* >::Invoke(3 /* System.String System.Object::ToString() */, L_28);
		IL2CPP_RUNTIME_CLASS_INIT(Console_t2311202731_il2cpp_TypeInfo_var);
		Console_WriteLine_m3271989373(NULL /*static, unused*/, L_29, /*hidden argument*/NULL);
		goto IL_00a8;
	} // end catch (depth: 1)

IL_00a8:
	{
		return;
	}
}
// System.Void AsynchronousClient::Send(System.Net.Sockets.Socket,System.String)
extern Il2CppClass* Encoding_t663144255_il2cpp_TypeInfo_var;
extern Il2CppClass* AsyncCallback_t163412349_il2cpp_TypeInfo_var;
extern const MethodInfo* AsynchronousClient_SendCallback_m2860036470_MethodInfo_var;
extern const uint32_t AsynchronousClient_Send_m2116773511_MetadataUsageId;
extern "C"  void AsynchronousClient_Send_m2116773511 (Il2CppObject * __this /* static, unused */, Socket_t3821512045 * ___client0, String_t* ___data1, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AsynchronousClient_Send_m2116773511_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	ByteU5BU5D_t3397334013* V_0 = NULL;
	{
		IL2CPP_RUNTIME_CLASS_INIT(Encoding_t663144255_il2cpp_TypeInfo_var);
		Encoding_t663144255 * L_0 = Encoding_get_ASCII_m2727409419(NULL /*static, unused*/, /*hidden argument*/NULL);
		String_t* L_1 = ___data1;
		ByteU5BU5D_t3397334013* L_2 = VirtFuncInvoker1< ByteU5BU5D_t3397334013*, String_t* >::Invoke(10 /* System.Byte[] System.Text.Encoding::GetBytes(System.String) */, L_0, L_1);
		V_0 = L_2;
		Socket_t3821512045 * L_3 = ___client0;
		ByteU5BU5D_t3397334013* L_4 = V_0;
		ByteU5BU5D_t3397334013* L_5 = V_0;
		IntPtr_t L_6;
		L_6.set_m_value_0((void*)(void*)AsynchronousClient_SendCallback_m2860036470_MethodInfo_var);
		AsyncCallback_t163412349 * L_7 = (AsyncCallback_t163412349 *)il2cpp_codegen_object_new(AsyncCallback_t163412349_il2cpp_TypeInfo_var);
		AsyncCallback__ctor_m3071689932(L_7, NULL, L_6, /*hidden argument*/NULL);
		Socket_t3821512045 * L_8 = ___client0;
		Socket_BeginSend_m2442178957(L_3, L_4, 0, (((int32_t)((int32_t)(((Il2CppArray *)L_5)->max_length)))), 0, L_7, L_8, /*hidden argument*/NULL);
		return;
	}
}
// System.Void AsynchronousClient::SendCallback(System.IAsyncResult)
extern Il2CppClass* IAsyncResult_t1999651008_il2cpp_TypeInfo_var;
extern Il2CppClass* Socket_t3821512045_il2cpp_TypeInfo_var;
extern Il2CppClass* Int32_t2071877448_il2cpp_TypeInfo_var;
extern Il2CppClass* Console_t2311202731_il2cpp_TypeInfo_var;
extern Il2CppClass* AsynchronousClient_t317815987_il2cpp_TypeInfo_var;
extern Il2CppClass* Exception_t1927440687_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral214954107;
extern const uint32_t AsynchronousClient_SendCallback_m2860036470_MetadataUsageId;
extern "C"  void AsynchronousClient_SendCallback_m2860036470 (Il2CppObject * __this /* static, unused */, Il2CppObject * ___ar0, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AsynchronousClient_SendCallback_m2860036470_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	Socket_t3821512045 * V_0 = NULL;
	int32_t V_1 = 0;
	Exception_t1927440687 * V_2 = NULL;
	Exception_t1927440687 * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t1927440687 * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	int32_t __leave_target = 0;
	NO_UNUSED_WARNING (__leave_target);

IL_0000:
	try
	{ // begin try (depth: 1)
		Il2CppObject * L_0 = ___ar0;
		Il2CppObject * L_1 = InterfaceFuncInvoker0< Il2CppObject * >::Invoke(0 /* System.Object System.IAsyncResult::get_AsyncState() */, IAsyncResult_t1999651008_il2cpp_TypeInfo_var, L_0);
		V_0 = ((Socket_t3821512045 *)CastclassClass(L_1, Socket_t3821512045_il2cpp_TypeInfo_var));
		Socket_t3821512045 * L_2 = V_0;
		Il2CppObject * L_3 = ___ar0;
		int32_t L_4 = Socket_EndSend_m2139370489(L_2, L_3, /*hidden argument*/NULL);
		V_1 = L_4;
		int32_t L_5 = V_1;
		int32_t L_6 = L_5;
		Il2CppObject * L_7 = Box(Int32_t2071877448_il2cpp_TypeInfo_var, &L_6);
		IL2CPP_RUNTIME_CLASS_INIT(Console_t2311202731_il2cpp_TypeInfo_var);
		Console_WriteLine_m3776981455(NULL /*static, unused*/, _stringLiteral214954107, L_7, /*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(AsynchronousClient_t317815987_il2cpp_TypeInfo_var);
		ManualResetEvent_t926074657 * L_8 = ((AsynchronousClient_t317815987_StaticFields*)AsynchronousClient_t317815987_il2cpp_TypeInfo_var->static_fields)->get_sendDone_2();
		EventWaitHandle_Set_m2975776670(L_8, /*hidden argument*/NULL);
		goto IL_0045;
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__exception_local = (Exception_t1927440687 *)e.ex;
		if(il2cpp_codegen_class_is_assignable_from (Exception_t1927440687_il2cpp_TypeInfo_var, e.ex->object.klass))
			goto CATCH_0034;
		throw e;
	}

CATCH_0034:
	{ // begin catch(System.Exception)
		V_2 = ((Exception_t1927440687 *)__exception_local);
		Exception_t1927440687 * L_9 = V_2;
		String_t* L_10 = VirtFuncInvoker0< String_t* >::Invoke(3 /* System.String System.Object::ToString() */, L_9);
		IL2CPP_RUNTIME_CLASS_INIT(Console_t2311202731_il2cpp_TypeInfo_var);
		Console_WriteLine_m3271989373(NULL /*static, unused*/, L_10, /*hidden argument*/NULL);
		goto IL_0045;
	} // end catch (depth: 1)

IL_0045:
	{
		return;
	}
}
// System.Void AsynchronousClient::.cctor()
extern Il2CppClass* ManualResetEvent_t926074657_il2cpp_TypeInfo_var;
extern Il2CppClass* AsynchronousClient_t317815987_il2cpp_TypeInfo_var;
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern const uint32_t AsynchronousClient__cctor_m1515036749_MetadataUsageId;
extern "C"  void AsynchronousClient__cctor_m1515036749 (Il2CppObject * __this /* static, unused */, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AsynchronousClient__cctor_m1515036749_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ManualResetEvent_t926074657 * L_0 = (ManualResetEvent_t926074657 *)il2cpp_codegen_object_new(ManualResetEvent_t926074657_il2cpp_TypeInfo_var);
		ManualResetEvent__ctor_m3470249043(L_0, (bool)0, /*hidden argument*/NULL);
		((AsynchronousClient_t317815987_StaticFields*)AsynchronousClient_t317815987_il2cpp_TypeInfo_var->static_fields)->set_connectDone_1(L_0);
		ManualResetEvent_t926074657 * L_1 = (ManualResetEvent_t926074657 *)il2cpp_codegen_object_new(ManualResetEvent_t926074657_il2cpp_TypeInfo_var);
		ManualResetEvent__ctor_m3470249043(L_1, (bool)0, /*hidden argument*/NULL);
		((AsynchronousClient_t317815987_StaticFields*)AsynchronousClient_t317815987_il2cpp_TypeInfo_var->static_fields)->set_sendDone_2(L_1);
		ManualResetEvent_t926074657 * L_2 = (ManualResetEvent_t926074657 *)il2cpp_codegen_object_new(ManualResetEvent_t926074657_il2cpp_TypeInfo_var);
		ManualResetEvent__ctor_m3470249043(L_2, (bool)0, /*hidden argument*/NULL);
		((AsynchronousClient_t317815987_StaticFields*)AsynchronousClient_t317815987_il2cpp_TypeInfo_var->static_fields)->set_receiveDone_3(L_2);
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_3 = ((String_t_StaticFields*)String_t_il2cpp_TypeInfo_var->static_fields)->get_Empty_2();
		((AsynchronousClient_t317815987_StaticFields*)AsynchronousClient_t317815987_il2cpp_TypeInfo_var->static_fields)->set_response_4(L_3);
		return;
	}
}
// System.Void ClientTCP::.ctor()
extern "C"  void ClientTCP__ctor_m664495037 (ClientTCP_t343911830 * __this, const MethodInfo* method)
{
	{
		__this->set_lap_4((bool)1);
		__this->set_speed_6((10.0f));
		MonoBehaviour__ctor_m2464341955(__this, /*hidden argument*/NULL);
		return;
	}
}
// System.Void ClientTCP::Start()
extern Il2CppClass* TcpClient_t408947970_il2cpp_TypeInfo_var;
extern Il2CppClass* Texture2D_t3542995729_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral994494093;
extern Il2CppCodeGenString* _stringLiteral3833175713;
extern const uint32_t ClientTCP_Start_m2597700317_MetadataUsageId;
extern "C"  void ClientTCP_Start_m2597700317 (ClientTCP_t343911830 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ClientTCP_Start_m2597700317_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		TcpClient_t408947970 * L_0 = (TcpClient_t408947970 *)il2cpp_codegen_object_new(TcpClient_t408947970_il2cpp_TypeInfo_var);
		TcpClient__ctor_m1345314116(L_0, /*hidden argument*/NULL);
		__this->set_tcpclnt_11(L_0);
		int32_t L_1 = Screen_get_width_m41137238(NULL /*static, unused*/, /*hidden argument*/NULL);
		int32_t L_2 = Screen_get_height_m1051800773(NULL /*static, unused*/, /*hidden argument*/NULL);
		Texture2D_t3542995729 * L_3 = (Texture2D_t3542995729 *)il2cpp_codegen_object_new(Texture2D_t3542995729_il2cpp_TypeInfo_var);
		Texture2D__ctor_m1873923924(L_3, L_1, L_2, 3, (bool)0, /*hidden argument*/NULL);
		__this->set_ScreenShot_10(L_3);
		InputField_t1631627530 * L_4 = __this->get_ip_14();
		InputField_set_text_m114077119(L_4, _stringLiteral994494093, /*hidden argument*/NULL);
		InputField_t1631627530 * L_5 = __this->get_port_15();
		InputField_set_text_m114077119(L_5, _stringLiteral3833175713, /*hidden argument*/NULL);
		Transform_t3275118058 * L_6 = Component_get_transform_m2697483695(__this, /*hidden argument*/NULL);
		Vector3_t2243707580  L_7 = Transform_get_position_m1104419803(L_6, /*hidden argument*/NULL);
		__this->set_iniPos_9(L_7);
		return;
	}
}
// System.Void ClientTCP::Update()
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern Il2CppClass* Input_t1785128008_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral1004098611;
extern Il2CppCodeGenString* _stringLiteral3110053107;
extern const uint32_t ClientTCP_Update_m3767610008_MetadataUsageId;
extern "C"  void ClientTCP_Update_m3767610008 (ClientTCP_t343911830 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ClientTCP_Update_m3767610008_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	Vector3_t2243707580  V_0;
	memset(&V_0, 0, sizeof(V_0));
	Vector3_t2243707580  V_1;
	memset(&V_1, 0, sizeof(V_1));
	Vector3_t2243707580  V_2;
	memset(&V_2, 0, sizeof(V_2));
	{
		TcpClient_t408947970 * L_0 = __this->get_tcpclnt_11();
		bool L_1 = TcpClient_get_Connected_m3815662272(L_0, /*hidden argument*/NULL);
		if (!L_1)
		{
			goto IL_00c8;
		}
	}
	{
		Transform_t3275118058 * L_2 = Component_get_transform_m2697483695(__this, /*hidden argument*/NULL);
		Transform_t3275118058 * L_3 = Component_get_transform_m2697483695(__this, /*hidden argument*/NULL);
		Vector3_t2243707580  L_4 = Transform_get_forward_m1833488937(L_3, /*hidden argument*/NULL);
		V_0 = L_4;
		float L_5 = (&V_0)->get_x_1();
		Transform_t3275118058 * L_6 = Component_get_transform_m2697483695(__this, /*hidden argument*/NULL);
		Vector3_t2243707580  L_7 = Transform_get_forward_m1833488937(L_6, /*hidden argument*/NULL);
		V_1 = L_7;
		float L_8 = (&V_1)->get_z_3();
		Vector3_t2243707580  L_9;
		memset(&L_9, 0, sizeof(L_9));
		Vector3__ctor_m2638739322(&L_9, L_5, (0.0f), L_8, /*hidden argument*/NULL);
		Vector3_t2243707580  L_10 = Vector3_op_Multiply_m1351554733(NULL /*static, unused*/, L_9, (0.001f), /*hidden argument*/NULL);
		float L_11 = __this->get_speed_6();
		Vector3_t2243707580  L_12 = Vector3_op_Multiply_m1351554733(NULL /*static, unused*/, L_10, L_11, /*hidden argument*/NULL);
		Transform_Translate_m423862381(L_2, L_12, 0, /*hidden argument*/NULL);
		bool L_13 = __this->get_lap_4();
		if (!L_13)
		{
			goto IL_007e;
		}
	}
	{
		float L_14 = __this->get_LapTime_5();
		float L_15 = Time_get_deltaTime_m2233168104(NULL /*static, unused*/, /*hidden argument*/NULL);
		__this->set_LapTime_5(((float)((float)L_14+(float)L_15)));
	}

IL_007e:
	{
		Vector3_t2243707580  L_16 = __this->get_iniPos_9();
		Transform_t3275118058 * L_17 = Component_get_transform_m2697483695(__this, /*hidden argument*/NULL);
		Vector3_t2243707580  L_18 = Transform_get_position_m1104419803(L_17, /*hidden argument*/NULL);
		float L_19 = Vector3_Distance_m1859670022(NULL /*static, unused*/, L_16, L_18, /*hidden argument*/NULL);
		if ((!(((float)L_19) < ((float)(0.1f)))))
		{
			goto IL_00c8;
		}
	}
	{
		Transform_t3275118058 * L_20 = Component_get_transform_m2697483695(__this, /*hidden argument*/NULL);
		Vector3_t2243707580  L_21 = Transform_get_position_m1104419803(L_20, /*hidden argument*/NULL);
		V_2 = L_21;
		float L_22 = (&V_2)->get_x_1();
		Vector3_t2243707580 * L_23 = __this->get_address_of_iniPos_9();
		float L_24 = L_23->get_x_1();
		if ((!(((float)L_22) < ((float)L_24))))
		{
			goto IL_00c8;
		}
	}
	{
		__this->set_lap_4((bool)0);
	}

IL_00c8:
	{
		Text_t356221433 * L_25 = __this->get_laptimeText_7();
		float* L_26 = __this->get_address_of_LapTime_5();
		String_t* L_27 = Single_ToString_m1813392066(L_26, /*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_28 = String_Concat_m612901809(NULL /*static, unused*/, _stringLiteral1004098611, L_27, _stringLiteral3110053107, /*hidden argument*/NULL);
		VirtActionInvoker1< String_t* >::Invoke(72 /* System.Void UnityEngine.UI.Text::set_text(System.String) */, L_25, L_28);
		Transform_t3275118058 * L_29 = Component_get_transform_m2697483695(__this, /*hidden argument*/NULL);
		Vector3_t2243707580  L_30 = Vector3_get_down_m2372302126(NULL /*static, unused*/, /*hidden argument*/NULL);
		int32_t L_31 = __this->get_dir_12();
		Vector3_t2243707580  L_32 = Vector3_op_Multiply_m1351554733(NULL /*static, unused*/, L_30, (((float)((float)L_31))), /*hidden argument*/NULL);
		Slider_t297367283 * L_33 = __this->get_sld_13();
		float L_34 = VirtFuncInvoker0< float >::Invoke(46 /* System.Single UnityEngine.UI.Slider::get_value() */, L_33);
		Vector3_t2243707580  L_35 = Vector3_op_Division_m3315615850(NULL /*static, unused*/, L_32, L_34, /*hidden argument*/NULL);
		Transform_Rotate_m2612876682(L_29, L_35, 0, /*hidden argument*/NULL);
		IL2CPP_RUNTIME_CLASS_INIT(Input_t1785128008_il2cpp_TypeInfo_var);
		bool L_36 = Input_GetKey_m3849524999(NULL /*static, unused*/, ((int32_t)27), /*hidden argument*/NULL);
		if (!L_36)
		{
			goto IL_0132;
		}
	}
	{
		Application_LoadLevel_m3450161284(NULL /*static, unused*/, 0, /*hidden argument*/NULL);
	}

IL_0132:
	{
		return;
	}
}
// System.Void ClientTCP::LateUpdate()
extern Il2CppClass* Object_t1021602117_il2cpp_TypeInfo_var;
extern Il2CppClass* Exception_t1927440687_il2cpp_TypeInfo_var;
extern Il2CppClass* ASCIIEncoding_t3022927988_il2cpp_TypeInfo_var;
extern Il2CppClass* ByteU5BU5D_t3397334013_il2cpp_TypeInfo_var;
extern Il2CppClass* String_t_il2cpp_TypeInfo_var;
extern Il2CppCodeGenString* _stringLiteral2992226367;
extern const uint32_t ClientTCP_LateUpdate_m1851021468_MetadataUsageId;
extern "C"  void ClientTCP_LateUpdate_m1851021468 (ClientTCP_t343911830 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ClientTCP_LateUpdate_m1851021468_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	Exception_t1927440687 * V_0 = NULL;
	Stream_t3255436806 * V_1 = NULL;
	ASCIIEncoding_t3022927988 * V_2 = NULL;
	ByteU5BU5D_t3397334013* V_3 = NULL;
	Exception_t1927440687 * __last_unhandled_exception = 0;
	NO_UNUSED_WARNING (__last_unhandled_exception);
	Exception_t1927440687 * __exception_local = 0;
	NO_UNUSED_WARNING (__exception_local);
	int32_t __leave_target = 0;
	NO_UNUSED_WARNING (__leave_target);
	{
		Texture2D_t3542995729 * L_0 = __this->get_ScreenShot_10();
		IL2CPP_RUNTIME_CLASS_INIT(Object_t1021602117_il2cpp_TypeInfo_var);
		bool L_1 = Object_op_Equality_m3764089466(NULL /*static, unused*/, L_0, (Object_t1021602117 *)NULL, /*hidden argument*/NULL);
		if (L_1)
		{
			goto IL_001c;
		}
	}
	{
		bool L_2 = __this->get_start_3();
		if (L_2)
		{
			goto IL_001d;
		}
	}

IL_001c:
	{
		return;
	}

IL_001d:
	{
		TcpClient_t408947970 * L_3 = __this->get_tcpclnt_11();
		bool L_4 = TcpClient_get_Connected_m3815662272(L_3, /*hidden argument*/NULL);
		if (L_4)
		{
			goto IL_0075;
		}
	}

IL_002d:
	try
	{ // begin try (depth: 1)
		TcpClient_t408947970 * L_5 = __this->get_tcpclnt_11();
		InputField_t1631627530 * L_6 = __this->get_ip_14();
		String_t* L_7 = InputField_get_text_m409351770(L_6, /*hidden argument*/NULL);
		InputField_t1631627530 * L_8 = __this->get_port_15();
		String_t* L_9 = InputField_get_text_m409351770(L_8, /*hidden argument*/NULL);
		int32_t L_10 = Int32_Parse_m3683414232(NULL /*static, unused*/, L_9, /*hidden argument*/NULL);
		TcpClient_Connect_m3290596007(L_5, L_7, L_10, /*hidden argument*/NULL);
		goto IL_0075;
	} // end try (depth: 1)
	catch(Il2CppExceptionWrapper& e)
	{
		__exception_local = (Exception_t1927440687 *)e.ex;
		if(il2cpp_codegen_class_is_assignable_from (Exception_t1927440687_il2cpp_TypeInfo_var, e.ex->object.klass))
			goto CATCH_0058;
		throw e;
	}

CATCH_0058:
	{ // begin catch(System.Exception)
		V_0 = ((Exception_t1927440687 *)__exception_local);
		GUIText_t2411476300 * L_11 = __this->get_txt_2();
		Exception_t1927440687 * L_12 = V_0;
		String_t* L_13 = VirtFuncInvoker0< String_t* >::Invoke(6 /* System.String System.Exception::get_Message() */, L_12);
		GUIText_set_text_m3758377277(L_11, L_13, /*hidden argument*/NULL);
		Application_LoadLevel_m3450161284(NULL /*static, unused*/, 0, /*hidden argument*/NULL);
		goto IL_0075;
	} // end catch (depth: 1)

IL_0075:
	{
		TcpClient_t408947970 * L_14 = __this->get_tcpclnt_11();
		NetworkStream_t581172200 * L_15 = TcpClient_GetStream_m872175179(L_14, /*hidden argument*/NULL);
		V_1 = L_15;
		ASCIIEncoding_t3022927988 * L_16 = (ASCIIEncoding_t3022927988 *)il2cpp_codegen_object_new(ASCIIEncoding_t3022927988_il2cpp_TypeInfo_var);
		ASCIIEncoding__ctor_m4127831672(L_16, /*hidden argument*/NULL);
		V_2 = L_16;
		Texture2D_t3542995729 * L_17 = __this->get_ScreenShot_10();
		ByteU5BU5D_t3397334013* L_18 = Texture2D_EncodeToJPG_m1212200800(L_17, /*hidden argument*/NULL);
		__this->set_ba_8(L_18);
		Stream_t3255436806 * L_19 = V_1;
		ByteU5BU5D_t3397334013* L_20 = __this->get_ba_8();
		ByteU5BU5D_t3397334013* L_21 = __this->get_ba_8();
		VirtActionInvoker3< ByteU5BU5D_t3397334013*, int32_t, int32_t >::Invoke(18 /* System.Void System.IO.Stream::Write(System.Byte[],System.Int32,System.Int32) */, L_19, L_20, 0, (((int32_t)((int32_t)(((Il2CppArray *)L_21)->max_length)))));
		V_3 = ((ByteU5BU5D_t3397334013*)SZArrayNew(ByteU5BU5D_t3397334013_il2cpp_TypeInfo_var, (uint32_t)((int32_t)100)));
		TcpClient_t408947970 * L_22 = __this->get_tcpclnt_11();
		bool L_23 = TcpClient_get_Connected_m3815662272(L_22, /*hidden argument*/NULL);
		if (!L_23)
		{
			goto IL_00d0;
		}
	}
	{
		Stream_t3255436806 * L_24 = V_1;
		ByteU5BU5D_t3397334013* L_25 = V_3;
		VirtFuncInvoker3< int32_t, ByteU5BU5D_t3397334013*, int32_t, int32_t >::Invoke(14 /* System.Int32 System.IO.Stream::Read(System.Byte[],System.Int32,System.Int32) */, L_24, L_25, 0, ((int32_t)100));
	}

IL_00d0:
	{
		GUIText_t2411476300 * L_26 = __this->get_txt_2();
		ASCIIEncoding_t3022927988 * L_27 = V_2;
		ByteU5BU5D_t3397334013* L_28 = V_3;
		String_t* L_29 = VirtFuncInvoker1< String_t*, ByteU5BU5D_t3397334013* >::Invoke(22 /* System.String System.Text.Encoding::GetString(System.Byte[]) */, L_27, L_28);
		IL2CPP_RUNTIME_CLASS_INIT(String_t_il2cpp_TypeInfo_var);
		String_t* L_30 = String_Concat_m2596409543(NULL /*static, unused*/, _stringLiteral2992226367, L_29, /*hidden argument*/NULL);
		GUIText_set_text_m3758377277(L_26, L_30, /*hidden argument*/NULL);
		ASCIIEncoding_t3022927988 * L_31 = V_2;
		ByteU5BU5D_t3397334013* L_32 = V_3;
		String_t* L_33 = VirtFuncInvoker1< String_t*, ByteU5BU5D_t3397334013* >::Invoke(22 /* System.String System.Text.Encoding::GetString(System.Byte[]) */, L_31, L_32);
		int32_t* L_34 = __this->get_address_of_dir_12();
		Int32_TryParse_m656840904(NULL /*static, unused*/, L_33, L_34, /*hidden argument*/NULL);
		return;
	}
}
// System.Void ClientTCP::OnPostRender()
extern "C"  void ClientTCP_OnPostRender_m1188910934 (ClientTCP_t343911830 * __this, const MethodInfo* method)
{
	{
		Texture2D_t3542995729 * L_0 = __this->get_ScreenShot_10();
		int32_t L_1 = Screen_get_width_m41137238(NULL /*static, unused*/, /*hidden argument*/NULL);
		int32_t L_2 = Screen_get_height_m1051800773(NULL /*static, unused*/, /*hidden argument*/NULL);
		Rect_t3681755626  L_3;
		memset(&L_3, 0, sizeof(L_3));
		Rect__ctor_m1220545469(&L_3, (0.0f), (0.0f), (((float)((float)L_1))), (((float)((float)L_2))), /*hidden argument*/NULL);
		Texture2D_ReadPixels_m1120832672(L_0, L_3, 0, 0, /*hidden argument*/NULL);
		Texture2D_t3542995729 * L_4 = __this->get_ScreenShot_10();
		Texture2D_Apply_m3543341930(L_4, /*hidden argument*/NULL);
		return;
	}
}
// System.Void ClientTCP::StartConnection()
extern Il2CppCodeGenString* _stringLiteral1993771182;
extern Il2CppCodeGenString* _stringLiteral332801758;
extern Il2CppCodeGenString* _stringLiteral486803623;
extern const uint32_t ClientTCP_StartConnection_m510890599_MetadataUsageId;
extern "C"  void ClientTCP_StartConnection_m510890599 (ClientTCP_t343911830 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ClientTCP_StartConnection_m510890599_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		__this->set_start_3((bool)1);
		InputField_t1631627530 * L_0 = __this->get_ip_14();
		GameObject_t1756533147 * L_1 = Component_get_gameObject_m3105766835(L_0, /*hidden argument*/NULL);
		GameObject_SetActive_m2887581199(L_1, (bool)0, /*hidden argument*/NULL);
		InputField_t1631627530 * L_2 = __this->get_port_15();
		GameObject_t1756533147 * L_3 = Component_get_gameObject_m3105766835(L_2, /*hidden argument*/NULL);
		GameObject_SetActive_m2887581199(L_3, (bool)0, /*hidden argument*/NULL);
		GameObject_t1756533147 * L_4 = GameObject_Find_m836511350(NULL /*static, unused*/, _stringLiteral1993771182, /*hidden argument*/NULL);
		GameObject_SetActive_m2887581199(L_4, (bool)0, /*hidden argument*/NULL);
		GameObject_t1756533147 * L_5 = GameObject_Find_m836511350(NULL /*static, unused*/, _stringLiteral332801758, /*hidden argument*/NULL);
		GameObject_SetActive_m2887581199(L_5, (bool)0, /*hidden argument*/NULL);
		GameObject_t1756533147 * L_6 = GameObject_Find_m836511350(NULL /*static, unused*/, _stringLiteral486803623, /*hidden argument*/NULL);
		GameObject_SetActive_m2887581199(L_6, (bool)0, /*hidden argument*/NULL);
		return;
	}
}
// System.Void StateObject::.ctor()
extern Il2CppClass* ByteU5BU5D_t3397334013_il2cpp_TypeInfo_var;
extern Il2CppClass* StringBuilder_t1221177846_il2cpp_TypeInfo_var;
extern const uint32_t StateObject__ctor_m1285744273_MetadataUsageId;
extern "C"  void StateObject__ctor_m1285744273 (StateObject_t1293687898 * __this, const MethodInfo* method)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (StateObject__ctor_m1285744273_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		__this->set_buffer_2(((ByteU5BU5D_t3397334013*)SZArrayNew(ByteU5BU5D_t3397334013_il2cpp_TypeInfo_var, (uint32_t)((int32_t)256))));
		StringBuilder_t1221177846 * L_0 = (StringBuilder_t1221177846 *)il2cpp_codegen_object_new(StringBuilder_t1221177846_il2cpp_TypeInfo_var);
		StringBuilder__ctor_m3946851802(L_0, /*hidden argument*/NULL);
		__this->set_sb_3(L_0);
		Object__ctor_m2551263788(__this, /*hidden argument*/NULL);
		return;
	}
}
#ifdef __clang__
#pragma clang diagnostic pop
#endif
