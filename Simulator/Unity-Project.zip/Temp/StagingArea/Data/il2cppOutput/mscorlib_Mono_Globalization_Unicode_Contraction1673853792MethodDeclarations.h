﻿#pragma once

#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <stdint.h>
#include <assert.h>
#include <exception>

// Mono.Globalization.Unicode.Contraction
struct Contraction_t1673853792;
// System.Char[]
struct CharU5BU5D_t1328083999;
// System.String
struct String_t;
// System.Byte[]
struct ByteU5BU5D_t3397334013;

#include "codegen/il2cpp-codegen.h"
#include "mscorlib_System_String2029220233.h"

// System.Void Mono.Globalization.Unicode.Contraction::.ctor(System.Char[],System.String,System.Byte[])
extern "C"  void Contraction__ctor_m1961818401 (Contraction_t1673853792 * __this, CharU5BU5D_t1328083999* ___source0, String_t* ___replacement1, ByteU5BU5D_t3397334013* ___sortkey2, const MethodInfo* method) IL2CPP_METHOD_ATTR;
