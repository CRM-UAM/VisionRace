﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif



#include "class-internals.h"
#include "codegen/il2cpp-codegen.h"
#include "mscorlib_System_Runtime_InteropServices_TypeLibVer3346496961.h"
#include "mscorlib_System_Runtime_InteropServices_TypeLibVer3346496961MethodDeclarations.h"
#include "mscorlib_System_Runtime_CompilerServices_RuntimeCo2430705542.h"
#include "mscorlib_System_Runtime_CompilerServices_RuntimeCo2430705542MethodDeclarations.h"
#include "mscorlib_System_Diagnostics_DebuggableAttribute994551506.h"
#include "mscorlib_System_Diagnostics_DebuggableAttribute994551506MethodDeclarations.h"
#include "mscorlib_System_Runtime_InteropServices_ComVisible2245573759.h"
#include "mscorlib_System_Runtime_InteropServices_ComVisible2245573759MethodDeclarations.h"
#include "mscorlib_System_Runtime_CompilerServices_Compilatio238494011.h"
#include "mscorlib_System_Runtime_CompilerServices_Compilatio238494011MethodDeclarations.h"
#include "mscorlib_System_Reflection_AssemblyDefaultAliasAtt1774139159.h"
#include "mscorlib_System_Reflection_AssemblyDefaultAliasAtt1774139159MethodDeclarations.h"
#include "mscorlib_System_Runtime_CompilerServices_StringFre2691375565.h"
#include "mscorlib_System_Runtime_CompilerServices_StringFre2691375565MethodDeclarations.h"
#include "mscorlib_System_Reflection_AssemblyDescriptionAttr1018387888.h"
#include "mscorlib_System_Reflection_AssemblyDescriptionAttr1018387888MethodDeclarations.h"
#include "mscorlib_System_Runtime_CompilerServices_DefaultDe3858269114.h"
#include "mscorlib_System_Runtime_CompilerServices_DefaultDe3858269114MethodDeclarations.h"
#include "mscorlib_System_Runtime_InteropServices_GuidAttribu222072359.h"
#include "mscorlib_System_Runtime_InteropServices_GuidAttribu222072359MethodDeclarations.h"
#include "mscorlib_System_Reflection_AssemblyInformationalVe3037389657.h"
#include "mscorlib_System_Reflection_AssemblyInformationalVe3037389657MethodDeclarations.h"
#include "mscorlib_System_Resources_SatelliteContractVersion2989984391.h"
#include "mscorlib_System_Resources_SatelliteContractVersion2989984391MethodDeclarations.h"
#include "mscorlib_System_Reflection_AssemblyCopyrightAttribu177123295.h"
#include "mscorlib_System_Reflection_AssemblyCopyrightAttribu177123295MethodDeclarations.h"
#include "mscorlib_System_Reflection_AssemblyCompanyAttribut2851673381.h"
#include "mscorlib_System_Reflection_AssemblyCompanyAttribut2851673381MethodDeclarations.h"
#include "mscorlib_System_Reflection_AssemblyProductAttribut1523443169.h"
#include "mscorlib_System_Reflection_AssemblyProductAttribut1523443169MethodDeclarations.h"
#include "mscorlib_System_Reflection_AssemblyKeyFileAttribute605245443.h"
#include "mscorlib_System_Reflection_AssemblyKeyFileAttribute605245443MethodDeclarations.h"
#include "mscorlib_System_Reflection_AssemblyFileVersionAttr2897687916.h"
#include "mscorlib_System_Reflection_AssemblyFileVersionAttr2897687916MethodDeclarations.h"
#include "mscorlib_System_Reflection_AssemblyDelaySignAttrib2705758496.h"
#include "mscorlib_System_Reflection_AssemblyDelaySignAttrib2705758496MethodDeclarations.h"
#include "mscorlib_System_Resources_NeutralResourcesLanguage3267676636.h"
#include "mscorlib_System_Resources_NeutralResourcesLanguage3267676636MethodDeclarations.h"
#include "mscorlib_System_CLSCompliantAttribute809966061.h"
#include "mscorlib_System_CLSCompliantAttribute809966061MethodDeclarations.h"
#include "mscorlib_System_Reflection_AssemblyTitleAttribute92945912.h"
#include "mscorlib_System_Reflection_AssemblyTitleAttribute92945912MethodDeclarations.h"
#include "mscorlib_System_Runtime_InteropServices_ClassInterf910653559.h"
#include "mscorlib_System_Runtime_InteropServices_ClassInterf910653559MethodDeclarations.h"
#include "mscorlib_System_Runtime_ConstrainedExecution_Relia1625655220.h"
#include "mscorlib_System_Runtime_ConstrainedExecution_Relia1625655220MethodDeclarations.h"
#include "mscorlib_System_Runtime_InteropServices_ComDefaultI347642415.h"
#include "mscorlib_System_Runtime_InteropServices_ComDefaultI347642415MethodDeclarations.h"
#include "mscorlib_System_AttributeUsageAttribute1057435127.h"
#include "mscorlib_System_AttributeUsageAttribute1057435127MethodDeclarations.h"
#include "mscorlib_System_Runtime_InteropServices_TypeLibImp2390314680.h"
#include "mscorlib_System_Runtime_InteropServices_TypeLibImp2390314680MethodDeclarations.h"
#include "mscorlib_System_Runtime_InteropServices_InterfaceT4113096249.h"
#include "mscorlib_System_Runtime_InteropServices_InterfaceT4113096249MethodDeclarations.h"
#include "mscorlib_System_Runtime_InteropServices_DispIdAttri607560947.h"
#include "mscorlib_System_Runtime_InteropServices_DispIdAttri607560947MethodDeclarations.h"
#include "mscorlib_System_Reflection_DefaultMemberAttribute889804479.h"
#include "mscorlib_System_Reflection_DefaultMemberAttribute889804479MethodDeclarations.h"
#include "mscorlib_System_ParamArrayAttribute2144993728.h"
#include "mscorlib_System_ParamArrayAttribute2144993728MethodDeclarations.h"
#include "mscorlib_System_MonoDocumentationNoteAttribute1101545345.h"
#include "mscorlib_System_MonoDocumentationNoteAttribute1101545345MethodDeclarations.h"
#include "mscorlib_System_Runtime_CompilerServices_DecimalCon569828555.h"
#include "mscorlib_System_Runtime_CompilerServices_DecimalCon569828555MethodDeclarations.h"
#include "mscorlib_System_ObsoleteAttribute3878847927.h"
#include "mscorlib_System_ObsoleteAttribute3878847927MethodDeclarations.h"
#include "mscorlib_System_Diagnostics_DebuggerHiddenAttribute638884887.h"
#include "mscorlib_System_Diagnostics_DebuggerHiddenAttribute638884887MethodDeclarations.h"
#include "mscorlib_System_Runtime_CompilerServices_CompilerGe497097752.h"
#include "mscorlib_System_Runtime_CompilerServices_CompilerGe497097752MethodDeclarations.h"
#include "mscorlib_System_MonoTODOAttribute3487514019.h"
#include "mscorlib_System_MonoTODOAttribute3487514019MethodDeclarations.h"
#include "mscorlib_System_Diagnostics_DebuggerDisplayAttribu1528914581.h"
#include "mscorlib_System_Diagnostics_DebuggerDisplayAttribu1528914581MethodDeclarations.h"
#include "mscorlib_System_Diagnostics_DebuggerTypeProxyAttrib970972087.h"
#include "mscorlib_System_Diagnostics_DebuggerTypeProxyAttrib970972087MethodDeclarations.h"
#include "mscorlib_System_FlagsAttribute859561169.h"
#include "mscorlib_System_FlagsAttribute859561169MethodDeclarations.h"
#include "mscorlib_System_Diagnostics_DebuggerStepThroughAttr518825354.h"
#include "mscorlib_System_Diagnostics_DebuggerStepThroughAttr518825354MethodDeclarations.h"
#include "mscorlib_System_Security_SuppressUnmanagedCodeSecuri39244474.h"
#include "mscorlib_System_Security_SuppressUnmanagedCodeSecuri39244474MethodDeclarations.h"
#include "mscorlib_System_ThreadStaticAttribute1787731584.h"
#include "mscorlib_System_ThreadStaticAttribute1787731584MethodDeclarations.h"
#include "mscorlib_System_Runtime_CompilerServices_Internals1037732567.h"
#include "mscorlib_System_Runtime_CompilerServices_Internals1037732567MethodDeclarations.h"
#include "System_System_MonoTODOAttribute3487514019.h"
#include "System_System_MonoTODOAttribute3487514019MethodDeclarations.h"
#include "System_System_ComponentModel_TypeConverterAttribute252469870.h"
#include "System_System_ComponentModel_TypeConverterAttribute252469870MethodDeclarations.h"
#include "System_Core_System_Runtime_CompilerServices_Extens1840441203.h"
#include "System_Core_System_Runtime_CompilerServices_Extens1840441203MethodDeclarations.h"
#include "System_Core_System_MonoTODOAttribute3487514019.h"
#include "System_Core_System_MonoTODOAttribute3487514019MethodDeclarations.h"
#include "UnityEngine_UnityEngine_Scripting_RequiredByNative1913052472.h"
#include "UnityEngine_UnityEngine_Scripting_RequiredByNative1913052472MethodDeclarations.h"
#include "UnityEngine_UnityEngine_ThreadAndSerializationSafe2122816804.h"
#include "UnityEngine_UnityEngine_ThreadAndSerializationSafe2122816804MethodDeclarations.h"
#include "UnityEngine_UnityEngine_WritableAttribute3715198420.h"
#include "UnityEngine_UnityEngine_WritableAttribute3715198420MethodDeclarations.h"
#include "UnityEngine_UnityEngine_Scripting_UsedByNativeCode3212052468.h"
#include "UnityEngine_UnityEngine_Scripting_UsedByNativeCode3212052468MethodDeclarations.h"
#include "UnityEngine_UnityEngine_Internal_ExcludeFromDocsAtt665825653.h"
#include "UnityEngine_UnityEngine_Internal_ExcludeFromDocsAtt665825653MethodDeclarations.h"
#include "UnityEngine_UnityEngineInternal_TypeInferenceRuleA1390152093.h"
#include "UnityEngine_UnityEngineInternal_TypeInferenceRuleA1390152093MethodDeclarations.h"
#include "mscorlib_System_Security_SecuritySafeCriticalAttrib372031554.h"
#include "mscorlib_System_Security_SecuritySafeCriticalAttrib372031554MethodDeclarations.h"
#include "UnityEngine_UnityEngine_Internal_DefaultValueAttri1027170048.h"
#include "UnityEngine_UnityEngine_Internal_DefaultValueAttri1027170048MethodDeclarations.h"
#include "System_System_ComponentModel_EditorBrowsableAttrib1050682502.h"
#include "System_System_ComponentModel_EditorBrowsableAttrib1050682502MethodDeclarations.h"
#include "mscorlib_System_Diagnostics_DebuggerBrowsableAttri1386379234.h"
#include "mscorlib_System_Diagnostics_DebuggerBrowsableAttri1386379234MethodDeclarations.h"
#include "UnityEngine_UnityEngine_SerializeField3073427462.h"
#include "UnityEngine_UnityEngine_SerializeField3073427462MethodDeclarations.h"
#include "UnityEngine_UnityEngine_ExecuteInEditMode3043633143.h"
#include "UnityEngine_UnityEngine_ExecuteInEditMode3043633143MethodDeclarations.h"
#include "UnityEngine_UnityEngine_IL2CPPStructAlignmentAttrib130316838.h"
#include "UnityEngine_UnityEngine_IL2CPPStructAlignmentAttrib130316838MethodDeclarations.h"
#include "UnityEngine_UnityEngine_Serialization_FormerlySeri3673080018.h"
#include "UnityEngine_UnityEngine_Serialization_FormerlySeri3673080018MethodDeclarations.h"
#include "mscorlib_System_Reflection_AssemblyConfigurationAt1678917172.h"
#include "mscorlib_System_Reflection_AssemblyConfigurationAt1678917172MethodDeclarations.h"
#include "mscorlib_System_Reflection_AssemblyTrademarkAttrib3740556705.h"
#include "mscorlib_System_Reflection_AssemblyTrademarkAttrib3740556705MethodDeclarations.h"
#include "UnityEngine_UnityEngine_AddComponentMenu1099699699.h"
#include "UnityEngine_UnityEngine_AddComponentMenu1099699699MethodDeclarations.h"
#include "UnityEngine_UnityEngine_RequireComponent864575032.h"
#include "UnityEngine_UnityEngine_RequireComponent864575032MethodDeclarations.h"
#include "UnityEngine_UnityEngine_RangeAttribute3336560921.h"
#include "UnityEngine_UnityEngine_RangeAttribute3336560921MethodDeclarations.h"
#include "UnityEngine_UnityEngine_SpaceAttribute952253354.h"
#include "UnityEngine_UnityEngine_SpaceAttribute952253354MethodDeclarations.h"
#include "UnityEngine_UnityEngine_DisallowMultipleComponent2656950.h"
#include "UnityEngine_UnityEngine_DisallowMultipleComponent2656950MethodDeclarations.h"
#include "UnityEngine_UnityEngine_SelectionBaseAttribute936505999.h"
#include "UnityEngine_UnityEngine_SelectionBaseAttribute936505999MethodDeclarations.h"
#include "UnityEngine_UnityEngine_TooltipAttribute4278647215.h"
#include "UnityEngine_UnityEngine_TooltipAttribute4278647215MethodDeclarations.h"
#include "UnityEngine_UnityEngine_TextAreaAttribute2454598508.h"
#include "UnityEngine_UnityEngine_TextAreaAttribute2454598508MethodDeclarations.h"

static void g_mscorlib_Assembly_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		TypeLibVersionAttribute_t3346496961 * tmp = (TypeLibVersionAttribute_t3346496961 *)cache->attributes[0];
		TypeLibVersionAttribute__ctor_m2430654495(tmp, 2LL, 0LL, NULL);
	}
	{
		RuntimeCompatibilityAttribute_t2430705542 * tmp = (RuntimeCompatibilityAttribute_t2430705542 *)cache->attributes[1];
		RuntimeCompatibilityAttribute__ctor_m1331212510(tmp, NULL);
		RuntimeCompatibilityAttribute_set_WrapNonExceptionThrows_m2174793351(tmp, true, NULL);
	}
	{
		DebuggableAttribute_t994551506 * tmp = (DebuggableAttribute_t994551506 *)cache->attributes[2];
		DebuggableAttribute__ctor_m1065484869(tmp, 2LL, NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[3];
		ComVisibleAttribute__ctor_m1789587486(tmp, false, NULL);
	}
	{
		CompilationRelaxationsAttribute_t238494011 * tmp = (CompilationRelaxationsAttribute_t238494011 *)cache->attributes[4];
		CompilationRelaxationsAttribute__ctor_m2800984288(tmp, 8LL, NULL);
	}
	{
		AssemblyDefaultAliasAttribute_t1774139159 * tmp = (AssemblyDefaultAliasAttribute_t1774139159 *)cache->attributes[5];
		AssemblyDefaultAliasAttribute__ctor_m746891723(tmp, il2cpp_codegen_string_new_wrapper("mscorlib.dll"), NULL);
	}
	{
		StringFreezingAttribute_t2691375565 * tmp = (StringFreezingAttribute_t2691375565 *)cache->attributes[6];
		StringFreezingAttribute__ctor_m2135695937(tmp, NULL);
	}
	{
		AssemblyDescriptionAttribute_t1018387888 * tmp = (AssemblyDescriptionAttribute_t1018387888 *)cache->attributes[7];
		AssemblyDescriptionAttribute__ctor_m3307088082(tmp, il2cpp_codegen_string_new_wrapper("mscorlib.dll"), NULL);
	}
	{
		DefaultDependencyAttribute_t3858269114 * tmp = (DefaultDependencyAttribute_t3858269114 *)cache->attributes[8];
		DefaultDependencyAttribute__ctor_m107693037(tmp, 1LL, NULL);
	}
	{
		GuidAttribute_t222072359 * tmp = (GuidAttribute_t222072359 *)cache->attributes[9];
		GuidAttribute__ctor_m1099153635(tmp, il2cpp_codegen_string_new_wrapper("BED7F4EA-1A96-11D2-8F08-00A0C9A6186D"), NULL);
	}
	{
		AssemblyInformationalVersionAttribute_t3037389657 * tmp = (AssemblyInformationalVersionAttribute_t3037389657 *)cache->attributes[10];
		AssemblyInformationalVersionAttribute__ctor_m376831533(tmp, il2cpp_codegen_string_new_wrapper("3.0.40818.0"), NULL);
	}
	{
		SatelliteContractVersionAttribute_t2989984391 * tmp = (SatelliteContractVersionAttribute_t2989984391 *)cache->attributes[11];
		SatelliteContractVersionAttribute__ctor_m2605651717(tmp, il2cpp_codegen_string_new_wrapper("2.0.5.0"), NULL);
	}
	{
		AssemblyCopyrightAttribute_t177123295 * tmp = (AssemblyCopyrightAttribute_t177123295 *)cache->attributes[12];
		AssemblyCopyrightAttribute__ctor_m2712202383(tmp, il2cpp_codegen_string_new_wrapper("(c) various MONO Authors"), NULL);
	}
	{
		AssemblyCompanyAttribute_t2851673381 * tmp = (AssemblyCompanyAttribute_t2851673381 *)cache->attributes[13];
		AssemblyCompanyAttribute__ctor_m1217508649(tmp, il2cpp_codegen_string_new_wrapper("MONO development team"), NULL);
	}
	{
		AssemblyProductAttribute_t1523443169 * tmp = (AssemblyProductAttribute_t1523443169 *)cache->attributes[14];
		AssemblyProductAttribute__ctor_m1807437213(tmp, il2cpp_codegen_string_new_wrapper("MONO Common language infrastructure"), NULL);
	}
	{
		AssemblyKeyFileAttribute_t605245443 * tmp = (AssemblyKeyFileAttribute_t605245443 *)cache->attributes[15];
		AssemblyKeyFileAttribute__ctor_m1072556611(tmp, il2cpp_codegen_string_new_wrapper("../silverlight.pub"), NULL);
	}
	{
		AssemblyFileVersionAttribute_t2897687916 * tmp = (AssemblyFileVersionAttribute_t2897687916 *)cache->attributes[16];
		AssemblyFileVersionAttribute__ctor_m2026149866(tmp, il2cpp_codegen_string_new_wrapper("3.0.40818.0"), NULL);
	}
	{
		AssemblyDelaySignAttribute_t2705758496 * tmp = (AssemblyDelaySignAttribute_t2705758496 *)cache->attributes[17];
		AssemblyDelaySignAttribute__ctor_m793760213(tmp, true, NULL);
	}
	{
		NeutralResourcesLanguageAttribute_t3267676636 * tmp = (NeutralResourcesLanguageAttribute_t3267676636 *)cache->attributes[18];
		NeutralResourcesLanguageAttribute__ctor_m1145808404(tmp, il2cpp_codegen_string_new_wrapper("en-US"), NULL);
	}
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[19];
		CLSCompliantAttribute__ctor_m1113299407(tmp, true, NULL);
	}
	{
		AssemblyTitleAttribute_t92945912 * tmp = (AssemblyTitleAttribute_t92945912 *)cache->attributes[20];
		AssemblyTitleAttribute__ctor_m1696431446(tmp, il2cpp_codegen_string_new_wrapper("mscorlib.dll"), NULL);
	}
}
static void Il2CppObject_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		ClassInterfaceAttribute_t910653559 * tmp = (ClassInterfaceAttribute_t910653559 *)cache->attributes[1];
		ClassInterfaceAttribute__ctor_m177247154(tmp, 2LL, NULL);
	}
}
static void Il2CppObject_CustomAttributesCacheGenerator_Object__ctor_m2551263788(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 3LL, 1LL, NULL);
	}
}
static void Il2CppObject_CustomAttributesCacheGenerator_Object_Finalize_m4087144328(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 3LL, 2LL, NULL);
	}
}
static void Il2CppObject_CustomAttributesCacheGenerator_Object_ReferenceEquals_m3900584722(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 3LL, 2LL, NULL);
	}
}
static void ValueType_t3507792607_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
extern const Il2CppType* _Attribute_t1557664299_0_0_0_var;
extern const uint32_t Attribute_t542643598_CustomAttributesCacheGenerator_MetadataUsageId;
static void Attribute_t542643598_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Attribute_t542643598_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ComDefaultInterfaceAttribute_t347642415 * tmp = (ComDefaultInterfaceAttribute_t347642415 *)cache->attributes[0];
		ComDefaultInterfaceAttribute__ctor_m254275202(tmp, il2cpp_codegen_type_get_object(_Attribute_t1557664299_0_0_0_var), NULL);
	}
	{
		ClassInterfaceAttribute_t910653559 * tmp = (ClassInterfaceAttribute_t910653559 *)cache->attributes[1];
		ClassInterfaceAttribute__ctor_m177247154(tmp, 0LL, NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[2];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[3];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 32767LL, NULL);
	}
}
extern const Il2CppType* Attribute_t542643598_0_0_0_var;
extern const uint32_t _Attribute_t1557664299_CustomAttributesCacheGenerator_MetadataUsageId;
static void _Attribute_t1557664299_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (_Attribute_t1557664299_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		GuidAttribute_t222072359 * tmp = (GuidAttribute_t222072359 *)cache->attributes[2];
		GuidAttribute__ctor_m1099153635(tmp, il2cpp_codegen_string_new_wrapper("917B14D0-2D9E-38B8-92A9-381ACF52F7C0"), NULL);
	}
	{
		TypeLibImportClassAttribute_t2390314680 * tmp = (TypeLibImportClassAttribute_t2390314680 *)cache->attributes[3];
		TypeLibImportClassAttribute__ctor_m658319193(tmp, il2cpp_codegen_type_get_object(Attribute_t542643598_0_0_0_var), NULL);
	}
	{
		InterfaceTypeAttribute_t4113096249 * tmp = (InterfaceTypeAttribute_t4113096249 *)cache->attributes[4];
		InterfaceTypeAttribute__ctor_m1747686341(tmp, 1LL, NULL);
	}
}
static void Int32_t2071877448_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void IFormattable_t1523031934_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void IConvertible_t908092482_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void IComparable_t1857082765_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void SerializableAttribute_t2780967079_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 4124LL, NULL);
		AttributeUsageAttribute_set_Inherited_m4085818998(tmp, false, NULL);
		AttributeUsageAttribute_set_AllowMultiple_m683830749(tmp, false, NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void AttributeUsageAttribute_t1057435127_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 4LL, NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void ComVisibleAttribute_t2245573759_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 5597LL, NULL);
		AttributeUsageAttribute_set_Inherited_m4085818998(tmp, false, NULL);
	}
}
static void Int64_t909078037_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void UInt32_t2149682021_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[1];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void UInt32_t2149682021_CustomAttributesCacheGenerator_UInt32_Parse_m3371984903(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void UInt32_t2149682021_CustomAttributesCacheGenerator_UInt32_Parse_m3339354106(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void UInt32_t2149682021_CustomAttributesCacheGenerator_UInt32_TryParse_m4283512434(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void UInt32_t2149682021_CustomAttributesCacheGenerator_UInt32_TryParse_m3987111861(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void CLSCompliantAttribute_t809966061_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 32767LL, NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void UInt64_t2909196914_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void UInt64_t2909196914_CustomAttributesCacheGenerator_UInt64_Parse_m834741018(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void UInt64_t2909196914_CustomAttributesCacheGenerator_UInt64_Parse_m1414377767(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void UInt64_t2909196914_CustomAttributesCacheGenerator_UInt64_TryParse_m3722071442(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Byte_t3683104436_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void SByte_t454417549_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[1];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void SByte_t454417549_CustomAttributesCacheGenerator_SByte_Parse_m1620039654(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void SByte_t454417549_CustomAttributesCacheGenerator_SByte_Parse_m2544167007(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void SByte_t454417549_CustomAttributesCacheGenerator_SByte_TryParse_m1263156074(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Int16_t4041245914_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void UInt16_t986882611_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[1];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void UInt16_t986882611_CustomAttributesCacheGenerator_UInt16_Parse_m3560204090(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void UInt16_t986882611_CustomAttributesCacheGenerator_UInt16_Parse_m3815892167(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void UInt16_t986882611_CustomAttributesCacheGenerator_UInt16_TryParse_m4241404978(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void UInt16_t986882611_CustomAttributesCacheGenerator_UInt16_TryParse_m1818885113(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void IEnumerator_t1466026749_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		GuidAttribute_t222072359 * tmp = (GuidAttribute_t222072359 *)cache->attributes[0];
		GuidAttribute__ctor_m1099153635(tmp, il2cpp_codegen_string_new_wrapper("496B0ABF-CDEE-11D3-88E8-00902754C43A"), NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void IEnumerable_t2911409499_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		GuidAttribute_t222072359 * tmp = (GuidAttribute_t222072359 *)cache->attributes[0];
		GuidAttribute__ctor_m1099153635(tmp, il2cpp_codegen_string_new_wrapper("496B0ABE-CDEE-11d3-88E8-00902754C43A"), NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void IEnumerable_t2911409499_CustomAttributesCacheGenerator_IEnumerable_GetEnumerator_m1462532911(CustomAttributesCache* cache)
{
	{
		DispIdAttribute_t607560947 * tmp = (DispIdAttribute_t607560947 *)cache->attributes[0];
		DispIdAttribute__ctor_m997729106(tmp, -4LL, NULL);
	}
}
static void IDisposable_t2427283555_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void Char_t3454481338_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void String_t_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t889804479 * tmp = (DefaultMemberAttribute_t889804479 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m2234856827(tmp, il2cpp_codegen_string_new_wrapper("Chars"), NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void String_t_CustomAttributesCacheGenerator_String__ctor_m2041020387(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void String_t_CustomAttributesCacheGenerator_String_Equals_m406432531(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 3LL, 1LL, NULL);
	}
}
static void String_t_CustomAttributesCacheGenerator_String_Equals_m2633592423(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 3LL, 1LL, NULL);
	}
}
static void String_t_CustomAttributesCacheGenerator_String_Split_m3326265864____separator0(CustomAttributesCache* cache)
{
	{
		ParamArrayAttribute_t2144993728 * tmp = (ParamArrayAttribute_t2144993728 *)cache->attributes[0];
		ParamArrayAttribute__ctor_m2215984741(tmp, NULL);
	}
}
static void String_t_CustomAttributesCacheGenerator_String_Split_m1779268055(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, false, NULL);
	}
	{
		MonoDocumentationNoteAttribute_t1101545345 * tmp = (MonoDocumentationNoteAttribute_t1101545345 *)cache->attributes[1];
		MonoDocumentationNoteAttribute__ctor_m2670604988(tmp, il2cpp_codegen_string_new_wrapper("code should be moved to managed"), NULL);
	}
}
static void String_t_CustomAttributesCacheGenerator_String_Split_m394273024(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, false, NULL);
	}
}
static void String_t_CustomAttributesCacheGenerator_String_Split_m3927740091(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, false, NULL);
	}
}
static void String_t_CustomAttributesCacheGenerator_String_Trim_m3982520224____trimChars0(CustomAttributesCache* cache)
{
	{
		ParamArrayAttribute_t2144993728 * tmp = (ParamArrayAttribute_t2144993728 *)cache->attributes[0];
		ParamArrayAttribute__ctor_m2215984741(tmp, NULL);
	}
}
static void String_t_CustomAttributesCacheGenerator_String_TrimStart_m710830036____trimChars0(CustomAttributesCache* cache)
{
	{
		ParamArrayAttribute_t2144993728 * tmp = (ParamArrayAttribute_t2144993728 *)cache->attributes[0];
		ParamArrayAttribute__ctor_m2215984741(tmp, NULL);
	}
}
static void String_t_CustomAttributesCacheGenerator_String_TrimEnd_m3153143011____trimChars0(CustomAttributesCache* cache)
{
	{
		ParamArrayAttribute_t2144993728 * tmp = (ParamArrayAttribute_t2144993728 *)cache->attributes[0];
		ParamArrayAttribute__ctor_m2215984741(tmp, NULL);
	}
}
static void String_t_CustomAttributesCacheGenerator_String_Format_m1263743648____args1(CustomAttributesCache* cache)
{
	{
		ParamArrayAttribute_t2144993728 * tmp = (ParamArrayAttribute_t2144993728 *)cache->attributes[0];
		ParamArrayAttribute__ctor_m2215984741(tmp, NULL);
	}
}
static void String_t_CustomAttributesCacheGenerator_String_Format_m876527052____args2(CustomAttributesCache* cache)
{
	{
		ParamArrayAttribute_t2144993728 * tmp = (ParamArrayAttribute_t2144993728 *)cache->attributes[0];
		ParamArrayAttribute__ctor_m2215984741(tmp, NULL);
	}
}
static void String_t_CustomAttributesCacheGenerator_String_FormatHelper_m1513692144____args3(CustomAttributesCache* cache)
{
	{
		ParamArrayAttribute_t2144993728 * tmp = (ParamArrayAttribute_t2144993728 *)cache->attributes[0];
		ParamArrayAttribute__ctor_m2215984741(tmp, NULL);
	}
}
static void String_t_CustomAttributesCacheGenerator_String_Concat_m3881798623____args0(CustomAttributesCache* cache)
{
	{
		ParamArrayAttribute_t2144993728 * tmp = (ParamArrayAttribute_t2144993728 *)cache->attributes[0];
		ParamArrayAttribute__ctor_m2215984741(tmp, NULL);
	}
}
static void String_t_CustomAttributesCacheGenerator_String_Concat_m626692867____values0(CustomAttributesCache* cache)
{
	{
		ParamArrayAttribute_t2144993728 * tmp = (ParamArrayAttribute_t2144993728 *)cache->attributes[0];
		ParamArrayAttribute__ctor_m2215984741(tmp, NULL);
	}
}
static void String_t_CustomAttributesCacheGenerator_String_GetHashCode_m931956593(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 3LL, 1LL, NULL);
	}
}
static void ICloneable_t3853279282_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void Single_t2076509932_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void Single_t2076509932_CustomAttributesCacheGenerator_Single_IsNaN_m2349591895(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 3LL, 2LL, NULL);
	}
}
static void Double_t4078015681_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void Double_t4078015681_CustomAttributesCacheGenerator_Double_IsNaN_m2289494211(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 3LL, 2LL, NULL);
	}
}
static void Decimal_t724701077_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void Decimal_t724701077_CustomAttributesCacheGenerator_MinValue(CustomAttributesCache* cache)
{
	{
		DecimalConstantAttribute_t569828555 * tmp = (DecimalConstantAttribute_t569828555 *)cache->attributes[0];
		DecimalConstantAttribute__ctor_m71487003(tmp, 0, 255, 4294967295LL, 4294967295LL, 4294967295LL, NULL);
	}
}
static void Decimal_t724701077_CustomAttributesCacheGenerator_MaxValue(CustomAttributesCache* cache)
{
	{
		DecimalConstantAttribute_t569828555 * tmp = (DecimalConstantAttribute_t569828555 *)cache->attributes[0];
		DecimalConstantAttribute__ctor_m71487003(tmp, 0, 0, 4294967295LL, 4294967295LL, 4294967295LL, NULL);
	}
}
static void Decimal_t724701077_CustomAttributesCacheGenerator_MinusOne(CustomAttributesCache* cache)
{
	{
		DecimalConstantAttribute_t569828555 * tmp = (DecimalConstantAttribute_t569828555 *)cache->attributes[0];
		DecimalConstantAttribute__ctor_m71487003(tmp, 0, 255, 0LL, 0LL, 1LL, NULL);
	}
}
static void Decimal_t724701077_CustomAttributesCacheGenerator_One(CustomAttributesCache* cache)
{
	{
		DecimalConstantAttribute_t569828555 * tmp = (DecimalConstantAttribute_t569828555 *)cache->attributes[0];
		DecimalConstantAttribute__ctor_m71487003(tmp, 0, 0, 0LL, 0LL, 1LL, NULL);
	}
}
static void Decimal_t724701077_CustomAttributesCacheGenerator_Decimal__ctor_m1376049078(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Decimal_t724701077_CustomAttributesCacheGenerator_Decimal__ctor_m569480123(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Decimal_t724701077_CustomAttributesCacheGenerator_Decimal_Compare_m1330176085(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 3LL, 2LL, NULL);
	}
}
static void Decimal_t724701077_CustomAttributesCacheGenerator_Decimal_op_Explicit_m2135374155(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Decimal_t724701077_CustomAttributesCacheGenerator_Decimal_op_Explicit_m1986696267(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Decimal_t724701077_CustomAttributesCacheGenerator_Decimal_op_Explicit_m714968249(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Decimal_t724701077_CustomAttributesCacheGenerator_Decimal_op_Explicit_m383920456(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Decimal_t724701077_CustomAttributesCacheGenerator_Decimal_op_Implicit_m623319612(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Decimal_t724701077_CustomAttributesCacheGenerator_Decimal_op_Implicit_m233687092(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Decimal_t724701077_CustomAttributesCacheGenerator_Decimal_op_Implicit_m4246329390(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Decimal_t724701077_CustomAttributesCacheGenerator_Decimal_op_Implicit_m2135798419(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Boolean_t3825574718_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void IntPtr_t_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void IntPtr_t_CustomAttributesCacheGenerator_IntPtr__ctor_m2996690883(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 2LL, 1LL, NULL);
	}
}
static void IntPtr_t_CustomAttributesCacheGenerator_IntPtr__ctor_m3803259710(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 2LL, 1LL, NULL);
	}
}
static void IntPtr_t_CustomAttributesCacheGenerator_IntPtr__ctor_m3033286303(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[1];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 2LL, 1LL, NULL);
	}
}
static void IntPtr_t_CustomAttributesCacheGenerator_IntPtr_get_Size_m3339807560(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 3LL, 2LL, NULL);
	}
}
static void IntPtr_t_CustomAttributesCacheGenerator_IntPtr_ToInt64_m39971741(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 3LL, 2LL, NULL);
	}
}
static void IntPtr_t_CustomAttributesCacheGenerator_IntPtr_ToPointer_m1888290092(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[1];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 3LL, 2LL, NULL);
	}
}
static void IntPtr_t_CustomAttributesCacheGenerator_IntPtr_op_Equality_m1573482188(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 3LL, 2LL, NULL);
	}
}
static void IntPtr_t_CustomAttributesCacheGenerator_IntPtr_op_Inequality_m3044532593(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 3LL, 2LL, NULL);
	}
}
static void IntPtr_t_CustomAttributesCacheGenerator_IntPtr_op_Explicit_m3896766622(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 2LL, 1LL, NULL);
	}
}
static void IntPtr_t_CustomAttributesCacheGenerator_IntPtr_op_Explicit_m3090197667(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 2LL, 1LL, NULL);
	}
}
static void IntPtr_t_CustomAttributesCacheGenerator_IntPtr_op_Explicit_m1401226878(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[1];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 2LL, 1LL, NULL);
	}
}
static void IntPtr_t_CustomAttributesCacheGenerator_IntPtr_op_Explicit_m1073656736(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void ISerializable_t1245643778_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void UIntPtr_t_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void UIntPtr_t_CustomAttributesCacheGenerator_UIntPtr__ctor_m2836115166(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void UIntPtr_t_CustomAttributesCacheGenerator_UIntPtr_ToPointer_m2844280029(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void UIntPtr_t_CustomAttributesCacheGenerator_UIntPtr_op_Explicit_m2497276212(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void UIntPtr_t_CustomAttributesCacheGenerator_UIntPtr_op_Explicit_m2011523904(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void MulticastDelegate_t3201952435_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void Delegate_t3022476291_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		ClassInterfaceAttribute_t910653559 * tmp = (ClassInterfaceAttribute_t910653559 *)cache->attributes[1];
		ClassInterfaceAttribute__ctor_m177247154(tmp, 2LL, NULL);
	}
}
static void Delegate_t3022476291_CustomAttributesCacheGenerator_Delegate_Combine_m1976351882(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void Delegate_t3022476291_CustomAttributesCacheGenerator_Delegate_Combine_m1976351882____delegates0(CustomAttributesCache* cache)
{
	{
		ParamArrayAttribute_t2144993728 * tmp = (ParamArrayAttribute_t2144993728 *)cache->attributes[0];
		ParamArrayAttribute__ctor_m2215984741(tmp, NULL);
	}
}
static void Enum_t2459695545_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void Enum_t2459695545_CustomAttributesCacheGenerator_Enum_GetName_m1226611481(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void Enum_t2459695545_CustomAttributesCacheGenerator_Enum_IsDefined_m92789062(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void Enum_t2459695545_CustomAttributesCacheGenerator_Enum_GetUnderlyingType_m3513899012(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void Enum_t2459695545_CustomAttributesCacheGenerator_Enum_Parse_m982704874(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void Enum_t2459695545_CustomAttributesCacheGenerator_Enum_ToString_m3754726711(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m2711473620(tmp, il2cpp_codegen_string_new_wrapper("Provider is ignored, just use ToString"), NULL);
	}
}
static void Enum_t2459695545_CustomAttributesCacheGenerator_Enum_ToString_m662345249(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m2711473620(tmp, il2cpp_codegen_string_new_wrapper("Provider is ignored, just use ToString"), NULL);
	}
}
static void Enum_t2459695545_CustomAttributesCacheGenerator_Enum_ToObject_m1688724857(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void Enum_t2459695545_CustomAttributesCacheGenerator_Enum_ToObject_m604645223(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void Enum_t2459695545_CustomAttributesCacheGenerator_Enum_ToObject_m322320225(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void Enum_t2459695545_CustomAttributesCacheGenerator_Enum_ToObject_m745807726(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void Enum_t2459695545_CustomAttributesCacheGenerator_Enum_ToObject_m2460371738(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void Enum_t2459695545_CustomAttributesCacheGenerator_Enum_ToObject_m2216605710(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[1];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Enum_t2459695545_CustomAttributesCacheGenerator_Enum_ToObject_m275924358(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[1];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Enum_t2459695545_CustomAttributesCacheGenerator_Enum_ToObject_m2601523252(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void Enum_t2459695545_CustomAttributesCacheGenerator_Enum_ToObject_m1438724003(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void Enum_t2459695545_CustomAttributesCacheGenerator_Enum_Format_m2294492821(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void Il2CppArray_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void Il2CppArray_CustomAttributesCacheGenerator_Array_System_Collections_IList_IndexOf_m3525625060(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 3LL, 1LL, NULL);
	}
}
static void Il2CppArray_CustomAttributesCacheGenerator_Array_get_Length_m1498215565(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 3LL, 2LL, NULL);
	}
}
static void Il2CppArray_CustomAttributesCacheGenerator_Array_get_LongLength_m2538298538(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 3LL, 2LL, NULL);
	}
}
static void Il2CppArray_CustomAttributesCacheGenerator_Array_get_Rank_m3837250695(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 3LL, 2LL, NULL);
	}
}
static void Il2CppArray_CustomAttributesCacheGenerator_Array_GetLongLength_m3005360186(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, false, NULL);
	}
}
static void Il2CppArray_CustomAttributesCacheGenerator_Array_GetLowerBound_m3733237204(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 3LL, 2LL, NULL);
	}
}
static void Il2CppArray_CustomAttributesCacheGenerator_Array_GetValue_m3550694941____indices0(CustomAttributesCache* cache)
{
	{
		ParamArrayAttribute_t2144993728 * tmp = (ParamArrayAttribute_t2144993728 *)cache->attributes[0];
		ParamArrayAttribute__ctor_m2215984741(tmp, NULL);
	}
}
static void Il2CppArray_CustomAttributesCacheGenerator_Array_SetValue_m2421438042____indices1(CustomAttributesCache* cache)
{
	{
		ParamArrayAttribute_t2144993728 * tmp = (ParamArrayAttribute_t2144993728 *)cache->attributes[0];
		ParamArrayAttribute__ctor_m2215984741(tmp, NULL);
	}
}
static void Il2CppArray_CustomAttributesCacheGenerator_Array_GetUpperBound_m1352329707(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 3LL, 2LL, NULL);
	}
}
static void Il2CppArray_CustomAttributesCacheGenerator_Array_GetValue_m152202090(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, false, NULL);
	}
}
static void Il2CppArray_CustomAttributesCacheGenerator_Array_GetValue_m518505780(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, false, NULL);
	}
}
static void Il2CppArray_CustomAttributesCacheGenerator_Array_GetValue_m3182152438(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, false, NULL);
	}
}
static void Il2CppArray_CustomAttributesCacheGenerator_Array_SetValue_m1489959987(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, false, NULL);
	}
}
static void Il2CppArray_CustomAttributesCacheGenerator_Array_SetValue_m2671138705(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, false, NULL);
	}
}
static void Il2CppArray_CustomAttributesCacheGenerator_Array_SetValue_m2039608971(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, false, NULL);
	}
}
static void Il2CppArray_CustomAttributesCacheGenerator_Array_CreateInstance_m3327690220____lengths1(CustomAttributesCache* cache)
{
	{
		ParamArrayAttribute_t2144993728 * tmp = (ParamArrayAttribute_t2144993728 *)cache->attributes[0];
		ParamArrayAttribute__ctor_m2215984741(tmp, NULL);
	}
}
static void Il2CppArray_CustomAttributesCacheGenerator_Array_CreateInstance_m679102425____lengths1(CustomAttributesCache* cache)
{
	{
		ParamArrayAttribute_t2144993728 * tmp = (ParamArrayAttribute_t2144993728 *)cache->attributes[0];
		ParamArrayAttribute__ctor_m2215984741(tmp, NULL);
	}
}
static void Il2CppArray_CustomAttributesCacheGenerator_Array_GetValue_m1507415734(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, false, NULL);
	}
}
static void Il2CppArray_CustomAttributesCacheGenerator_Array_GetValue_m1507415734____indices0(CustomAttributesCache* cache)
{
	{
		ParamArrayAttribute_t2144993728 * tmp = (ParamArrayAttribute_t2144993728 *)cache->attributes[0];
		ParamArrayAttribute__ctor_m2215984741(tmp, NULL);
	}
}
static void Il2CppArray_CustomAttributesCacheGenerator_Array_SetValue_m169741241(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, false, NULL);
	}
}
static void Il2CppArray_CustomAttributesCacheGenerator_Array_SetValue_m169741241____indices1(CustomAttributesCache* cache)
{
	{
		ParamArrayAttribute_t2144993728 * tmp = (ParamArrayAttribute_t2144993728 *)cache->attributes[0];
		ParamArrayAttribute__ctor_m2215984741(tmp, NULL);
	}
}
static void Il2CppArray_CustomAttributesCacheGenerator_Array_BinarySearch_m3522310993(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 3LL, 1LL, NULL);
	}
}
static void Il2CppArray_CustomAttributesCacheGenerator_Array_BinarySearch_m1368352453(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 3LL, 1LL, NULL);
	}
}
static void Il2CppArray_CustomAttributesCacheGenerator_Array_BinarySearch_m2287427837(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 3LL, 1LL, NULL);
	}
}
static void Il2CppArray_CustomAttributesCacheGenerator_Array_BinarySearch_m3270245097(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 3LL, 1LL, NULL);
	}
}
static void Il2CppArray_CustomAttributesCacheGenerator_Array_Clear_m782967417(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 3LL, 2LL, NULL);
	}
}
static void Il2CppArray_CustomAttributesCacheGenerator_Array_Copy_m2363740072(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 2LL, 1LL, NULL);
	}
}
static void Il2CppArray_CustomAttributesCacheGenerator_Array_Copy_m3808317496(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 2LL, 1LL, NULL);
	}
}
static void Il2CppArray_CustomAttributesCacheGenerator_Array_Copy_m1969461849(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 2LL, 1LL, NULL);
	}
}
static void Il2CppArray_CustomAttributesCacheGenerator_Array_Copy_m1557170853(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 2LL, 1LL, NULL);
	}
}
static void Il2CppArray_CustomAttributesCacheGenerator_Array_IndexOf_m77084779(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 3LL, 1LL, NULL);
	}
}
static void Il2CppArray_CustomAttributesCacheGenerator_Array_IndexOf_m2819632474(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 3LL, 1LL, NULL);
	}
}
static void Il2CppArray_CustomAttributesCacheGenerator_Array_IndexOf_m2447301431(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 3LL, 1LL, NULL);
	}
}
static void Il2CppArray_CustomAttributesCacheGenerator_Array_LastIndexOf_m229510321(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 3LL, 1LL, NULL);
	}
}
static void Il2CppArray_CustomAttributesCacheGenerator_Array_LastIndexOf_m4096535198(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 3LL, 1LL, NULL);
	}
}
static void Il2CppArray_CustomAttributesCacheGenerator_Array_LastIndexOf_m512887013(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 3LL, 1LL, NULL);
	}
}
static void Il2CppArray_CustomAttributesCacheGenerator_Array_Reverse_m3883292526(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 2LL, 1LL, NULL);
	}
}
static void Il2CppArray_CustomAttributesCacheGenerator_Array_Reverse_m3433347928(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 2LL, 1LL, NULL);
	}
}
static void Il2CppArray_CustomAttributesCacheGenerator_Array_Sort_m2994254654(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 2LL, 1LL, NULL);
	}
}
static void Il2CppArray_CustomAttributesCacheGenerator_Array_Sort_m3002148658(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 2LL, 1LL, NULL);
	}
}
static void Il2CppArray_CustomAttributesCacheGenerator_Array_Sort_m1417611156(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 2LL, 1LL, NULL);
	}
}
static void Il2CppArray_CustomAttributesCacheGenerator_Array_Sort_m3645766612(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 2LL, 1LL, NULL);
	}
}
static void Il2CppArray_CustomAttributesCacheGenerator_Array_Sort_m4096942812(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 2LL, 1LL, NULL);
	}
}
static void Il2CppArray_CustomAttributesCacheGenerator_Array_Sort_m3500510484(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 2LL, 1LL, NULL);
	}
}
static void Il2CppArray_CustomAttributesCacheGenerator_Array_Sort_m2323017822(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 2LL, 1LL, NULL);
	}
}
static void Il2CppArray_CustomAttributesCacheGenerator_Array_Sort_m3742784266(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 2LL, 1LL, NULL);
	}
}
static void Il2CppArray_CustomAttributesCacheGenerator_Array_Sort_m1730553742(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 2LL, 1LL, NULL);
	}
}
static void Il2CppArray_CustomAttributesCacheGenerator_Array_Sort_m3106198730(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 2LL, 1LL, NULL);
	}
}
static void Il2CppArray_CustomAttributesCacheGenerator_Array_Sort_m2090966156(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 2LL, 1LL, NULL);
	}
}
static void Il2CppArray_CustomAttributesCacheGenerator_Array_Sort_m1985772939(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 2LL, 1LL, NULL);
	}
}
static void Il2CppArray_CustomAttributesCacheGenerator_Array_Sort_m2736815140(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 2LL, 1LL, NULL);
	}
}
static void Il2CppArray_CustomAttributesCacheGenerator_Array_Sort_m2468799988(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 2LL, 1LL, NULL);
	}
}
static void Il2CppArray_CustomAttributesCacheGenerator_Array_Sort_m2587948790(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 2LL, 1LL, NULL);
	}
}
static void Il2CppArray_CustomAttributesCacheGenerator_Array_Sort_m1279015767(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 2LL, 1LL, NULL);
	}
}
static void Il2CppArray_CustomAttributesCacheGenerator_Array_CopyTo_m1950502352(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, false, NULL);
	}
}
static void Il2CppArray_CustomAttributesCacheGenerator_Array_Resize_m1201602141(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 3LL, 1LL, NULL);
	}
}
static void Il2CppArray_CustomAttributesCacheGenerator_Array_BinarySearch_m525402987(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 3LL, 1LL, NULL);
	}
}
static void Il2CppArray_CustomAttributesCacheGenerator_Array_BinarySearch_m3577113407(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 3LL, 1LL, NULL);
	}
}
static void Il2CppArray_CustomAttributesCacheGenerator_Array_BinarySearch_m1033585031(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 3LL, 1LL, NULL);
	}
}
static void Il2CppArray_CustomAttributesCacheGenerator_Array_BinarySearch_m3052238307(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 3LL, 1LL, NULL);
	}
}
static void Il2CppArray_CustomAttributesCacheGenerator_Array_ConstrainedCopy_m1922927602(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 3LL, 2LL, NULL);
	}
}
static void Il2CppArray_CustomAttributesCacheGenerator_Il2CppArray____LongLength_PropertyInfo(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, false, NULL);
	}
}
static void ArrayReadOnlyList_1_t3367196019_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t889804479 * tmp = (DefaultMemberAttribute_t889804479 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m2234856827(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void ArrayReadOnlyList_1_t3367196019_CustomAttributesCacheGenerator_ArrayReadOnlyList_1_GetEnumerator_m3031680693(CustomAttributesCache* cache)
{
	{
		DebuggerHiddenAttribute_t638884887 * tmp = (DebuggerHiddenAttribute_t638884887 *)cache->attributes[0];
		DebuggerHiddenAttribute__ctor_m2012788180(tmp, NULL);
	}
}
static void U3CGetEnumeratorU3Ec__Iterator0_t1667190089_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void U3CGetEnumeratorU3Ec__Iterator0_t1667190089_CustomAttributesCacheGenerator_U3CGetEnumeratorU3Ec__Iterator0_System_Collections_Generic_IEnumeratorU3CTU3E_get_Current_m2965013776(CustomAttributesCache* cache)
{
	{
		DebuggerHiddenAttribute_t638884887 * tmp = (DebuggerHiddenAttribute_t638884887 *)cache->attributes[0];
		DebuggerHiddenAttribute__ctor_m2012788180(tmp, NULL);
	}
}
static void U3CGetEnumeratorU3Ec__Iterator0_t1667190089_CustomAttributesCacheGenerator_U3CGetEnumeratorU3Ec__Iterator0_System_Collections_IEnumerator_get_Current_m1649432893(CustomAttributesCache* cache)
{
	{
		DebuggerHiddenAttribute_t638884887 * tmp = (DebuggerHiddenAttribute_t638884887 *)cache->attributes[0];
		DebuggerHiddenAttribute__ctor_m2012788180(tmp, NULL);
	}
}
static void U3CGetEnumeratorU3Ec__Iterator0_t1667190089_CustomAttributesCacheGenerator_U3CGetEnumeratorU3Ec__Iterator0_Dispose_m3682973538(CustomAttributesCache* cache)
{
	{
		DebuggerHiddenAttribute_t638884887 * tmp = (DebuggerHiddenAttribute_t638884887 *)cache->attributes[0];
		DebuggerHiddenAttribute__ctor_m2012788180(tmp, NULL);
	}
}
static void U3CGetEnumeratorU3Ec__Iterator0_t1667190089_CustomAttributesCacheGenerator_U3CGetEnumeratorU3Ec__Iterator0_Reset_m669313508(CustomAttributesCache* cache)
{
	{
		DebuggerHiddenAttribute_t638884887 * tmp = (DebuggerHiddenAttribute_t638884887 *)cache->attributes[0];
		DebuggerHiddenAttribute__ctor_m2012788180(tmp, NULL);
	}
}
static void ICollection_t91669223_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void IList_t3321498491_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t889804479 * tmp = (DefaultMemberAttribute_t889804479 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m2234856827(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void IList_1_t3737699284_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t889804479 * tmp = (DefaultMemberAttribute_t889804479 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m2234856827(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void Void_t1841601450_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
extern const Il2CppType* _Type_t102776839_0_0_0_var;
extern const uint32_t Type_t_CustomAttributesCacheGenerator_MetadataUsageId;
static void Type_t_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Type_t_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ClassInterfaceAttribute_t910653559 * tmp = (ClassInterfaceAttribute_t910653559 *)cache->attributes[0];
		ClassInterfaceAttribute__ctor_m177247154(tmp, 0LL, NULL);
	}
	{
		ComDefaultInterfaceAttribute_t347642415 * tmp = (ComDefaultInterfaceAttribute_t347642415 *)cache->attributes[1];
		ComDefaultInterfaceAttribute__ctor_m254275202(tmp, il2cpp_codegen_type_get_object(_Type_t102776839_0_0_0_var), NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[2];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void Type_t_CustomAttributesCacheGenerator_Type_IsSubclassOf_m2450899481(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void Type_t_CustomAttributesCacheGenerator_Type_GetConstructor_m132234455(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void Type_t_CustomAttributesCacheGenerator_Type_GetConstructor_m663514781(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void Type_t_CustomAttributesCacheGenerator_Type_GetConstructor_m835344477(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void Type_t_CustomAttributesCacheGenerator_Type_GetConstructors_m2314877651(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void Type_t_CustomAttributesCacheGenerator_Type_MakeGenericType_m2765875033____typeArguments0(CustomAttributesCache* cache)
{
	{
		ParamArrayAttribute_t2144993728 * tmp = (ParamArrayAttribute_t2144993728 *)cache->attributes[0];
		ParamArrayAttribute__ctor_m2215984741(tmp, NULL);
	}
}
extern const Il2CppType* _MemberInfo_t332722161_0_0_0_var;
extern const uint32_t MemberInfo_t_CustomAttributesCacheGenerator_MetadataUsageId;
static void MemberInfo_t_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (MemberInfo_t_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ClassInterfaceAttribute_t910653559 * tmp = (ClassInterfaceAttribute_t910653559 *)cache->attributes[0];
		ClassInterfaceAttribute__ctor_m177247154(tmp, 0LL, NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		ComDefaultInterfaceAttribute_t347642415 * tmp = (ComDefaultInterfaceAttribute_t347642415 *)cache->attributes[2];
		ComDefaultInterfaceAttribute__ctor_m254275202(tmp, il2cpp_codegen_type_get_object(_MemberInfo_t332722161_0_0_0_var), NULL);
	}
}
static void ICustomAttributeProvider_t502202687_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
extern const Il2CppType* MemberInfo_t_0_0_0_var;
extern const uint32_t _MemberInfo_t332722161_CustomAttributesCacheGenerator_MetadataUsageId;
static void _MemberInfo_t332722161_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (_MemberInfo_t332722161_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		GuidAttribute_t222072359 * tmp = (GuidAttribute_t222072359 *)cache->attributes[0];
		GuidAttribute__ctor_m1099153635(tmp, il2cpp_codegen_string_new_wrapper("f7102fa9-cabb-3a74-a6da-b4567ef1b079"), NULL);
	}
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[1];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
	{
		InterfaceTypeAttribute_t4113096249 * tmp = (InterfaceTypeAttribute_t4113096249 *)cache->attributes[2];
		InterfaceTypeAttribute__ctor_m1747686341(tmp, 1LL, NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[3];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		TypeLibImportClassAttribute_t2390314680 * tmp = (TypeLibImportClassAttribute_t2390314680 *)cache->attributes[4];
		TypeLibImportClassAttribute__ctor_m658319193(tmp, il2cpp_codegen_type_get_object(MemberInfo_t_0_0_0_var), NULL);
	}
}
static void IReflect_t3412036974_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		GuidAttribute_t222072359 * tmp = (GuidAttribute_t222072359 *)cache->attributes[1];
		GuidAttribute__ctor_m1099153635(tmp, il2cpp_codegen_string_new_wrapper("AFBF15E5-C37C-11d2-B88E-00A0C9B471B8"), NULL);
	}
}
extern const Il2CppType* Type_t_0_0_0_var;
extern const uint32_t _Type_t102776839_CustomAttributesCacheGenerator_MetadataUsageId;
static void _Type_t102776839_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (_Type_t102776839_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		GuidAttribute_t222072359 * tmp = (GuidAttribute_t222072359 *)cache->attributes[0];
		GuidAttribute__ctor_m1099153635(tmp, il2cpp_codegen_string_new_wrapper("BCA8B44D-AAD6-3A86-8AB7-03349F4F2DA2"), NULL);
	}
	{
		InterfaceTypeAttribute_t4113096249 * tmp = (InterfaceTypeAttribute_t4113096249 *)cache->attributes[1];
		InterfaceTypeAttribute__ctor_m1747686341(tmp, 1LL, NULL);
	}
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[2];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[3];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		TypeLibImportClassAttribute_t2390314680 * tmp = (TypeLibImportClassAttribute_t2390314680 *)cache->attributes[4];
		TypeLibImportClassAttribute__ctor_m658319193(tmp, il2cpp_codegen_type_get_object(Type_t_0_0_0_var), NULL);
	}
}
extern const Il2CppType* _Exception_t3026971024_0_0_0_var;
extern const uint32_t Exception_t1927440687_CustomAttributesCacheGenerator_MetadataUsageId;
static void Exception_t1927440687_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Exception_t1927440687_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ClassInterfaceAttribute_t910653559 * tmp = (ClassInterfaceAttribute_t910653559 *)cache->attributes[0];
		ClassInterfaceAttribute__ctor_m177247154(tmp, 0LL, NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		ComDefaultInterfaceAttribute_t347642415 * tmp = (ComDefaultInterfaceAttribute_t347642415 *)cache->attributes[2];
		ComDefaultInterfaceAttribute__ctor_m254275202(tmp, il2cpp_codegen_type_get_object(_Exception_t3026971024_0_0_0_var), NULL);
	}
}
static void _Exception_t3026971024_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		GuidAttribute_t222072359 * tmp = (GuidAttribute_t222072359 *)cache->attributes[0];
		GuidAttribute__ctor_m1099153635(tmp, il2cpp_codegen_string_new_wrapper("b36b5c63-42ef-38bc-a07e-0b34c98f164a"), NULL);
	}
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[1];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[2];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		InterfaceTypeAttribute_t4113096249 * tmp = (InterfaceTypeAttribute_t4113096249 *)cache->attributes[3];
		InterfaceTypeAttribute__ctor_m1747686341(tmp, 0LL, NULL);
	}
}
static void RuntimeFieldHandle_t2331729674_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t3487514019 * tmp = (MonoTODOAttribute_t3487514019 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m1339517176(tmp, il2cpp_codegen_string_new_wrapper("Serialization needs tests"), NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void RuntimeFieldHandle_t2331729674_CustomAttributesCacheGenerator_RuntimeFieldHandle_Equals_m1202966418(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 3LL, 2LL, NULL);
	}
}
static void RuntimeTypeHandle_t2330101084_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t3487514019 * tmp = (MonoTODOAttribute_t3487514019 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m1339517176(tmp, il2cpp_codegen_string_new_wrapper("Serialization needs tests"), NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void RuntimeTypeHandle_t2330101084_CustomAttributesCacheGenerator_RuntimeTypeHandle_Equals_m452760426(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 3LL, 2LL, NULL);
	}
}
static void ParamArrayAttribute_t2144993728_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 2048LL, NULL);
	}
}
static void OutAttribute_t1539424546_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 2048LL, NULL);
		AttributeUsageAttribute_set_Inherited_m4085818998(tmp, false, NULL);
	}
}
static void ObsoleteAttribute_t3878847927_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 6140LL, NULL);
		AttributeUsageAttribute_set_Inherited_m4085818998(tmp, false, NULL);
	}
}
static void DllImportAttribute_t3000813225_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 64LL, NULL);
		AttributeUsageAttribute_set_Inherited_m4085818998(tmp, false, NULL);
	}
}
static void MarshalAsAttribute_t2900773360_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 10496LL, NULL);
		AttributeUsageAttribute_set_Inherited_m4085818998(tmp, false, NULL);
	}
}
static void MarshalAsAttribute_t2900773360_CustomAttributesCacheGenerator_MarshalType(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void MarshalAsAttribute_t2900773360_CustomAttributesCacheGenerator_MarshalTypeRef(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void InAttribute_t1394050551_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 2048LL, NULL);
		AttributeUsageAttribute_set_Inherited_m4085818998(tmp, false, NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void GuidAttribute_t222072359_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 5149LL, NULL);
		AttributeUsageAttribute_set_Inherited_m4085818998(tmp, false, NULL);
	}
}
static void ComImportAttribute_t468083054_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 1028LL, NULL);
		AttributeUsageAttribute_set_Inherited_m4085818998(tmp, false, NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void OptionalAttribute_t827982902_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 2048LL, NULL);
		AttributeUsageAttribute_set_Inherited_m4085818998(tmp, false, NULL);
	}
}
static void CompilerGeneratedAttribute_t497097752_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 32767LL, NULL);
	}
}
static void InternalsVisibleToAttribute_t1037732567_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 1LL, NULL);
		AttributeUsageAttribute_set_AllowMultiple_m683830749(tmp, true, NULL);
		AttributeUsageAttribute_set_Inherited_m4085818998(tmp, false, NULL);
	}
}
static void RuntimeCompatibilityAttribute_t2430705542_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 1LL, NULL);
		AttributeUsageAttribute_set_Inherited_m4085818998(tmp, false, NULL);
		AttributeUsageAttribute_set_AllowMultiple_m683830749(tmp, false, NULL);
	}
}
static void DebuggerHiddenAttribute_t638884887_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 224LL, NULL);
		AttributeUsageAttribute_set_Inherited_m4085818998(tmp, false, NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void DefaultMemberAttribute_t889804479_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 1036LL, NULL);
	}
}
static void DecimalConstantAttribute_t569828555_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 2304LL, NULL);
		AttributeUsageAttribute_set_Inherited_m4085818998(tmp, false, NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void DecimalConstantAttribute_t569828555_CustomAttributesCacheGenerator_DecimalConstantAttribute__ctor_m71487003(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void FieldOffsetAttribute_t1553145711_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 256LL, NULL);
		AttributeUsageAttribute_set_Inherited_m4085818998(tmp, false, NULL);
	}
}
static void RuntimeArgumentHandle_t3259266975_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void AsyncCallback_t163412349_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void IAsyncResult_t1999651008_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void TypedReference_t1025199857_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void MarshalByRefObject_t1285298191_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void Locale_t4255929014_CustomAttributesCacheGenerator_Locale_GetText_m2553164138____args1(CustomAttributesCache* cache)
{
	{
		ParamArrayAttribute_t2144993728 * tmp = (ParamArrayAttribute_t2144993728 *)cache->attributes[0];
		ParamArrayAttribute__ctor_m2215984741(tmp, NULL);
	}
}
static void MonoTODOAttribute_t3487514019_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 32767LL, NULL);
		AttributeUsageAttribute_set_AllowMultiple_m683830749(tmp, true, NULL);
	}
}
static void MonoDocumentationNoteAttribute_t1101545345_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 32767LL, NULL);
		AttributeUsageAttribute_set_AllowMultiple_m683830749(tmp, true, NULL);
	}
}
static void SafeHandleZeroOrMinusOneIsInvalid_t1177681199_CustomAttributesCacheGenerator_SafeHandleZeroOrMinusOneIsInvalid__ctor_m3340306667(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 3LL, 1LL, NULL);
	}
}
static void SafeWaitHandle_t481461830_CustomAttributesCacheGenerator_SafeWaitHandle__ctor_m1710231470(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 3LL, 1LL, NULL);
	}
}
static void MSCompatUnicodeTable_t1231687219_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map2(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void MSCompatUnicodeTable_t1231687219_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map3(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void MSCompatUnicodeTable_t1231687219_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map4(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void SortKey_t1270563137_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void PKCS12_t1362584794_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map8(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void PKCS12_t1362584794_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map9(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void PKCS12_t1362584794_CustomAttributesCacheGenerator_U3CU3Ef__switchU24mapA(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void PKCS12_t1362584794_CustomAttributesCacheGenerator_U3CU3Ef__switchU24mapB(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void PKCS12_t1362584794_CustomAttributesCacheGenerator_U3CU3Ef__switchU24mapF(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void X509CertificateCollection_t3592472865_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t889804479 * tmp = (DefaultMemberAttribute_t889804479 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m2234856827(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void X509ExtensionCollection_t1640144839_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t889804479 * tmp = (DefaultMemberAttribute_t889804479 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m2234856827(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void ASN1_t924533535_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t889804479 * tmp = (DefaultMemberAttribute_t889804479 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m2234856827(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void SmallXmlParser_t3549787957_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map18(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
extern const Il2CppType* CollectionDebuggerView_2_t1818615358_0_0_0_var;
extern const uint32_t Dictionary_2_t2276497324_CustomAttributesCacheGenerator_MetadataUsageId;
static void Dictionary_2_t2276497324_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Dictionary_2_t2276497324_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		DebuggerDisplayAttribute_t1528914581 * tmp = (DebuggerDisplayAttribute_t1528914581 *)cache->attributes[0];
		DebuggerDisplayAttribute__ctor_m1420611550(tmp, il2cpp_codegen_string_new_wrapper("Count={Count}"), NULL);
	}
	{
		DefaultMemberAttribute_t889804479 * tmp = (DefaultMemberAttribute_t889804479 *)cache->attributes[1];
		DefaultMemberAttribute__ctor_m2234856827(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[2];
		ComVisibleAttribute__ctor_m1789587486(tmp, false, NULL);
	}
	{
		DebuggerTypeProxyAttribute_t970972087 * tmp = (DebuggerTypeProxyAttribute_t970972087 *)cache->attributes[3];
		DebuggerTypeProxyAttribute__ctor_m3082078467(tmp, il2cpp_codegen_type_get_object(CollectionDebuggerView_2_t1818615358_0_0_0_var), NULL);
	}
}
static void Dictionary_2_t2276497324_CustomAttributesCacheGenerator_U3CU3Ef__amU24cacheB(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void Dictionary_2_t2276497324_CustomAttributesCacheGenerator_Dictionary_2_U3CCopyToU3Em__0_m3609630743(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
extern const Il2CppType* CollectionDebuggerView_2_t1818615358_0_0_0_var;
extern const uint32_t ValueCollection_t2262344653_CustomAttributesCacheGenerator_MetadataUsageId;
static void ValueCollection_t2262344653_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ValueCollection_t2262344653_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		DebuggerDisplayAttribute_t1528914581 * tmp = (DebuggerDisplayAttribute_t1528914581 *)cache->attributes[0];
		DebuggerDisplayAttribute__ctor_m1420611550(tmp, il2cpp_codegen_string_new_wrapper("Count={Count}"), NULL);
	}
	{
		DebuggerTypeProxyAttribute_t970972087 * tmp = (DebuggerTypeProxyAttribute_t970972087 *)cache->attributes[1];
		DebuggerTypeProxyAttribute__ctor_m3082078467(tmp, il2cpp_codegen_type_get_object(CollectionDebuggerView_2_t1818615358_0_0_0_var), NULL);
	}
}
static void IDictionary_2_t3502329323_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t889804479 * tmp = (DefaultMemberAttribute_t889804479 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m2234856827(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void KeyNotFoundException_t1722175009_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void KeyValuePair_2_t1988958766_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DebuggerDisplayAttribute_t1528914581 * tmp = (DebuggerDisplayAttribute_t1528914581 *)cache->attributes[0];
		DebuggerDisplayAttribute__ctor_m1420611550(tmp, il2cpp_codegen_string_new_wrapper("{value}"), NULL);
		DebuggerDisplayAttribute_set_Name_m3640338590(tmp, il2cpp_codegen_string_new_wrapper("[{key}]"), NULL);
	}
}
extern const Il2CppType* CollectionDebuggerView_1_t1818615357_0_0_0_var;
extern const uint32_t List_1_t1169184319_CustomAttributesCacheGenerator_MetadataUsageId;
static void List_1_t1169184319_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (List_1_t1169184319_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		DebuggerTypeProxyAttribute_t970972087 * tmp = (DebuggerTypeProxyAttribute_t970972087 *)cache->attributes[0];
		DebuggerTypeProxyAttribute__ctor_m3082078467(tmp, il2cpp_codegen_type_get_object(CollectionDebuggerView_1_t1818615357_0_0_0_var), NULL);
	}
	{
		DefaultMemberAttribute_t889804479 * tmp = (DefaultMemberAttribute_t889804479 *)cache->attributes[1];
		DefaultMemberAttribute__ctor_m2234856827(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
	{
		DebuggerDisplayAttribute_t1528914581 * tmp = (DebuggerDisplayAttribute_t1528914581 *)cache->attributes[2];
		DebuggerDisplayAttribute__ctor_m1420611550(tmp, il2cpp_codegen_string_new_wrapper("Count={Count}"), NULL);
	}
}
static void Collection_1_t686054069_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, false, NULL);
	}
	{
		DefaultMemberAttribute_t889804479 * tmp = (DefaultMemberAttribute_t889804479 *)cache->attributes[1];
		DefaultMemberAttribute__ctor_m2234856827(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void ReadOnlyCollection_1_t3540981679_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t889804479 * tmp = (DefaultMemberAttribute_t889804479 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m2234856827(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, false, NULL);
	}
}
extern const Il2CppType* CollectionDebuggerView_t1643796100_0_0_0_var;
extern const uint32_t ArrayList_t4252133567_CustomAttributesCacheGenerator_MetadataUsageId;
static void ArrayList_t4252133567_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ArrayList_t4252133567_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		DefaultMemberAttribute_t889804479 * tmp = (DefaultMemberAttribute_t889804479 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m2234856827(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
	{
		DebuggerDisplayAttribute_t1528914581 * tmp = (DebuggerDisplayAttribute_t1528914581 *)cache->attributes[1];
		DebuggerDisplayAttribute__ctor_m1420611550(tmp, il2cpp_codegen_string_new_wrapper("Count={Count}"), NULL);
	}
	{
		DebuggerTypeProxyAttribute_t970972087 * tmp = (DebuggerTypeProxyAttribute_t970972087 *)cache->attributes[2];
		DebuggerTypeProxyAttribute__ctor_m3082078467(tmp, il2cpp_codegen_type_get_object(CollectionDebuggerView_t1643796100_0_0_0_var), NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[3];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void ArrayListWrapper_t3918858854_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t889804479 * tmp = (DefaultMemberAttribute_t889804479 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m2234856827(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void SynchronizedArrayListWrapper_t3317806524_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t889804479 * tmp = (DefaultMemberAttribute_t889804479 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m2234856827(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void ReadOnlyArrayListWrapper_t4044524772_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t889804479 * tmp = (DefaultMemberAttribute_t889804479 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m2234856827(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void BitArray_t4180138994_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t889804479 * tmp = (DefaultMemberAttribute_t889804479 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m2234856827(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void CaseInsensitiveComparer_t157661140_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void CaseInsensitiveHashCodeProvider_t2307530285_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m2711473620(tmp, il2cpp_codegen_string_new_wrapper("Please use StringComparer instead."), NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void CollectionBase_t1101587467_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void Comparer_t3673668605_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void DictionaryEntry_t3048875398_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		DebuggerDisplayAttribute_t1528914581 * tmp = (DebuggerDisplayAttribute_t1528914581 *)cache->attributes[1];
		DebuggerDisplayAttribute__ctor_m1420611550(tmp, il2cpp_codegen_string_new_wrapper("{_value}"), NULL);
		DebuggerDisplayAttribute_set_Name_m3640338590(tmp, il2cpp_codegen_string_new_wrapper("[{_key}]"), NULL);
	}
}
extern const Il2CppType* CollectionDebuggerView_t1643796100_0_0_0_var;
extern const uint32_t Hashtable_t909839986_CustomAttributesCacheGenerator_MetadataUsageId;
static void Hashtable_t909839986_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Hashtable_t909839986_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		DebuggerDisplayAttribute_t1528914581 * tmp = (DebuggerDisplayAttribute_t1528914581 *)cache->attributes[1];
		DebuggerDisplayAttribute__ctor_m1420611550(tmp, il2cpp_codegen_string_new_wrapper("Count={Count}"), NULL);
	}
	{
		DebuggerTypeProxyAttribute_t970972087 * tmp = (DebuggerTypeProxyAttribute_t970972087 *)cache->attributes[2];
		DebuggerTypeProxyAttribute__ctor_m3082078467(tmp, il2cpp_codegen_type_get_object(CollectionDebuggerView_t1643796100_0_0_0_var), NULL);
	}
	{
		DefaultMemberAttribute_t889804479 * tmp = (DefaultMemberAttribute_t889804479 *)cache->attributes[3];
		DefaultMemberAttribute__ctor_m2234856827(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void Hashtable_t909839986_CustomAttributesCacheGenerator_Hashtable__ctor_m846339375(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m2711473620(tmp, il2cpp_codegen_string_new_wrapper("Please use Hashtable(int, float, IEqualityComparer) instead"), NULL);
	}
}
static void Hashtable_t909839986_CustomAttributesCacheGenerator_Hashtable__ctor_m4106078798(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m2711473620(tmp, il2cpp_codegen_string_new_wrapper("Please use Hashtable(int, IEqualityComparer) instead"), NULL);
	}
}
static void Hashtable_t909839986_CustomAttributesCacheGenerator_Hashtable__ctor_m2894679847(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m2711473620(tmp, il2cpp_codegen_string_new_wrapper("Please use Hashtable(IDictionary, float, IEqualityComparer) instead"), NULL);
	}
}
static void Hashtable_t909839986_CustomAttributesCacheGenerator_Hashtable__ctor_m3742489710(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m2711473620(tmp, il2cpp_codegen_string_new_wrapper("Please use Hashtable(IDictionary, IEqualityComparer) instead"), NULL);
	}
}
static void Hashtable_t909839986_CustomAttributesCacheGenerator_Hashtable__ctor_m2337481811(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m2711473620(tmp, il2cpp_codegen_string_new_wrapper("Please use Hashtable(IEqualityComparer) instead"), NULL);
	}
}
static void Hashtable_t909839986_CustomAttributesCacheGenerator_Hashtable_Clear_m3672070813(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 3LL, 2LL, NULL);
	}
}
static void Hashtable_t909839986_CustomAttributesCacheGenerator_Hashtable_Remove_m607079606(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 3LL, 1LL, NULL);
	}
}
static void Hashtable_t909839986_CustomAttributesCacheGenerator_Hashtable_OnDeserialization_m4192849898(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t3487514019 * tmp = (MonoTODOAttribute_t3487514019 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m1339517176(tmp, il2cpp_codegen_string_new_wrapper("Serialize equalityComparer"), NULL);
	}
}
static void Hashtable_t909839986_CustomAttributesCacheGenerator_Hashtable_t909839986____comparer_PropertyInfo(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m2711473620(tmp, il2cpp_codegen_string_new_wrapper("Please use EqualityComparer property."), NULL);
	}
}
static void Hashtable_t909839986_CustomAttributesCacheGenerator_Hashtable_t909839986____hcp_PropertyInfo(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m2711473620(tmp, il2cpp_codegen_string_new_wrapper("Please use EqualityComparer property."), NULL);
	}
}
extern const Il2CppType* CollectionDebuggerView_t1643796100_0_0_0_var;
extern const uint32_t HashKeys_t187688763_CustomAttributesCacheGenerator_MetadataUsageId;
static void HashKeys_t187688763_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (HashKeys_t187688763_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		DebuggerTypeProxyAttribute_t970972087 * tmp = (DebuggerTypeProxyAttribute_t970972087 *)cache->attributes[0];
		DebuggerTypeProxyAttribute__ctor_m3082078467(tmp, il2cpp_codegen_type_get_object(CollectionDebuggerView_t1643796100_0_0_0_var), NULL);
	}
	{
		DebuggerDisplayAttribute_t1528914581 * tmp = (DebuggerDisplayAttribute_t1528914581 *)cache->attributes[1];
		DebuggerDisplayAttribute__ctor_m1420611550(tmp, il2cpp_codegen_string_new_wrapper("Count={Count}"), NULL);
	}
}
extern const Il2CppType* CollectionDebuggerView_t1643796100_0_0_0_var;
extern const uint32_t HashValues_t2390200547_CustomAttributesCacheGenerator_MetadataUsageId;
static void HashValues_t2390200547_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (HashValues_t2390200547_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		DebuggerDisplayAttribute_t1528914581 * tmp = (DebuggerDisplayAttribute_t1528914581 *)cache->attributes[0];
		DebuggerDisplayAttribute__ctor_m1420611550(tmp, il2cpp_codegen_string_new_wrapper("Count={Count}"), NULL);
	}
	{
		DebuggerTypeProxyAttribute_t970972087 * tmp = (DebuggerTypeProxyAttribute_t970972087 *)cache->attributes[1];
		DebuggerTypeProxyAttribute__ctor_m3082078467(tmp, il2cpp_codegen_type_get_object(CollectionDebuggerView_t1643796100_0_0_0_var), NULL);
	}
}
static void SyncHashtable_t1343674558_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t889804479 * tmp = (DefaultMemberAttribute_t889804479 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m2234856827(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void IComparer_t3952557350_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void IDictionary_t596158605_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t889804479 * tmp = (DefaultMemberAttribute_t889804479 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m2234856827(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void IDictionaryEnumerator_t259680273_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void IEqualityComparer_t2716208158_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void IHashCodeProvider_t1980576455_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[1];
		ObsoleteAttribute__ctor_m2711473620(tmp, il2cpp_codegen_string_new_wrapper("Please use IEqualityComparer instead."), NULL);
	}
}
extern const Il2CppType* CollectionDebuggerView_t1643796100_0_0_0_var;
extern const uint32_t Queue_t1288490777_CustomAttributesCacheGenerator_MetadataUsageId;
static void Queue_t1288490777_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Queue_t1288490777_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		DebuggerDisplayAttribute_t1528914581 * tmp = (DebuggerDisplayAttribute_t1528914581 *)cache->attributes[0];
		DebuggerDisplayAttribute__ctor_m1420611550(tmp, il2cpp_codegen_string_new_wrapper("Count={Count}"), NULL);
	}
	{
		DebuggerTypeProxyAttribute_t970972087 * tmp = (DebuggerTypeProxyAttribute_t970972087 *)cache->attributes[1];
		DebuggerTypeProxyAttribute__ctor_m3082078467(tmp, il2cpp_codegen_type_get_object(CollectionDebuggerView_t1643796100_0_0_0_var), NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[2];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void SortedList_t3004938869_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t889804479 * tmp = (DefaultMemberAttribute_t889804479 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m2234856827(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
	{
		DebuggerDisplayAttribute_t1528914581 * tmp = (DebuggerDisplayAttribute_t1528914581 *)cache->attributes[1];
		DebuggerDisplayAttribute__ctor_m1420611550(tmp, il2cpp_codegen_string_new_wrapper("Count={Count}"), NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[2];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
extern const Il2CppType* CollectionDebuggerView_t1643796100_0_0_0_var;
extern const uint32_t Stack_t1043988394_CustomAttributesCacheGenerator_MetadataUsageId;
static void Stack_t1043988394_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Stack_t1043988394_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		DebuggerTypeProxyAttribute_t970972087 * tmp = (DebuggerTypeProxyAttribute_t970972087 *)cache->attributes[0];
		DebuggerTypeProxyAttribute__ctor_m3082078467(tmp, il2cpp_codegen_type_get_object(CollectionDebuggerView_t1643796100_0_0_0_var), NULL);
	}
	{
		DebuggerDisplayAttribute_t1528914581 * tmp = (DebuggerDisplayAttribute_t1528914581 *)cache->attributes[1];
		DebuggerDisplayAttribute__ctor_m1420611550(tmp, il2cpp_codegen_string_new_wrapper("Count={Count}"), NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[2];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void AssemblyHashAlgorithm_t4147282775_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void AssemblyVersionCompatibility_t1223556284_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void DebuggableAttribute_t994551506_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 3LL, NULL);
	}
}
static void DebuggingModes_t2073970606_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		FlagsAttribute_t859561169 * tmp = (FlagsAttribute_t859561169 *)cache->attributes[0];
		FlagsAttribute__ctor_m1848108622(tmp, NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void DebuggerBrowsableAttribute_t1386379234_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 384LL, NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void DebuggerBrowsableState_t944457511_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void DebuggerDisplayAttribute_t1528914581_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 4509LL, NULL);
		AttributeUsageAttribute_set_AllowMultiple_m683830749(tmp, true, NULL);
	}
}
static void DebuggerStepThroughAttribute_t518825354_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 108LL, NULL);
		AttributeUsageAttribute_set_Inherited_m4085818998(tmp, false, NULL);
	}
}
static void DebuggerTypeProxyAttribute_t970972087_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 13LL, NULL);
		AttributeUsageAttribute_set_AllowMultiple_m683830749(tmp, true, NULL);
	}
}
static void StackFrame_t2050294881_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		MonoTODOAttribute_t3487514019 * tmp = (MonoTODOAttribute_t3487514019 *)cache->attributes[1];
		MonoTODOAttribute__ctor_m1339517176(tmp, il2cpp_codegen_string_new_wrapper("Serialized objects are not compatible with MS.NET"), NULL);
	}
}
static void StackTrace_t2500644597_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		MonoTODOAttribute_t3487514019 * tmp = (MonoTODOAttribute_t3487514019 *)cache->attributes[1];
		MonoTODOAttribute__ctor_m1339517176(tmp, il2cpp_codegen_string_new_wrapper("Serialized objects are not compatible with .NET"), NULL);
	}
}
static void Calendar_t585061108_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void Calendar_t585061108_CustomAttributesCacheGenerator_Calendar_Clone_m3159430630(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, false, NULL);
	}
}
static void CompareInfo_t2310920157_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void CompareOptions_t2829943955_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		FlagsAttribute_t859561169 * tmp = (FlagsAttribute_t859561169 *)cache->attributes[1];
		FlagsAttribute__ctor_m1848108622(tmp, NULL);
	}
}
static void CultureInfo_t3500843524_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void CultureInfo_t3500843524_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map19(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void CultureInfo_t3500843524_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map1A(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void DateTimeFormatFlags_t3140910561_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		FlagsAttribute_t859561169 * tmp = (FlagsAttribute_t859561169 *)cache->attributes[0];
		FlagsAttribute__ctor_m1848108622(tmp, NULL);
	}
}
static void DateTimeFormatInfo_t2187473504_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void DateTimeStyles_t370343085_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		FlagsAttribute_t859561169 * tmp = (FlagsAttribute_t859561169 *)cache->attributes[1];
		FlagsAttribute__ctor_m1848108622(tmp, NULL);
	}
}
static void DaylightTime_t3800227331_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void GregorianCalendar_t3361245568_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		MonoTODOAttribute_t3487514019 * tmp = (MonoTODOAttribute_t3487514019 *)cache->attributes[1];
		MonoTODOAttribute__ctor_m1339517176(tmp, il2cpp_codegen_string_new_wrapper("Serialization format not compatible with .NET"), NULL);
	}
}
static void GregorianCalendarTypes_t3080789929_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void NumberFormatInfo_t104580544_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void NumberStyles_t3408984435_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		FlagsAttribute_t859561169 * tmp = (FlagsAttribute_t859561169 *)cache->attributes[1];
		FlagsAttribute__ctor_m1848108622(tmp, NULL);
	}
}
static void TextInfo_t3620182823_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		MonoTODOAttribute_t3487514019 * tmp = (MonoTODOAttribute_t3487514019 *)cache->attributes[1];
		MonoTODOAttribute__ctor_m1339517176(tmp, il2cpp_codegen_string_new_wrapper("IDeserializationCallback isn't implemented."), NULL);
	}
}
static void TextInfo_t3620182823_CustomAttributesCacheGenerator_TextInfo_System_Runtime_Serialization_IDeserializationCallback_OnDeserialization_m4238883895(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t3487514019 * tmp = (MonoTODOAttribute_t3487514019 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m1075768078(tmp, NULL);
	}
}
static void TextInfo_t3620182823_CustomAttributesCacheGenerator_TextInfo_Clone_m1096841305(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, false, NULL);
	}
}
static void TextInfo_t3620182823_CustomAttributesCacheGenerator_TextInfo_t3620182823____CultureName_PropertyInfo(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, false, NULL);
	}
}
static void UnicodeCategory_t682236799_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void IsolatedStorageException_t2011779685_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void BinaryReader_t2491843768_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void BinaryReader_t2491843768_CustomAttributesCacheGenerator_BinaryReader_ReadSByte_m1712621355(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void BinaryReader_t2491843768_CustomAttributesCacheGenerator_BinaryReader_ReadUInt16_m2664161107(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void BinaryReader_t2491843768_CustomAttributesCacheGenerator_BinaryReader_ReadUInt32_m1363572147(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void BinaryReader_t2491843768_CustomAttributesCacheGenerator_BinaryReader_ReadUInt64_m1893783375(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Directory_t3318511961_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void DirectoryInfo_t1934446453_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void DirectoryNotFoundException_t373523477_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void EndOfStreamException_t1711658693_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void File_t1930543328_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void FileAccess_t4282042064_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		FlagsAttribute_t859561169 * tmp = (FlagsAttribute_t859561169 *)cache->attributes[0];
		FlagsAttribute__ctor_m1848108622(tmp, NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void FileAttributes_t3843045335_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		FlagsAttribute_t859561169 * tmp = (FlagsAttribute_t859561169 *)cache->attributes[0];
		FlagsAttribute__ctor_m1848108622(tmp, NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void FileLoadException_t3198361301_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void FileMode_t236403845_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void FileNotFoundException_t4200667904_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void FileOptions_t3144759768_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		FlagsAttribute_t859561169 * tmp = (FlagsAttribute_t859561169 *)cache->attributes[0];
		FlagsAttribute__ctor_m1848108622(tmp, NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void FileShare_t3362491215_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		FlagsAttribute_t859561169 * tmp = (FlagsAttribute_t859561169 *)cache->attributes[0];
		FlagsAttribute__ctor_m1848108622(tmp, NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void FileStream_t1695958676_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void FileSystemInfo_t2360991899_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void FileSystemInfo_t2360991899_CustomAttributesCacheGenerator_FileSystemInfo_GetObjectData_m1755848054(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, false, NULL);
	}
}
static void IOException_t2458421087_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void MemoryStream_t743994179_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t3487514019 * tmp = (MonoTODOAttribute_t3487514019 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m1339517176(tmp, il2cpp_codegen_string_new_wrapper("Serialization format not compatible with .NET"), NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void Path_t41728875_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void Path_t41728875_CustomAttributesCacheGenerator_InvalidPathChars(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m2711473620(tmp, il2cpp_codegen_string_new_wrapper("see GetInvalidPathChars and GetInvalidFileNameChars methods."), NULL);
	}
}
static void PathTooLongException_t2469314706_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void SeekOrigin_t2475945306_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void Stream_t3255436806_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void StreamReader_t2360341767_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void StreamWriter_t3858580635_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void StringReader_t1480123486_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void TextReader_t1561828458_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void TextWriter_t4027217640_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void UnmanagedMemoryStream_t822875729_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
extern const Il2CppType* _AssemblyBuilder_t418776366_0_0_0_var;
extern const uint32_t AssemblyBuilder_t1646117627_CustomAttributesCacheGenerator_MetadataUsageId;
static void AssemblyBuilder_t1646117627_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AssemblyBuilder_t1646117627_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ComDefaultInterfaceAttribute_t347642415 * tmp = (ComDefaultInterfaceAttribute_t347642415 *)cache->attributes[0];
		ComDefaultInterfaceAttribute__ctor_m254275202(tmp, il2cpp_codegen_type_get_object(_AssemblyBuilder_t418776366_0_0_0_var), NULL);
	}
	{
		ClassInterfaceAttribute_t910653559 * tmp = (ClassInterfaceAttribute_t910653559 *)cache->attributes[1];
		ClassInterfaceAttribute__ctor_m177247154(tmp, 0LL, NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[2];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
extern const Il2CppType* _ConstructorBuilder_t1236878896_0_0_0_var;
extern const uint32_t ConstructorBuilder_t700974433_CustomAttributesCacheGenerator_MetadataUsageId;
static void ConstructorBuilder_t700974433_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ConstructorBuilder_t700974433_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		ComDefaultInterfaceAttribute_t347642415 * tmp = (ComDefaultInterfaceAttribute_t347642415 *)cache->attributes[1];
		ComDefaultInterfaceAttribute__ctor_m254275202(tmp, il2cpp_codegen_type_get_object(_ConstructorBuilder_t1236878896_0_0_0_var), NULL);
	}
	{
		ClassInterfaceAttribute_t910653559 * tmp = (ClassInterfaceAttribute_t910653559 *)cache->attributes[2];
		ClassInterfaceAttribute__ctor_m177247154(tmp, 0LL, NULL);
	}
}
static void ConstructorBuilder_t700974433_CustomAttributesCacheGenerator_ConstructorBuilder_t700974433____CallingConvention_PropertyInfo(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t3487514019 * tmp = (MonoTODOAttribute_t3487514019 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m1075768078(tmp, NULL);
	}
}
static void DerivedType_t1016359113_CustomAttributesCacheGenerator_DerivedType_MakeGenericType_m742223168____typeArguments0(CustomAttributesCache* cache)
{
	{
		ParamArrayAttribute_t2144993728 * tmp = (ParamArrayAttribute_t2144993728 *)cache->attributes[0];
		ParamArrayAttribute__ctor_m2215984741(tmp, NULL);
	}
}
extern const Il2CppType* _EnumBuilder_t1044146361_0_0_0_var;
extern const uint32_t EnumBuilder_t2808714468_CustomAttributesCacheGenerator_MetadataUsageId;
static void EnumBuilder_t2808714468_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (EnumBuilder_t2808714468_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		ComDefaultInterfaceAttribute_t347642415 * tmp = (ComDefaultInterfaceAttribute_t347642415 *)cache->attributes[1];
		ComDefaultInterfaceAttribute__ctor_m254275202(tmp, il2cpp_codegen_type_get_object(_EnumBuilder_t1044146361_0_0_0_var), NULL);
	}
	{
		ClassInterfaceAttribute_t910653559 * tmp = (ClassInterfaceAttribute_t910653559 *)cache->attributes[2];
		ClassInterfaceAttribute__ctor_m177247154(tmp, 0LL, NULL);
	}
}
static void EnumBuilder_t2808714468_CustomAttributesCacheGenerator_EnumBuilder_GetConstructors_m3240699827(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
extern const Il2CppType* _FieldBuilder_t1895266044_0_0_0_var;
extern const uint32_t FieldBuilder_t2784804005_CustomAttributesCacheGenerator_MetadataUsageId;
static void FieldBuilder_t2784804005_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (FieldBuilder_t2784804005_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		ComDefaultInterfaceAttribute_t347642415 * tmp = (ComDefaultInterfaceAttribute_t347642415 *)cache->attributes[1];
		ComDefaultInterfaceAttribute__ctor_m254275202(tmp, il2cpp_codegen_type_get_object(_FieldBuilder_t1895266044_0_0_0_var), NULL);
	}
	{
		ClassInterfaceAttribute_t910653559 * tmp = (ClassInterfaceAttribute_t910653559 *)cache->attributes[2];
		ClassInterfaceAttribute__ctor_m177247154(tmp, 0LL, NULL);
	}
}
static void GenericTypeParameterBuilder_t1370236603_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void GenericTypeParameterBuilder_t1370236603_CustomAttributesCacheGenerator_GenericTypeParameterBuilder_IsSubclassOf_m563999142(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void GenericTypeParameterBuilder_t1370236603_CustomAttributesCacheGenerator_GenericTypeParameterBuilder_GetConstructors_m103067670(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void GenericTypeParameterBuilder_t1370236603_CustomAttributesCacheGenerator_GenericTypeParameterBuilder_Equals_m2498927509(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t3487514019 * tmp = (MonoTODOAttribute_t3487514019 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m1075768078(tmp, NULL);
	}
}
static void GenericTypeParameterBuilder_t1370236603_CustomAttributesCacheGenerator_GenericTypeParameterBuilder_GetHashCode_m867619899(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t3487514019 * tmp = (MonoTODOAttribute_t3487514019 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m1075768078(tmp, NULL);
	}
}
static void GenericTypeParameterBuilder_t1370236603_CustomAttributesCacheGenerator_GenericTypeParameterBuilder_MakeGenericType_m2955814622(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t3487514019 * tmp = (MonoTODOAttribute_t3487514019 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m1075768078(tmp, NULL);
	}
}
static void GenericTypeParameterBuilder_t1370236603_CustomAttributesCacheGenerator_GenericTypeParameterBuilder_MakeGenericType_m2955814622____typeArguments0(CustomAttributesCache* cache)
{
	{
		ParamArrayAttribute_t2144993728 * tmp = (ParamArrayAttribute_t2144993728 *)cache->attributes[0];
		ParamArrayAttribute__ctor_m2215984741(tmp, NULL);
	}
}
extern const Il2CppType* _ILGenerator_t4199470953_0_0_0_var;
extern const uint32_t ILGenerator_t99948092_CustomAttributesCacheGenerator_MetadataUsageId;
static void ILGenerator_t99948092_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ILGenerator_t99948092_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ComDefaultInterfaceAttribute_t347642415 * tmp = (ComDefaultInterfaceAttribute_t347642415 *)cache->attributes[0];
		ComDefaultInterfaceAttribute__ctor_m254275202(tmp, il2cpp_codegen_type_get_object(_ILGenerator_t4199470953_0_0_0_var), NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		ClassInterfaceAttribute_t910653559 * tmp = (ClassInterfaceAttribute_t910653559 *)cache->attributes[2];
		ClassInterfaceAttribute__ctor_m177247154(tmp, 0LL, NULL);
	}
}
static void ILGenerator_t99948092_CustomAttributesCacheGenerator_ILGenerator_Emit_m116557729(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void ILGenerator_t99948092_CustomAttributesCacheGenerator_ILGenerator_Mono_GetCurrentOffset_m3553856682(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m2711473620(tmp, il2cpp_codegen_string_new_wrapper("Use ILOffset"), NULL);
	}
}
extern const Il2CppType* _MethodBuilder_t3932949077_0_0_0_var;
extern const uint32_t MethodBuilder_t644187984_CustomAttributesCacheGenerator_MetadataUsageId;
static void MethodBuilder_t644187984_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (MethodBuilder_t644187984_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ClassInterfaceAttribute_t910653559 * tmp = (ClassInterfaceAttribute_t910653559 *)cache->attributes[0];
		ClassInterfaceAttribute__ctor_m177247154(tmp, 0LL, NULL);
	}
	{
		ComDefaultInterfaceAttribute_t347642415 * tmp = (ComDefaultInterfaceAttribute_t347642415 *)cache->attributes[1];
		ComDefaultInterfaceAttribute__ctor_m254275202(tmp, il2cpp_codegen_type_get_object(_MethodBuilder_t3932949077_0_0_0_var), NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[2];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void MethodBuilder_t644187984_CustomAttributesCacheGenerator_MethodBuilder_Equals_m1205580640(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t3487514019 * tmp = (MonoTODOAttribute_t3487514019 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m1075768078(tmp, NULL);
	}
}
static void MethodBuilder_t644187984_CustomAttributesCacheGenerator_MethodBuilder_MakeGenericMethod_m303913412____typeArguments0(CustomAttributesCache* cache)
{
	{
		ParamArrayAttribute_t2144993728 * tmp = (ParamArrayAttribute_t2144993728 *)cache->attributes[0];
		ParamArrayAttribute__ctor_m2215984741(tmp, NULL);
	}
}
static void MethodToken_t3991686330_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
extern const Il2CppType* _ModuleBuilder_t1075102050_0_0_0_var;
extern const uint32_t ModuleBuilder_t4156028127_CustomAttributesCacheGenerator_MetadataUsageId;
static void ModuleBuilder_t4156028127_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ModuleBuilder_t4156028127_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ComDefaultInterfaceAttribute_t347642415 * tmp = (ComDefaultInterfaceAttribute_t347642415 *)cache->attributes[0];
		ComDefaultInterfaceAttribute__ctor_m254275202(tmp, il2cpp_codegen_type_get_object(_ModuleBuilder_t1075102050_0_0_0_var), NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		ClassInterfaceAttribute_t910653559 * tmp = (ClassInterfaceAttribute_t910653559 *)cache->attributes[2];
		ClassInterfaceAttribute__ctor_m177247154(tmp, 0LL, NULL);
	}
}
static void OpCode_t2247480392_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void OpCodes_t3494785031_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void OpCodes_t3494785031_CustomAttributesCacheGenerator_Castclass(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
extern const Il2CppType* _ParameterBuilder_t2251638747_0_0_0_var;
extern const uint32_t ParameterBuilder_t3344728474_CustomAttributesCacheGenerator_MetadataUsageId;
static void ParameterBuilder_t3344728474_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ParameterBuilder_t3344728474_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		ClassInterfaceAttribute_t910653559 * tmp = (ClassInterfaceAttribute_t910653559 *)cache->attributes[1];
		ClassInterfaceAttribute__ctor_m177247154(tmp, 0LL, NULL);
	}
	{
		ComDefaultInterfaceAttribute_t347642415 * tmp = (ComDefaultInterfaceAttribute_t347642415 *)cache->attributes[2];
		ComDefaultInterfaceAttribute__ctor_m254275202(tmp, il2cpp_codegen_type_get_object(_ParameterBuilder_t2251638747_0_0_0_var), NULL);
	}
}
static void StackBehaviour_t1390406961_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
extern const Il2CppType* _TypeBuilder_t2783404358_0_0_0_var;
extern const uint32_t TypeBuilder_t3308873219_CustomAttributesCacheGenerator_MetadataUsageId;
static void TypeBuilder_t3308873219_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (TypeBuilder_t3308873219_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ComDefaultInterfaceAttribute_t347642415 * tmp = (ComDefaultInterfaceAttribute_t347642415 *)cache->attributes[0];
		ComDefaultInterfaceAttribute__ctor_m254275202(tmp, il2cpp_codegen_type_get_object(_TypeBuilder_t2783404358_0_0_0_var), NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		ClassInterfaceAttribute_t910653559 * tmp = (ClassInterfaceAttribute_t910653559 *)cache->attributes[2];
		ClassInterfaceAttribute__ctor_m177247154(tmp, 0LL, NULL);
	}
}
static void TypeBuilder_t3308873219_CustomAttributesCacheGenerator_TypeBuilder_DefineConstructor_m3431248509(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void TypeBuilder_t3308873219_CustomAttributesCacheGenerator_TypeBuilder_DefineConstructor_m2972481149(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void TypeBuilder_t3308873219_CustomAttributesCacheGenerator_TypeBuilder_DefineDefaultConstructor_m2225828699(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void TypeBuilder_t3308873219_CustomAttributesCacheGenerator_TypeBuilder_GetConstructors_m774120094(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void TypeBuilder_t3308873219_CustomAttributesCacheGenerator_TypeBuilder_MakeGenericType_m4282022646(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t3487514019 * tmp = (MonoTODOAttribute_t3487514019 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m1075768078(tmp, NULL);
	}
}
static void TypeBuilder_t3308873219_CustomAttributesCacheGenerator_TypeBuilder_MakeGenericType_m4282022646____typeArguments0(CustomAttributesCache* cache)
{
	{
		ParamArrayAttribute_t2144993728 * tmp = (ParamArrayAttribute_t2144993728 *)cache->attributes[0];
		ParamArrayAttribute__ctor_m2215984741(tmp, NULL);
	}
}
static void TypeBuilder_t3308873219_CustomAttributesCacheGenerator_TypeBuilder_IsAssignableFrom_m212977480(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t3487514019 * tmp = (MonoTODOAttribute_t3487514019 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m1075768078(tmp, NULL);
	}
}
static void TypeBuilder_t3308873219_CustomAttributesCacheGenerator_TypeBuilder_IsSubclassOf_m428846622(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t3487514019 * tmp = (MonoTODOAttribute_t3487514019 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m1075768078(tmp, NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void TypeBuilder_t3308873219_CustomAttributesCacheGenerator_TypeBuilder_IsAssignableTo_m3210661829(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t3487514019 * tmp = (MonoTODOAttribute_t3487514019 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m1339517176(tmp, il2cpp_codegen_string_new_wrapper("arrays"), NULL);
	}
}
static void UnmanagedMarshal_t4270021860_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[1];
		ObsoleteAttribute__ctor_m2711473620(tmp, il2cpp_codegen_string_new_wrapper("An alternate API is available: Emit the MarshalAs custom attribute instead."), NULL);
	}
}
static void AmbiguousMatchException_t1406414556_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
extern const Il2CppType* _Assembly_t2937922309_0_0_0_var;
extern const uint32_t Assembly_t4268412390_CustomAttributesCacheGenerator_MetadataUsageId;
static void Assembly_t4268412390_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Assembly_t4268412390_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		ClassInterfaceAttribute_t910653559 * tmp = (ClassInterfaceAttribute_t910653559 *)cache->attributes[1];
		ClassInterfaceAttribute__ctor_m177247154(tmp, 0LL, NULL);
	}
	{
		ComDefaultInterfaceAttribute_t347642415 * tmp = (ComDefaultInterfaceAttribute_t347642415 *)cache->attributes[2];
		ComDefaultInterfaceAttribute__ctor_m254275202(tmp, il2cpp_codegen_type_get_object(_Assembly_t2937922309_0_0_0_var), NULL);
	}
}
static void Assembly_t4268412390_CustomAttributesCacheGenerator_Assembly_GetName_m3984565618(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t3487514019 * tmp = (MonoTODOAttribute_t3487514019 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m1339517176(tmp, il2cpp_codegen_string_new_wrapper("copiedName == true is not supported"), NULL);
	}
}
static void AssemblyCompanyAttribute_t2851673381_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 1LL, NULL);
		AttributeUsageAttribute_set_Inherited_m4085818998(tmp, false, NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void AssemblyConfigurationAttribute_t1678917172_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 1LL, NULL);
		AttributeUsageAttribute_set_Inherited_m4085818998(tmp, false, NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void AssemblyCopyrightAttribute_t177123295_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 1LL, NULL);
		AttributeUsageAttribute_set_Inherited_m4085818998(tmp, false, NULL);
	}
}
static void AssemblyDefaultAliasAttribute_t1774139159_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 1LL, NULL);
		AttributeUsageAttribute_set_Inherited_m4085818998(tmp, false, NULL);
	}
}
static void AssemblyDelaySignAttribute_t2705758496_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 1LL, NULL);
		AttributeUsageAttribute_set_Inherited_m4085818998(tmp, false, NULL);
	}
}
static void AssemblyDescriptionAttribute_t1018387888_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 1LL, NULL);
		AttributeUsageAttribute_set_Inherited_m4085818998(tmp, false, NULL);
	}
}
static void AssemblyFileVersionAttribute_t2897687916_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 1LL, NULL);
		AttributeUsageAttribute_set_Inherited_m4085818998(tmp, false, NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void AssemblyInformationalVersionAttribute_t3037389657_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 1LL, NULL);
		AttributeUsageAttribute_set_Inherited_m4085818998(tmp, false, NULL);
	}
}
static void AssemblyKeyFileAttribute_t605245443_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 1LL, NULL);
		AttributeUsageAttribute_set_Inherited_m4085818998(tmp, false, NULL);
	}
}
extern const Il2CppType* _AssemblyName_t582342236_0_0_0_var;
extern const uint32_t AssemblyName_t894705941_CustomAttributesCacheGenerator_MetadataUsageId;
static void AssemblyName_t894705941_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AssemblyName_t894705941_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ComDefaultInterfaceAttribute_t347642415 * tmp = (ComDefaultInterfaceAttribute_t347642415 *)cache->attributes[0];
		ComDefaultInterfaceAttribute__ctor_m254275202(tmp, il2cpp_codegen_type_get_object(_AssemblyName_t582342236_0_0_0_var), NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		ClassInterfaceAttribute_t910653559 * tmp = (ClassInterfaceAttribute_t910653559 *)cache->attributes[2];
		ClassInterfaceAttribute__ctor_m177247154(tmp, 0LL, NULL);
	}
}
static void AssemblyNameFlags_t1794031440_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		FlagsAttribute_t859561169 * tmp = (FlagsAttribute_t859561169 *)cache->attributes[1];
		FlagsAttribute__ctor_m1848108622(tmp, NULL);
	}
}
static void AssemblyProductAttribute_t1523443169_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 1LL, NULL);
		AttributeUsageAttribute_set_Inherited_m4085818998(tmp, false, NULL);
	}
}
static void AssemblyTitleAttribute_t92945912_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 1LL, NULL);
		AttributeUsageAttribute_set_Inherited_m4085818998(tmp, false, NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void AssemblyTrademarkAttribute_t3740556705_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 1LL, NULL);
		AttributeUsageAttribute_set_Inherited_m4085818998(tmp, false, NULL);
	}
}
static void Binder_t3404612058_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		ClassInterfaceAttribute_t910653559 * tmp = (ClassInterfaceAttribute_t910653559 *)cache->attributes[1];
		ClassInterfaceAttribute__ctor_m177247154(tmp, 2LL, NULL);
	}
}
static void Default_t3956931304_CustomAttributesCacheGenerator_Default_ReorderArgumentArray_m3980835731(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t3487514019 * tmp = (MonoTODOAttribute_t3487514019 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m1339517176(tmp, il2cpp_codegen_string_new_wrapper("This method does not do anything in Mono"), NULL);
	}
}
static void BindingFlags_t1082350898_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		FlagsAttribute_t859561169 * tmp = (FlagsAttribute_t859561169 *)cache->attributes[1];
		FlagsAttribute__ctor_m1848108622(tmp, NULL);
	}
}
static void CallingConventions_t1097349142_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		FlagsAttribute_t859561169 * tmp = (FlagsAttribute_t859561169 *)cache->attributes[0];
		FlagsAttribute__ctor_m1848108622(tmp, NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
extern const Il2CppType* _ConstructorInfo_t3269099341_0_0_0_var;
extern const uint32_t ConstructorInfo_t2851816542_CustomAttributesCacheGenerator_MetadataUsageId;
static void ConstructorInfo_t2851816542_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ConstructorInfo_t2851816542_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ClassInterfaceAttribute_t910653559 * tmp = (ClassInterfaceAttribute_t910653559 *)cache->attributes[0];
		ClassInterfaceAttribute__ctor_m177247154(tmp, 0LL, NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		ComDefaultInterfaceAttribute_t347642415 * tmp = (ComDefaultInterfaceAttribute_t347642415 *)cache->attributes[2];
		ComDefaultInterfaceAttribute__ctor_m254275202(tmp, il2cpp_codegen_type_get_object(_ConstructorInfo_t3269099341_0_0_0_var), NULL);
	}
}
static void ConstructorInfo_t2851816542_CustomAttributesCacheGenerator_ConstructorName(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void ConstructorInfo_t2851816542_CustomAttributesCacheGenerator_TypeConstructorName(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void ConstructorInfo_t2851816542_CustomAttributesCacheGenerator_ConstructorInfo_Invoke_m2144827141(CustomAttributesCache* cache)
{
	{
		DebuggerHiddenAttribute_t638884887 * tmp = (DebuggerHiddenAttribute_t638884887 *)cache->attributes[0];
		DebuggerHiddenAttribute__ctor_m2012788180(tmp, NULL);
	}
	{
		DebuggerStepThroughAttribute_t518825354 * tmp = (DebuggerStepThroughAttribute_t518825354 *)cache->attributes[1];
		DebuggerStepThroughAttribute__ctor_m3511084653(tmp, NULL);
	}
}
static void ConstructorInfo_t2851816542_CustomAttributesCacheGenerator_ConstructorInfo_t2851816542____MemberType_PropertyInfo(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void CustomAttributeData_t3093286891_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void CustomAttributeData_t3093286891_CustomAttributesCacheGenerator_CustomAttributeData_t3093286891____Constructor_PropertyInfo(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void CustomAttributeData_t3093286891_CustomAttributesCacheGenerator_CustomAttributeData_t3093286891____ConstructorArguments_PropertyInfo(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void CustomAttributeNamedArgument_t94157543_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void CustomAttributeTypedArgument_t1498197914_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void EventAttributes_t2989788983_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		FlagsAttribute_t859561169 * tmp = (FlagsAttribute_t859561169 *)cache->attributes[1];
		FlagsAttribute__ctor_m1848108622(tmp, NULL);
	}
}
extern const Il2CppType* _EventInfo_t2430923913_0_0_0_var;
extern const uint32_t EventInfo_t_CustomAttributesCacheGenerator_MetadataUsageId;
static void EventInfo_t_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (EventInfo_t_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ComDefaultInterfaceAttribute_t347642415 * tmp = (ComDefaultInterfaceAttribute_t347642415 *)cache->attributes[0];
		ComDefaultInterfaceAttribute__ctor_m254275202(tmp, il2cpp_codegen_type_get_object(_EventInfo_t2430923913_0_0_0_var), NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		ClassInterfaceAttribute_t910653559 * tmp = (ClassInterfaceAttribute_t910653559 *)cache->attributes[2];
		ClassInterfaceAttribute__ctor_m177247154(tmp, 0LL, NULL);
	}
}
static void FieldAttributes_t1122705193_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		FlagsAttribute_t859561169 * tmp = (FlagsAttribute_t859561169 *)cache->attributes[1];
		FlagsAttribute__ctor_m1848108622(tmp, NULL);
	}
}
extern const Il2CppType* _FieldInfo_t2511231167_0_0_0_var;
extern const uint32_t FieldInfo_t_CustomAttributesCacheGenerator_MetadataUsageId;
static void FieldInfo_t_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (FieldInfo_t_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		ComDefaultInterfaceAttribute_t347642415 * tmp = (ComDefaultInterfaceAttribute_t347642415 *)cache->attributes[1];
		ComDefaultInterfaceAttribute__ctor_m254275202(tmp, il2cpp_codegen_type_get_object(_FieldInfo_t2511231167_0_0_0_var), NULL);
	}
	{
		ClassInterfaceAttribute_t910653559 * tmp = (ClassInterfaceAttribute_t910653559 *)cache->attributes[2];
		ClassInterfaceAttribute__ctor_m177247154(tmp, 0LL, NULL);
	}
}
static void FieldInfo_t_CustomAttributesCacheGenerator_FieldInfo_SetValue_m2504255891(CustomAttributesCache* cache)
{
	{
		DebuggerHiddenAttribute_t638884887 * tmp = (DebuggerHiddenAttribute_t638884887 *)cache->attributes[0];
		DebuggerHiddenAttribute__ctor_m2012788180(tmp, NULL);
	}
	{
		DebuggerStepThroughAttribute_t518825354 * tmp = (DebuggerStepThroughAttribute_t518825354 *)cache->attributes[1];
		DebuggerStepThroughAttribute__ctor_m3511084653(tmp, NULL);
	}
}
static void MemberTypes_t3343038963_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		FlagsAttribute_t859561169 * tmp = (FlagsAttribute_t859561169 *)cache->attributes[0];
		FlagsAttribute__ctor_m1848108622(tmp, NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void MethodAttributes_t790385034_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		FlagsAttribute_t859561169 * tmp = (FlagsAttribute_t859561169 *)cache->attributes[0];
		FlagsAttribute__ctor_m1848108622(tmp, NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
extern const Il2CppType* _MethodBase_t1935530873_0_0_0_var;
extern const uint32_t MethodBase_t904190842_CustomAttributesCacheGenerator_MetadataUsageId;
static void MethodBase_t904190842_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (MethodBase_t904190842_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		ClassInterfaceAttribute_t910653559 * tmp = (ClassInterfaceAttribute_t910653559 *)cache->attributes[1];
		ClassInterfaceAttribute__ctor_m177247154(tmp, 0LL, NULL);
	}
	{
		ComDefaultInterfaceAttribute_t347642415 * tmp = (ComDefaultInterfaceAttribute_t347642415 *)cache->attributes[2];
		ComDefaultInterfaceAttribute__ctor_m254275202(tmp, il2cpp_codegen_type_get_object(_MethodBase_t1935530873_0_0_0_var), NULL);
	}
}
static void MethodBase_t904190842_CustomAttributesCacheGenerator_MethodBase_Invoke_m1075809207(CustomAttributesCache* cache)
{
	{
		DebuggerStepThroughAttribute_t518825354 * tmp = (DebuggerStepThroughAttribute_t518825354 *)cache->attributes[0];
		DebuggerStepThroughAttribute__ctor_m3511084653(tmp, NULL);
	}
	{
		DebuggerHiddenAttribute_t638884887 * tmp = (DebuggerHiddenAttribute_t638884887 *)cache->attributes[1];
		DebuggerHiddenAttribute__ctor_m2012788180(tmp, NULL);
	}
}
static void MethodBase_t904190842_CustomAttributesCacheGenerator_MethodBase_GetGenericArguments_m1277035033(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void MethodImplAttributes_t1541361196_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
extern const Il2CppType* _MethodInfo_t3642518830_0_0_0_var;
extern const uint32_t MethodInfo_t_CustomAttributesCacheGenerator_MetadataUsageId;
static void MethodInfo_t_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (MethodInfo_t_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ClassInterfaceAttribute_t910653559 * tmp = (ClassInterfaceAttribute_t910653559 *)cache->attributes[0];
		ClassInterfaceAttribute__ctor_m177247154(tmp, 0LL, NULL);
	}
	{
		ComDefaultInterfaceAttribute_t347642415 * tmp = (ComDefaultInterfaceAttribute_t347642415 *)cache->attributes[1];
		ComDefaultInterfaceAttribute__ctor_m254275202(tmp, il2cpp_codegen_type_get_object(_MethodInfo_t3642518830_0_0_0_var), NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[2];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void MethodInfo_t_CustomAttributesCacheGenerator_MethodInfo_MakeGenericMethod_m3327556920____typeArguments0(CustomAttributesCache* cache)
{
	{
		ParamArrayAttribute_t2144993728 * tmp = (ParamArrayAttribute_t2144993728 *)cache->attributes[0];
		ParamArrayAttribute__ctor_m2215984741(tmp, NULL);
	}
}
static void MethodInfo_t_CustomAttributesCacheGenerator_MethodInfo_GetGenericArguments_m3393347888(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void Missing_t1033855606_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void Missing_t1033855606_CustomAttributesCacheGenerator_Missing_System_Runtime_Serialization_ISerializable_GetObjectData_m3092937593(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t3487514019 * tmp = (MonoTODOAttribute_t3487514019 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m1075768078(tmp, NULL);
	}
}
extern const Il2CppType* _Module_t2144668161_0_0_0_var;
extern const uint32_t Module_t4282841206_CustomAttributesCacheGenerator_MetadataUsageId;
static void Module_t4282841206_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Module_t4282841206_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ClassInterfaceAttribute_t910653559 * tmp = (ClassInterfaceAttribute_t910653559 *)cache->attributes[0];
		ClassInterfaceAttribute__ctor_m177247154(tmp, 0LL, NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		ComDefaultInterfaceAttribute_t347642415 * tmp = (ComDefaultInterfaceAttribute_t347642415 *)cache->attributes[2];
		ComDefaultInterfaceAttribute__ctor_m254275202(tmp, il2cpp_codegen_type_get_object(_Module_t2144668161_0_0_0_var), NULL);
	}
}
static void PInfo_t957350482_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		FlagsAttribute_t859561169 * tmp = (FlagsAttribute_t859561169 *)cache->attributes[0];
		FlagsAttribute__ctor_m1848108622(tmp, NULL);
	}
}
static void ParameterAttributes_t1266705348_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		FlagsAttribute_t859561169 * tmp = (FlagsAttribute_t859561169 *)cache->attributes[0];
		FlagsAttribute__ctor_m1848108622(tmp, NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
extern const Il2CppType* _ParameterInfo_t470209990_0_0_0_var;
extern const uint32_t ParameterInfo_t2249040075_CustomAttributesCacheGenerator_MetadataUsageId;
static void ParameterInfo_t2249040075_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ParameterInfo_t2249040075_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ClassInterfaceAttribute_t910653559 * tmp = (ClassInterfaceAttribute_t910653559 *)cache->attributes[0];
		ClassInterfaceAttribute__ctor_m177247154(tmp, 0LL, NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		ComDefaultInterfaceAttribute_t347642415 * tmp = (ComDefaultInterfaceAttribute_t347642415 *)cache->attributes[2];
		ComDefaultInterfaceAttribute__ctor_m254275202(tmp, il2cpp_codegen_type_get_object(_ParameterInfo_t470209990_0_0_0_var), NULL);
	}
}
static void ParameterModifier_t1820634920_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		DefaultMemberAttribute_t889804479 * tmp = (DefaultMemberAttribute_t889804479 *)cache->attributes[1];
		DefaultMemberAttribute__ctor_m2234856827(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void Pointer_t937075087_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void ProcessorArchitecture_t1620065459_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void PropertyAttributes_t883448530_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		FlagsAttribute_t859561169 * tmp = (FlagsAttribute_t859561169 *)cache->attributes[1];
		FlagsAttribute__ctor_m1848108622(tmp, NULL);
	}
}
extern const Il2CppType* _PropertyInfo_t1567586598_0_0_0_var;
extern const uint32_t PropertyInfo_t_CustomAttributesCacheGenerator_MetadataUsageId;
static void PropertyInfo_t_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (PropertyInfo_t_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ComDefaultInterfaceAttribute_t347642415 * tmp = (ComDefaultInterfaceAttribute_t347642415 *)cache->attributes[0];
		ComDefaultInterfaceAttribute__ctor_m254275202(tmp, il2cpp_codegen_type_get_object(_PropertyInfo_t1567586598_0_0_0_var), NULL);
	}
	{
		ClassInterfaceAttribute_t910653559 * tmp = (ClassInterfaceAttribute_t910653559 *)cache->attributes[1];
		ClassInterfaceAttribute__ctor_m177247154(tmp, 0LL, NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[2];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void PropertyInfo_t_CustomAttributesCacheGenerator_PropertyInfo_GetValue_m3655964945(CustomAttributesCache* cache)
{
	{
		DebuggerHiddenAttribute_t638884887 * tmp = (DebuggerHiddenAttribute_t638884887 *)cache->attributes[0];
		DebuggerHiddenAttribute__ctor_m2012788180(tmp, NULL);
	}
	{
		DebuggerStepThroughAttribute_t518825354 * tmp = (DebuggerStepThroughAttribute_t518825354 *)cache->attributes[1];
		DebuggerStepThroughAttribute__ctor_m3511084653(tmp, NULL);
	}
}
static void PropertyInfo_t_CustomAttributesCacheGenerator_PropertyInfo_SetValue_m2961483868(CustomAttributesCache* cache)
{
	{
		DebuggerStepThroughAttribute_t518825354 * tmp = (DebuggerStepThroughAttribute_t518825354 *)cache->attributes[0];
		DebuggerStepThroughAttribute__ctor_m3511084653(tmp, NULL);
	}
	{
		DebuggerHiddenAttribute_t638884887 * tmp = (DebuggerHiddenAttribute_t638884887 *)cache->attributes[1];
		DebuggerHiddenAttribute__ctor_m2012788180(tmp, NULL);
	}
}
static void StrongNameKeyPair_t4090869089_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void TargetException_t1572104820_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void TargetInvocationException_t4098620458_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void TargetParameterCountException_t1554451430_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void TypeAttributes_t2229518203_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		FlagsAttribute_t859561169 * tmp = (FlagsAttribute_t859561169 *)cache->attributes[0];
		FlagsAttribute__ctor_m1848108622(tmp, NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void IResourceReader_t3222588482_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void NeutralResourcesLanguageAttribute_t3267676636_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 1LL, NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void ResourceManager_t264715885_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void ResourceReader_t2463923611_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void ResourceSet_t1348327650_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void ResourceSet_t1348327650_CustomAttributesCacheGenerator_ResourceSet_GetEnumerator_m1363893992(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, false, NULL);
	}
}
static void SatelliteContractVersionAttribute_t2989984391_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 1LL, NULL);
	}
}
static void CompilationRelaxations_t4211964247_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		FlagsAttribute_t859561169 * tmp = (FlagsAttribute_t859561169 *)cache->attributes[0];
		FlagsAttribute__ctor_m1848108622(tmp, NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void CompilationRelaxationsAttribute_t238494011_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 71LL, NULL);
	}
}
static void DefaultDependencyAttribute_t3858269114_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 1LL, NULL);
	}
}
static void IsVolatile_t700755342_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void StringFreezingAttribute_t2691375565_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 1LL, NULL);
		AttributeUsageAttribute_set_Inherited_m4085818998(tmp, false, NULL);
	}
}
static void CriticalFinalizerObject_t1920899984_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void CriticalFinalizerObject_t1920899984_CustomAttributesCacheGenerator_CriticalFinalizerObject__ctor_m229488711(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 3LL, 1LL, NULL);
	}
}
static void CriticalFinalizerObject_t1920899984_CustomAttributesCacheGenerator_CriticalFinalizerObject_Finalize_m2361345429(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 3LL, 2LL, NULL);
	}
}
static void ReliabilityContractAttribute_t1625655220_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 1133LL, NULL);
		AttributeUsageAttribute_set_Inherited_m4085818998(tmp, false, NULL);
	}
}
static void ActivationArguments_t640021366_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void COMException_t1790481504_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void CallingConvention_t3354538265_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void CharSet_t2778376310_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void ClassInterfaceAttribute_t910653559_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 5LL, NULL);
		AttributeUsageAttribute_set_Inherited_m4085818998(tmp, false, NULL);
	}
}
static void ClassInterfaceType_t295178211_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void ComDefaultInterfaceAttribute_t347642415_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 4LL, NULL);
		AttributeUsageAttribute_set_Inherited_m4085818998(tmp, false, NULL);
	}
}
static void ComInterfaceType_t1898221498_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void DispIdAttribute_t607560947_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 960LL, NULL);
		AttributeUsageAttribute_set_Inherited_m4085818998(tmp, false, NULL);
	}
}
static void ErrorWrapper_t2775489663_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void ExternalException_t1252662682_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void GCHandle_t3409268066_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		MonoTODOAttribute_t3487514019 * tmp = (MonoTODOAttribute_t3487514019 *)cache->attributes[1];
		MonoTODOAttribute__ctor_m1339517176(tmp, il2cpp_codegen_string_new_wrapper("Struct should be [StructLayout(LayoutKind.Sequential)] but will need to be reordered for that."), NULL);
	}
}
static void GCHandleType_t1970708122_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void InterfaceTypeAttribute_t4113096249_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 1024LL, NULL);
		AttributeUsageAttribute_set_Inherited_m4085818998(tmp, false, NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void Marshal_t785896760_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		SuppressUnmanagedCodeSecurityAttribute_t39244474 * tmp = (SuppressUnmanagedCodeSecurityAttribute_t39244474 *)cache->attributes[0];
		SuppressUnmanagedCodeSecurityAttribute__ctor_m1596284123(tmp, NULL);
	}
}
static void Marshal_t785896760_CustomAttributesCacheGenerator_Marshal_GetLastWin32Error_m4162683157(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 3LL, 2LL, NULL);
	}
}
static void MarshalDirectiveException_t1326890414_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void PreserveSigAttribute_t1564965109_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 64LL, NULL);
		AttributeUsageAttribute_set_Inherited_m4085818998(tmp, false, NULL);
	}
}
static void SafeHandle_t2733794115_CustomAttributesCacheGenerator_SafeHandle__ctor_m1890452380(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 3LL, 1LL, NULL);
	}
}
static void SafeHandle_t2733794115_CustomAttributesCacheGenerator_SafeHandle_Close_m1146946803(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 3LL, 2LL, NULL);
	}
}
static void SafeHandle_t2733794115_CustomAttributesCacheGenerator_SafeHandle_DangerousAddRef_m3138941540(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 3LL, 1LL, NULL);
	}
}
static void SafeHandle_t2733794115_CustomAttributesCacheGenerator_SafeHandle_DangerousGetHandle_m1328172664(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 3LL, 2LL, NULL);
	}
}
static void SafeHandle_t2733794115_CustomAttributesCacheGenerator_SafeHandle_DangerousRelease_m2167699172(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 3LL, 2LL, NULL);
	}
}
static void SafeHandle_t2733794115_CustomAttributesCacheGenerator_SafeHandle_Dispose_m1233016688(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 3LL, 2LL, NULL);
	}
}
static void SafeHandle_t2733794115_CustomAttributesCacheGenerator_SafeHandle_Dispose_m3871883741(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 3LL, 2LL, NULL);
	}
}
static void SafeHandle_t2733794115_CustomAttributesCacheGenerator_SafeHandle_ReleaseHandle_m1505220038(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 3LL, 2LL, NULL);
	}
}
static void SafeHandle_t2733794115_CustomAttributesCacheGenerator_SafeHandle_SetHandle_m1980208835(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 3LL, 2LL, NULL);
	}
}
static void SafeHandle_t2733794115_CustomAttributesCacheGenerator_SafeHandle_get_IsInvalid_m3910183075(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 3LL, 2LL, NULL);
	}
}
static void TypeLibImportClassAttribute_t2390314680_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 1024LL, NULL);
		AttributeUsageAttribute_set_Inherited_m4085818998(tmp, false, NULL);
	}
}
static void TypeLibVersionAttribute_t3346496961_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 1LL, NULL);
		AttributeUsageAttribute_set_AllowMultiple_m683830749(tmp, false, NULL);
		AttributeUsageAttribute_set_Inherited_m4085818998(tmp, false, NULL);
	}
}
static void UnmanagedType_t2550630890_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
extern const Il2CppType* Activator_t1850728717_0_0_0_var;
extern const uint32_t _Activator_t3825585294_CustomAttributesCacheGenerator_MetadataUsageId;
static void _Activator_t3825585294_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (_Activator_t3825585294_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		GuidAttribute_t222072359 * tmp = (GuidAttribute_t222072359 *)cache->attributes[1];
		GuidAttribute__ctor_m1099153635(tmp, il2cpp_codegen_string_new_wrapper("03973551-57A1-3900-A2B5-9083E3FF2943"), NULL);
	}
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[2];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
	{
		TypeLibImportClassAttribute_t2390314680 * tmp = (TypeLibImportClassAttribute_t2390314680 *)cache->attributes[3];
		TypeLibImportClassAttribute__ctor_m658319193(tmp, il2cpp_codegen_type_get_object(Activator_t1850728717_0_0_0_var), NULL);
	}
	{
		InterfaceTypeAttribute_t4113096249 * tmp = (InterfaceTypeAttribute_t4113096249 *)cache->attributes[4];
		InterfaceTypeAttribute__ctor_m1747686341(tmp, 1LL, NULL);
	}
}
extern const Il2CppType* Assembly_t4268412390_0_0_0_var;
extern const uint32_t _Assembly_t2937922309_CustomAttributesCacheGenerator_MetadataUsageId;
static void _Assembly_t2937922309_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (_Assembly_t2937922309_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		GuidAttribute_t222072359 * tmp = (GuidAttribute_t222072359 *)cache->attributes[0];
		GuidAttribute__ctor_m1099153635(tmp, il2cpp_codegen_string_new_wrapper("17156360-2F1A-384A-BC52-FDE93C215C5B"), NULL);
	}
	{
		InterfaceTypeAttribute_t4113096249 * tmp = (InterfaceTypeAttribute_t4113096249 *)cache->attributes[1];
		InterfaceTypeAttribute__ctor_m1747686341(tmp, 0LL, NULL);
	}
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[2];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[3];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		TypeLibImportClassAttribute_t2390314680 * tmp = (TypeLibImportClassAttribute_t2390314680 *)cache->attributes[4];
		TypeLibImportClassAttribute__ctor_m658319193(tmp, il2cpp_codegen_type_get_object(Assembly_t4268412390_0_0_0_var), NULL);
	}
}
extern const Il2CppType* AssemblyBuilder_t1646117627_0_0_0_var;
extern const uint32_t _AssemblyBuilder_t418776366_CustomAttributesCacheGenerator_MetadataUsageId;
static void _AssemblyBuilder_t418776366_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (_AssemblyBuilder_t418776366_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		GuidAttribute_t222072359 * tmp = (GuidAttribute_t222072359 *)cache->attributes[0];
		GuidAttribute__ctor_m1099153635(tmp, il2cpp_codegen_string_new_wrapper("BEBB2505-8B54-3443-AEAD-142A16DD9CC7"), NULL);
	}
	{
		InterfaceTypeAttribute_t4113096249 * tmp = (InterfaceTypeAttribute_t4113096249 *)cache->attributes[1];
		InterfaceTypeAttribute__ctor_m1747686341(tmp, 1LL, NULL);
	}
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[2];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[3];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		TypeLibImportClassAttribute_t2390314680 * tmp = (TypeLibImportClassAttribute_t2390314680 *)cache->attributes[4];
		TypeLibImportClassAttribute__ctor_m658319193(tmp, il2cpp_codegen_type_get_object(AssemblyBuilder_t1646117627_0_0_0_var), NULL);
	}
}
extern const Il2CppType* AssemblyName_t894705941_0_0_0_var;
extern const uint32_t _AssemblyName_t582342236_CustomAttributesCacheGenerator_MetadataUsageId;
static void _AssemblyName_t582342236_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (_AssemblyName_t582342236_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		GuidAttribute_t222072359 * tmp = (GuidAttribute_t222072359 *)cache->attributes[0];
		GuidAttribute__ctor_m1099153635(tmp, il2cpp_codegen_string_new_wrapper("B42B6AAC-317E-34D5-9FA9-093BB4160C50"), NULL);
	}
	{
		InterfaceTypeAttribute_t4113096249 * tmp = (InterfaceTypeAttribute_t4113096249 *)cache->attributes[1];
		InterfaceTypeAttribute__ctor_m1747686341(tmp, 1LL, NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[2];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[3];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
	{
		TypeLibImportClassAttribute_t2390314680 * tmp = (TypeLibImportClassAttribute_t2390314680 *)cache->attributes[4];
		TypeLibImportClassAttribute__ctor_m658319193(tmp, il2cpp_codegen_type_get_object(AssemblyName_t894705941_0_0_0_var), NULL);
	}
}
extern const Il2CppType* ConstructorBuilder_t700974433_0_0_0_var;
extern const uint32_t _ConstructorBuilder_t1236878896_CustomAttributesCacheGenerator_MetadataUsageId;
static void _ConstructorBuilder_t1236878896_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (_ConstructorBuilder_t1236878896_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		InterfaceTypeAttribute_t4113096249 * tmp = (InterfaceTypeAttribute_t4113096249 *)cache->attributes[0];
		InterfaceTypeAttribute__ctor_m1747686341(tmp, 1LL, NULL);
	}
	{
		GuidAttribute_t222072359 * tmp = (GuidAttribute_t222072359 *)cache->attributes[1];
		GuidAttribute__ctor_m1099153635(tmp, il2cpp_codegen_string_new_wrapper("ED3E4384-D7E2-3FA7-8FFD-8940D330519A"), NULL);
	}
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[2];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[3];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		TypeLibImportClassAttribute_t2390314680 * tmp = (TypeLibImportClassAttribute_t2390314680 *)cache->attributes[4];
		TypeLibImportClassAttribute__ctor_m658319193(tmp, il2cpp_codegen_type_get_object(ConstructorBuilder_t700974433_0_0_0_var), NULL);
	}
}
extern const Il2CppType* ConstructorInfo_t2851816542_0_0_0_var;
extern const uint32_t _ConstructorInfo_t3269099341_CustomAttributesCacheGenerator_MetadataUsageId;
static void _ConstructorInfo_t3269099341_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (_ConstructorInfo_t3269099341_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		TypeLibImportClassAttribute_t2390314680 * tmp = (TypeLibImportClassAttribute_t2390314680 *)cache->attributes[0];
		TypeLibImportClassAttribute__ctor_m658319193(tmp, il2cpp_codegen_type_get_object(ConstructorInfo_t2851816542_0_0_0_var), NULL);
	}
	{
		InterfaceTypeAttribute_t4113096249 * tmp = (InterfaceTypeAttribute_t4113096249 *)cache->attributes[1];
		InterfaceTypeAttribute__ctor_m1747686341(tmp, 1LL, NULL);
	}
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[2];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[3];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		GuidAttribute_t222072359 * tmp = (GuidAttribute_t222072359 *)cache->attributes[4];
		GuidAttribute__ctor_m1099153635(tmp, il2cpp_codegen_string_new_wrapper("E9A19478-9646-3679-9B10-8411AE1FD57D"), NULL);
	}
}
extern const Il2CppType* EnumBuilder_t2808714468_0_0_0_var;
extern const uint32_t _EnumBuilder_t1044146361_CustomAttributesCacheGenerator_MetadataUsageId;
static void _EnumBuilder_t1044146361_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (_EnumBuilder_t1044146361_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		InterfaceTypeAttribute_t4113096249 * tmp = (InterfaceTypeAttribute_t4113096249 *)cache->attributes[1];
		InterfaceTypeAttribute__ctor_m1747686341(tmp, 1LL, NULL);
	}
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[2];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
	{
		TypeLibImportClassAttribute_t2390314680 * tmp = (TypeLibImportClassAttribute_t2390314680 *)cache->attributes[3];
		TypeLibImportClassAttribute__ctor_m658319193(tmp, il2cpp_codegen_type_get_object(EnumBuilder_t2808714468_0_0_0_var), NULL);
	}
	{
		GuidAttribute_t222072359 * tmp = (GuidAttribute_t222072359 *)cache->attributes[4];
		GuidAttribute__ctor_m1099153635(tmp, il2cpp_codegen_string_new_wrapper("C7BD73DE-9F85-3290-88EE-090B8BDFE2DF"), NULL);
	}
}
extern const Il2CppType* EventInfo_t_0_0_0_var;
extern const uint32_t _EventInfo_t2430923913_CustomAttributesCacheGenerator_MetadataUsageId;
static void _EventInfo_t2430923913_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (_EventInfo_t2430923913_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		InterfaceTypeAttribute_t4113096249 * tmp = (InterfaceTypeAttribute_t4113096249 *)cache->attributes[1];
		InterfaceTypeAttribute__ctor_m1747686341(tmp, 1LL, NULL);
	}
	{
		GuidAttribute_t222072359 * tmp = (GuidAttribute_t222072359 *)cache->attributes[2];
		GuidAttribute__ctor_m1099153635(tmp, il2cpp_codegen_string_new_wrapper("9DE59C64-D889-35A1-B897-587D74469E5B"), NULL);
	}
	{
		TypeLibImportClassAttribute_t2390314680 * tmp = (TypeLibImportClassAttribute_t2390314680 *)cache->attributes[3];
		TypeLibImportClassAttribute__ctor_m658319193(tmp, il2cpp_codegen_type_get_object(EventInfo_t_0_0_0_var), NULL);
	}
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[4];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
extern const Il2CppType* FieldBuilder_t2784804005_0_0_0_var;
extern const uint32_t _FieldBuilder_t1895266044_CustomAttributesCacheGenerator_MetadataUsageId;
static void _FieldBuilder_t1895266044_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (_FieldBuilder_t1895266044_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		TypeLibImportClassAttribute_t2390314680 * tmp = (TypeLibImportClassAttribute_t2390314680 *)cache->attributes[1];
		TypeLibImportClassAttribute__ctor_m658319193(tmp, il2cpp_codegen_type_get_object(FieldBuilder_t2784804005_0_0_0_var), NULL);
	}
	{
		GuidAttribute_t222072359 * tmp = (GuidAttribute_t222072359 *)cache->attributes[2];
		GuidAttribute__ctor_m1099153635(tmp, il2cpp_codegen_string_new_wrapper("CE1A3BF5-975E-30CC-97C9-1EF70F8F3993"), NULL);
	}
	{
		InterfaceTypeAttribute_t4113096249 * tmp = (InterfaceTypeAttribute_t4113096249 *)cache->attributes[3];
		InterfaceTypeAttribute__ctor_m1747686341(tmp, 1LL, NULL);
	}
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[4];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
extern const Il2CppType* FieldInfo_t_0_0_0_var;
extern const uint32_t _FieldInfo_t2511231167_CustomAttributesCacheGenerator_MetadataUsageId;
static void _FieldInfo_t2511231167_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (_FieldInfo_t2511231167_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		InterfaceTypeAttribute_t4113096249 * tmp = (InterfaceTypeAttribute_t4113096249 *)cache->attributes[0];
		InterfaceTypeAttribute__ctor_m1747686341(tmp, 1LL, NULL);
	}
	{
		TypeLibImportClassAttribute_t2390314680 * tmp = (TypeLibImportClassAttribute_t2390314680 *)cache->attributes[1];
		TypeLibImportClassAttribute__ctor_m658319193(tmp, il2cpp_codegen_type_get_object(FieldInfo_t_0_0_0_var), NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[2];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		GuidAttribute_t222072359 * tmp = (GuidAttribute_t222072359 *)cache->attributes[3];
		GuidAttribute__ctor_m1099153635(tmp, il2cpp_codegen_string_new_wrapper("8A7C1442-A9FB-366B-80D8-4939FFA6DBE0"), NULL);
	}
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[4];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
extern const Il2CppType* ILGenerator_t99948092_0_0_0_var;
extern const uint32_t _ILGenerator_t4199470953_CustomAttributesCacheGenerator_MetadataUsageId;
static void _ILGenerator_t4199470953_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (_ILGenerator_t4199470953_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
	{
		InterfaceTypeAttribute_t4113096249 * tmp = (InterfaceTypeAttribute_t4113096249 *)cache->attributes[1];
		InterfaceTypeAttribute__ctor_m1747686341(tmp, 1LL, NULL);
	}
	{
		GuidAttribute_t222072359 * tmp = (GuidAttribute_t222072359 *)cache->attributes[2];
		GuidAttribute__ctor_m1099153635(tmp, il2cpp_codegen_string_new_wrapper("A4924B27-6E3B-37F7-9B83-A4501955E6A7"), NULL);
	}
	{
		TypeLibImportClassAttribute_t2390314680 * tmp = (TypeLibImportClassAttribute_t2390314680 *)cache->attributes[3];
		TypeLibImportClassAttribute__ctor_m658319193(tmp, il2cpp_codegen_type_get_object(ILGenerator_t99948092_0_0_0_var), NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[4];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
extern const Il2CppType* MethodBase_t904190842_0_0_0_var;
extern const uint32_t _MethodBase_t1935530873_CustomAttributesCacheGenerator_MetadataUsageId;
static void _MethodBase_t1935530873_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (_MethodBase_t1935530873_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		InterfaceTypeAttribute_t4113096249 * tmp = (InterfaceTypeAttribute_t4113096249 *)cache->attributes[0];
		InterfaceTypeAttribute__ctor_m1747686341(tmp, 1LL, NULL);
	}
	{
		GuidAttribute_t222072359 * tmp = (GuidAttribute_t222072359 *)cache->attributes[1];
		GuidAttribute__ctor_m1099153635(tmp, il2cpp_codegen_string_new_wrapper("6240837A-707F-3181-8E98-A36AE086766B"), NULL);
	}
	{
		TypeLibImportClassAttribute_t2390314680 * tmp = (TypeLibImportClassAttribute_t2390314680 *)cache->attributes[2];
		TypeLibImportClassAttribute__ctor_m658319193(tmp, il2cpp_codegen_type_get_object(MethodBase_t904190842_0_0_0_var), NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[3];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[4];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
extern const Il2CppType* MethodBuilder_t644187984_0_0_0_var;
extern const uint32_t _MethodBuilder_t3932949077_CustomAttributesCacheGenerator_MetadataUsageId;
static void _MethodBuilder_t3932949077_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (_MethodBuilder_t3932949077_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		GuidAttribute_t222072359 * tmp = (GuidAttribute_t222072359 *)cache->attributes[0];
		GuidAttribute__ctor_m1099153635(tmp, il2cpp_codegen_string_new_wrapper("007D8A14-FDF3-363E-9A0B-FEC0618260A2"), NULL);
	}
	{
		TypeLibImportClassAttribute_t2390314680 * tmp = (TypeLibImportClassAttribute_t2390314680 *)cache->attributes[1];
		TypeLibImportClassAttribute__ctor_m658319193(tmp, il2cpp_codegen_type_get_object(MethodBuilder_t644187984_0_0_0_var), NULL);
	}
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[2];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[3];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		InterfaceTypeAttribute_t4113096249 * tmp = (InterfaceTypeAttribute_t4113096249 *)cache->attributes[4];
		InterfaceTypeAttribute__ctor_m1747686341(tmp, 1LL, NULL);
	}
}
extern const Il2CppType* MethodInfo_t_0_0_0_var;
extern const uint32_t _MethodInfo_t3642518830_CustomAttributesCacheGenerator_MetadataUsageId;
static void _MethodInfo_t3642518830_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (_MethodInfo_t3642518830_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		GuidAttribute_t222072359 * tmp = (GuidAttribute_t222072359 *)cache->attributes[0];
		GuidAttribute__ctor_m1099153635(tmp, il2cpp_codegen_string_new_wrapper("FFCC1B5D-ECB8-38DD-9B01-3DC8ABC2AA5F"), NULL);
	}
	{
		TypeLibImportClassAttribute_t2390314680 * tmp = (TypeLibImportClassAttribute_t2390314680 *)cache->attributes[1];
		TypeLibImportClassAttribute__ctor_m658319193(tmp, il2cpp_codegen_type_get_object(MethodInfo_t_0_0_0_var), NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[2];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[3];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
	{
		InterfaceTypeAttribute_t4113096249 * tmp = (InterfaceTypeAttribute_t4113096249 *)cache->attributes[4];
		InterfaceTypeAttribute__ctor_m1747686341(tmp, 1LL, NULL);
	}
}
extern const Il2CppType* Module_t4282841206_0_0_0_var;
extern const uint32_t _Module_t2144668161_CustomAttributesCacheGenerator_MetadataUsageId;
static void _Module_t2144668161_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (_Module_t2144668161_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		InterfaceTypeAttribute_t4113096249 * tmp = (InterfaceTypeAttribute_t4113096249 *)cache->attributes[0];
		InterfaceTypeAttribute__ctor_m1747686341(tmp, 1LL, NULL);
	}
	{
		GuidAttribute_t222072359 * tmp = (GuidAttribute_t222072359 *)cache->attributes[1];
		GuidAttribute__ctor_m1099153635(tmp, il2cpp_codegen_string_new_wrapper("D002E9BA-D9E3-3749-B1D3-D565A08B13E7"), NULL);
	}
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[2];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
	{
		TypeLibImportClassAttribute_t2390314680 * tmp = (TypeLibImportClassAttribute_t2390314680 *)cache->attributes[3];
		TypeLibImportClassAttribute__ctor_m658319193(tmp, il2cpp_codegen_type_get_object(Module_t4282841206_0_0_0_var), NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[4];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
extern const Il2CppType* ModuleBuilder_t4156028127_0_0_0_var;
extern const uint32_t _ModuleBuilder_t1075102050_CustomAttributesCacheGenerator_MetadataUsageId;
static void _ModuleBuilder_t1075102050_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (_ModuleBuilder_t1075102050_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		GuidAttribute_t222072359 * tmp = (GuidAttribute_t222072359 *)cache->attributes[0];
		GuidAttribute__ctor_m1099153635(tmp, il2cpp_codegen_string_new_wrapper("D05FFA9A-04AF-3519-8EE1-8D93AD73430B"), NULL);
	}
	{
		TypeLibImportClassAttribute_t2390314680 * tmp = (TypeLibImportClassAttribute_t2390314680 *)cache->attributes[1];
		TypeLibImportClassAttribute__ctor_m658319193(tmp, il2cpp_codegen_type_get_object(ModuleBuilder_t4156028127_0_0_0_var), NULL);
	}
	{
		InterfaceTypeAttribute_t4113096249 * tmp = (InterfaceTypeAttribute_t4113096249 *)cache->attributes[2];
		InterfaceTypeAttribute__ctor_m1747686341(tmp, 1LL, NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[3];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[4];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
extern const Il2CppType* ParameterBuilder_t3344728474_0_0_0_var;
extern const uint32_t _ParameterBuilder_t2251638747_CustomAttributesCacheGenerator_MetadataUsageId;
static void _ParameterBuilder_t2251638747_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (_ParameterBuilder_t2251638747_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[1];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
	{
		GuidAttribute_t222072359 * tmp = (GuidAttribute_t222072359 *)cache->attributes[2];
		GuidAttribute__ctor_m1099153635(tmp, il2cpp_codegen_string_new_wrapper("36329EBA-F97A-3565-BC07-0ED5C6EF19FC"), NULL);
	}
	{
		InterfaceTypeAttribute_t4113096249 * tmp = (InterfaceTypeAttribute_t4113096249 *)cache->attributes[3];
		InterfaceTypeAttribute__ctor_m1747686341(tmp, 1LL, NULL);
	}
	{
		TypeLibImportClassAttribute_t2390314680 * tmp = (TypeLibImportClassAttribute_t2390314680 *)cache->attributes[4];
		TypeLibImportClassAttribute__ctor_m658319193(tmp, il2cpp_codegen_type_get_object(ParameterBuilder_t3344728474_0_0_0_var), NULL);
	}
}
extern const Il2CppType* ParameterInfo_t2249040075_0_0_0_var;
extern const uint32_t _ParameterInfo_t470209990_CustomAttributesCacheGenerator_MetadataUsageId;
static void _ParameterInfo_t470209990_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (_ParameterInfo_t470209990_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		InterfaceTypeAttribute_t4113096249 * tmp = (InterfaceTypeAttribute_t4113096249 *)cache->attributes[1];
		InterfaceTypeAttribute__ctor_m1747686341(tmp, 1LL, NULL);
	}
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[2];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
	{
		TypeLibImportClassAttribute_t2390314680 * tmp = (TypeLibImportClassAttribute_t2390314680 *)cache->attributes[3];
		TypeLibImportClassAttribute__ctor_m658319193(tmp, il2cpp_codegen_type_get_object(ParameterInfo_t2249040075_0_0_0_var), NULL);
	}
	{
		GuidAttribute_t222072359 * tmp = (GuidAttribute_t222072359 *)cache->attributes[4];
		GuidAttribute__ctor_m1099153635(tmp, il2cpp_codegen_string_new_wrapper("993634C4-E47A-32CC-BE08-85F567DC27D6"), NULL);
	}
}
extern const Il2CppType* PropertyInfo_t_0_0_0_var;
extern const uint32_t _PropertyInfo_t1567586598_CustomAttributesCacheGenerator_MetadataUsageId;
static void _PropertyInfo_t1567586598_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (_PropertyInfo_t1567586598_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[1];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
	{
		InterfaceTypeAttribute_t4113096249 * tmp = (InterfaceTypeAttribute_t4113096249 *)cache->attributes[2];
		InterfaceTypeAttribute__ctor_m1747686341(tmp, 1LL, NULL);
	}
	{
		TypeLibImportClassAttribute_t2390314680 * tmp = (TypeLibImportClassAttribute_t2390314680 *)cache->attributes[3];
		TypeLibImportClassAttribute__ctor_m658319193(tmp, il2cpp_codegen_type_get_object(PropertyInfo_t_0_0_0_var), NULL);
	}
	{
		GuidAttribute_t222072359 * tmp = (GuidAttribute_t222072359 *)cache->attributes[4];
		GuidAttribute__ctor_m1099153635(tmp, il2cpp_codegen_string_new_wrapper("F59ED4E4-E68F-3218-BD77-061AA82824BF"), NULL);
	}
}
extern const Il2CppType* Thread_t241561612_0_0_0_var;
extern const uint32_t _Thread_t1894135853_CustomAttributesCacheGenerator_MetadataUsageId;
static void _Thread_t1894135853_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (_Thread_t1894135853_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		GuidAttribute_t222072359 * tmp = (GuidAttribute_t222072359 *)cache->attributes[0];
		GuidAttribute__ctor_m1099153635(tmp, il2cpp_codegen_string_new_wrapper("C281C7F1-4AA9-3517-961A-463CFED57E75"), NULL);
	}
	{
		TypeLibImportClassAttribute_t2390314680 * tmp = (TypeLibImportClassAttribute_t2390314680 *)cache->attributes[1];
		TypeLibImportClassAttribute__ctor_m658319193(tmp, il2cpp_codegen_type_get_object(Thread_t241561612_0_0_0_var), NULL);
	}
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[2];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
	{
		InterfaceTypeAttribute_t4113096249 * tmp = (InterfaceTypeAttribute_t4113096249 *)cache->attributes[3];
		InterfaceTypeAttribute__ctor_m1747686341(tmp, 1LL, NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[4];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
extern const Il2CppType* TypeBuilder_t3308873219_0_0_0_var;
extern const uint32_t _TypeBuilder_t2783404358_CustomAttributesCacheGenerator_MetadataUsageId;
static void _TypeBuilder_t2783404358_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (_TypeBuilder_t2783404358_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		GuidAttribute_t222072359 * tmp = (GuidAttribute_t222072359 *)cache->attributes[0];
		GuidAttribute__ctor_m1099153635(tmp, il2cpp_codegen_string_new_wrapper("7E5678EE-48B3-3F83-B076-C58543498A58"), NULL);
	}
	{
		InterfaceTypeAttribute_t4113096249 * tmp = (InterfaceTypeAttribute_t4113096249 *)cache->attributes[1];
		InterfaceTypeAttribute__ctor_m1747686341(tmp, 1LL, NULL);
	}
	{
		TypeLibImportClassAttribute_t2390314680 * tmp = (TypeLibImportClassAttribute_t2390314680 *)cache->attributes[2];
		TypeLibImportClassAttribute__ctor_m658319193(tmp, il2cpp_codegen_type_get_object(TypeBuilder_t3308873219_0_0_0_var), NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[3];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[4];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void IActivator_t1538980900_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void IConstructionCallMessage_t2459197515_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void UrlAttribute_t1544437301_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void UrlAttribute_t1544437301_CustomAttributesCacheGenerator_UrlAttribute_GetPropertiesForNewContext_m1831666581(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void UrlAttribute_t1544437301_CustomAttributesCacheGenerator_UrlAttribute_IsContextOK_m3121915198(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void ChannelServices_t2007814595_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void ChannelServices_t2007814595_CustomAttributesCacheGenerator_ChannelServices_RegisterChannel_m3832858065(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m2711473620(tmp, il2cpp_codegen_string_new_wrapper("Use RegisterChannel(IChannel,Boolean)"), NULL);
	}
}
static void CrossAppDomainSink_t2368859578_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t3487514019 * tmp = (MonoTODOAttribute_t3487514019 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m1339517176(tmp, il2cpp_codegen_string_new_wrapper("Handle domain unloading?"), NULL);
	}
}
static void IChannel_t321318132_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void IChannelDataStore_t1307999835_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t889804479 * tmp = (DefaultMemberAttribute_t889804479 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m2234856827(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void IChannelReceiver_t2788889625_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void IChannelSender_t714647579_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void IClientChannelSinkProvider_t2522474175_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void IServerChannelSinkProvider_t2060956099_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void SinkProviderData_t2645445792_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void Context_t502196753_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void ContextAttribute_t197102333_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 4LL, NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void IContextAttribute_t2439121372_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void IContextProperty_t287246399_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void IContributeClientContextSink_t3409105893_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void IContributeDynamicSink_t486956128_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void IContributeEnvoySink_t4106549430_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void IContributeObjectSink_t2326363786_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void IContributeServerContextSink_t1849145353_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void IDynamicMessageSink_t3056162262_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void IDynamicProperty_t603529997_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void SynchronizationAttribute_t3073724998_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 4LL, NULL);
	}
}
static void SynchronizationAttribute_t3073724998_CustomAttributesCacheGenerator_SynchronizationAttribute_GetPropertiesForNewContext_m2175864602(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void SynchronizationAttribute_t3073724998_CustomAttributesCacheGenerator_SynchronizationAttribute_IsContextOK_m525966365(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void LifetimeServices_t2939669377_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void AsyncResult_t2232356043_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void ConstructionCall_t1254994451_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[1];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void ConstructionCall_t1254994451_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map20(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void ConstructionCallDictionary_t2993650247_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map23(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void ConstructionCallDictionary_t2993650247_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map24(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void Header_t2756440555_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void IMessage_t3044378324_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void IMessageCtrl_t2081697019_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void IMessageSink_t2189618969_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void IMethodCallMessage_t645865707_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void IMethodMessage_t1899389025_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void IMethodReturnMessage_t323645523_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void IRemotingFormatter_t4112065742_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void LogicalCallContext_t725724420_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void MethodCall_t2461541281_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[1];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void MethodCall_t2461541281_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map1F(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void MethodDictionary_t1742974787_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t889804479 * tmp = (DefaultMemberAttribute_t889804479 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m2234856827(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void MethodDictionary_t1742974787_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map21(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void MethodDictionary_t1742974787_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map22(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void RemotingSurrogateSelector_t2821375126_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void ReturnMessage_t3411975905_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void SoapAttribute_t1982224933_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void SoapFieldAttribute_t3073759685_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 256LL, NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void SoapMethodAttribute_t2381910676_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 64LL, NULL);
	}
}
static void SoapParameterAttribute_t2780084514_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 2048LL, NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void SoapTypeAttribute_t3444503085_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 1052LL, NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void ProxyAttribute_t4031752430_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 4LL, NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void ProxyAttribute_t4031752430_CustomAttributesCacheGenerator_ProxyAttribute_GetPropertiesForNewContext_m3587421540(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void ProxyAttribute_t4031752430_CustomAttributesCacheGenerator_ProxyAttribute_IsContextOK_m2391079277(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void RealProxy_t298428346_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void ITrackingHandler_t2759960940_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void TrackingServices_t3722365321_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void ActivatedClientTypeEntry_t4060499430_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void ActivatedServiceTypeEntry_t3934090848_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void IChannelInfo_t185176048_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void IEnvoyInfo_t503256512_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void IRemotingTypeInfo_t1105948144_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void InternalRemotingServices_t3953136710_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void ObjRef_t318414488_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void ObjRef_t318414488_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map26(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void ObjRef_t318414488_CustomAttributesCacheGenerator_ObjRef_get_ChannelInfo_m53840305(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 3LL, 2LL, NULL);
	}
}
static void RemotingConfiguration_t438177651_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void ConfigHandler_t2180714860_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map27(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void ConfigHandler_t2180714860_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map28(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void ConfigHandler_t2180714860_CustomAttributesCacheGenerator_ConfigHandler_ValidatePath_m3188987489____paths1(CustomAttributesCache* cache)
{
	{
		ParamArrayAttribute_t2144993728 * tmp = (ParamArrayAttribute_t2144993728 *)cache->attributes[0];
		ParamArrayAttribute__ctor_m2215984741(tmp, NULL);
	}
}
static void RemotingException_t109604560_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void RemotingServices_t2399536837_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void RemotingServices_t2399536837_CustomAttributesCacheGenerator_RemotingServices_IsTransparentProxy_m162250343(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 3LL, 2LL, NULL);
	}
}
static void RemotingServices_t2399536837_CustomAttributesCacheGenerator_RemotingServices_GetRealProxy_m620317996(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 3LL, 2LL, NULL);
	}
}
static void SoapServices_t3397513225_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void TypeEntry_t3321373506_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void WellKnownClientTypeEntry_t3314744170_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void WellKnownObjectMode_t2630225581_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void WellKnownServiceTypeEntry_t1712728956_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void BinaryFormatter_t1866979105_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void BinaryFormatter_t1866979105_CustomAttributesCacheGenerator_U3CDefaultSurrogateSelectorU3Ek__BackingField(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void BinaryFormatter_t1866979105_CustomAttributesCacheGenerator_BinaryFormatter_get_DefaultSurrogateSelector_m219714691(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void FormatterAssemblyStyle_t999493661_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void FormatterTypeStyle_t943306207_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void TypeFilterLevel_t1182459634_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void FormatterConverter_t764140214_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void FormatterServices_t3161112612_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void IDeserializationCallback_t327125377_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void IFormatter_t936711909_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void IFormatterConverter_t1473156697_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void IObjectReference_t2936130011_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void ISerializationSurrogate_t1282780357_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void ISurrogateSelector_t1912587528_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void ObjectManager_t2645893724_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void OnDeserializedAttribute_t3172265744_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 64LL, NULL);
		AttributeUsageAttribute_set_Inherited_m4085818998(tmp, false, NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void OnDeserializingAttribute_t484921187_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 64LL, NULL);
		AttributeUsageAttribute_set_Inherited_m4085818998(tmp, false, NULL);
	}
}
static void OnSerializedAttribute_t3742956097_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 64LL, NULL);
		AttributeUsageAttribute_set_Inherited_m4085818998(tmp, false, NULL);
	}
}
static void OnSerializingAttribute_t2011372116_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 64LL, NULL);
		AttributeUsageAttribute_set_Inherited_m4085818998(tmp, false, NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void SerializationBinder_t3985864818_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void SerializationEntry_t3485203212_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void SerializationException_t753258759_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void SerializationInfo_t228987430_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void SerializationInfo_t228987430_CustomAttributesCacheGenerator_SerializationInfo__ctor_m4016423422(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void SerializationInfo_t228987430_CustomAttributesCacheGenerator_SerializationInfo_AddValue_m4254971664(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void SerializationInfoEnumerator_t589103770_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void StreamingContext_t1417235061_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void StreamingContextStates_t4264247603_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		FlagsAttribute_t859561169 * tmp = (FlagsAttribute_t859561169 *)cache->attributes[0];
		FlagsAttribute__ctor_m1848108622(tmp, NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void X509Certificate_t283079845_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t3487514019 * tmp = (MonoTODOAttribute_t3487514019 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m1339517176(tmp, il2cpp_codegen_string_new_wrapper("X509ContentType.SerializedCert isn't supported (anywhere in the class)"), NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void X509Certificate_t283079845_CustomAttributesCacheGenerator_X509Certificate_GetIssuerName_m3607271213(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m2711473620(tmp, il2cpp_codegen_string_new_wrapper("Use the Issuer property."), NULL);
	}
}
static void X509Certificate_t283079845_CustomAttributesCacheGenerator_X509Certificate_GetName_m2354987368(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m2711473620(tmp, il2cpp_codegen_string_new_wrapper("Use the Subject property."), NULL);
	}
}
static void X509Certificate_t283079845_CustomAttributesCacheGenerator_X509Certificate_Equals_m4141136939(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, false, NULL);
	}
}
static void X509Certificate_t283079845_CustomAttributesCacheGenerator_X509Certificate_Import_m562956152(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, false, NULL);
	}
	{
		MonoTODOAttribute_t3487514019 * tmp = (MonoTODOAttribute_t3487514019 *)cache->attributes[1];
		MonoTODOAttribute__ctor_m1339517176(tmp, il2cpp_codegen_string_new_wrapper("missing KeyStorageFlags support"), NULL);
	}
}
static void X509Certificate_t283079845_CustomAttributesCacheGenerator_X509Certificate_Reset_m1676863543(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, false, NULL);
	}
}
static void X509KeyStorageFlags_t1216946873_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		FlagsAttribute_t859561169 * tmp = (FlagsAttribute_t859561169 *)cache->attributes[0];
		FlagsAttribute__ctor_m1848108622(tmp, NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void AsymmetricAlgorithm_t784058677_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void AsymmetricKeyExchangeFormatter_t3339648384_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void AsymmetricSignatureDeformatter_t3580832979_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void AsymmetricSignatureFormatter_t4058014248_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void CipherMode_t162592484_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void CryptoConfig_t896479599_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void CryptoConfig_t896479599_CustomAttributesCacheGenerator_CryptoConfig_CreateFromName_m2169102076____args1(CustomAttributesCache* cache)
{
	{
		ParamArrayAttribute_t2144993728 * tmp = (ParamArrayAttribute_t2144993728 *)cache->attributes[0];
		ParamArrayAttribute__ctor_m2215984741(tmp, NULL);
	}
}
static void CryptographicException_t3349726436_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void CryptographicUnexpectedOperationException_t4184064416_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void CspParameters_t46065560_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void CspProviderFlags_t105264000_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		FlagsAttribute_t859561169 * tmp = (FlagsAttribute_t859561169 *)cache->attributes[1];
		FlagsAttribute__ctor_m1848108622(tmp, NULL);
	}
}
static void DES_t1353513560_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void DESCryptoServiceProvider_t933603253_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void DSA_t903174880_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void DSACryptoServiceProvider_t2915171657_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void DSACryptoServiceProvider_t2915171657_CustomAttributesCacheGenerator_DSACryptoServiceProvider_t2915171657____PublicOnly_PropertyInfo(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, false, NULL);
	}
}
static void DSAParameters_t1872138834_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void DSASignatureDeformatter_t2187578719_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void DSASignatureFormatter_t1065727064_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void HMAC_t130461695_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void HMACMD5_t2214610803_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void HMACRIPEMD160_t131410643_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void HMACSHA1_t1958407246_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void HMACSHA256_t2622794722_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void HMACSHA384_t3026079344_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void HMACSHA512_t653426285_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void HashAlgorithm_t2624936259_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void ICryptoTransform_t281704372_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void ICspAsymmetricAlgorithm_t662762374_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void KeyedHashAlgorithm_t1374150027_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void MACTripleDES_t442445873_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void MD5_t1507972490_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void MD5CryptoServiceProvider_t4009738925_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void PaddingMode_t3032142640_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void RC2_t3410342145_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void RC2CryptoServiceProvider_t663781682_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void RIPEMD160_t1732039966_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void RIPEMD160Managed_t1613307429_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void RSA_t3719518354_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void RSACryptoServiceProvider_t4229286967_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void RSACryptoServiceProvider_t4229286967_CustomAttributesCacheGenerator_RSACryptoServiceProvider_t4229286967____PublicOnly_PropertyInfo(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, false, NULL);
	}
}
static void RSAPKCS1KeyExchangeFormatter_t4167037264_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void RSAPKCS1SignatureDeformatter_t145198701_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void RSAPKCS1SignatureFormatter_t925064184_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void RSAParameters_t1462703416_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void Rijndael_t2154803531_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void RijndaelManaged_t1034060848_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void RijndaelManagedTransform_t135163252_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void SHA1_t3336793149_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void SHA1CryptoServiceProvider_t3913997830_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void SHA1Managed_t7268864_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void SHA256_t582564463_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void SHA256Managed_t2029745292_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void SHA384_t535510267_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void SHA384Managed_t741627254_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void SHA512_t2908163326_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void SHA512Managed_t3949709369_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void SignatureDescription_t89145500_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void SymmetricAlgorithm_t1108166522_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void ToBase64Transform_t625739466_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void TripleDES_t243950698_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void TripleDESCryptoServiceProvider_t2380467305_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void IUnrestrictedPermission_t3323397702_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void SecurityPermission_t502442079_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void SecurityPermissionFlag_t1642245049_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		FlagsAttribute_t859561169 * tmp = (FlagsAttribute_t859561169 *)cache->attributes[0];
		FlagsAttribute__ctor_m1848108622(tmp, NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[2];
		ObsoleteAttribute__ctor_m2711473620(tmp, il2cpp_codegen_string_new_wrapper("CAS support is not available with Silverlight applications."), NULL);
	}
}
static void StrongNamePublicKeyBlob_t2860422703_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void ApplicationTrust_t3968282840_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void Evidence_t1407710183_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		MonoTODOAttribute_t3487514019 * tmp = (MonoTODOAttribute_t3487514019 *)cache->attributes[1];
		MonoTODOAttribute__ctor_m1339517176(tmp, il2cpp_codegen_string_new_wrapper("Serialization format not compatible with .NET"), NULL);
	}
}
static void Evidence_t1407710183_CustomAttributesCacheGenerator_Evidence_Equals_m2325859915(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, false, NULL);
	}
}
static void Evidence_t1407710183_CustomAttributesCacheGenerator_Evidence_GetHashCode_m1260371757(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, false, NULL);
	}
}
static void Hash_t2681437964_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void IIdentityPermissionFactory_t2988326850_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void StrongName_t2988747270_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void IIdentity_t2445095625_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void IPrincipal_t783141777_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void PrincipalPolicy_t289802916_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void WindowsAccountType_t4179100204_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void WindowsIdentity_t373339331_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void WindowsIdentity_t373339331_CustomAttributesCacheGenerator_WindowsIdentity_Dispose_m2649088337(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, false, NULL);
	}
}
static void CodeAccessPermission_t3468021764_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t3487514019 * tmp = (MonoTODOAttribute_t3487514019 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m1339517176(tmp, il2cpp_codegen_string_new_wrapper("CAS support is experimental (and unsupported)."), NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void CodeAccessPermission_t3468021764_CustomAttributesCacheGenerator_CodeAccessPermission_Equals_m1762790716(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, false, NULL);
	}
}
static void CodeAccessPermission_t3468021764_CustomAttributesCacheGenerator_CodeAccessPermission_GetHashCode_m3295132136(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, false, NULL);
	}
}
static void IPermission_t182075948_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void ISecurityEncodable_t2815109328_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void IStackWalk_t1717744784_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void PermissionSet_t1941658161_CustomAttributesCacheGenerator_U3CDeclarativeSecurityU3Ek__BackingField(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void PermissionSet_t1941658161_CustomAttributesCacheGenerator_PermissionSet_set_DeclarativeSecurity_m3993468766(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void SecurityElement_t2325568386_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void SecurityException_t887327375_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void SecurityException_t887327375_CustomAttributesCacheGenerator_SecurityException_t887327375____Demanded_PropertyInfo(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, false, NULL);
	}
}
static void SecurityManager_t3191249573_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void SecurityManager_t3191249573_CustomAttributesCacheGenerator_SecurityManager_t3191249573____SecurityEnabled_PropertyInfo(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m2711473620(tmp, il2cpp_codegen_string_new_wrapper("The security manager cannot be turned off on MS runtime"), NULL);
	}
}
static void SecuritySafeCriticalAttribute_t372031554_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 32767LL, NULL);
		AttributeUsageAttribute_set_AllowMultiple_m683830749(tmp, false, NULL);
		AttributeUsageAttribute_set_Inherited_m4085818998(tmp, false, NULL);
	}
	{
		MonoTODOAttribute_t3487514019 * tmp = (MonoTODOAttribute_t3487514019 *)cache->attributes[1];
		MonoTODOAttribute__ctor_m1339517176(tmp, il2cpp_codegen_string_new_wrapper("Only supported by the runtime when CoreCLR is enabled"), NULL);
	}
}
static void SuppressUnmanagedCodeSecurityAttribute_t39244474_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 5188LL, NULL);
		AttributeUsageAttribute_set_AllowMultiple_m683830749(tmp, true, NULL);
		AttributeUsageAttribute_set_Inherited_m4085818998(tmp, false, NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void UnverifiableCodeAttribute_t765455733_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 2LL, NULL);
		AttributeUsageAttribute_set_AllowMultiple_m683830749(tmp, true, NULL);
		AttributeUsageAttribute_set_Inherited_m4085818998(tmp, false, NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void ASCIIEncoding_t3022927988_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t3487514019 * tmp = (MonoTODOAttribute_t3487514019 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m1339517176(tmp, il2cpp_codegen_string_new_wrapper("Serialization format not compatible with .NET"), NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void ASCIIEncoding_t3022927988_CustomAttributesCacheGenerator_ASCIIEncoding_GetBytes_m3744562901(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, false, NULL);
	}
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[1];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void ASCIIEncoding_t3022927988_CustomAttributesCacheGenerator_ASCIIEncoding_GetByteCount_m1396020051(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, false, NULL);
	}
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[1];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void ASCIIEncoding_t3022927988_CustomAttributesCacheGenerator_ASCIIEncoding_GetDecoder_m3693600923(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, false, NULL);
	}
	{
		MonoTODOAttribute_t3487514019 * tmp = (MonoTODOAttribute_t3487514019 *)cache->attributes[1];
		MonoTODOAttribute__ctor_m1339517176(tmp, il2cpp_codegen_string_new_wrapper("we have simple override to match method signature."), NULL);
	}
}
static void Decoder_t3792697818_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void Decoder_t3792697818_CustomAttributesCacheGenerator_Decoder_t3792697818____Fallback_PropertyInfo(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, false, NULL);
	}
}
static void Decoder_t3792697818_CustomAttributesCacheGenerator_Decoder_t3792697818____FallbackBuffer_PropertyInfo(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, false, NULL);
	}
}
static void DecoderReplacementFallback_t3042394152_CustomAttributesCacheGenerator_DecoderReplacementFallback__ctor_m2344783488(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t3487514019 * tmp = (MonoTODOAttribute_t3487514019 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m1075768078(tmp, NULL);
	}
}
static void EncoderReplacementFallback_t4228544112_CustomAttributesCacheGenerator_EncoderReplacementFallback__ctor_m517300448(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t3487514019 * tmp = (MonoTODOAttribute_t3487514019 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m1075768078(tmp, NULL);
	}
}
static void Encoding_t663144255_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void Encoding_t663144255_CustomAttributesCacheGenerator_Encoding_InvokeI18N_m4199316552____args1(CustomAttributesCache* cache)
{
	{
		ParamArrayAttribute_t2144993728 * tmp = (ParamArrayAttribute_t2144993728 *)cache->attributes[0];
		ParamArrayAttribute__ctor_m2215984741(tmp, NULL);
	}
}
static void Encoding_t663144255_CustomAttributesCacheGenerator_Encoding_Clone_m2663608141(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, false, NULL);
	}
}
static void Encoding_t663144255_CustomAttributesCacheGenerator_Encoding_GetByteCount_m4104502544(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, false, NULL);
	}
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[1];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Encoding_t663144255_CustomAttributesCacheGenerator_Encoding_GetBytes_m3820493744(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, false, NULL);
	}
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[1];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Encoding_t663144255_CustomAttributesCacheGenerator_Encoding_t663144255____IsReadOnly_PropertyInfo(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, false, NULL);
	}
}
static void Encoding_t663144255_CustomAttributesCacheGenerator_Encoding_t663144255____DecoderFallback_PropertyInfo(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, false, NULL);
	}
}
static void Encoding_t663144255_CustomAttributesCacheGenerator_Encoding_t663144255____EncoderFallback_PropertyInfo(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, false, NULL);
	}
}
static void StringBuilder_t1221177846_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		DefaultMemberAttribute_t889804479 * tmp = (DefaultMemberAttribute_t889804479 *)cache->attributes[1];
		DefaultMemberAttribute__ctor_m2234856827(tmp, il2cpp_codegen_string_new_wrapper("Chars"), NULL);
	}
	{
		MonoTODOAttribute_t3487514019 * tmp = (MonoTODOAttribute_t3487514019 *)cache->attributes[2];
		MonoTODOAttribute__ctor_m1339517176(tmp, il2cpp_codegen_string_new_wrapper("Serialization format not compatible with .NET"), NULL);
	}
}
static void StringBuilder_t1221177846_CustomAttributesCacheGenerator_StringBuilder_AppendLine_m1686706871(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, false, NULL);
	}
}
static void StringBuilder_t1221177846_CustomAttributesCacheGenerator_StringBuilder_AppendLine_m2033101329(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, false, NULL);
	}
}
static void StringBuilder_t1221177846_CustomAttributesCacheGenerator_StringBuilder_AppendFormat_m1879616656____args1(CustomAttributesCache* cache)
{
	{
		ParamArrayAttribute_t2144993728 * tmp = (ParamArrayAttribute_t2144993728 *)cache->attributes[0];
		ParamArrayAttribute__ctor_m2215984741(tmp, NULL);
	}
}
static void StringBuilder_t1221177846_CustomAttributesCacheGenerator_StringBuilder_AppendFormat_m3178887408____args2(CustomAttributesCache* cache)
{
	{
		ParamArrayAttribute_t2144993728 * tmp = (ParamArrayAttribute_t2144993728 *)cache->attributes[0];
		ParamArrayAttribute__ctor_m2215984741(tmp, NULL);
	}
}
static void UTF32Encoding_t549530865_CustomAttributesCacheGenerator_UTF32Encoding_GetByteCount_m3183615393(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t3487514019 * tmp = (MonoTODOAttribute_t3487514019 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m1339517176(tmp, il2cpp_codegen_string_new_wrapper("handle fallback"), NULL);
	}
}
static void UTF32Encoding_t549530865_CustomAttributesCacheGenerator_UTF32Encoding_GetBytes_m2290150495(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t3487514019 * tmp = (MonoTODOAttribute_t3487514019 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m1339517176(tmp, il2cpp_codegen_string_new_wrapper("handle fallback"), NULL);
	}
}
static void UTF32Encoding_t549530865_CustomAttributesCacheGenerator_UTF32Encoding_GetByteCount_m77034086(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void UTF32Encoding_t549530865_CustomAttributesCacheGenerator_UTF32Encoding_GetBytes_m2093416998(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void UTF7Encoding_t741406939_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t3487514019 * tmp = (MonoTODOAttribute_t3487514019 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m1339517176(tmp, il2cpp_codegen_string_new_wrapper("Serialization format not compatible with .NET"), NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void UTF7Encoding_t741406939_CustomAttributesCacheGenerator_UTF7Encoding_GetHashCode_m359766848(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, false, NULL);
	}
}
static void UTF7Encoding_t741406939_CustomAttributesCacheGenerator_UTF7Encoding_Equals_m3706778156(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, false, NULL);
	}
}
static void UTF7Encoding_t741406939_CustomAttributesCacheGenerator_UTF7Encoding_GetByteCount_m273209154(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, false, NULL);
	}
}
static void UTF7Encoding_t741406939_CustomAttributesCacheGenerator_UTF7Encoding_GetByteCount_m1588484494(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, false, NULL);
	}
}
static void UTF7Encoding_t741406939_CustomAttributesCacheGenerator_UTF7Encoding_GetBytes_m3015176946(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, false, NULL);
	}
}
static void UTF7Encoding_t741406939_CustomAttributesCacheGenerator_UTF7Encoding_GetBytes_m3033375614(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, false, NULL);
	}
}
static void UTF7Encoding_t741406939_CustomAttributesCacheGenerator_UTF7Encoding_GetString_m4263430344(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, false, NULL);
	}
}
static void UTF8Encoding_t111055448_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t3487514019 * tmp = (MonoTODOAttribute_t3487514019 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m1339517176(tmp, il2cpp_codegen_string_new_wrapper("EncoderFallback is not handled"), NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		MonoTODOAttribute_t3487514019 * tmp = (MonoTODOAttribute_t3487514019 *)cache->attributes[2];
		MonoTODOAttribute__ctor_m1339517176(tmp, il2cpp_codegen_string_new_wrapper("Serialization format not compatible with .NET"), NULL);
	}
}
static void UTF8Encoding_t111055448_CustomAttributesCacheGenerator_UTF8Encoding_GetByteCount_m2547312609(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, false, NULL);
	}
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[1];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void UTF8Encoding_t111055448_CustomAttributesCacheGenerator_UTF8Encoding_GetBytes_m2973831055(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, false, NULL);
	}
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[1];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void UTF8Encoding_t111055448_CustomAttributesCacheGenerator_UTF8Encoding_GetString_m1836344205(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, false, NULL);
	}
}
static void UnicodeEncoding_t4081757012_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t3487514019 * tmp = (MonoTODOAttribute_t3487514019 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m1339517176(tmp, il2cpp_codegen_string_new_wrapper("Serialization format not compatible with .NET"), NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void UnicodeEncoding_t4081757012_CustomAttributesCacheGenerator_UnicodeEncoding_GetByteCount_m662995793(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, false, NULL);
	}
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[1];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void UnicodeEncoding_t4081757012_CustomAttributesCacheGenerator_UnicodeEncoding_GetBytes_m1575298215(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, false, NULL);
	}
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[1];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void UnicodeEncoding_t4081757012_CustomAttributesCacheGenerator_UnicodeEncoding_GetString_m542738941(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, false, NULL);
	}
}
static void CompressedStack_t1568001503_CustomAttributesCacheGenerator_CompressedStack_CreateCopy_m3321727874(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, false, NULL);
	}
}
static void CompressedStack_t1568001503_CustomAttributesCacheGenerator_CompressedStack_GetObjectData_m2387204186(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t3487514019 * tmp = (MonoTODOAttribute_t3487514019 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m1339517176(tmp, il2cpp_codegen_string_new_wrapper("incomplete"), NULL);
	}
}
static void EventResetMode_t4116945436_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, false, NULL);
	}
}
static void EventWaitHandle_t2091316307_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void ExecutionContext_t1392266323_CustomAttributesCacheGenerator_ExecutionContext__ctor_m573218565(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t3487514019 * tmp = (MonoTODOAttribute_t3487514019 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m1075768078(tmp, NULL);
	}
}
static void ExecutionContext_t1392266323_CustomAttributesCacheGenerator_ExecutionContext_GetObjectData_m1456913356(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t3487514019 * tmp = (MonoTODOAttribute_t3487514019 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m1075768078(tmp, NULL);
	}
}
static void Interlocked_t1625106012_CustomAttributesCacheGenerator_Interlocked_CompareExchange_m3339239614(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 3LL, 2LL, NULL);
	}
}
static void Interlocked_t1625106012_CustomAttributesCacheGenerator_Interlocked_CompareExchange_m3263020936(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 3LL, 2LL, NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, false, NULL);
	}
}
static void ManualResetEvent_t926074657_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void Monitor_t3228523394_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void Monitor_t3228523394_CustomAttributesCacheGenerator_Monitor_Exit_m2677760297(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 3LL, 2LL, NULL);
	}
}
static void Mutex_t297030111_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void Mutex_t297030111_CustomAttributesCacheGenerator_Mutex__ctor_m2649008317(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 3LL, 1LL, NULL);
	}
}
static void Mutex_t297030111_CustomAttributesCacheGenerator_Mutex_ReleaseMutex_m2143813124(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 3LL, 1LL, NULL);
	}
}
static void SynchronizationLockException_t117698316_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
extern const Il2CppType* _Thread_t1894135853_0_0_0_var;
extern const uint32_t Thread_t241561612_CustomAttributesCacheGenerator_MetadataUsageId;
static void Thread_t241561612_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Thread_t241561612_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ComDefaultInterfaceAttribute_t347642415 * tmp = (ComDefaultInterfaceAttribute_t347642415 *)cache->attributes[0];
		ComDefaultInterfaceAttribute__ctor_m254275202(tmp, il2cpp_codegen_type_get_object(_Thread_t1894135853_0_0_0_var), NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		ClassInterfaceAttribute_t910653559 * tmp = (ClassInterfaceAttribute_t910653559 *)cache->attributes[2];
		ClassInterfaceAttribute__ctor_m177247154(tmp, 0LL, NULL);
	}
}
static void Thread_t241561612_CustomAttributesCacheGenerator_local_slots(CustomAttributesCache* cache)
{
	{
		ThreadStaticAttribute_t1787731584 * tmp = (ThreadStaticAttribute_t1787731584 *)cache->attributes[0];
		ThreadStaticAttribute__ctor_m460210245(tmp, NULL);
	}
}
static void Thread_t241561612_CustomAttributesCacheGenerator__ec(CustomAttributesCache* cache)
{
	{
		ThreadStaticAttribute_t1787731584 * tmp = (ThreadStaticAttribute_t1787731584 *)cache->attributes[0];
		ThreadStaticAttribute__ctor_m460210245(tmp, NULL);
	}
}
static void Thread_t241561612_CustomAttributesCacheGenerator_Thread_get_CurrentThread_m3667342817(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 3LL, 1LL, NULL);
	}
}
static void Thread_t241561612_CustomAttributesCacheGenerator_Thread_Finalize_m3231208127(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 3LL, 2LL, NULL);
	}
}
static void Thread_t241561612_CustomAttributesCacheGenerator_Thread_get_ExecutionContext_m922067206(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 3LL, 1LL, NULL);
	}
}
static void Thread_t241561612_CustomAttributesCacheGenerator_Thread_get_ManagedThreadId_m1995754972(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 3LL, 2LL, NULL);
	}
}
static void Thread_t241561612_CustomAttributesCacheGenerator_Thread_GetHashCode_m2038641494(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, false, NULL);
	}
}
static void Thread_t241561612_CustomAttributesCacheGenerator_Thread_GetCompressedStack_m1220107123(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m2711473620(tmp, il2cpp_codegen_string_new_wrapper("see CompressedStack class"), NULL);
	}
}
static void Thread_t241561612_CustomAttributesCacheGenerator_Thread_t241561612____ExecutionContext_PropertyInfo(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t3487514019 * tmp = (MonoTODOAttribute_t3487514019 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m1339517176(tmp, il2cpp_codegen_string_new_wrapper("limited to CompressedStack support"), NULL);
	}
}
static void ThreadAbortException_t1150575753_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void ThreadInterruptedException_t63303933_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void ThreadState_t1158972609_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		FlagsAttribute_t859561169 * tmp = (FlagsAttribute_t859561169 *)cache->attributes[1];
		FlagsAttribute__ctor_m1848108622(tmp, NULL);
	}
}
static void ThreadStateException_t1404755912_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void Timer_t791717973_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void WaitHandle_t677569169_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void WaitHandle_t677569169_CustomAttributesCacheGenerator_WaitHandle_t677569169____Handle_PropertyInfo(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m2711473620(tmp, il2cpp_codegen_string_new_wrapper("In the profiles > 2.x, use SafeHandle instead of Handle"), NULL);
	}
}
static void AccessViolationException_t182079320_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void ActivationContext_t1572332809_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, false, NULL);
	}
}
static void ActivationContext_t1572332809_CustomAttributesCacheGenerator_ActivationContext_System_Runtime_Serialization_ISerializable_GetObjectData_m775951299(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t3487514019 * tmp = (MonoTODOAttribute_t3487514019 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m1339517176(tmp, il2cpp_codegen_string_new_wrapper("Missing serialization support"), NULL);
	}
}
extern const Il2CppType* _Activator_t3825585294_0_0_0_var;
extern const uint32_t Activator_t1850728717_CustomAttributesCacheGenerator_MetadataUsageId;
static void Activator_t1850728717_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Activator_t1850728717_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ClassInterfaceAttribute_t910653559 * tmp = (ClassInterfaceAttribute_t910653559 *)cache->attributes[0];
		ClassInterfaceAttribute__ctor_m177247154(tmp, 0LL, NULL);
	}
	{
		ComDefaultInterfaceAttribute_t347642415 * tmp = (ComDefaultInterfaceAttribute_t347642415 *)cache->attributes[1];
		ComDefaultInterfaceAttribute__ctor_m254275202(tmp, il2cpp_codegen_type_get_object(_Activator_t3825585294_0_0_0_var), NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[2];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void Activator_t1850728717_CustomAttributesCacheGenerator_Activator_CreateInstance_m1465989661____args1(CustomAttributesCache* cache)
{
	{
		ParamArrayAttribute_t2144993728 * tmp = (ParamArrayAttribute_t2144993728 *)cache->attributes[0];
		ParamArrayAttribute__ctor_m2215984741(tmp, NULL);
	}
}
static void AppDomain_t2719102437_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ClassInterfaceAttribute_t910653559 * tmp = (ClassInterfaceAttribute_t910653559 *)cache->attributes[0];
		ClassInterfaceAttribute__ctor_m177247154(tmp, 0LL, NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void AppDomain_t2719102437_CustomAttributesCacheGenerator_type_resolve_in_progress(CustomAttributesCache* cache)
{
	{
		ThreadStaticAttribute_t1787731584 * tmp = (ThreadStaticAttribute_t1787731584 *)cache->attributes[0];
		ThreadStaticAttribute__ctor_m460210245(tmp, NULL);
	}
}
static void AppDomain_t2719102437_CustomAttributesCacheGenerator_assembly_resolve_in_progress(CustomAttributesCache* cache)
{
	{
		ThreadStaticAttribute_t1787731584 * tmp = (ThreadStaticAttribute_t1787731584 *)cache->attributes[0];
		ThreadStaticAttribute__ctor_m460210245(tmp, NULL);
	}
}
static void AppDomain_t2719102437_CustomAttributesCacheGenerator_assembly_resolve_in_progress_refonly(CustomAttributesCache* cache)
{
	{
		ThreadStaticAttribute_t1787731584 * tmp = (ThreadStaticAttribute_t1787731584 *)cache->attributes[0];
		ThreadStaticAttribute__ctor_m460210245(tmp, NULL);
	}
}
static void AppDomain_t2719102437_CustomAttributesCacheGenerator__principal(CustomAttributesCache* cache)
{
	{
		ThreadStaticAttribute_t1787731584 * tmp = (ThreadStaticAttribute_t1787731584 *)cache->attributes[0];
		ThreadStaticAttribute__ctor_m460210245(tmp, NULL);
	}
}
static void AppDomainManager_t54965696_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void AppDomainSetup_t611332832_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ClassInterfaceAttribute_t910653559 * tmp = (ClassInterfaceAttribute_t910653559 *)cache->attributes[0];
		ClassInterfaceAttribute__ctor_m177247154(tmp, 0LL, NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void ApplicationException_t474868623_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void ApplicationIdentity_t3292367950_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, false, NULL);
	}
}
static void ApplicationIdentity_t3292367950_CustomAttributesCacheGenerator_ApplicationIdentity_System_Runtime_Serialization_ISerializable_GetObjectData_m77567264(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t3487514019 * tmp = (MonoTODOAttribute_t3487514019 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m1339517176(tmp, il2cpp_codegen_string_new_wrapper("Missing serialization"), NULL);
	}
}
static void ArgumentException_t3259014390_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void ArgumentNullException_t628810857_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void ArgumentOutOfRangeException_t279959794_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void ArithmeticException_t3261462543_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void ArrayTypeMismatchException_t2071164632_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void AssemblyLoadEventArgs_t4233815743_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void AttributeTargets_t1984597432_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		FlagsAttribute_t859561169 * tmp = (FlagsAttribute_t859561169 *)cache->attributes[0];
		FlagsAttribute__ctor_m1848108622(tmp, NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void Buffer_t3497320070_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void CharEnumerator_t1926099410_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void ContextBoundObject_t4264702438_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToBoolean_m3882815225(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToBoolean_m2188088811(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToBoolean_m3169319766(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToBoolean_m2470413809(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToByte_m2303223565(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToByte_m509311047(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToByte_m932798552(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToByte_m791636053(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToChar_m541258017(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToChar_m528169935(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToChar_m951657444(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToChar_m245844937(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToDateTime_m1020507389(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToDateTime_m3528521877(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToDateTime_m3810846875(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToDateTime_m1626410554(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToDecimal_m2736745817(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToDecimal_m777781771(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToDecimal_m354294262(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToDecimal_m1060106769(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToDouble_m2226915533(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToDouble_m4236754739(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToDouble_m923018402(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToDouble_m3954429733(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToInt16_m960783641(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToInt16_m1536565067(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToInt16_m1113077558(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToInt16_m1818890065(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToInt32_m2209788057(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToInt32_m1523194571(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToInt32_m1099707062(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToInt32_m1805519569(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToInt64_m1009422297(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToInt64_m4057339019(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToInt64_m3633851510(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToInt64_m44696721(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToSByte_m615207682(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToSByte_m2470292806(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToSByte_m2665932200(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToSByte_m3295168715(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToSByte_m3768984293(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToSByte_m1183867428(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToSByte_m3208712702(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToSByte_m2045913061(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToSByte_m883113940(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToSByte_m1570938941(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToSByte_m2303634571(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToSByte_m1880147062(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToSByte_m2585959569(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToSByte_m1972336057(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToSingle_m3186653037(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToSingle_m2156102599(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToSingle_m2579590104(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToSingle_m2438427605(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt16_m1043031438(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt16_m3860123086(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt16_m36213644(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt16_m588378195(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt16_m3265369225(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt16_m3866680988(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt16_m1665900934(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt16_m2828700513(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt16_m3982177821(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt16_m3991499696(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt16_m1058302913(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt16_m2130758075(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt16_m4241289050(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt16_m590399293(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt32_m3686071170(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt32_m3492113030(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt32_m797503336(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt32_m610956619(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt32_m1336475941(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt32_m3394039268(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt32_m3085255294(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt32_m1922455781(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt32_m671585177(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt32_m759656532(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt32_m776714429(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt32_m4090244982(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt32_m3391339025(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt32_m817681977(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt64_m1479404080(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt64_m1568624612(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt64_m1319798722(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt64_m3944965503(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt64_m3559662221(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt64_m2215781574(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt64_m1691869628(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt64_m2498438645(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt64_m2643825617(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt64_m3661238030(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt64_m3596570605(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt64_m1109896503(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt64_m827571497(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt64_m1896191125(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt64_m345450801(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void DBNull_t972229383_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void DateTimeKind_t2186819611_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void DateTimeOffset_t1362988906_CustomAttributesCacheGenerator_DateTimeOffset_System_Runtime_Serialization_IDeserializationCallback_OnDeserialization_m1059347059(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t3487514019 * tmp = (MonoTODOAttribute_t3487514019 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m1075768078(tmp, NULL);
	}
}
static void DayOfWeek_t721777893_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void DivideByZeroException_t1660837001_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void DllNotFoundException_t3636280042_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void EntryPointNotFoundException_t3956266210_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void MonoEnumInfo_t2335995564_CustomAttributesCacheGenerator_cache(CustomAttributesCache* cache)
{
	{
		ThreadStaticAttribute_t1787731584 * tmp = (ThreadStaticAttribute_t1787731584 *)cache->attributes[0];
		ThreadStaticAttribute__ctor_m460210245(tmp, NULL);
	}
}
static void Environment_t3662374671_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void SpecialFolder_t1519540278_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void EventArgs_t3289624707_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void ExecutionEngineException_t1360775125_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void FieldAccessException_t1797813379_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void FlagsAttribute_t859561169_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 16LL, NULL);
		AttributeUsageAttribute_set_Inherited_m4085818998(tmp, false, NULL);
	}
}
static void FormatException_t2948921286_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void GC_t2902933594_CustomAttributesCacheGenerator_GC_SuppressFinalize_m953228702(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 3LL, 2LL, NULL);
	}
}
static void Guid_t2533601593_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void ICustomFormatter_t2344731076_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void IFormatProvider_t2849799027_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void IndexOutOfRangeException_t3527622107_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void InvalidCastException_t3625212209_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void InvalidOperationException_t721527559_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void LoaderOptimization_t1143026982_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void LoaderOptimization_t1143026982_CustomAttributesCacheGenerator_DomainMask(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m842106750(tmp, NULL);
	}
}
static void LoaderOptimization_t1143026982_CustomAttributesCacheGenerator_DisallowBindings(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m842106750(tmp, NULL);
	}
}
static void LocalDataStoreSlot_t486331200_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void Math_t2022911894_CustomAttributesCacheGenerator_Math_Max_m2671311541(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 3LL, 2LL, NULL);
	}
}
static void Math_t2022911894_CustomAttributesCacheGenerator_Math_Min_m4290821911(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 3LL, 2LL, NULL);
	}
}
static void Math_t2022911894_CustomAttributesCacheGenerator_Math_Sqrt_m932242488(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 3LL, 2LL, NULL);
	}
}
static void MemberAccessException_t2005094827_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void MethodAccessException_t4093255254_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void MissingFieldException_t3702079619_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void MissingMemberException_t1839900847_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void MissingMethodException_t3441205986_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void MulticastNotSupportedException_t1815247018_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void NonSerializedAttribute_t399263003_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 256LL, NULL);
		AttributeUsageAttribute_set_Inherited_m4085818998(tmp, false, NULL);
	}
}
static void NotImplementedException_t2785117854_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void NotSupportedException_t1793819818_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void NullReferenceException_t3156209119_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void NumberFormatter_t2933946347_CustomAttributesCacheGenerator_threadNumberFormatter(CustomAttributesCache* cache)
{
	{
		ThreadStaticAttribute_t1787731584 * tmp = (ThreadStaticAttribute_t1787731584 *)cache->attributes[0];
		ThreadStaticAttribute__ctor_m460210245(tmp, NULL);
	}
}
static void ObjectDisposedException_t2695136451_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void OperatingSystem_t290860502_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void OutOfMemoryException_t1181064283_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void OverflowException_t1075868493_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void PlatformID_t1006634368_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void PlatformNotSupportedException_t3778770305_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void RankException_t1539875949_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void ResolveEventArgs_t1859808873_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void RuntimeMethodHandle_t894824333_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		MonoTODOAttribute_t3487514019 * tmp = (MonoTODOAttribute_t3487514019 *)cache->attributes[1];
		MonoTODOAttribute__ctor_m1339517176(tmp, il2cpp_codegen_string_new_wrapper("Serialization needs tests"), NULL);
	}
}
static void RuntimeMethodHandle_t894824333_CustomAttributesCacheGenerator_RuntimeMethodHandle_Equals_m813356023(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 3LL, 2LL, NULL);
	}
}
static void StringComparer_t1574862926_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void StringComparison_t2376310518_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void StringSplitOptions_t2996162939_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, false, NULL);
	}
	{
		FlagsAttribute_t859561169 * tmp = (FlagsAttribute_t859561169 *)cache->attributes[1];
		FlagsAttribute__ctor_m1848108622(tmp, NULL);
	}
}
static void SystemException_t3877406272_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void ThreadStaticAttribute_t1787731584_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 256LL, NULL);
		AttributeUsageAttribute_set_Inherited_m4085818998(tmp, false, NULL);
	}
}
static void TimeSpan_t3430258949_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void TimeZone_t4008205267_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void TypeCode_t2536926201_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void TypeInitializationException_t3654642183_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void TypeLoadException_t723359155_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void UnauthorizedAccessException_t886535555_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void UnhandledExceptionEventArgs_t3067050131_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void UnhandledExceptionEventArgs_t3067050131_CustomAttributesCacheGenerator_UnhandledExceptionEventArgs_get_ExceptionObject_m2339769046(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 3LL, 2LL, NULL);
	}
}
static void UnhandledExceptionEventArgs_t3067050131_CustomAttributesCacheGenerator_UnhandledExceptionEventArgs_get_IsTerminating_m2266550949(CustomAttributesCache* cache)
{
	{
		ReliabilityContractAttribute_t1625655220 * tmp = (ReliabilityContractAttribute_t1625655220 *)cache->attributes[0];
		ReliabilityContractAttribute__ctor_m1496374289(tmp, 3LL, 2LL, NULL);
	}
}
static void Version_t1755874712_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void WeakReference_t1077405567_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void MemberFilter_t3405857066_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void TypeFilter_t2905709404_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void CrossContextDelegate_t754146990_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void HeaderHandler_t324204131_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void ThreadStart_t3437517264_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void TimerCallback_t1684927372_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void WaitCallback_t2798937288_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void AppDomainInitializer_t3898244613_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void AssemblyLoadEventHandler_t2169307382_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void EventHandler_t277755526_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void ResolveEventHandler_t3842432458_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void UnhandledExceptionEventHandler_t1916531888_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void U3CPrivateImplementationDetailsU3E_t1486305137_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void g_System_Assembly_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AssemblyInformationalVersionAttribute_t3037389657 * tmp = (AssemblyInformationalVersionAttribute_t3037389657 *)cache->attributes[0];
		AssemblyInformationalVersionAttribute__ctor_m376831533(tmp, il2cpp_codegen_string_new_wrapper("3.0.40818.0"), NULL);
	}
	{
		SatelliteContractVersionAttribute_t2989984391 * tmp = (SatelliteContractVersionAttribute_t2989984391 *)cache->attributes[1];
		SatelliteContractVersionAttribute__ctor_m2605651717(tmp, il2cpp_codegen_string_new_wrapper("2.0.5.0"), NULL);
	}
	{
		NeutralResourcesLanguageAttribute_t3267676636 * tmp = (NeutralResourcesLanguageAttribute_t3267676636 *)cache->attributes[2];
		NeutralResourcesLanguageAttribute__ctor_m1145808404(tmp, il2cpp_codegen_string_new_wrapper("en-US"), NULL);
	}
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[3];
		CLSCompliantAttribute__ctor_m1113299407(tmp, true, NULL);
	}
	{
		AssemblyCopyrightAttribute_t177123295 * tmp = (AssemblyCopyrightAttribute_t177123295 *)cache->attributes[4];
		AssemblyCopyrightAttribute__ctor_m2712202383(tmp, il2cpp_codegen_string_new_wrapper("(c) various MONO Authors"), NULL);
	}
	{
		AssemblyDefaultAliasAttribute_t1774139159 * tmp = (AssemblyDefaultAliasAttribute_t1774139159 *)cache->attributes[5];
		AssemblyDefaultAliasAttribute__ctor_m746891723(tmp, il2cpp_codegen_string_new_wrapper("System.dll"), NULL);
	}
	{
		AssemblyDescriptionAttribute_t1018387888 * tmp = (AssemblyDescriptionAttribute_t1018387888 *)cache->attributes[6];
		AssemblyDescriptionAttribute__ctor_m3307088082(tmp, il2cpp_codegen_string_new_wrapper("System.dll"), NULL);
	}
	{
		AssemblyProductAttribute_t1523443169 * tmp = (AssemblyProductAttribute_t1523443169 *)cache->attributes[7];
		AssemblyProductAttribute__ctor_m1807437213(tmp, il2cpp_codegen_string_new_wrapper("MONO Common language infrastructure"), NULL);
	}
	{
		AssemblyCompanyAttribute_t2851673381 * tmp = (AssemblyCompanyAttribute_t2851673381 *)cache->attributes[8];
		AssemblyCompanyAttribute__ctor_m1217508649(tmp, il2cpp_codegen_string_new_wrapper("MONO development team"), NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[9];
		ComVisibleAttribute__ctor_m1789587486(tmp, false, NULL);
	}
	{
		CompilationRelaxationsAttribute_t238494011 * tmp = (CompilationRelaxationsAttribute_t238494011 *)cache->attributes[10];
		CompilationRelaxationsAttribute__ctor_m2800984288(tmp, 8LL, NULL);
	}
	{
		DebuggableAttribute_t994551506 * tmp = (DebuggableAttribute_t994551506 *)cache->attributes[11];
		DebuggableAttribute__ctor_m1065484869(tmp, 2LL, NULL);
	}
	{
		AssemblyTitleAttribute_t92945912 * tmp = (AssemblyTitleAttribute_t92945912 *)cache->attributes[12];
		AssemblyTitleAttribute__ctor_m1696431446(tmp, il2cpp_codegen_string_new_wrapper("System.dll"), NULL);
	}
	{
		RuntimeCompatibilityAttribute_t2430705542 * tmp = (RuntimeCompatibilityAttribute_t2430705542 *)cache->attributes[13];
		RuntimeCompatibilityAttribute__ctor_m1331212510(tmp, NULL);
		RuntimeCompatibilityAttribute_set_WrapNonExceptionThrows_m2174793351(tmp, true, NULL);
	}
	{
		AssemblyKeyFileAttribute_t605245443 * tmp = (AssemblyKeyFileAttribute_t605245443 *)cache->attributes[14];
		AssemblyKeyFileAttribute__ctor_m1072556611(tmp, il2cpp_codegen_string_new_wrapper("../silverlight.pub"), NULL);
	}
	{
		AssemblyDelaySignAttribute_t2705758496 * tmp = (AssemblyDelaySignAttribute_t2705758496 *)cache->attributes[15];
		AssemblyDelaySignAttribute__ctor_m793760213(tmp, true, NULL);
	}
	{
		AssemblyFileVersionAttribute_t2897687916 * tmp = (AssemblyFileVersionAttribute_t2897687916 *)cache->attributes[16];
		AssemblyFileVersionAttribute__ctor_m2026149866(tmp, il2cpp_codegen_string_new_wrapper("3.0.40818.0"), NULL);
	}
	{
		InternalsVisibleToAttribute_t1037732567 * tmp = (InternalsVisibleToAttribute_t1037732567 *)cache->attributes[17];
		InternalsVisibleToAttribute__ctor_m573685517(tmp, il2cpp_codegen_string_new_wrapper("System.Net, PublicKey=00240000048000009400000006020000002400005253413100040000010001008D56C76F9E8649383049F383C44BE0EC204181822A6C31CF5EB7EF486944D032188EA1D3920763712CCB12D75FB77E9811149E6148E5D32FBAAB37611C1878DDC19E20EF135D0CB2CFF2BFEC3D115810C3D9069638FE4BE215DBF795861920E5AB6F7DB2E2CEEF136AC23D5DD2BF031700AEC232F6C6B1C785B4305C123B37AB"), NULL);
	}
}
static void Locale_t4255929015_CustomAttributesCacheGenerator_Locale_GetText_m1445803604____args1(CustomAttributesCache* cache)
{
	{
		ParamArrayAttribute_t2144993728 * tmp = (ParamArrayAttribute_t2144993728 *)cache->attributes[0];
		ParamArrayAttribute__ctor_m2215984741(tmp, NULL);
	}
}
static void MonoTODOAttribute_t3487514020_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 32767LL, NULL);
		AttributeUsageAttribute_set_AllowMultiple_m683830749(tmp, true, NULL);
	}
}
static void Stack_1_t4016656541_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, false, NULL);
	}
}
static void HybridDictionary_t290043810_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t889804479 * tmp = (DefaultMemberAttribute_t889804479 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m2234856827(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void ListDictionary_t3458713452_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t889804479 * tmp = (DefaultMemberAttribute_t889804479 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m2234856827(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void NameObjectCollectionBase_t2034248631_CustomAttributesCacheGenerator_NameObjectCollectionBase_FindFirstMatchedItem_m2460648656(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t3487514020 * tmp = (MonoTODOAttribute_t3487514020 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m4004919844(tmp, NULL);
	}
}
static void KeysCollection_t633582367_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t889804479 * tmp = (DefaultMemberAttribute_t889804479 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m2234856827(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void NameValueCollection_t3047564564_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t889804479 * tmp = (DefaultMemberAttribute_t889804479 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m2234856827(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void EditorBrowsableAttribute_t1050682502_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 6140LL, NULL);
	}
}
static void TypeConverter_t745995970_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void TypeConverterAttribute_t252469870_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[0];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 32767LL, NULL);
	}
}
static void Win32Exception_t1708275760_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		SuppressUnmanagedCodeSecurityAttribute_t39244474 * tmp = (SuppressUnmanagedCodeSecurityAttribute_t39244474 *)cache->attributes[0];
		SuppressUnmanagedCodeSecurityAttribute__ctor_m1596284123(tmp, NULL);
	}
}
static void SslPolicyErrors_t1928581431_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		FlagsAttribute_t859561169 * tmp = (FlagsAttribute_t859561169 *)cache->attributes[0];
		FlagsAttribute__ctor_m1848108622(tmp, NULL);
	}
}
static void Socket_t3821512045_CustomAttributesCacheGenerator_Socket_t3821512045____SupportsIPv6_PropertyInfo(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m2711473620(tmp, il2cpp_codegen_string_new_wrapper("Use OSSupportsIPv6 instead"), NULL);
	}
}
static void SocketFlags_t2353657790_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		FlagsAttribute_t859561169 * tmp = (FlagsAttribute_t859561169 *)cache->attributes[0];
		FlagsAttribute__ctor_m1848108622(tmp, NULL);
	}
}
static void Dns_t1335526197_CustomAttributesCacheGenerator_Dns_GetHostByName_m3673230969(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m2711473620(tmp, il2cpp_codegen_string_new_wrapper("Use GetHostEntry instead"), NULL);
	}
}
static void FileWebRequest_t1571840111_CustomAttributesCacheGenerator_FileWebRequest__ctor_m4003648606(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m834417715(tmp, il2cpp_codegen_string_new_wrapper("Serialization is obsoleted for this type"), false, NULL);
	}
}
static void FtpWebRequest_t3120721823_CustomAttributesCacheGenerator_U3CU3Ef__amU24cache1C(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void FtpWebRequest_t3120721823_CustomAttributesCacheGenerator_FtpWebRequest_U3CcallbackU3Em__B_m4153123054(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void GlobalProxySelection_t2251180943_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m2711473620(tmp, il2cpp_codegen_string_new_wrapper("Use WebRequest.DefaultProxy instead"), NULL);
	}
}
static void HttpWebRequest_t1951404513_CustomAttributesCacheGenerator_HttpWebRequest__ctor_m1248252412(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m834417715(tmp, il2cpp_codegen_string_new_wrapper("Serialization is obsoleted for this type"), false, NULL);
	}
}
static void IPv6Address_t2596635879_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t889804479 * tmp = (DefaultMemberAttribute_t889804479 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m2234856827(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void SecurityProtocolType_t3099771628_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		FlagsAttribute_t859561169 * tmp = (FlagsAttribute_t859561169 *)cache->attributes[0];
		FlagsAttribute__ctor_m1848108622(tmp, NULL);
	}
}
static void ServicePointManager_t745663000_CustomAttributesCacheGenerator_ServicePointManager_t745663000____CertificatePolicy_PropertyInfo(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m834417715(tmp, il2cpp_codegen_string_new_wrapper("Use ServerCertificateValidationCallback instead"), false, NULL);
	}
}
static void ServicePointManager_t745663000_CustomAttributesCacheGenerator_ServicePointManager_t745663000____CheckCertificateRevocationList_PropertyInfo(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t3487514020 * tmp = (MonoTODOAttribute_t3487514020 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m991492462(tmp, il2cpp_codegen_string_new_wrapper("CRL checks not implemented"), NULL);
	}
}
static void SocketAddress_t838303055_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t889804479 * tmp = (DefaultMemberAttribute_t889804479 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m2234856827(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void WebHeaderCollection_t3028142837_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t889804479 * tmp = (DefaultMemberAttribute_t889804479 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m2234856827(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[1];
		ComVisibleAttribute__ctor_m1789587486(tmp, true, NULL);
	}
}
static void WebProxy_t1169192840_CustomAttributesCacheGenerator_WebProxy_t1169192840____UseDefaultCredentials_PropertyInfo(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t3487514020 * tmp = (MonoTODOAttribute_t3487514020 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m991492462(tmp, il2cpp_codegen_string_new_wrapper("Does not affect Credentials, since CredentialCache.DefaultCredentials is not implemented."), NULL);
	}
}
static void WebRequest_t1365124353_CustomAttributesCacheGenerator_WebRequest_GetDefaultWebProxy_m1479642708(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t3487514020 * tmp = (MonoTODOAttribute_t3487514020 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m991492462(tmp, il2cpp_codegen_string_new_wrapper("Needs to respect Module, Proxy.AutoDetect, and Proxy.ScriptLocation config settings"), NULL);
	}
}
static void OpenFlags_t2370524385_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		FlagsAttribute_t859561169 * tmp = (FlagsAttribute_t859561169 *)cache->attributes[0];
		FlagsAttribute__ctor_m1848108622(tmp, NULL);
	}
}
static void PublicKey_t870392_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map9(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void X500DistinguishedName_t452415348_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t3487514020 * tmp = (MonoTODOAttribute_t3487514020 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m991492462(tmp, il2cpp_codegen_string_new_wrapper("Some X500DistinguishedNameFlags options aren't supported, like DoNotUsePlusSign, DoNotUseQuotes and ForceUTF8Encoding"), NULL);
	}
}
static void X500DistinguishedNameFlags_t2005802885_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		FlagsAttribute_t859561169 * tmp = (FlagsAttribute_t859561169 *)cache->attributes[0];
		FlagsAttribute__ctor_m1848108622(tmp, NULL);
	}
}
static void X509Certificate2_t4056456767_CustomAttributesCacheGenerator_X509Certificate2_GetNameInfo_m402390219(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t3487514020 * tmp = (MonoTODOAttribute_t3487514020 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m991492462(tmp, il2cpp_codegen_string_new_wrapper("always return String.Empty for UpnName, DnsFromAlternativeName and UrlName"), NULL);
	}
}
static void X509Certificate2_t4056456767_CustomAttributesCacheGenerator_X509Certificate2_Import_m3813388542(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t3487514020 * tmp = (MonoTODOAttribute_t3487514020 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m991492462(tmp, il2cpp_codegen_string_new_wrapper("missing KeyStorageFlags support"), NULL);
	}
}
static void X509Certificate2_t4056456767_CustomAttributesCacheGenerator_X509Certificate2_Verify_m1574874641(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t3487514020 * tmp = (MonoTODOAttribute_t3487514020 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m991492462(tmp, il2cpp_codegen_string_new_wrapper("by default this depends on the incomplete X509Chain"), NULL);
	}
}
static void X509Certificate2Collection_t1108969367_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t889804479 * tmp = (DefaultMemberAttribute_t889804479 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m2234856827(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void X509Certificate2Collection_t1108969367_CustomAttributesCacheGenerator_X509Certificate2Collection_AddRange_m1503879780(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t3487514020 * tmp = (MonoTODOAttribute_t3487514020 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m991492462(tmp, il2cpp_codegen_string_new_wrapper("Method isn't transactional (like documented)"), NULL);
	}
}
static void X509Certificate2Collection_t1108969367_CustomAttributesCacheGenerator_X509Certificate2Collection_Find_m1629908635(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t3487514020 * tmp = (MonoTODOAttribute_t3487514020 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m991492462(tmp, il2cpp_codegen_string_new_wrapper("Does not support X509FindType.FindByTemplateName, FindByApplicationPolicy and FindByCertificatePolicy"), NULL);
	}
}
static void X509CertificateCollection_t1197680765_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t889804479 * tmp = (DefaultMemberAttribute_t889804479 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m2234856827(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void X509Chain_t777637347_CustomAttributesCacheGenerator_U3CU3Ef__switchU24mapB(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void X509Chain_t777637347_CustomAttributesCacheGenerator_U3CU3Ef__switchU24mapC(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void X509Chain_t777637347_CustomAttributesCacheGenerator_U3CU3Ef__switchU24mapD(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void X509Chain_t777637347_CustomAttributesCacheGenerator_X509Chain_Build_m1140429528(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t3487514020 * tmp = (MonoTODOAttribute_t3487514020 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m991492462(tmp, il2cpp_codegen_string_new_wrapper("Not totally RFC3280 compliant, but neither is MS implementation..."), NULL);
	}
}
static void X509ChainElementCollection_t2081831987_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t889804479 * tmp = (DefaultMemberAttribute_t889804479 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m2234856827(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void X509ChainStatusFlags_t480677120_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		FlagsAttribute_t859561169 * tmp = (FlagsAttribute_t859561169 *)cache->attributes[0];
		FlagsAttribute__ctor_m1848108622(tmp, NULL);
	}
}
static void X509EnhancedKeyUsageExtension_t2099881051_CustomAttributesCacheGenerator_U3CU3Ef__switchU24mapE(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void X509ExtensionCollection_t650873211_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t889804479 * tmp = (DefaultMemberAttribute_t889804479 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m2234856827(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void X509KeyUsageFlags_t2461349531_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		FlagsAttribute_t859561169 * tmp = (FlagsAttribute_t859561169 *)cache->attributes[0];
		FlagsAttribute__ctor_m1848108622(tmp, NULL);
	}
}
static void X509Store_t1617430119_CustomAttributesCacheGenerator_U3CU3Ef__switchU24mapF(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void X509VerificationFlags_t2169036324_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		FlagsAttribute_t859561169 * tmp = (FlagsAttribute_t859561169 *)cache->attributes[0];
		FlagsAttribute__ctor_m1848108622(tmp, NULL);
	}
}
static void AsnEncodedData_t463456204_CustomAttributesCacheGenerator_U3CU3Ef__switchU24mapA(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void Oid_t3221867120_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map10(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void OidCollection_t3790243618_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t889804479 * tmp = (DefaultMemberAttribute_t889804479 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m2234856827(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void CaptureCollection_t1671345504_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t889804479 * tmp = (DefaultMemberAttribute_t889804479 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m2234856827(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void GroupCollection_t939014605_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t889804479 * tmp = (DefaultMemberAttribute_t889804479 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m2234856827(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void MatchCollection_t3718216671_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t889804479 * tmp = (DefaultMemberAttribute_t889804479 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m2234856827(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void RegexOptions_t2418259727_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		FlagsAttribute_t859561169 * tmp = (FlagsAttribute_t859561169 *)cache->attributes[0];
		FlagsAttribute__ctor_m1848108622(tmp, NULL);
	}
}
static void OpFlags_t378191910_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		FlagsAttribute_t859561169 * tmp = (FlagsAttribute_t859561169 *)cache->attributes[0];
		FlagsAttribute__ctor_m1848108622(tmp, NULL);
	}
}
static void IntervalCollection_t4130821325_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t889804479 * tmp = (DefaultMemberAttribute_t889804479 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m2234856827(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void ExpressionCollection_t238836340_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t889804479 * tmp = (DefaultMemberAttribute_t889804479 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m2234856827(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
extern const Il2CppType* UriTypeConverter_t3912970448_0_0_0_var;
extern const uint32_t Uri_t19570940_CustomAttributesCacheGenerator_MetadataUsageId;
static void Uri_t19570940_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Uri_t19570940_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		TypeConverterAttribute_t252469870 * tmp = (TypeConverterAttribute_t252469870 *)cache->attributes[0];
		TypeConverterAttribute__ctor_m4061167050(tmp, il2cpp_codegen_type_get_object(UriTypeConverter_t3912970448_0_0_0_var), NULL);
	}
}
static void Uri_t19570940_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map14(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void Uri_t19570940_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map15(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void Uri_t19570940_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map16(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void Uri_t19570940_CustomAttributesCacheGenerator_Uri__ctor_m3854873816(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m842106750(tmp, NULL);
	}
}
static void Uri_t19570940_CustomAttributesCacheGenerator_Uri_EscapeString_m1753508368(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m842106750(tmp, NULL);
	}
}
static void Uri_t19570940_CustomAttributesCacheGenerator_Uri_Unescape_m3356737110(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m842106750(tmp, NULL);
	}
}
static void UriParser_t1012511323_CustomAttributesCacheGenerator_UriParser_OnRegister_m4010407891(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t3487514020 * tmp = (MonoTODOAttribute_t3487514020 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m4004919844(tmp, NULL);
	}
}
static void U3CPrivateImplementationDetailsU3E_t1486305138_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void g_Mono_Security_Assembly_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AssemblyTitleAttribute_t92945912 * tmp = (AssemblyTitleAttribute_t92945912 *)cache->attributes[0];
		AssemblyTitleAttribute__ctor_m1696431446(tmp, il2cpp_codegen_string_new_wrapper("Mono.Security.dll"), NULL);
	}
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[1];
		CLSCompliantAttribute__ctor_m1113299407(tmp, true, NULL);
	}
	{
		AssemblyCompanyAttribute_t2851673381 * tmp = (AssemblyCompanyAttribute_t2851673381 *)cache->attributes[2];
		AssemblyCompanyAttribute__ctor_m1217508649(tmp, il2cpp_codegen_string_new_wrapper("MONO development team"), NULL);
	}
	{
		AssemblyCopyrightAttribute_t177123295 * tmp = (AssemblyCopyrightAttribute_t177123295 *)cache->attributes[3];
		AssemblyCopyrightAttribute__ctor_m2712202383(tmp, il2cpp_codegen_string_new_wrapper("(c) 2003-2004 Various Authors"), NULL);
	}
	{
		AssemblyDescriptionAttribute_t1018387888 * tmp = (AssemblyDescriptionAttribute_t1018387888 *)cache->attributes[4];
		AssemblyDescriptionAttribute__ctor_m3307088082(tmp, il2cpp_codegen_string_new_wrapper("Mono.Security.dll"), NULL);
	}
	{
		AssemblyProductAttribute_t1523443169 * tmp = (AssemblyProductAttribute_t1523443169 *)cache->attributes[5];
		AssemblyProductAttribute__ctor_m1807437213(tmp, il2cpp_codegen_string_new_wrapper("MONO CLI"), NULL);
	}
	{
		InternalsVisibleToAttribute_t1037732567 * tmp = (InternalsVisibleToAttribute_t1037732567 *)cache->attributes[6];
		InternalsVisibleToAttribute__ctor_m573685517(tmp, il2cpp_codegen_string_new_wrapper("System, PublicKey=00240000048000009400000006020000002400005253413100040000010001008D56C76F9E8649383049F383C44BE0EC204181822A6C31CF5EB7EF486944D032188EA1D3920763712CCB12D75FB77E9811149E6148E5D32FBAAB37611C1878DDC19E20EF135D0CB2CFF2BFEC3D115810C3D9069638FE4BE215DBF795861920E5AB6F7DB2E2CEEF136AC23D5DD2BF031700AEC232F6C6B1C785B4305C123B37AB"), NULL);
	}
	{
		RuntimeCompatibilityAttribute_t2430705542 * tmp = (RuntimeCompatibilityAttribute_t2430705542 *)cache->attributes[7];
		RuntimeCompatibilityAttribute__ctor_m1331212510(tmp, NULL);
		RuntimeCompatibilityAttribute_set_WrapNonExceptionThrows_m2174793351(tmp, true, NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[8];
		ComVisibleAttribute__ctor_m1789587486(tmp, false, NULL);
	}
	{
		NeutralResourcesLanguageAttribute_t3267676636 * tmp = (NeutralResourcesLanguageAttribute_t3267676636 *)cache->attributes[9];
		NeutralResourcesLanguageAttribute__ctor_m1145808404(tmp, il2cpp_codegen_string_new_wrapper("en-US"), NULL);
	}
	{
		AssemblyDelaySignAttribute_t2705758496 * tmp = (AssemblyDelaySignAttribute_t2705758496 *)cache->attributes[10];
		AssemblyDelaySignAttribute__ctor_m793760213(tmp, true, NULL);
	}
	{
		AssemblyKeyFileAttribute_t605245443 * tmp = (AssemblyKeyFileAttribute_t605245443 *)cache->attributes[11];
		AssemblyKeyFileAttribute__ctor_m1072556611(tmp, il2cpp_codegen_string_new_wrapper("../mono.pub"), NULL);
	}
}
static void BigInteger_t925946153_CustomAttributesCacheGenerator_BigInteger__ctor_m4013661868(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void BigInteger_t925946153_CustomAttributesCacheGenerator_BigInteger__ctor_m3239748086(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void BigInteger_t925946153_CustomAttributesCacheGenerator_BigInteger__ctor_m3787562545(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void BigInteger_t925946153_CustomAttributesCacheGenerator_BigInteger_SetBit_m426619300(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void BigInteger_t925946153_CustomAttributesCacheGenerator_BigInteger_SetBit_m576108355(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void BigInteger_t925946153_CustomAttributesCacheGenerator_BigInteger_ToString_m1842353154(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void BigInteger_t925946153_CustomAttributesCacheGenerator_BigInteger_ToString_m2878297110(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void BigInteger_t925946153_CustomAttributesCacheGenerator_BigInteger_op_Implicit_m622924526(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void BigInteger_t925946153_CustomAttributesCacheGenerator_BigInteger_op_Modulus_m2895726170(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void BigInteger_t925946153_CustomAttributesCacheGenerator_BigInteger_op_Equality_m2683055762(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void BigInteger_t925946153_CustomAttributesCacheGenerator_BigInteger_op_Inequality_m744282323(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void ModulusRing_t80355992_CustomAttributesCacheGenerator_ModulusRing_Pow_m661630322(CustomAttributesCache* cache)
{
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[0];
		CLSCompliantAttribute__ctor_m1113299407(tmp, false, NULL);
	}
}
static void ASN1_t924533536_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t889804479 * tmp = (DefaultMemberAttribute_t889804479 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m2234856827(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void PKCS12_t1362584795_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map5(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void PKCS12_t1362584795_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map6(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void PKCS12_t1362584795_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map7(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void PKCS12_t1362584795_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map8(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void PKCS12_t1362584795_CustomAttributesCacheGenerator_U3CU3Ef__switchU24mapC(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void X509Certificate_t324051958_CustomAttributesCacheGenerator_U3CU3Ef__switchU24mapF(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void X509Certificate_t324051958_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map10(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void X509Certificate_t324051958_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map11(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void X509CertificateCollection_t3592472866_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t889804479 * tmp = (DefaultMemberAttribute_t889804479 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m2234856827(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void X509ChainStatusFlags_t2843686920_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		FlagsAttribute_t859561169 * tmp = (FlagsAttribute_t859561169 *)cache->attributes[0];
		FlagsAttribute__ctor_m1848108622(tmp, NULL);
	}
}
static void X509Crl_t1699034837_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t889804479 * tmp = (DefaultMemberAttribute_t889804479 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m2234856827(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void X509Crl_t1699034837_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map13(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void X509ExtensionCollection_t1640144840_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t889804479 * tmp = (DefaultMemberAttribute_t889804479 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m2234856827(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void ExtendedKeyUsageExtension_t3816993686_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map14(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void KeyUsages_t530589947_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		FlagsAttribute_t859561169 * tmp = (FlagsAttribute_t859561169 *)cache->attributes[0];
		FlagsAttribute__ctor_m1848108622(tmp, NULL);
	}
}
static void CertTypes_t3955735183_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		FlagsAttribute_t859561169 * tmp = (FlagsAttribute_t859561169 *)cache->attributes[0];
		FlagsAttribute__ctor_m1848108622(tmp, NULL);
	}
}
static void CipherSuiteCollection_t2431504453_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t889804479 * tmp = (DefaultMemberAttribute_t889804479 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m2234856827(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void HttpsClientStream_t3823629320_CustomAttributesCacheGenerator_U3CU3Ef__amU24cache2(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void HttpsClientStream_t3823629320_CustomAttributesCacheGenerator_U3CU3Ef__amU24cache3(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void HttpsClientStream_t3823629320_CustomAttributesCacheGenerator_HttpsClientStream_U3CHttpsClientStreamU3Em__0_m3176353714(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void HttpsClientStream_t3823629320_CustomAttributesCacheGenerator_HttpsClientStream_U3CHttpsClientStreamU3Em__1_m4293802471(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void RSASslSignatureDeformatter_t389653629_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map15(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void RSASslSignatureFormatter_t1282301050_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map16(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void SecurityProtocolType_t155967584_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		FlagsAttribute_t859561169 * tmp = (FlagsAttribute_t859561169 *)cache->attributes[0];
		FlagsAttribute__ctor_m1848108622(tmp, NULL);
	}
}
static void U3CPrivateImplementationDetailsU3E_t1486305139_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void g_System_Core_Assembly_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		SatelliteContractVersionAttribute_t2989984391 * tmp = (SatelliteContractVersionAttribute_t2989984391 *)cache->attributes[0];
		SatelliteContractVersionAttribute__ctor_m2605651717(tmp, il2cpp_codegen_string_new_wrapper("2.0.5.0"), NULL);
	}
	{
		AssemblyCopyrightAttribute_t177123295 * tmp = (AssemblyCopyrightAttribute_t177123295 *)cache->attributes[1];
		AssemblyCopyrightAttribute__ctor_m2712202383(tmp, il2cpp_codegen_string_new_wrapper("(c) various MONO Authors"), NULL);
	}
	{
		AssemblyFileVersionAttribute_t2897687916 * tmp = (AssemblyFileVersionAttribute_t2897687916 *)cache->attributes[2];
		AssemblyFileVersionAttribute__ctor_m2026149866(tmp, il2cpp_codegen_string_new_wrapper("3.0.40818.0"), NULL);
	}
	{
		AssemblyInformationalVersionAttribute_t3037389657 * tmp = (AssemblyInformationalVersionAttribute_t3037389657 *)cache->attributes[3];
		AssemblyInformationalVersionAttribute__ctor_m376831533(tmp, il2cpp_codegen_string_new_wrapper("3.0.40818.0"), NULL);
	}
	{
		AssemblyDefaultAliasAttribute_t1774139159 * tmp = (AssemblyDefaultAliasAttribute_t1774139159 *)cache->attributes[4];
		AssemblyDefaultAliasAttribute__ctor_m746891723(tmp, il2cpp_codegen_string_new_wrapper("System.Core.dll"), NULL);
	}
	{
		AssemblyDescriptionAttribute_t1018387888 * tmp = (AssemblyDescriptionAttribute_t1018387888 *)cache->attributes[5];
		AssemblyDescriptionAttribute__ctor_m3307088082(tmp, il2cpp_codegen_string_new_wrapper("System.Core.dll"), NULL);
	}
	{
		AssemblyProductAttribute_t1523443169 * tmp = (AssemblyProductAttribute_t1523443169 *)cache->attributes[6];
		AssemblyProductAttribute__ctor_m1807437213(tmp, il2cpp_codegen_string_new_wrapper("MONO Common language infrastructure"), NULL);
	}
	{
		AssemblyCompanyAttribute_t2851673381 * tmp = (AssemblyCompanyAttribute_t2851673381 *)cache->attributes[7];
		AssemblyCompanyAttribute__ctor_m1217508649(tmp, il2cpp_codegen_string_new_wrapper("MONO development team"), NULL);
	}
	{
		CompilationRelaxationsAttribute_t238494011 * tmp = (CompilationRelaxationsAttribute_t238494011 *)cache->attributes[8];
		CompilationRelaxationsAttribute__ctor_m2800984288(tmp, 8LL, NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[9];
		ComVisibleAttribute__ctor_m1789587486(tmp, false, NULL);
	}
	{
		RuntimeCompatibilityAttribute_t2430705542 * tmp = (RuntimeCompatibilityAttribute_t2430705542 *)cache->attributes[10];
		RuntimeCompatibilityAttribute__ctor_m1331212510(tmp, NULL);
		RuntimeCompatibilityAttribute_set_WrapNonExceptionThrows_m2174793351(tmp, true, NULL);
	}
	{
		DebuggableAttribute_t994551506 * tmp = (DebuggableAttribute_t994551506 *)cache->attributes[11];
		DebuggableAttribute__ctor_m1065484869(tmp, 2LL, NULL);
	}
	{
		CLSCompliantAttribute_t809966061 * tmp = (CLSCompliantAttribute_t809966061 *)cache->attributes[12];
		CLSCompliantAttribute__ctor_m1113299407(tmp, true, NULL);
	}
	{
		NeutralResourcesLanguageAttribute_t3267676636 * tmp = (NeutralResourcesLanguageAttribute_t3267676636 *)cache->attributes[13];
		NeutralResourcesLanguageAttribute__ctor_m1145808404(tmp, il2cpp_codegen_string_new_wrapper("en-US"), NULL);
	}
	{
		AssemblyKeyFileAttribute_t605245443 * tmp = (AssemblyKeyFileAttribute_t605245443 *)cache->attributes[14];
		AssemblyKeyFileAttribute__ctor_m1072556611(tmp, il2cpp_codegen_string_new_wrapper("../silverlight.pub"), NULL);
	}
	{
		AssemblyDelaySignAttribute_t2705758496 * tmp = (AssemblyDelaySignAttribute_t2705758496 *)cache->attributes[15];
		AssemblyDelaySignAttribute__ctor_m793760213(tmp, true, NULL);
	}
	{
		ExtensionAttribute_t1840441203 * tmp = (ExtensionAttribute_t1840441203 *)cache->attributes[16];
		ExtensionAttribute__ctor_m1028297080(tmp, NULL);
	}
	{
		AssemblyTitleAttribute_t92945912 * tmp = (AssemblyTitleAttribute_t92945912 *)cache->attributes[17];
		AssemblyTitleAttribute__ctor_m1696431446(tmp, il2cpp_codegen_string_new_wrapper("System.Core.dll"), NULL);
	}
}
static void ExtensionAttribute_t1840441203_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 69LL, NULL);
	}
}
static void Locale_t4255929017_CustomAttributesCacheGenerator_Locale_GetText_m512920887____args1(CustomAttributesCache* cache)
{
	{
		ParamArrayAttribute_t2144993728 * tmp = (ParamArrayAttribute_t2144993728 *)cache->attributes[0];
		ParamArrayAttribute__ctor_m2215984741(tmp, NULL);
	}
}
static void MonoTODOAttribute_t3487514021_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 32767LL, NULL);
		AttributeUsageAttribute_set_AllowMultiple_m683830749(tmp, true, NULL);
	}
}
static void HashSet_1_t2624254809_CustomAttributesCacheGenerator_HashSet_1_GetObjectData_m2015489021(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t3487514021 * tmp = (MonoTODOAttribute_t3487514021 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m1425119999(tmp, NULL);
	}
}
static void HashSet_1_t2624254809_CustomAttributesCacheGenerator_HashSet_1_OnDeserialization_m627602129(CustomAttributesCache* cache)
{
	{
		MonoTODOAttribute_t3487514021 * tmp = (MonoTODOAttribute_t3487514021 *)cache->attributes[0];
		MonoTODOAttribute__ctor_m1425119999(tmp, NULL);
	}
}
static void Enumerable_t2148412300_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ExtensionAttribute_t1840441203 * tmp = (ExtensionAttribute_t1840441203 *)cache->attributes[0];
		ExtensionAttribute__ctor_m1028297080(tmp, NULL);
	}
}
static void Enumerable_t2148412300_CustomAttributesCacheGenerator_Enumerable_Where_m2409552823(CustomAttributesCache* cache)
{
	{
		ExtensionAttribute_t1840441203 * tmp = (ExtensionAttribute_t1840441203 *)cache->attributes[0];
		ExtensionAttribute__ctor_m1028297080(tmp, NULL);
	}
}
static void Enumerable_t2148412300_CustomAttributesCacheGenerator_Enumerable_CreateWhereIterator_m2714912225(CustomAttributesCache* cache)
{
	{
		DebuggerHiddenAttribute_t638884887 * tmp = (DebuggerHiddenAttribute_t638884887 *)cache->attributes[0];
		DebuggerHiddenAttribute__ctor_m2012788180(tmp, NULL);
	}
}
static void U3CCreateWhereIteratorU3Ec__Iterator1D_1_t2523986802_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void U3CCreateWhereIteratorU3Ec__Iterator1D_1_t2523986802_CustomAttributesCacheGenerator_U3CCreateWhereIteratorU3Ec__Iterator1D_1_System_Collections_Generic_IEnumeratorU3CTSourceU3E_get_Current_m517722874(CustomAttributesCache* cache)
{
	{
		DebuggerHiddenAttribute_t638884887 * tmp = (DebuggerHiddenAttribute_t638884887 *)cache->attributes[0];
		DebuggerHiddenAttribute__ctor_m2012788180(tmp, NULL);
	}
}
static void U3CCreateWhereIteratorU3Ec__Iterator1D_1_t2523986802_CustomAttributesCacheGenerator_U3CCreateWhereIteratorU3Ec__Iterator1D_1_System_Collections_IEnumerator_get_Current_m1354814095(CustomAttributesCache* cache)
{
	{
		DebuggerHiddenAttribute_t638884887 * tmp = (DebuggerHiddenAttribute_t638884887 *)cache->attributes[0];
		DebuggerHiddenAttribute__ctor_m2012788180(tmp, NULL);
	}
}
static void U3CCreateWhereIteratorU3Ec__Iterator1D_1_t2523986802_CustomAttributesCacheGenerator_U3CCreateWhereIteratorU3Ec__Iterator1D_1_System_Collections_IEnumerable_GetEnumerator_m3687475306(CustomAttributesCache* cache)
{
	{
		DebuggerHiddenAttribute_t638884887 * tmp = (DebuggerHiddenAttribute_t638884887 *)cache->attributes[0];
		DebuggerHiddenAttribute__ctor_m2012788180(tmp, NULL);
	}
}
static void U3CCreateWhereIteratorU3Ec__Iterator1D_1_t2523986802_CustomAttributesCacheGenerator_U3CCreateWhereIteratorU3Ec__Iterator1D_1_System_Collections_Generic_IEnumerableU3CTSourceU3E_GetEnumerator_m2392330777(CustomAttributesCache* cache)
{
	{
		DebuggerHiddenAttribute_t638884887 * tmp = (DebuggerHiddenAttribute_t638884887 *)cache->attributes[0];
		DebuggerHiddenAttribute__ctor_m2012788180(tmp, NULL);
	}
}
static void U3CCreateWhereIteratorU3Ec__Iterator1D_1_t2523986802_CustomAttributesCacheGenerator_U3CCreateWhereIteratorU3Ec__Iterator1D_1_Dispose_m3152287270(CustomAttributesCache* cache)
{
	{
		DebuggerHiddenAttribute_t638884887 * tmp = (DebuggerHiddenAttribute_t638884887 *)cache->attributes[0];
		DebuggerHiddenAttribute__ctor_m2012788180(tmp, NULL);
	}
}
static void U3CCreateWhereIteratorU3Ec__Iterator1D_1_t2523986802_CustomAttributesCacheGenerator_U3CCreateWhereIteratorU3Ec__Iterator1D_1_Reset_m3335334056(CustomAttributesCache* cache)
{
	{
		DebuggerHiddenAttribute_t638884887 * tmp = (DebuggerHiddenAttribute_t638884887 *)cache->attributes[0];
		DebuggerHiddenAttribute__ctor_m2012788180(tmp, NULL);
	}
}
static void U3CPrivateImplementationDetailsU3E_t1486305140_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void g_UnityEngine_Assembly_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		InternalsVisibleToAttribute_t1037732567 * tmp = (InternalsVisibleToAttribute_t1037732567 *)cache->attributes[0];
		InternalsVisibleToAttribute__ctor_m573685517(tmp, il2cpp_codegen_string_new_wrapper("UnityEngine.TerrainPhysics"), NULL);
	}
	{
		InternalsVisibleToAttribute_t1037732567 * tmp = (InternalsVisibleToAttribute_t1037732567 *)cache->attributes[1];
		InternalsVisibleToAttribute__ctor_m573685517(tmp, il2cpp_codegen_string_new_wrapper("UnityEngine.Networking"), NULL);
	}
	{
		InternalsVisibleToAttribute_t1037732567 * tmp = (InternalsVisibleToAttribute_t1037732567 *)cache->attributes[2];
		InternalsVisibleToAttribute__ctor_m573685517(tmp, il2cpp_codegen_string_new_wrapper("UnityEngine.Terrain"), NULL);
	}
	{
		InternalsVisibleToAttribute_t1037732567 * tmp = (InternalsVisibleToAttribute_t1037732567 *)cache->attributes[3];
		InternalsVisibleToAttribute__ctor_m573685517(tmp, il2cpp_codegen_string_new_wrapper("Unity.Automation"), NULL);
	}
	{
		InternalsVisibleToAttribute_t1037732567 * tmp = (InternalsVisibleToAttribute_t1037732567 *)cache->attributes[4];
		InternalsVisibleToAttribute__ctor_m573685517(tmp, il2cpp_codegen_string_new_wrapper("UnityEngine.Physics"), NULL);
	}
	{
		InternalsVisibleToAttribute_t1037732567 * tmp = (InternalsVisibleToAttribute_t1037732567 *)cache->attributes[5];
		InternalsVisibleToAttribute__ctor_m573685517(tmp, il2cpp_codegen_string_new_wrapper("UnityEngine.Advertisements"), NULL);
	}
	{
		InternalsVisibleToAttribute_t1037732567 * tmp = (InternalsVisibleToAttribute_t1037732567 *)cache->attributes[6];
		InternalsVisibleToAttribute__ctor_m573685517(tmp, il2cpp_codegen_string_new_wrapper("UnityEngine.Purchasing"), NULL);
	}
	{
		InternalsVisibleToAttribute_t1037732567 * tmp = (InternalsVisibleToAttribute_t1037732567 *)cache->attributes[7];
		InternalsVisibleToAttribute__ctor_m573685517(tmp, il2cpp_codegen_string_new_wrapper("UnityEngine.Analytics"), NULL);
	}
	{
		InternalsVisibleToAttribute_t1037732567 * tmp = (InternalsVisibleToAttribute_t1037732567 *)cache->attributes[8];
		InternalsVisibleToAttribute__ctor_m573685517(tmp, il2cpp_codegen_string_new_wrapper("UnityEngine.Cloud"), NULL);
	}
	{
		InternalsVisibleToAttribute_t1037732567 * tmp = (InternalsVisibleToAttribute_t1037732567 *)cache->attributes[9];
		InternalsVisibleToAttribute__ctor_m573685517(tmp, il2cpp_codegen_string_new_wrapper("UnityEngine.Cloud.Service"), NULL);
	}
	{
		RuntimeCompatibilityAttribute_t2430705542 * tmp = (RuntimeCompatibilityAttribute_t2430705542 *)cache->attributes[10];
		RuntimeCompatibilityAttribute__ctor_m1331212510(tmp, NULL);
		RuntimeCompatibilityAttribute_set_WrapNonExceptionThrows_m2174793351(tmp, true, NULL);
	}
	{
		InternalsVisibleToAttribute_t1037732567 * tmp = (InternalsVisibleToAttribute_t1037732567 *)cache->attributes[11];
		InternalsVisibleToAttribute__ctor_m573685517(tmp, il2cpp_codegen_string_new_wrapper("Unity.IntegrationTests.UnityAnalytics"), NULL);
	}
	{
		InternalsVisibleToAttribute_t1037732567 * tmp = (InternalsVisibleToAttribute_t1037732567 *)cache->attributes[12];
		InternalsVisibleToAttribute__ctor_m573685517(tmp, il2cpp_codegen_string_new_wrapper("Unity.IntegrationTests"), NULL);
	}
	{
		InternalsVisibleToAttribute_t1037732567 * tmp = (InternalsVisibleToAttribute_t1037732567 *)cache->attributes[13];
		InternalsVisibleToAttribute__ctor_m573685517(tmp, il2cpp_codegen_string_new_wrapper("Unity.RuntimeTests"), NULL);
	}
	{
		InternalsVisibleToAttribute_t1037732567 * tmp = (InternalsVisibleToAttribute_t1037732567 *)cache->attributes[14];
		InternalsVisibleToAttribute__ctor_m573685517(tmp, il2cpp_codegen_string_new_wrapper("Unity.IntegrationTests.Framework"), NULL);
	}
	{
		InternalsVisibleToAttribute_t1037732567 * tmp = (InternalsVisibleToAttribute_t1037732567 *)cache->attributes[15];
		InternalsVisibleToAttribute__ctor_m573685517(tmp, il2cpp_codegen_string_new_wrapper("Unity.DeploymentTests.Services"), NULL);
	}
	{
		ExtensionAttribute_t1840441203 * tmp = (ExtensionAttribute_t1840441203 *)cache->attributes[16];
		ExtensionAttribute__ctor_m1028297080(tmp, NULL);
	}
	{
		DebuggableAttribute_t994551506 * tmp = (DebuggableAttribute_t994551506 *)cache->attributes[17];
		DebuggableAttribute__ctor_m1065484869(tmp, 258LL, NULL);
	}
	{
		InternalsVisibleToAttribute_t1037732567 * tmp = (InternalsVisibleToAttribute_t1037732567 *)cache->attributes[18];
		InternalsVisibleToAttribute__ctor_m573685517(tmp, il2cpp_codegen_string_new_wrapper("Unity.RuntimeTests.Framework"), NULL);
	}
	{
		InternalsVisibleToAttribute_t1037732567 * tmp = (InternalsVisibleToAttribute_t1037732567 *)cache->attributes[19];
		InternalsVisibleToAttribute__ctor_m573685517(tmp, il2cpp_codegen_string_new_wrapper("Unity.RuntimeTests.Framework.Tests"), NULL);
	}
}
static void Application_t354826772_CustomAttributesCacheGenerator_Application_CallLogCallback_m3408386792(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void Application_t354826772_CustomAttributesCacheGenerator_Application_LoadLevel_m3450161284(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m2711473620(tmp, il2cpp_codegen_string_new_wrapper("Use SceneManager.LoadScene"), NULL);
	}
}
static void Application_t354826772_CustomAttributesCacheGenerator_Application_t354826772____platform_PropertyInfo(CustomAttributesCache* cache)
{
	{
		ThreadAndSerializationSafe_t2122816804 * tmp = (ThreadAndSerializationSafe_t2122816804 *)cache->attributes[0];
		ThreadAndSerializationSafe__ctor_m84326599(tmp, NULL);
	}
}
static void AssetBundleCreateRequest_t1038783543_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void AssetBundleRequest_t2674559435_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void AsyncOperation_t3814632279_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void AsyncOperation_t3814632279_CustomAttributesCacheGenerator_AsyncOperation_InternalDestroy_m3312061823(CustomAttributesCache* cache)
{
	{
		ThreadAndSerializationSafe_t2122816804 * tmp = (ThreadAndSerializationSafe_t2122816804 *)cache->attributes[0];
		ThreadAndSerializationSafe__ctor_m84326599(tmp, NULL);
	}
}
static void WaitForSeconds_t3839502067_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void WaitForFixedUpdate_t3968615785_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void WaitForEndOfFrame_t1785723201_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void Coroutine_t2299508840_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void Coroutine_t2299508840_CustomAttributesCacheGenerator_Coroutine_ReleaseCoroutine_m833118514(CustomAttributesCache* cache)
{
	{
		ThreadAndSerializationSafe_t2122816804 * tmp = (ThreadAndSerializationSafe_t2122816804 *)cache->attributes[0];
		ThreadAndSerializationSafe__ctor_m84326599(tmp, NULL);
	}
}
static void ScriptableObject_t1975622470_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void ScriptableObject_t1975622470_CustomAttributesCacheGenerator_ScriptableObject_Internal_CreateScriptableObject_m1778903390(CustomAttributesCache* cache)
{
	{
		ThreadAndSerializationSafe_t2122816804 * tmp = (ThreadAndSerializationSafe_t2122816804 *)cache->attributes[0];
		ThreadAndSerializationSafe__ctor_m84326599(tmp, NULL);
	}
}
static void ScriptableObject_t1975622470_CustomAttributesCacheGenerator_ScriptableObject_Internal_CreateScriptableObject_m1778903390____self0(CustomAttributesCache* cache)
{
	{
		WritableAttribute_t3715198420 * tmp = (WritableAttribute_t3715198420 *)cache->attributes[0];
		WritableAttribute__ctor_m761932763(tmp, NULL);
	}
}
static void Camera_t189460977_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		UsedByNativeCodeAttribute_t3212052468 * tmp = (UsedByNativeCodeAttribute_t3212052468 *)cache->attributes[0];
		UsedByNativeCodeAttribute__ctor_m2459832290(tmp, NULL);
	}
}
static void Camera_t189460977_CustomAttributesCacheGenerator_Camera_FireOnPreCull_m1679634170(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void Camera_t189460977_CustomAttributesCacheGenerator_Camera_FireOnPreRender_m24116662(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void Camera_t189460977_CustomAttributesCacheGenerator_Camera_FireOnPostRender_m94860165(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void Camera_t189460977_CustomAttributesCacheGenerator_Camera_RaycastTry_m3412198936(CustomAttributesCache* cache)
{
	{
		ExcludeFromDocsAttribute_t665825653 * tmp = (ExcludeFromDocsAttribute_t665825653 *)cache->attributes[0];
		ExcludeFromDocsAttribute__ctor_m1684225175(tmp, NULL);
	}
}
static void Component_t3819376471_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void Component_t3819376471_CustomAttributesCacheGenerator_Component_GetComponent_m4225719715(CustomAttributesCache* cache)
{
	{
		TypeInferenceRuleAttribute_t1390152093 * tmp = (TypeInferenceRuleAttribute_t1390152093 *)cache->attributes[0];
		TypeInferenceRuleAttribute__ctor_m599630929(tmp, 0LL, NULL);
	}
}
static void Component_t3819376471_CustomAttributesCacheGenerator_Component_GetComponent_m3720754210(CustomAttributesCache* cache)
{
	{
		SecuritySafeCriticalAttribute_t372031554 * tmp = (SecuritySafeCriticalAttribute_t372031554 *)cache->attributes[0];
		SecuritySafeCriticalAttribute__ctor_m2508714287(tmp, NULL);
	}
}
static void Component_t3819376471_CustomAttributesCacheGenerator_Component_GetComponentInChildren_m3925629424(CustomAttributesCache* cache)
{
	{
		TypeInferenceRuleAttribute_t1390152093 * tmp = (TypeInferenceRuleAttribute_t1390152093 *)cache->attributes[0];
		TypeInferenceRuleAttribute__ctor_m599630929(tmp, 0LL, NULL);
	}
}
static void Component_t3819376471_CustomAttributesCacheGenerator_Component_GetComponentInChildren_m3985003615(CustomAttributesCache* cache)
{
	{
		TypeInferenceRuleAttribute_t1390152093 * tmp = (TypeInferenceRuleAttribute_t1390152093 *)cache->attributes[0];
		TypeInferenceRuleAttribute__ctor_m599630929(tmp, 0LL, NULL);
	}
}
static void Component_t3819376471_CustomAttributesCacheGenerator_Component_GetComponentInChildren_m3417738402(CustomAttributesCache* cache)
{
	{
		ExcludeFromDocsAttribute_t665825653 * tmp = (ExcludeFromDocsAttribute_t665825653 *)cache->attributes[0];
		ExcludeFromDocsAttribute__ctor_m1684225175(tmp, NULL);
	}
}
static void Component_t3819376471_CustomAttributesCacheGenerator_Component_GetComponentInChildren_m2730561359____includeInactive0(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1027170048 * tmp = (DefaultValueAttribute_t1027170048 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m4191464344(tmp, il2cpp_codegen_string_new_wrapper("false"), NULL);
	}
}
static void Component_t3819376471_CustomAttributesCacheGenerator_Component_GetComponentsInChildren_m843288020(CustomAttributesCache* cache)
{
	{
		ExcludeFromDocsAttribute_t665825653 * tmp = (ExcludeFromDocsAttribute_t665825653 *)cache->attributes[0];
		ExcludeFromDocsAttribute__ctor_m1684225175(tmp, NULL);
	}
}
static void Component_t3819376471_CustomAttributesCacheGenerator_Component_GetComponentsInChildren_m908027537____includeInactive1(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1027170048 * tmp = (DefaultValueAttribute_t1027170048 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m4191464344(tmp, il2cpp_codegen_string_new_wrapper("false"), NULL);
	}
}
static void Component_t3819376471_CustomAttributesCacheGenerator_Component_GetComponentInParent_m2799402500(CustomAttributesCache* cache)
{
	{
		TypeInferenceRuleAttribute_t1390152093 * tmp = (TypeInferenceRuleAttribute_t1390152093 *)cache->attributes[0];
		TypeInferenceRuleAttribute__ctor_m599630929(tmp, 0LL, NULL);
	}
}
static void Component_t3819376471_CustomAttributesCacheGenerator_Component_GetComponentsInParent_m4192184629(CustomAttributesCache* cache)
{
	{
		ExcludeFromDocsAttribute_t665825653 * tmp = (ExcludeFromDocsAttribute_t665825653 *)cache->attributes[0];
		ExcludeFromDocsAttribute__ctor_m1684225175(tmp, NULL);
	}
}
static void Component_t3819376471_CustomAttributesCacheGenerator_Component_GetComponentsInParent_m1920178904____includeInactive1(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1027170048 * tmp = (DefaultValueAttribute_t1027170048 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m4191464344(tmp, il2cpp_codegen_string_new_wrapper("false"), NULL);
	}
}
static void Component_t3819376471_CustomAttributesCacheGenerator_Component_SendMessageUpwards_m2584088787____value1(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1027170048 * tmp = (DefaultValueAttribute_t1027170048 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m4191464344(tmp, il2cpp_codegen_string_new_wrapper("null"), NULL);
	}
}
static void Component_t3819376471_CustomAttributesCacheGenerator_Component_SendMessageUpwards_m2584088787____options2(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1027170048 * tmp = (DefaultValueAttribute_t1027170048 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m4191464344(tmp, il2cpp_codegen_string_new_wrapper("SendMessageOptions.RequireReceiver"), NULL);
	}
}
static void Component_t3819376471_CustomAttributesCacheGenerator_Component_SendMessageUpwards_m325086847(CustomAttributesCache* cache)
{
	{
		ExcludeFromDocsAttribute_t665825653 * tmp = (ExcludeFromDocsAttribute_t665825653 *)cache->attributes[0];
		ExcludeFromDocsAttribute__ctor_m1684225175(tmp, NULL);
	}
}
static void Component_t3819376471_CustomAttributesCacheGenerator_Component_SendMessageUpwards_m2041012277(CustomAttributesCache* cache)
{
	{
		ExcludeFromDocsAttribute_t665825653 * tmp = (ExcludeFromDocsAttribute_t665825653 *)cache->attributes[0];
		ExcludeFromDocsAttribute__ctor_m1684225175(tmp, NULL);
	}
}
static void Component_t3819376471_CustomAttributesCacheGenerator_Component_SendMessage_m2241432133____value1(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1027170048 * tmp = (DefaultValueAttribute_t1027170048 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m4191464344(tmp, il2cpp_codegen_string_new_wrapper("null"), NULL);
	}
}
static void Component_t3819376471_CustomAttributesCacheGenerator_Component_SendMessage_m2241432133____options2(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1027170048 * tmp = (DefaultValueAttribute_t1027170048 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m4191464344(tmp, il2cpp_codegen_string_new_wrapper("SendMessageOptions.RequireReceiver"), NULL);
	}
}
static void Component_t3819376471_CustomAttributesCacheGenerator_Component_SendMessage_m913946877(CustomAttributesCache* cache)
{
	{
		ExcludeFromDocsAttribute_t665825653 * tmp = (ExcludeFromDocsAttribute_t665825653 *)cache->attributes[0];
		ExcludeFromDocsAttribute__ctor_m1684225175(tmp, NULL);
	}
}
static void Component_t3819376471_CustomAttributesCacheGenerator_Component_SendMessage_m3615678587(CustomAttributesCache* cache)
{
	{
		ExcludeFromDocsAttribute_t665825653 * tmp = (ExcludeFromDocsAttribute_t665825653 *)cache->attributes[0];
		ExcludeFromDocsAttribute__ctor_m1684225175(tmp, NULL);
	}
}
static void Component_t3819376471_CustomAttributesCacheGenerator_Component_BroadcastMessage_m2230184532____parameter1(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1027170048 * tmp = (DefaultValueAttribute_t1027170048 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m4191464344(tmp, il2cpp_codegen_string_new_wrapper("null"), NULL);
	}
}
static void Component_t3819376471_CustomAttributesCacheGenerator_Component_BroadcastMessage_m2230184532____options2(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1027170048 * tmp = (DefaultValueAttribute_t1027170048 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m4191464344(tmp, il2cpp_codegen_string_new_wrapper("SendMessageOptions.RequireReceiver"), NULL);
	}
}
static void Component_t3819376471_CustomAttributesCacheGenerator_Component_BroadcastMessage_m1308086896(CustomAttributesCache* cache)
{
	{
		ExcludeFromDocsAttribute_t665825653 * tmp = (ExcludeFromDocsAttribute_t665825653 *)cache->attributes[0];
		ExcludeFromDocsAttribute__ctor_m1684225175(tmp, NULL);
	}
}
static void Component_t3819376471_CustomAttributesCacheGenerator_Component_BroadcastMessage_m1706240890(CustomAttributesCache* cache)
{
	{
		ExcludeFromDocsAttribute_t665825653 * tmp = (ExcludeFromDocsAttribute_t665825653 *)cache->attributes[0];
		ExcludeFromDocsAttribute__ctor_m1684225175(tmp, NULL);
	}
}
static void CullingGroup_t1091689465_CustomAttributesCacheGenerator_CullingGroup_SendEvents_m1292564468(CustomAttributesCache* cache)
{
	{
		SecuritySafeCriticalAttribute_t372031554 * tmp = (SecuritySafeCriticalAttribute_t372031554 *)cache->attributes[0];
		SecuritySafeCriticalAttribute__ctor_m2508714287(tmp, NULL);
	}
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[1];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void CullingGroup_t1091689465_CustomAttributesCacheGenerator_CullingGroup_FinalizerFailure_m3675513936(CustomAttributesCache* cache)
{
	{
		ThreadAndSerializationSafe_t2122816804 * tmp = (ThreadAndSerializationSafe_t2122816804 *)cache->attributes[0];
		ThreadAndSerializationSafe__ctor_m84326599(tmp, NULL);
	}
}
static void DebugLogHandler_t865810509_CustomAttributesCacheGenerator_DebugLogHandler_Internal_Log_m3491540823(CustomAttributesCache* cache)
{
	{
		ThreadAndSerializationSafe_t2122816804 * tmp = (ThreadAndSerializationSafe_t2122816804 *)cache->attributes[0];
		ThreadAndSerializationSafe__ctor_m84326599(tmp, NULL);
	}
}
static void DebugLogHandler_t865810509_CustomAttributesCacheGenerator_DebugLogHandler_Internal_Log_m3491540823____obj2(CustomAttributesCache* cache)
{
	{
		WritableAttribute_t3715198420 * tmp = (WritableAttribute_t3715198420 *)cache->attributes[0];
		WritableAttribute__ctor_m761932763(tmp, NULL);
	}
}
static void DebugLogHandler_t865810509_CustomAttributesCacheGenerator_DebugLogHandler_Internal_LogException_m317712981(CustomAttributesCache* cache)
{
	{
		ThreadAndSerializationSafe_t2122816804 * tmp = (ThreadAndSerializationSafe_t2122816804 *)cache->attributes[0];
		ThreadAndSerializationSafe__ctor_m84326599(tmp, NULL);
	}
}
static void DebugLogHandler_t865810509_CustomAttributesCacheGenerator_DebugLogHandler_Internal_LogException_m317712981____obj1(CustomAttributesCache* cache)
{
	{
		WritableAttribute_t3715198420 * tmp = (WritableAttribute_t3715198420 *)cache->attributes[0];
		WritableAttribute__ctor_m761932763(tmp, NULL);
	}
}
static void DebugLogHandler_t865810509_CustomAttributesCacheGenerator_DebugLogHandler_LogFormat_m177245518____args3(CustomAttributesCache* cache)
{
	{
		ParamArrayAttribute_t2144993728 * tmp = (ParamArrayAttribute_t2144993728 *)cache->attributes[0];
		ParamArrayAttribute__ctor_m2215984741(tmp, NULL);
	}
}
static void Debug_t1368543263_CustomAttributesCacheGenerator_Debug_LogErrorFormat_m60495267____args2(CustomAttributesCache* cache)
{
	{
		ParamArrayAttribute_t2144993728 * tmp = (ParamArrayAttribute_t2144993728 *)cache->attributes[0];
		ParamArrayAttribute__ctor_m2215984741(tmp, NULL);
	}
}
static void Debug_t1368543263_CustomAttributesCacheGenerator_Debug_LogWarningFormat_m79553173____args2(CustomAttributesCache* cache)
{
	{
		ParamArrayAttribute_t2144993728 * tmp = (ParamArrayAttribute_t2144993728 *)cache->attributes[0];
		ParamArrayAttribute__ctor_m2215984741(tmp, NULL);
	}
}
static void Display_t3666191348_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		UsedByNativeCodeAttribute_t3212052468 * tmp = (UsedByNativeCodeAttribute_t3212052468 *)cache->attributes[0];
		UsedByNativeCodeAttribute__ctor_m2459832290(tmp, NULL);
	}
}
static void Display_t3666191348_CustomAttributesCacheGenerator_Display_RecreateDisplayList_m3412638488(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void Display_t3666191348_CustomAttributesCacheGenerator_Display_FireDisplaysUpdated_m3557250167(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void GameObject_t1756533147_CustomAttributesCacheGenerator_GameObject_GetComponent_m306258075(CustomAttributesCache* cache)
{
	{
		TypeInferenceRuleAttribute_t1390152093 * tmp = (TypeInferenceRuleAttribute_t1390152093 *)cache->attributes[0];
		TypeInferenceRuleAttribute__ctor_m599630929(tmp, 0LL, NULL);
	}
}
static void GameObject_t1756533147_CustomAttributesCacheGenerator_GameObject_GetComponent_m1986025102(CustomAttributesCache* cache)
{
	{
		SecuritySafeCriticalAttribute_t372031554 * tmp = (SecuritySafeCriticalAttribute_t372031554 *)cache->attributes[0];
		SecuritySafeCriticalAttribute__ctor_m2508714287(tmp, NULL);
	}
}
static void GameObject_t1756533147_CustomAttributesCacheGenerator_GameObject_GetComponentInChildren_m4263325740(CustomAttributesCache* cache)
{
	{
		TypeInferenceRuleAttribute_t1390152093 * tmp = (TypeInferenceRuleAttribute_t1390152093 *)cache->attributes[0];
		TypeInferenceRuleAttribute__ctor_m599630929(tmp, 0LL, NULL);
	}
}
static void GameObject_t1756533147_CustomAttributesCacheGenerator_GameObject_GetComponentInChildren_m3844288190(CustomAttributesCache* cache)
{
	{
		ExcludeFromDocsAttribute_t665825653 * tmp = (ExcludeFromDocsAttribute_t665825653 *)cache->attributes[0];
		ExcludeFromDocsAttribute__ctor_m1684225175(tmp, NULL);
	}
}
static void GameObject_t1756533147_CustomAttributesCacheGenerator_GameObject_GetComponentInChildren_m252895367____includeInactive0(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1027170048 * tmp = (DefaultValueAttribute_t1027170048 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m4191464344(tmp, il2cpp_codegen_string_new_wrapper("false"), NULL);
	}
}
static void GameObject_t1756533147_CustomAttributesCacheGenerator_GameObject_GetComponentInParent_m1235194528(CustomAttributesCache* cache)
{
	{
		TypeInferenceRuleAttribute_t1390152093 * tmp = (TypeInferenceRuleAttribute_t1390152093 *)cache->attributes[0];
		TypeInferenceRuleAttribute__ctor_m599630929(tmp, 0LL, NULL);
	}
}
static void GameObject_t1756533147_CustomAttributesCacheGenerator_GameObject_GetComponentsInChildren_m993725821____includeInactive1(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1027170048 * tmp = (DefaultValueAttribute_t1027170048 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m4191464344(tmp, il2cpp_codegen_string_new_wrapper("false"), NULL);
	}
}
static void GameObject_t1756533147_CustomAttributesCacheGenerator_GameObject_GetComponentsInParent_m1568786844____includeInactive1(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1027170048 * tmp = (DefaultValueAttribute_t1027170048 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m4191464344(tmp, il2cpp_codegen_string_new_wrapper("false"), NULL);
	}
}
static void GameObject_t1756533147_CustomAttributesCacheGenerator_GameObject_SendMessage_m71956653____value1(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1027170048 * tmp = (DefaultValueAttribute_t1027170048 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m4191464344(tmp, il2cpp_codegen_string_new_wrapper("null"), NULL);
	}
}
static void GameObject_t1756533147_CustomAttributesCacheGenerator_GameObject_SendMessage_m71956653____options2(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1027170048 * tmp = (DefaultValueAttribute_t1027170048 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m4191464344(tmp, il2cpp_codegen_string_new_wrapper("SendMessageOptions.RequireReceiver"), NULL);
	}
}
static void GameObject_t1756533147_CustomAttributesCacheGenerator_GameObject_AddComponent_m3757565614(CustomAttributesCache* cache)
{
	{
		TypeInferenceRuleAttribute_t1390152093 * tmp = (TypeInferenceRuleAttribute_t1390152093 *)cache->attributes[0];
		TypeInferenceRuleAttribute__ctor_m599630929(tmp, 0LL, NULL);
	}
}
static void GameObject_t1756533147_CustomAttributesCacheGenerator_GameObject_Internal_CreateGameObject_m3428198595____mono0(CustomAttributesCache* cache)
{
	{
		WritableAttribute_t3715198420 * tmp = (WritableAttribute_t3715198420 *)cache->attributes[0];
		WritableAttribute__ctor_m761932763(tmp, NULL);
	}
}
static void Gradient_t3600583008_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void Gradient_t3600583008_CustomAttributesCacheGenerator_Gradient__ctor_m954570311(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void Gradient_t3600583008_CustomAttributesCacheGenerator_Gradient_Init_m4156899649(CustomAttributesCache* cache)
{
	{
		ThreadAndSerializationSafe_t2122816804 * tmp = (ThreadAndSerializationSafe_t2122816804 *)cache->attributes[0];
		ThreadAndSerializationSafe__ctor_m84326599(tmp, NULL);
	}
}
static void Gradient_t3600583008_CustomAttributesCacheGenerator_Gradient_Cleanup_m3573871739(CustomAttributesCache* cache)
{
	{
		ThreadAndSerializationSafe_t2122816804 * tmp = (ThreadAndSerializationSafe_t2122816804 *)cache->attributes[0];
		ThreadAndSerializationSafe__ctor_m84326599(tmp, NULL);
	}
}
static void Screen_t786852042_CustomAttributesCacheGenerator_Screen_t786852042____width_PropertyInfo(CustomAttributesCache* cache)
{
	{
		ThreadAndSerializationSafe_t2122816804 * tmp = (ThreadAndSerializationSafe_t2122816804 *)cache->attributes[0];
		ThreadAndSerializationSafe__ctor_m84326599(tmp, NULL);
	}
}
static void Screen_t786852042_CustomAttributesCacheGenerator_Screen_t786852042____height_PropertyInfo(CustomAttributesCache* cache)
{
	{
		ThreadAndSerializationSafe_t2122816804 * tmp = (ThreadAndSerializationSafe_t2122816804 *)cache->attributes[0];
		ThreadAndSerializationSafe__ctor_m84326599(tmp, NULL);
	}
}
static void RectOffset_t3387826427_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		UsedByNativeCodeAttribute_t3212052468 * tmp = (UsedByNativeCodeAttribute_t3212052468 *)cache->attributes[0];
		UsedByNativeCodeAttribute__ctor_m2459832290(tmp, NULL);
	}
}
static void RectOffset_t3387826427_CustomAttributesCacheGenerator_RectOffset_Init_m4361650(CustomAttributesCache* cache)
{
	{
		ThreadAndSerializationSafe_t2122816804 * tmp = (ThreadAndSerializationSafe_t2122816804 *)cache->attributes[0];
		ThreadAndSerializationSafe__ctor_m84326599(tmp, NULL);
	}
}
static void RectOffset_t3387826427_CustomAttributesCacheGenerator_RectOffset_Cleanup_m3198970074(CustomAttributesCache* cache)
{
	{
		ThreadAndSerializationSafe_t2122816804 * tmp = (ThreadAndSerializationSafe_t2122816804 *)cache->attributes[0];
		ThreadAndSerializationSafe__ctor_m84326599(tmp, NULL);
	}
}
static void TouchScreenKeyboard_t601950206_CustomAttributesCacheGenerator_TouchScreenKeyboard_Open_m2760130151(CustomAttributesCache* cache)
{
	{
		ExcludeFromDocsAttribute_t665825653 * tmp = (ExcludeFromDocsAttribute_t665825653 *)cache->attributes[0];
		ExcludeFromDocsAttribute__ctor_m1684225175(tmp, NULL);
	}
}
static void TouchScreenKeyboard_t601950206_CustomAttributesCacheGenerator_TouchScreenKeyboard_Open_m913506328(CustomAttributesCache* cache)
{
	{
		ExcludeFromDocsAttribute_t665825653 * tmp = (ExcludeFromDocsAttribute_t665825653 *)cache->attributes[0];
		ExcludeFromDocsAttribute__ctor_m1684225175(tmp, NULL);
	}
}
static void TouchScreenKeyboard_t601950206_CustomAttributesCacheGenerator_TouchScreenKeyboard_Open_m3410222954____keyboardType1(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1027170048 * tmp = (DefaultValueAttribute_t1027170048 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m4191464344(tmp, il2cpp_codegen_string_new_wrapper("TouchScreenKeyboardType.Default"), NULL);
	}
}
static void TouchScreenKeyboard_t601950206_CustomAttributesCacheGenerator_TouchScreenKeyboard_Open_m3410222954____autocorrection2(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1027170048 * tmp = (DefaultValueAttribute_t1027170048 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m4191464344(tmp, il2cpp_codegen_string_new_wrapper("true"), NULL);
	}
}
static void TouchScreenKeyboard_t601950206_CustomAttributesCacheGenerator_TouchScreenKeyboard_Open_m3410222954____multiline3(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1027170048 * tmp = (DefaultValueAttribute_t1027170048 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m4191464344(tmp, il2cpp_codegen_string_new_wrapper("false"), NULL);
	}
}
static void TouchScreenKeyboard_t601950206_CustomAttributesCacheGenerator_TouchScreenKeyboard_Open_m3410222954____secure4(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1027170048 * tmp = (DefaultValueAttribute_t1027170048 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m4191464344(tmp, il2cpp_codegen_string_new_wrapper("false"), NULL);
	}
}
static void TouchScreenKeyboard_t601950206_CustomAttributesCacheGenerator_TouchScreenKeyboard_Open_m3410222954____alert5(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1027170048 * tmp = (DefaultValueAttribute_t1027170048 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m4191464344(tmp, il2cpp_codegen_string_new_wrapper("false"), NULL);
	}
}
static void TouchScreenKeyboard_t601950206_CustomAttributesCacheGenerator_TouchScreenKeyboard_Open_m3410222954____textPlaceholder6(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1027170048 * tmp = (DefaultValueAttribute_t1027170048 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m4191464344(tmp, il2cpp_codegen_string_new_wrapper("\"\""), NULL);
	}
}
static void LayerMask_t3188175821_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		UsedByNativeCodeAttribute_t3212052468 * tmp = (UsedByNativeCodeAttribute_t3212052468 *)cache->attributes[0];
		UsedByNativeCodeAttribute__ctor_m2459832290(tmp, NULL);
	}
}
static void Vector3_t2243707580_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		UsedByNativeCodeAttribute_t3212052468 * tmp = (UsedByNativeCodeAttribute_t3212052468 *)cache->attributes[0];
		UsedByNativeCodeAttribute__ctor_m2459832290(tmp, NULL);
	}
	{
		DefaultMemberAttribute_t889804479 * tmp = (DefaultMemberAttribute_t889804479 *)cache->attributes[1];
		DefaultMemberAttribute__ctor_m2234856827(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void Quaternion_t4030073918_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		UsedByNativeCodeAttribute_t3212052468 * tmp = (UsedByNativeCodeAttribute_t3212052468 *)cache->attributes[0];
		UsedByNativeCodeAttribute__ctor_m2459832290(tmp, NULL);
	}
	{
		DefaultMemberAttribute_t889804479 * tmp = (DefaultMemberAttribute_t889804479 *)cache->attributes[1];
		DefaultMemberAttribute__ctor_m2234856827(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void Matrix4x4_t2933234003_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		UsedByNativeCodeAttribute_t3212052468 * tmp = (UsedByNativeCodeAttribute_t3212052468 *)cache->attributes[0];
		UsedByNativeCodeAttribute__ctor_m2459832290(tmp, NULL);
	}
	{
		DefaultMemberAttribute_t889804479 * tmp = (DefaultMemberAttribute_t889804479 *)cache->attributes[1];
		DefaultMemberAttribute__ctor_m2234856827(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void Bounds_t3033363703_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		UsedByNativeCodeAttribute_t3212052468 * tmp = (UsedByNativeCodeAttribute_t3212052468 *)cache->attributes[0];
		UsedByNativeCodeAttribute__ctor_m2459832290(tmp, NULL);
	}
}
static void Mathf_t2336485820_CustomAttributesCacheGenerator_Mathf_SmoothDamp_m1604773625____maxSpeed4(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1027170048 * tmp = (DefaultValueAttribute_t1027170048 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m4191464344(tmp, il2cpp_codegen_string_new_wrapper("Mathf.Infinity"), NULL);
	}
}
static void Mathf_t2336485820_CustomAttributesCacheGenerator_Mathf_SmoothDamp_m1604773625____deltaTime5(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1027170048 * tmp = (DefaultValueAttribute_t1027170048 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m4191464344(tmp, il2cpp_codegen_string_new_wrapper("Time.deltaTime"), NULL);
	}
}
static void Keyframe_t1449471340_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void AnimationCurve_t3306541151_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
	{
		DefaultMemberAttribute_t889804479 * tmp = (DefaultMemberAttribute_t889804479 *)cache->attributes[1];
		DefaultMemberAttribute__ctor_m2234856827(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void AnimationCurve_t3306541151_CustomAttributesCacheGenerator_AnimationCurve__ctor_m2814448007____keys0(CustomAttributesCache* cache)
{
	{
		ParamArrayAttribute_t2144993728 * tmp = (ParamArrayAttribute_t2144993728 *)cache->attributes[0];
		ParamArrayAttribute__ctor_m2215984741(tmp, NULL);
	}
}
static void AnimationCurve_t3306541151_CustomAttributesCacheGenerator_AnimationCurve__ctor_m3707994114(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void AnimationCurve_t3306541151_CustomAttributesCacheGenerator_AnimationCurve_Cleanup_m2190142678(CustomAttributesCache* cache)
{
	{
		ThreadAndSerializationSafe_t2122816804 * tmp = (ThreadAndSerializationSafe_t2122816804 *)cache->attributes[0];
		ThreadAndSerializationSafe__ctor_m84326599(tmp, NULL);
	}
}
static void AnimationCurve_t3306541151_CustomAttributesCacheGenerator_AnimationCurve_Init_m1486386337(CustomAttributesCache* cache)
{
	{
		ThreadAndSerializationSafe_t2122816804 * tmp = (ThreadAndSerializationSafe_t2122816804 *)cache->attributes[0];
		ThreadAndSerializationSafe__ctor_m84326599(tmp, NULL);
	}
}
static void Mesh_t1356156583_CustomAttributesCacheGenerator_Mesh_Internal_Create_m1486058998____mono0(CustomAttributesCache* cache)
{
	{
		WritableAttribute_t3715198420 * tmp = (WritableAttribute_t3715198420 *)cache->attributes[0];
		WritableAttribute__ctor_m761932763(tmp, NULL);
	}
}
static void Mesh_t1356156583_CustomAttributesCacheGenerator_Mesh_Clear_m3100797454____keepVertexLayout0(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1027170048 * tmp = (DefaultValueAttribute_t1027170048 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m4191464344(tmp, il2cpp_codegen_string_new_wrapper("true"), NULL);
	}
}
static void Mesh_t1356156583_CustomAttributesCacheGenerator_Mesh_Clear_m231813403(CustomAttributesCache* cache)
{
	{
		ExcludeFromDocsAttribute_t665825653 * tmp = (ExcludeFromDocsAttribute_t665825653 *)cache->attributes[0];
		ExcludeFromDocsAttribute__ctor_m1684225175(tmp, NULL);
	}
}
static void Mesh_t1356156583_CustomAttributesCacheGenerator_Mesh_SetTrianglesImpl_m2743099196____calculateBounds3(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1027170048 * tmp = (DefaultValueAttribute_t1027170048 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m4191464344(tmp, il2cpp_codegen_string_new_wrapper("true"), NULL);
	}
}
static void Mesh_t1356156583_CustomAttributesCacheGenerator_Mesh_SetTriangles_m2017297103(CustomAttributesCache* cache)
{
	{
		ExcludeFromDocsAttribute_t665825653 * tmp = (ExcludeFromDocsAttribute_t665825653 *)cache->attributes[0];
		ExcludeFromDocsAttribute__ctor_m1684225175(tmp, NULL);
	}
}
static void Mesh_t1356156583_CustomAttributesCacheGenerator_Mesh_SetTriangles_m2506325172____calculateBounds2(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1027170048 * tmp = (DefaultValueAttribute_t1027170048 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m4191464344(tmp, il2cpp_codegen_string_new_wrapper("true"), NULL);
	}
}
static void MonoBehaviour_t1158329972_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void MonoBehaviour_t1158329972_CustomAttributesCacheGenerator_MonoBehaviour_StartCoroutine_Auto_m1744905232(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m834417715(tmp, il2cpp_codegen_string_new_wrapper("StartCoroutine_Auto has been deprecated. Use StartCoroutine instead (UnityUpgradable) -> StartCoroutine([mscorlib] System.Collections.IEnumerator)"), false, NULL);
	}
}
static void MonoBehaviour_t1158329972_CustomAttributesCacheGenerator_MonoBehaviour_StartCoroutine_m296997955____value1(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1027170048 * tmp = (DefaultValueAttribute_t1027170048 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m4191464344(tmp, il2cpp_codegen_string_new_wrapper("null"), NULL);
	}
}
static void MonoBehaviour_t1158329972_CustomAttributesCacheGenerator_MonoBehaviour_StartCoroutine_m1399371129(CustomAttributesCache* cache)
{
	{
		ExcludeFromDocsAttribute_t665825653 * tmp = (ExcludeFromDocsAttribute_t665825653 *)cache->attributes[0];
		ExcludeFromDocsAttribute__ctor_m1684225175(tmp, NULL);
	}
}
static void DrivenTransformProperties_t2488747555_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		FlagsAttribute_t859561169 * tmp = (FlagsAttribute_t859561169 *)cache->attributes[0];
		FlagsAttribute__ctor_m1848108622(tmp, NULL);
	}
}
static void RectTransform_t3349966182_CustomAttributesCacheGenerator_RectTransform_SendReapplyDrivenProperties_m90487700(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void ResourceRequest_t2560315377_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void Resources_t339470017_CustomAttributesCacheGenerator_Resources_Load_m243305716(CustomAttributesCache* cache)
{
	{
		TypeInferenceRuleAttribute_t1390152093 * tmp = (TypeInferenceRuleAttribute_t1390152093 *)cache->attributes[0];
		TypeInferenceRuleAttribute__ctor_m599630929(tmp, 1LL, NULL);
	}
}
static void Resources_t339470017_CustomAttributesCacheGenerator_Resources_GetBuiltinResource_m582410469(CustomAttributesCache* cache)
{
	{
		TypeInferenceRuleAttribute_t1390152093 * tmp = (TypeInferenceRuleAttribute_t1390152093 *)cache->attributes[0];
		TypeInferenceRuleAttribute__ctor_m599630929(tmp, 0LL, NULL);
	}
}
static void Material_t193706927_CustomAttributesCacheGenerator_Material_Internal_CreateWithMaterial_m2907597451____mono0(CustomAttributesCache* cache)
{
	{
		WritableAttribute_t3715198420 * tmp = (WritableAttribute_t3715198420 *)cache->attributes[0];
		WritableAttribute__ctor_m761932763(tmp, NULL);
	}
}
static void Texture2D_t3542995729_CustomAttributesCacheGenerator_Texture2D_Internal_Create_m3012183307____mono0(CustomAttributesCache* cache)
{
	{
		WritableAttribute_t3715198420 * tmp = (WritableAttribute_t3715198420 *)cache->attributes[0];
		WritableAttribute__ctor_m761932763(tmp, NULL);
	}
}
static void Texture2D_t3542995729_CustomAttributesCacheGenerator_Texture2D_Apply_m3753817130____updateMipmaps0(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1027170048 * tmp = (DefaultValueAttribute_t1027170048 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m4191464344(tmp, il2cpp_codegen_string_new_wrapper("true"), NULL);
	}
}
static void Texture2D_t3542995729_CustomAttributesCacheGenerator_Texture2D_Apply_m3753817130____makeNoLongerReadable1(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1027170048 * tmp = (DefaultValueAttribute_t1027170048 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m4191464344(tmp, il2cpp_codegen_string_new_wrapper("false"), NULL);
	}
}
static void Texture2D_t3542995729_CustomAttributesCacheGenerator_Texture2D_Apply_m3543341930(CustomAttributesCache* cache)
{
	{
		ExcludeFromDocsAttribute_t665825653 * tmp = (ExcludeFromDocsAttribute_t665825653 *)cache->attributes[0];
		ExcludeFromDocsAttribute__ctor_m1684225175(tmp, NULL);
	}
}
static void Texture2D_t3542995729_CustomAttributesCacheGenerator_Texture2D_ReadPixels_m1120832672(CustomAttributesCache* cache)
{
	{
		ExcludeFromDocsAttribute_t665825653 * tmp = (ExcludeFromDocsAttribute_t665825653 *)cache->attributes[0];
		ExcludeFromDocsAttribute__ctor_m1684225175(tmp, NULL);
	}
}
static void RenderTexture_t2666733923_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		UsedByNativeCodeAttribute_t3212052468 * tmp = (UsedByNativeCodeAttribute_t3212052468 *)cache->attributes[0];
		UsedByNativeCodeAttribute__ctor_m2459832290(tmp, NULL);
	}
}
static void Transform_t3275118058_CustomAttributesCacheGenerator_Transform_Translate_m423862381____relativeTo1(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1027170048 * tmp = (DefaultValueAttribute_t1027170048 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m4191464344(tmp, il2cpp_codegen_string_new_wrapper("Space.Self"), NULL);
	}
}
static void Transform_t3275118058_CustomAttributesCacheGenerator_Transform_Rotate_m2612876682____relativeTo1(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1027170048 * tmp = (DefaultValueAttribute_t1027170048 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m4191464344(tmp, il2cpp_codegen_string_new_wrapper("Space.Self"), NULL);
	}
}
static void HideFlags_t1434274199_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		FlagsAttribute_t859561169 * tmp = (FlagsAttribute_t859561169 *)cache->attributes[0];
		FlagsAttribute__ctor_m1848108622(tmp, NULL);
	}
}
static void Object_t1021602117_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void Object_t1021602117_CustomAttributesCacheGenerator_Object_Internal_InstantiateSingle_m2776302597(CustomAttributesCache* cache)
{
	{
		ThreadAndSerializationSafe_t2122816804 * tmp = (ThreadAndSerializationSafe_t2122816804 *)cache->attributes[0];
		ThreadAndSerializationSafe__ctor_m84326599(tmp, NULL);
	}
}
static void Object_t1021602117_CustomAttributesCacheGenerator_Object_GetOffsetOfInstanceIDInCPlusPlusObject_m1587840561(CustomAttributesCache* cache)
{
	{
		ThreadAndSerializationSafe_t2122816804 * tmp = (ThreadAndSerializationSafe_t2122816804 *)cache->attributes[0];
		ThreadAndSerializationSafe__ctor_m84326599(tmp, NULL);
	}
}
static void Object_t1021602117_CustomAttributesCacheGenerator_Object_EnsureRunningOnMainThread_m3042842193(CustomAttributesCache* cache)
{
	{
		ThreadAndSerializationSafe_t2122816804 * tmp = (ThreadAndSerializationSafe_t2122816804 *)cache->attributes[0];
		ThreadAndSerializationSafe__ctor_m84326599(tmp, NULL);
	}
}
static void Object_t1021602117_CustomAttributesCacheGenerator_Object_Destroy_m4279412553____t1(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1027170048 * tmp = (DefaultValueAttribute_t1027170048 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m4191464344(tmp, il2cpp_codegen_string_new_wrapper("0.0F"), NULL);
	}
}
static void Object_t1021602117_CustomAttributesCacheGenerator_Object_Destroy_m4145850038(CustomAttributesCache* cache)
{
	{
		ExcludeFromDocsAttribute_t665825653 * tmp = (ExcludeFromDocsAttribute_t665825653 *)cache->attributes[0];
		ExcludeFromDocsAttribute__ctor_m1684225175(tmp, NULL);
	}
}
static void Object_t1021602117_CustomAttributesCacheGenerator_Object_DestroyImmediate_m3563317232____allowDestroyingAssets1(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1027170048 * tmp = (DefaultValueAttribute_t1027170048 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m4191464344(tmp, il2cpp_codegen_string_new_wrapper("false"), NULL);
	}
}
static void Object_t1021602117_CustomAttributesCacheGenerator_Object_DestroyImmediate_m95027445(CustomAttributesCache* cache)
{
	{
		ExcludeFromDocsAttribute_t665825653 * tmp = (ExcludeFromDocsAttribute_t665825653 *)cache->attributes[0];
		ExcludeFromDocsAttribute__ctor_m1684225175(tmp, NULL);
	}
}
static void Object_t1021602117_CustomAttributesCacheGenerator_Object_FindObjectsOfType_m2121813744(CustomAttributesCache* cache)
{
	{
		TypeInferenceRuleAttribute_t1390152093 * tmp = (TypeInferenceRuleAttribute_t1390152093 *)cache->attributes[0];
		TypeInferenceRuleAttribute__ctor_m599630929(tmp, 2LL, NULL);
	}
}
static void Object_t1021602117_CustomAttributesCacheGenerator_Object_DestroyObject_m282495858____t1(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1027170048 * tmp = (DefaultValueAttribute_t1027170048 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m4191464344(tmp, il2cpp_codegen_string_new_wrapper("0.0F"), NULL);
	}
}
static void Object_t1021602117_CustomAttributesCacheGenerator_Object_DestroyObject_m2343493981(CustomAttributesCache* cache)
{
	{
		ExcludeFromDocsAttribute_t665825653 * tmp = (ExcludeFromDocsAttribute_t665825653 *)cache->attributes[0];
		ExcludeFromDocsAttribute__ctor_m1684225175(tmp, NULL);
	}
}
static void Object_t1021602117_CustomAttributesCacheGenerator_Object_FindSceneObjectsOfType_m1833688338(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m2711473620(tmp, il2cpp_codegen_string_new_wrapper("use Object.FindObjectsOfType instead."), NULL);
	}
}
static void Object_t1021602117_CustomAttributesCacheGenerator_Object_FindObjectsOfTypeIncludingAssets_m3988851426(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m2711473620(tmp, il2cpp_codegen_string_new_wrapper("use Resources.FindObjectsOfTypeAll instead."), NULL);
	}
}
static void Object_t1021602117_CustomAttributesCacheGenerator_Object_DoesObjectWithInstanceIDExist_m2570795274(CustomAttributesCache* cache)
{
	{
		ThreadAndSerializationSafe_t2122816804 * tmp = (ThreadAndSerializationSafe_t2122816804 *)cache->attributes[0];
		ThreadAndSerializationSafe__ctor_m84326599(tmp, NULL);
	}
}
static void Object_t1021602117_CustomAttributesCacheGenerator_Object_GetInstanceID_m1920497914(CustomAttributesCache* cache)
{
	{
		SecuritySafeCriticalAttribute_t372031554 * tmp = (SecuritySafeCriticalAttribute_t372031554 *)cache->attributes[0];
		SecuritySafeCriticalAttribute__ctor_m2508714287(tmp, NULL);
	}
}
static void Object_t1021602117_CustomAttributesCacheGenerator_Object_Instantiate_m938141395(CustomAttributesCache* cache)
{
	{
		TypeInferenceRuleAttribute_t1390152093 * tmp = (TypeInferenceRuleAttribute_t1390152093 *)cache->attributes[0];
		TypeInferenceRuleAttribute__ctor_m599630929(tmp, 3LL, NULL);
	}
}
static void Object_t1021602117_CustomAttributesCacheGenerator_Object_Instantiate_m2160322936(CustomAttributesCache* cache)
{
	{
		TypeInferenceRuleAttribute_t1390152093 * tmp = (TypeInferenceRuleAttribute_t1390152093 *)cache->attributes[0];
		TypeInferenceRuleAttribute__ctor_m599630929(tmp, 3LL, NULL);
	}
}
static void Object_t1021602117_CustomAttributesCacheGenerator_Object_Instantiate_m2439155489(CustomAttributesCache* cache)
{
	{
		TypeInferenceRuleAttribute_t1390152093 * tmp = (TypeInferenceRuleAttribute_t1390152093 *)cache->attributes[0];
		TypeInferenceRuleAttribute__ctor_m599630929(tmp, 3LL, NULL);
	}
}
static void Object_t1021602117_CustomAttributesCacheGenerator_Object_Instantiate_m2177117080(CustomAttributesCache* cache)
{
	{
		TypeInferenceRuleAttribute_t1390152093 * tmp = (TypeInferenceRuleAttribute_t1390152093 *)cache->attributes[0];
		TypeInferenceRuleAttribute__ctor_m599630929(tmp, 3LL, NULL);
	}
}
static void Object_t1021602117_CustomAttributesCacheGenerator_Object_Instantiate_m2489341053(CustomAttributesCache* cache)
{
	{
		TypeInferenceRuleAttribute_t1390152093 * tmp = (TypeInferenceRuleAttribute_t1390152093 *)cache->attributes[0];
		TypeInferenceRuleAttribute__ctor_m599630929(tmp, 3LL, NULL);
	}
}
static void Object_t1021602117_CustomAttributesCacheGenerator_Object_FindObjectOfType_m2330404063(CustomAttributesCache* cache)
{
	{
		TypeInferenceRuleAttribute_t1390152093 * tmp = (TypeInferenceRuleAttribute_t1390152093 *)cache->attributes[0];
		TypeInferenceRuleAttribute__ctor_m599630929(tmp, 0LL, NULL);
	}
}
static void Playable_t3667545548_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		UsedByNativeCodeAttribute_t3212052468 * tmp = (UsedByNativeCodeAttribute_t3212052468 *)cache->attributes[0];
		UsedByNativeCodeAttribute__ctor_m2459832290(tmp, NULL);
	}
}
static void GenericMixerPlayable_t788733994_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void ScriptPlayable_t4067966717_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void SceneManager_t90660965_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void SceneManager_t90660965_CustomAttributesCacheGenerator_SceneManager_LoadScene_m592643733____mode1(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1027170048 * tmp = (DefaultValueAttribute_t1027170048 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m4191464344(tmp, il2cpp_codegen_string_new_wrapper("LoadSceneMode.Single"), NULL);
	}
}
static void SceneManager_t90660965_CustomAttributesCacheGenerator_SceneManager_Internal_SceneLoaded_m4005732915(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void SceneManager_t90660965_CustomAttributesCacheGenerator_SceneManager_Internal_SceneUnloaded_m4108957131(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void SceneManager_t90660965_CustomAttributesCacheGenerator_SceneManager_Internal_ActiveSceneChanged_m1162592635(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void ControllerColliderHit_t4070855101_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void Collision_t2876846408_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void Collision_t2876846408_CustomAttributesCacheGenerator_Collision_t2876846408____impactForceSum_PropertyInfo(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m834417715(tmp, il2cpp_codegen_string_new_wrapper("Use Collision.relativeVelocity instead."), false, NULL);
	}
}
static void Collision_t2876846408_CustomAttributesCacheGenerator_Collision_t2876846408____frictionForceSum_PropertyInfo(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m834417715(tmp, il2cpp_codegen_string_new_wrapper("Will always return zero."), false, NULL);
	}
}
static void Collision_t2876846408_CustomAttributesCacheGenerator_Collision_t2876846408____other_PropertyInfo(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m834417715(tmp, il2cpp_codegen_string_new_wrapper("Please use Collision.rigidbody, Collision.transform or Collision.collider instead"), false, NULL);
	}
}
static void Physics_t634932869_CustomAttributesCacheGenerator_Physics_Raycast_m2874007225(CustomAttributesCache* cache)
{
	{
		ExcludeFromDocsAttribute_t665825653 * tmp = (ExcludeFromDocsAttribute_t665825653 *)cache->attributes[0];
		ExcludeFromDocsAttribute__ctor_m1684225175(tmp, NULL);
	}
}
static void Physics_t634932869_CustomAttributesCacheGenerator_Physics_Raycast_m89212106(CustomAttributesCache* cache)
{
	{
		ExcludeFromDocsAttribute_t665825653 * tmp = (ExcludeFromDocsAttribute_t665825653 *)cache->attributes[0];
		ExcludeFromDocsAttribute__ctor_m1684225175(tmp, NULL);
	}
}
static void Physics_t634932869_CustomAttributesCacheGenerator_Physics_Raycast_m2667915561(CustomAttributesCache* cache)
{
	{
		ExcludeFromDocsAttribute_t665825653 * tmp = (ExcludeFromDocsAttribute_t665825653 *)cache->attributes[0];
		ExcludeFromDocsAttribute__ctor_m1684225175(tmp, NULL);
	}
}
static void Physics_t634932869_CustomAttributesCacheGenerator_Physics_Raycast_m3475924638____maxDistance2(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1027170048 * tmp = (DefaultValueAttribute_t1027170048 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m4191464344(tmp, il2cpp_codegen_string_new_wrapper("Mathf.Infinity"), NULL);
	}
}
static void Physics_t634932869_CustomAttributesCacheGenerator_Physics_Raycast_m3475924638____layerMask3(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1027170048 * tmp = (DefaultValueAttribute_t1027170048 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m4191464344(tmp, il2cpp_codegen_string_new_wrapper("DefaultRaycastLayers"), NULL);
	}
}
static void Physics_t634932869_CustomAttributesCacheGenerator_Physics_Raycast_m3475924638____queryTriggerInteraction4(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1027170048 * tmp = (DefaultValueAttribute_t1027170048 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m4191464344(tmp, il2cpp_codegen_string_new_wrapper("QueryTriggerInteraction.UseGlobal"), NULL);
	}
}
static void Physics_t634932869_CustomAttributesCacheGenerator_Physics_Raycast_m1929115794(CustomAttributesCache* cache)
{
	{
		ExcludeFromDocsAttribute_t665825653 * tmp = (ExcludeFromDocsAttribute_t665825653 *)cache->attributes[0];
		ExcludeFromDocsAttribute__ctor_m1684225175(tmp, NULL);
	}
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[1];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void Physics_t634932869_CustomAttributesCacheGenerator_Physics_Raycast_m2994111303(CustomAttributesCache* cache)
{
	{
		ExcludeFromDocsAttribute_t665825653 * tmp = (ExcludeFromDocsAttribute_t665825653 *)cache->attributes[0];
		ExcludeFromDocsAttribute__ctor_m1684225175(tmp, NULL);
	}
}
static void Physics_t634932869_CustomAttributesCacheGenerator_Physics_Raycast_m4027183840(CustomAttributesCache* cache)
{
	{
		ExcludeFromDocsAttribute_t665825653 * tmp = (ExcludeFromDocsAttribute_t665825653 *)cache->attributes[0];
		ExcludeFromDocsAttribute__ctor_m1684225175(tmp, NULL);
	}
}
static void Physics_t634932869_CustomAttributesCacheGenerator_Physics_Raycast_m2036777053____maxDistance3(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1027170048 * tmp = (DefaultValueAttribute_t1027170048 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m4191464344(tmp, il2cpp_codegen_string_new_wrapper("Mathf.Infinity"), NULL);
	}
}
static void Physics_t634932869_CustomAttributesCacheGenerator_Physics_Raycast_m2036777053____layerMask4(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1027170048 * tmp = (DefaultValueAttribute_t1027170048 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m4191464344(tmp, il2cpp_codegen_string_new_wrapper("DefaultRaycastLayers"), NULL);
	}
}
static void Physics_t634932869_CustomAttributesCacheGenerator_Physics_Raycast_m2036777053____queryTriggerInteraction5(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1027170048 * tmp = (DefaultValueAttribute_t1027170048 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m4191464344(tmp, il2cpp_codegen_string_new_wrapper("QueryTriggerInteraction.UseGlobal"), NULL);
	}
}
static void Physics_t634932869_CustomAttributesCacheGenerator_Physics_Raycast_m2691929452(CustomAttributesCache* cache)
{
	{
		ExcludeFromDocsAttribute_t665825653 * tmp = (ExcludeFromDocsAttribute_t665825653 *)cache->attributes[0];
		ExcludeFromDocsAttribute__ctor_m1684225175(tmp, NULL);
	}
}
static void Physics_t634932869_CustomAttributesCacheGenerator_Physics_Raycast_m780162053(CustomAttributesCache* cache)
{
	{
		ExcludeFromDocsAttribute_t665825653 * tmp = (ExcludeFromDocsAttribute_t665825653 *)cache->attributes[0];
		ExcludeFromDocsAttribute__ctor_m1684225175(tmp, NULL);
	}
}
static void Physics_t634932869_CustomAttributesCacheGenerator_Physics_Raycast_m2686676054(CustomAttributesCache* cache)
{
	{
		ExcludeFromDocsAttribute_t665825653 * tmp = (ExcludeFromDocsAttribute_t665825653 *)cache->attributes[0];
		ExcludeFromDocsAttribute__ctor_m1684225175(tmp, NULL);
	}
}
static void Physics_t634932869_CustomAttributesCacheGenerator_Physics_Raycast_m1844392139____maxDistance1(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1027170048 * tmp = (DefaultValueAttribute_t1027170048 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m4191464344(tmp, il2cpp_codegen_string_new_wrapper("Mathf.Infinity"), NULL);
	}
}
static void Physics_t634932869_CustomAttributesCacheGenerator_Physics_Raycast_m1844392139____layerMask2(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1027170048 * tmp = (DefaultValueAttribute_t1027170048 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m4191464344(tmp, il2cpp_codegen_string_new_wrapper("DefaultRaycastLayers"), NULL);
	}
}
static void Physics_t634932869_CustomAttributesCacheGenerator_Physics_Raycast_m1844392139____queryTriggerInteraction3(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1027170048 * tmp = (DefaultValueAttribute_t1027170048 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m4191464344(tmp, il2cpp_codegen_string_new_wrapper("QueryTriggerInteraction.UseGlobal"), NULL);
	}
}
static void Physics_t634932869_CustomAttributesCacheGenerator_Physics_Raycast_m2009151399(CustomAttributesCache* cache)
{
	{
		ExcludeFromDocsAttribute_t665825653 * tmp = (ExcludeFromDocsAttribute_t665825653 *)cache->attributes[0];
		ExcludeFromDocsAttribute__ctor_m1684225175(tmp, NULL);
	}
}
static void Physics_t634932869_CustomAttributesCacheGenerator_Physics_Raycast_m2308457076(CustomAttributesCache* cache)
{
	{
		ExcludeFromDocsAttribute_t665825653 * tmp = (ExcludeFromDocsAttribute_t665825653 *)cache->attributes[0];
		ExcludeFromDocsAttribute__ctor_m1684225175(tmp, NULL);
	}
}
static void Physics_t634932869_CustomAttributesCacheGenerator_Physics_Raycast_m2736931691(CustomAttributesCache* cache)
{
	{
		ExcludeFromDocsAttribute_t665825653 * tmp = (ExcludeFromDocsAttribute_t665825653 *)cache->attributes[0];
		ExcludeFromDocsAttribute__ctor_m1684225175(tmp, NULL);
	}
}
static void Physics_t634932869_CustomAttributesCacheGenerator_Physics_Raycast_m233619224____maxDistance2(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1027170048 * tmp = (DefaultValueAttribute_t1027170048 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m4191464344(tmp, il2cpp_codegen_string_new_wrapper("Mathf.Infinity"), NULL);
	}
}
static void Physics_t634932869_CustomAttributesCacheGenerator_Physics_Raycast_m233619224____layerMask3(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1027170048 * tmp = (DefaultValueAttribute_t1027170048 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m4191464344(tmp, il2cpp_codegen_string_new_wrapper("DefaultRaycastLayers"), NULL);
	}
}
static void Physics_t634932869_CustomAttributesCacheGenerator_Physics_Raycast_m233619224____queryTriggerInteraction4(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1027170048 * tmp = (DefaultValueAttribute_t1027170048 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m4191464344(tmp, il2cpp_codegen_string_new_wrapper("QueryTriggerInteraction.UseGlobal"), NULL);
	}
}
static void Physics_t634932869_CustomAttributesCacheGenerator_Physics_RaycastAll_m233036521(CustomAttributesCache* cache)
{
	{
		ExcludeFromDocsAttribute_t665825653 * tmp = (ExcludeFromDocsAttribute_t665825653 *)cache->attributes[0];
		ExcludeFromDocsAttribute__ctor_m1684225175(tmp, NULL);
	}
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[1];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void Physics_t634932869_CustomAttributesCacheGenerator_Physics_RaycastAll_m3928448900(CustomAttributesCache* cache)
{
	{
		ExcludeFromDocsAttribute_t665825653 * tmp = (ExcludeFromDocsAttribute_t665825653 *)cache->attributes[0];
		ExcludeFromDocsAttribute__ctor_m1684225175(tmp, NULL);
	}
}
static void Physics_t634932869_CustomAttributesCacheGenerator_Physics_RaycastAll_m1246652201(CustomAttributesCache* cache)
{
	{
		ExcludeFromDocsAttribute_t665825653 * tmp = (ExcludeFromDocsAttribute_t665825653 *)cache->attributes[0];
		ExcludeFromDocsAttribute__ctor_m1684225175(tmp, NULL);
	}
}
static void Physics_t634932869_CustomAttributesCacheGenerator_Physics_RaycastAll_m410413656____maxDistance1(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1027170048 * tmp = (DefaultValueAttribute_t1027170048 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m4191464344(tmp, il2cpp_codegen_string_new_wrapper("Mathf.Infinity"), NULL);
	}
}
static void Physics_t634932869_CustomAttributesCacheGenerator_Physics_RaycastAll_m410413656____layerMask2(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1027170048 * tmp = (DefaultValueAttribute_t1027170048 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m4191464344(tmp, il2cpp_codegen_string_new_wrapper("DefaultRaycastLayers"), NULL);
	}
}
static void Physics_t634932869_CustomAttributesCacheGenerator_Physics_RaycastAll_m410413656____queryTriggerInteraction3(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1027170048 * tmp = (DefaultValueAttribute_t1027170048 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m4191464344(tmp, il2cpp_codegen_string_new_wrapper("QueryTriggerInteraction.UseGlobal"), NULL);
	}
}
static void Physics_t634932869_CustomAttributesCacheGenerator_Physics_RaycastAll_m3908263591____maxDistance2(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1027170048 * tmp = (DefaultValueAttribute_t1027170048 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m4191464344(tmp, il2cpp_codegen_string_new_wrapper("Mathf.Infinity"), NULL);
	}
}
static void Physics_t634932869_CustomAttributesCacheGenerator_Physics_RaycastAll_m3908263591____layermask3(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1027170048 * tmp = (DefaultValueAttribute_t1027170048 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m4191464344(tmp, il2cpp_codegen_string_new_wrapper("DefaultRaycastLayers"), NULL);
	}
}
static void Physics_t634932869_CustomAttributesCacheGenerator_Physics_RaycastAll_m3908263591____queryTriggerInteraction4(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1027170048 * tmp = (DefaultValueAttribute_t1027170048 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m4191464344(tmp, il2cpp_codegen_string_new_wrapper("QueryTriggerInteraction.UseGlobal"), NULL);
	}
}
static void Physics_t634932869_CustomAttributesCacheGenerator_Physics_RaycastAll_m3256436970(CustomAttributesCache* cache)
{
	{
		ExcludeFromDocsAttribute_t665825653 * tmp = (ExcludeFromDocsAttribute_t665825653 *)cache->attributes[0];
		ExcludeFromDocsAttribute__ctor_m1684225175(tmp, NULL);
	}
}
static void Physics_t634932869_CustomAttributesCacheGenerator_Physics_RaycastAll_m3484190429(CustomAttributesCache* cache)
{
	{
		ExcludeFromDocsAttribute_t665825653 * tmp = (ExcludeFromDocsAttribute_t665825653 *)cache->attributes[0];
		ExcludeFromDocsAttribute__ctor_m1684225175(tmp, NULL);
	}
}
static void Physics_t634932869_CustomAttributesCacheGenerator_Physics_RaycastAll_m3650851272(CustomAttributesCache* cache)
{
	{
		ExcludeFromDocsAttribute_t665825653 * tmp = (ExcludeFromDocsAttribute_t665825653 *)cache->attributes[0];
		ExcludeFromDocsAttribute__ctor_m1684225175(tmp, NULL);
	}
}
static void ContactPoint_t1376425630_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		UsedByNativeCodeAttribute_t3212052468 * tmp = (UsedByNativeCodeAttribute_t3212052468 *)cache->attributes[0];
		UsedByNativeCodeAttribute__ctor_m2459832290(tmp, NULL);
	}
}
static void RaycastHit_t87180320_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		UsedByNativeCodeAttribute_t3212052468 * tmp = (UsedByNativeCodeAttribute_t3212052468 *)cache->attributes[0];
		UsedByNativeCodeAttribute__ctor_m2459832290(tmp, NULL);
	}
}
static void RaycastHit2D_t4063908774_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		UsedByNativeCodeAttribute_t3212052468 * tmp = (UsedByNativeCodeAttribute_t3212052468 *)cache->attributes[0];
		UsedByNativeCodeAttribute__ctor_m2459832290(tmp, NULL);
	}
}
static void Physics2D_t2540166467_CustomAttributesCacheGenerator_Physics2D_Raycast_m1220041042(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
	{
		ExcludeFromDocsAttribute_t665825653 * tmp = (ExcludeFromDocsAttribute_t665825653 *)cache->attributes[1];
		ExcludeFromDocsAttribute__ctor_m1684225175(tmp, NULL);
	}
}
static void Physics2D_t2540166467_CustomAttributesCacheGenerator_Physics2D_Raycast_m122312471(CustomAttributesCache* cache)
{
	{
		ExcludeFromDocsAttribute_t665825653 * tmp = (ExcludeFromDocsAttribute_t665825653 *)cache->attributes[0];
		ExcludeFromDocsAttribute__ctor_m1684225175(tmp, NULL);
	}
}
static void Physics2D_t2540166467_CustomAttributesCacheGenerator_Physics2D_Raycast_m3913913442(CustomAttributesCache* cache)
{
	{
		ExcludeFromDocsAttribute_t665825653 * tmp = (ExcludeFromDocsAttribute_t665825653 *)cache->attributes[0];
		ExcludeFromDocsAttribute__ctor_m1684225175(tmp, NULL);
	}
}
static void Physics2D_t2540166467_CustomAttributesCacheGenerator_Physics2D_Raycast_m2560154475(CustomAttributesCache* cache)
{
	{
		ExcludeFromDocsAttribute_t665825653 * tmp = (ExcludeFromDocsAttribute_t665825653 *)cache->attributes[0];
		ExcludeFromDocsAttribute__ctor_m1684225175(tmp, NULL);
	}
}
static void Physics2D_t2540166467_CustomAttributesCacheGenerator_Physics2D_Raycast_m2303387255____distance2(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1027170048 * tmp = (DefaultValueAttribute_t1027170048 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m4191464344(tmp, il2cpp_codegen_string_new_wrapper("Mathf.Infinity"), NULL);
	}
}
static void Physics2D_t2540166467_CustomAttributesCacheGenerator_Physics2D_Raycast_m2303387255____layerMask3(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1027170048 * tmp = (DefaultValueAttribute_t1027170048 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m4191464344(tmp, il2cpp_codegen_string_new_wrapper("DefaultRaycastLayers"), NULL);
	}
}
static void Physics2D_t2540166467_CustomAttributesCacheGenerator_Physics2D_Raycast_m2303387255____minDepth4(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1027170048 * tmp = (DefaultValueAttribute_t1027170048 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m4191464344(tmp, il2cpp_codegen_string_new_wrapper("-Mathf.Infinity"), NULL);
	}
}
static void Physics2D_t2540166467_CustomAttributesCacheGenerator_Physics2D_Raycast_m2303387255____maxDepth5(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1027170048 * tmp = (DefaultValueAttribute_t1027170048 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m4191464344(tmp, il2cpp_codegen_string_new_wrapper("Mathf.Infinity"), NULL);
	}
}
static void Physics2D_t2540166467_CustomAttributesCacheGenerator_Physics2D_GetRayIntersectionAll_m253330691(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void Physics2D_t2540166467_CustomAttributesCacheGenerator_Physics2D_GetRayIntersectionAll_m253330691____distance1(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1027170048 * tmp = (DefaultValueAttribute_t1027170048 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m4191464344(tmp, il2cpp_codegen_string_new_wrapper("Mathf.Infinity"), NULL);
	}
}
static void Physics2D_t2540166467_CustomAttributesCacheGenerator_Physics2D_GetRayIntersectionAll_m253330691____layerMask2(CustomAttributesCache* cache)
{
	{
		DefaultValueAttribute_t1027170048 * tmp = (DefaultValueAttribute_t1027170048 *)cache->attributes[0];
		DefaultValueAttribute__ctor_m4191464344(tmp, il2cpp_codegen_string_new_wrapper("DefaultRaycastLayers"), NULL);
	}
}
static void Physics2D_t2540166467_CustomAttributesCacheGenerator_Physics2D_GetRayIntersectionAll_m2808325432(CustomAttributesCache* cache)
{
	{
		ExcludeFromDocsAttribute_t665825653 * tmp = (ExcludeFromDocsAttribute_t665825653 *)cache->attributes[0];
		ExcludeFromDocsAttribute__ctor_m1684225175(tmp, NULL);
	}
}
static void Physics2D_t2540166467_CustomAttributesCacheGenerator_Physics2D_GetRayIntersectionAll_m120415839(CustomAttributesCache* cache)
{
	{
		ExcludeFromDocsAttribute_t665825653 * tmp = (ExcludeFromDocsAttribute_t665825653 *)cache->attributes[0];
		ExcludeFromDocsAttribute__ctor_m1684225175(tmp, NULL);
	}
}
static void ContactPoint2D_t3659330976_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		UsedByNativeCodeAttribute_t3212052468 * tmp = (UsedByNativeCodeAttribute_t3212052468 *)cache->attributes[0];
		UsedByNativeCodeAttribute__ctor_m2459832290(tmp, NULL);
	}
}
static void Collision2D_t1539500754_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void AudioSettings_t3144015719_CustomAttributesCacheGenerator_AudioSettings_InvokeOnAudioConfigurationChanged_m3225073778(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void AudioClip_t1932558630_CustomAttributesCacheGenerator_AudioClip_InvokePCMReaderCallback_Internal_m1966286598(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void AudioClip_t1932558630_CustomAttributesCacheGenerator_AudioClip_InvokePCMSetPositionCallback_Internal_m2304858844(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void AnimationEvent_t2428323300_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void AnimationEvent_t2428323300_CustomAttributesCacheGenerator_AnimationEvent_t2428323300____data_PropertyInfo(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m2711473620(tmp, il2cpp_codegen_string_new_wrapper("Use stringParameter instead"), NULL);
	}
}
static void AnimationState_t1303741697_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		UsedByNativeCodeAttribute_t3212052468 * tmp = (UsedByNativeCodeAttribute_t3212052468 *)cache->attributes[0];
		UsedByNativeCodeAttribute__ctor_m2459832290(tmp, NULL);
	}
}
static void AnimatorClipInfo_t3905751349_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		UsedByNativeCodeAttribute_t3212052468 * tmp = (UsedByNativeCodeAttribute_t3212052468 *)cache->attributes[0];
		UsedByNativeCodeAttribute__ctor_m2459832290(tmp, NULL);
	}
}
static void AnimatorStateInfo_t2577870592_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void AnimatorStateInfo_t2577870592_CustomAttributesCacheGenerator_AnimatorStateInfo_t2577870592____nameHash_PropertyInfo(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m2711473620(tmp, il2cpp_codegen_string_new_wrapper("Use AnimatorStateInfo.fullPathHash instead."), NULL);
	}
}
static void AnimatorTransitionInfo_t2410896200_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void Animator_t69676727_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		UsedByNativeCodeAttribute_t3212052468 * tmp = (UsedByNativeCodeAttribute_t3212052468 *)cache->attributes[0];
		UsedByNativeCodeAttribute__ctor_m2459832290(tmp, NULL);
	}
}
static void Animator_t69676727_CustomAttributesCacheGenerator_Animator_StringToHash_m3313850714(CustomAttributesCache* cache)
{
	{
		ThreadAndSerializationSafe_t2122816804 * tmp = (ThreadAndSerializationSafe_t2122816804 *)cache->attributes[0];
		ThreadAndSerializationSafe__ctor_m84326599(tmp, NULL);
	}
}
static void SkeletonBone_t345082847_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void SkeletonBone_t345082847_CustomAttributesCacheGenerator_SkeletonBone_t345082847____transformModified_PropertyInfo(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m834417715(tmp, il2cpp_codegen_string_new_wrapper("transformModified is no longer used and has been deprecated."), true, NULL);
	}
}
static void HumanBone_t1529896151_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void AnimatorControllerPlayable_t4078305555_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		UsedByNativeCodeAttribute_t3212052468 * tmp = (UsedByNativeCodeAttribute_t3212052468 *)cache->attributes[0];
		UsedByNativeCodeAttribute__ctor_m2459832290(tmp, NULL);
	}
}
static void AnimationPlayable_t1693994278_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		UsedByNativeCodeAttribute_t3212052468 * tmp = (UsedByNativeCodeAttribute_t3212052468 *)cache->attributes[0];
		UsedByNativeCodeAttribute__ctor_m2459832290(tmp, NULL);
	}
}
static void CustomAnimationPlayable_t3423099547_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void TextGenerationError_t780770201_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		FlagsAttribute_t859561169 * tmp = (FlagsAttribute_t859561169 *)cache->attributes[0];
		FlagsAttribute__ctor_m1848108622(tmp, NULL);
	}
}
static void TextGenerator_t647235000_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		UsedByNativeCodeAttribute_t3212052468 * tmp = (UsedByNativeCodeAttribute_t3212052468 *)cache->attributes[0];
		UsedByNativeCodeAttribute__ctor_m2459832290(tmp, NULL);
	}
}
static void TextGenerator_t647235000_CustomAttributesCacheGenerator_TextGenerator_Dispose_cpp_m1755131202(CustomAttributesCache* cache)
{
	{
		ThreadAndSerializationSafe_t2122816804 * tmp = (ThreadAndSerializationSafe_t2122816804 *)cache->attributes[0];
		ThreadAndSerializationSafe__ctor_m84326599(tmp, NULL);
	}
}
static void Font_t4239498691_CustomAttributesCacheGenerator_Font_InvokeTextureRebuilt_Internal_m2007522718(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void FontTextureRebuildCallback_t1272078033_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		EditorBrowsableAttribute_t1050682502 * tmp = (EditorBrowsableAttribute_t1050682502 *)cache->attributes[0];
		EditorBrowsableAttribute__ctor_m2635501285(tmp, 1LL, NULL);
	}
}
static void UICharInfo_t3056636800_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		UsedByNativeCodeAttribute_t3212052468 * tmp = (UsedByNativeCodeAttribute_t3212052468 *)cache->attributes[0];
		UsedByNativeCodeAttribute__ctor_m2459832290(tmp, NULL);
	}
}
static void UILineInfo_t3621277874_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		UsedByNativeCodeAttribute_t3212052468 * tmp = (UsedByNativeCodeAttribute_t3212052468 *)cache->attributes[0];
		UsedByNativeCodeAttribute__ctor_m2459832290(tmp, NULL);
	}
}
static void UIVertex_t1204258818_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		UsedByNativeCodeAttribute_t3212052468 * tmp = (UsedByNativeCodeAttribute_t3212052468 *)cache->attributes[0];
		UsedByNativeCodeAttribute__ctor_m2459832290(tmp, NULL);
	}
}
static void Canvas_t209405766_CustomAttributesCacheGenerator_Canvas_SendWillRenderCanvases_m3796535067(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void Event_t3028476042_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map0(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void Event_t3028476042_CustomAttributesCacheGenerator_Event_Internal_MakeMasterEventCurrent_m1829330051(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void Event_t3028476042_CustomAttributesCacheGenerator_Event_Init_m3901382626(CustomAttributesCache* cache)
{
	{
		ThreadAndSerializationSafe_t2122816804 * tmp = (ThreadAndSerializationSafe_t2122816804 *)cache->attributes[0];
		ThreadAndSerializationSafe__ctor_m84326599(tmp, NULL);
	}
}
static void Event_t3028476042_CustomAttributesCacheGenerator_Event_Cleanup_m1195902101(CustomAttributesCache* cache)
{
	{
		ThreadAndSerializationSafe_t2122816804 * tmp = (ThreadAndSerializationSafe_t2122816804 *)cache->attributes[0];
		ThreadAndSerializationSafe__ctor_m84326599(tmp, NULL);
	}
}
static void EventModifiers_t2690251474_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		FlagsAttribute_t859561169 * tmp = (FlagsAttribute_t859561169 *)cache->attributes[0];
		FlagsAttribute__ctor_m1848108622(tmp, NULL);
	}
}
static void GUI_t4082743951_CustomAttributesCacheGenerator_U3CnextScrollStepTimeU3Ek__BackingField(CustomAttributesCache* cache)
{
	{
		DebuggerBrowsableAttribute_t1386379234 * tmp = (DebuggerBrowsableAttribute_t1386379234 *)cache->attributes[0];
		DebuggerBrowsableAttribute__ctor_m3729055103(tmp, 0LL, NULL);
	}
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[1];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void GUI_t4082743951_CustomAttributesCacheGenerator_GUI_set_nextScrollStepTime_m2724006954(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void GUI_t4082743951_CustomAttributesCacheGenerator_GUI_CallWindowDelegate_m634477008(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void ScrollViewState_t2792222924_CustomAttributesCacheGenerator_ScrollViewState__ctor_m853546402(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void GUIContent_t4210063000_CustomAttributesCacheGenerator_m_Text(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void GUIContent_t4210063000_CustomAttributesCacheGenerator_m_Image(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void GUIContent_t4210063000_CustomAttributesCacheGenerator_m_Tooltip(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void GUIScrollGroup_t755788567_CustomAttributesCacheGenerator_GUIScrollGroup__ctor_m3551718706(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void GUISettings_t622856320_CustomAttributesCacheGenerator_m_DoubleClickSelectsWord(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void GUISettings_t622856320_CustomAttributesCacheGenerator_m_TripleClickSelectsLine(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void GUISettings_t622856320_CustomAttributesCacheGenerator_m_CursorColor(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void GUISettings_t622856320_CustomAttributesCacheGenerator_m_CursorFlashSpeed(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void GUISettings_t622856320_CustomAttributesCacheGenerator_m_SelectionColor(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void GUISkin_t1436893342_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
	{
		ExecuteInEditMode_t3043633143 * tmp = (ExecuteInEditMode_t3043633143 *)cache->attributes[1];
		ExecuteInEditMode__ctor_m495837196(tmp, NULL);
	}
}
static void GUISkin_t1436893342_CustomAttributesCacheGenerator_m_Font(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void GUISkin_t1436893342_CustomAttributesCacheGenerator_m_box(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void GUISkin_t1436893342_CustomAttributesCacheGenerator_m_button(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void GUISkin_t1436893342_CustomAttributesCacheGenerator_m_toggle(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void GUISkin_t1436893342_CustomAttributesCacheGenerator_m_label(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void GUISkin_t1436893342_CustomAttributesCacheGenerator_m_textField(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void GUISkin_t1436893342_CustomAttributesCacheGenerator_m_textArea(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void GUISkin_t1436893342_CustomAttributesCacheGenerator_m_window(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void GUISkin_t1436893342_CustomAttributesCacheGenerator_m_horizontalSlider(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void GUISkin_t1436893342_CustomAttributesCacheGenerator_m_horizontalSliderThumb(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void GUISkin_t1436893342_CustomAttributesCacheGenerator_m_verticalSlider(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void GUISkin_t1436893342_CustomAttributesCacheGenerator_m_verticalSliderThumb(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void GUISkin_t1436893342_CustomAttributesCacheGenerator_m_horizontalScrollbar(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void GUISkin_t1436893342_CustomAttributesCacheGenerator_m_horizontalScrollbarThumb(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void GUISkin_t1436893342_CustomAttributesCacheGenerator_m_horizontalScrollbarLeftButton(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void GUISkin_t1436893342_CustomAttributesCacheGenerator_m_horizontalScrollbarRightButton(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void GUISkin_t1436893342_CustomAttributesCacheGenerator_m_verticalScrollbar(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void GUISkin_t1436893342_CustomAttributesCacheGenerator_m_verticalScrollbarThumb(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void GUISkin_t1436893342_CustomAttributesCacheGenerator_m_verticalScrollbarUpButton(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void GUISkin_t1436893342_CustomAttributesCacheGenerator_m_verticalScrollbarDownButton(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void GUISkin_t1436893342_CustomAttributesCacheGenerator_m_ScrollView(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void GUISkin_t1436893342_CustomAttributesCacheGenerator_m_CustomStyles(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void GUISkin_t1436893342_CustomAttributesCacheGenerator_m_Settings(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void GUIStyleState_t3801000545_CustomAttributesCacheGenerator_GUIStyleState_Init_m2434147050(CustomAttributesCache* cache)
{
	{
		ThreadAndSerializationSafe_t2122816804 * tmp = (ThreadAndSerializationSafe_t2122816804 *)cache->attributes[0];
		ThreadAndSerializationSafe__ctor_m84326599(tmp, NULL);
	}
}
static void GUIStyleState_t3801000545_CustomAttributesCacheGenerator_GUIStyleState_Cleanup_m705006206(CustomAttributesCache* cache)
{
	{
		ThreadAndSerializationSafe_t2122816804 * tmp = (ThreadAndSerializationSafe_t2122816804 *)cache->attributes[0];
		ThreadAndSerializationSafe__ctor_m84326599(tmp, NULL);
	}
}
static void GUIStyleState_t3801000545_CustomAttributesCacheGenerator_GUIStyleState_GetBackgroundInternalFromDeserialization_m1892089769(CustomAttributesCache* cache)
{
	{
		ThreadAndSerializationSafe_t2122816804 * tmp = (ThreadAndSerializationSafe_t2122816804 *)cache->attributes[0];
		ThreadAndSerializationSafe__ctor_m84326599(tmp, NULL);
	}
}
static void GUIStyle_t1799908754_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void GUIStyle_t1799908754_CustomAttributesCacheGenerator_GUIStyle_Init_m3872198731(CustomAttributesCache* cache)
{
	{
		ThreadAndSerializationSafe_t2122816804 * tmp = (ThreadAndSerializationSafe_t2122816804 *)cache->attributes[0];
		ThreadAndSerializationSafe__ctor_m84326599(tmp, NULL);
	}
}
static void GUIStyle_t1799908754_CustomAttributesCacheGenerator_GUIStyle_InitCopy_m3676786505(CustomAttributesCache* cache)
{
	{
		ThreadAndSerializationSafe_t2122816804 * tmp = (ThreadAndSerializationSafe_t2122816804 *)cache->attributes[0];
		ThreadAndSerializationSafe__ctor_m84326599(tmp, NULL);
	}
}
static void GUIStyle_t1799908754_CustomAttributesCacheGenerator_GUIStyle_Cleanup_m1915255373(CustomAttributesCache* cache)
{
	{
		ThreadAndSerializationSafe_t2122816804 * tmp = (ThreadAndSerializationSafe_t2122816804 *)cache->attributes[0];
		ThreadAndSerializationSafe__ctor_m84326599(tmp, NULL);
	}
}
static void GUIStyle_t1799908754_CustomAttributesCacheGenerator_GUIStyle_GetStyleStatePtr_m1972527409(CustomAttributesCache* cache)
{
	{
		ThreadAndSerializationSafe_t2122816804 * tmp = (ThreadAndSerializationSafe_t2122816804 *)cache->attributes[0];
		ThreadAndSerializationSafe__ctor_m84326599(tmp, NULL);
	}
}
static void GUIStyle_t1799908754_CustomAttributesCacheGenerator_GUIStyle_GetFontInternalDuringLoadingThread_m229734483(CustomAttributesCache* cache)
{
	{
		ThreadAndSerializationSafe_t2122816804 * tmp = (ThreadAndSerializationSafe_t2122816804 *)cache->attributes[0];
		ThreadAndSerializationSafe__ctor_m84326599(tmp, NULL);
	}
}
static void GUIStyle_t1799908754_CustomAttributesCacheGenerator_GUIStyle_t1799908754____clipOffset_PropertyInfo(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m2711473620(tmp, il2cpp_codegen_string_new_wrapper("warning Don't use clipOffset - put things inside BeginGroup instead. This functionality will be removed in a later version."), NULL);
	}
}
static void GUITargetAttribute_t863467180_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 64LL, NULL);
	}
}
static void GUITargetAttribute_t863467180_CustomAttributesCacheGenerator_GUITargetAttribute_GetGUITargetAttrValue_m3740620102(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void GUIUtility_t3275770671_CustomAttributesCacheGenerator_U3CguiIsExitingU3Ek__BackingField(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
	{
		DebuggerBrowsableAttribute_t1386379234 * tmp = (DebuggerBrowsableAttribute_t1386379234 *)cache->attributes[1];
		DebuggerBrowsableAttribute__ctor_m3729055103(tmp, 0LL, NULL);
	}
}
static void GUIUtility_t3275770671_CustomAttributesCacheGenerator_GUIUtility_set_guiIsExiting_m2362636745(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void GUIUtility_t3275770671_CustomAttributesCacheGenerator_GUIUtility_BeginGUI_m2907220931(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void GUIUtility_t3275770671_CustomAttributesCacheGenerator_GUIUtility_EndGUI_m3538781391(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void GUIUtility_t3275770671_CustomAttributesCacheGenerator_GUIUtility_EndGUIFromException_m2091524531(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void SliderState_t1595681032_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void TextEditor_t3975561390_CustomAttributesCacheGenerator_TextEditor__ctor_m1990252461(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void WebRequestUtils_t4100941042_CustomAttributesCacheGenerator_WebRequestUtils_RedirectTo_m3803295888(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void RemoteSettings_t392466225_CustomAttributesCacheGenerator_RemoteSettings_CallOnUpdate_m1624968574(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void AttributeHelperEngine_t958797062_CustomAttributesCacheGenerator_AttributeHelperEngine_GetParentTypeDisallowingMultipleInclusion_m685343645(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void AttributeHelperEngine_t958797062_CustomAttributesCacheGenerator_AttributeHelperEngine_GetRequiredComponents_m120894667(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void AttributeHelperEngine_t958797062_CustomAttributesCacheGenerator_AttributeHelperEngine_CheckIsEditorScript_m2980171478(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void AttributeHelperEngine_t958797062_CustomAttributesCacheGenerator_AttributeHelperEngine_GetDefaultExecutionOrderFor_m451063166(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void DisallowMultipleComponent_t2656950_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 4LL, NULL);
		AttributeUsageAttribute_set_Inherited_m4085818998(tmp, false, NULL);
	}
}
static void RequireComponent_t864575032_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 4LL, NULL);
		AttributeUsageAttribute_set_AllowMultiple_m683830749(tmp, true, NULL);
	}
}
static void DefaultExecutionOrder_t2717914595_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		UsedByNativeCodeAttribute_t3212052468 * tmp = (UsedByNativeCodeAttribute_t3212052468 *)cache->attributes[0];
		UsedByNativeCodeAttribute__ctor_m2459832290(tmp, NULL);
	}
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 4LL, NULL);
	}
}
static void DefaultExecutionOrder_t2717914595_CustomAttributesCacheGenerator_U3CorderU3Ek__BackingField(CustomAttributesCache* cache)
{
	{
		DebuggerBrowsableAttribute_t1386379234 * tmp = (DebuggerBrowsableAttribute_t1386379234 *)cache->attributes[0];
		DebuggerBrowsableAttribute__ctor_m3729055103(tmp, 0LL, NULL);
	}
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[1];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void DefaultExecutionOrder_t2717914595_CustomAttributesCacheGenerator_DefaultExecutionOrder_get_order_m1561221759(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void IL2CPPStructAlignmentAttribute_t130316838_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 8LL, NULL);
	}
}
static void RuntimePlatform_t1869584967_CustomAttributesCacheGenerator_OSXWebPlayer(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m2711473620(tmp, il2cpp_codegen_string_new_wrapper("WebPlayer export is no longer supported in Unity 5.4+."), NULL);
	}
}
static void RuntimePlatform_t1869584967_CustomAttributesCacheGenerator_WindowsWebPlayer(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m2711473620(tmp, il2cpp_codegen_string_new_wrapper("WebPlayer export is no longer supported in Unity 5.4+."), NULL);
	}
}
static void RuntimePlatform_t1869584967_CustomAttributesCacheGenerator_XBOX360(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m2711473620(tmp, il2cpp_codegen_string_new_wrapper("Xbox360 export is no longer supported in Unity 5.5+."), NULL);
	}
}
static void RuntimePlatform_t1869584967_CustomAttributesCacheGenerator_PS3(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m2711473620(tmp, il2cpp_codegen_string_new_wrapper("PS3 export is no longer supported in Unity >=5.5."), NULL);
	}
}
static void RuntimePlatform_t1869584967_CustomAttributesCacheGenerator_NaCl(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m2711473620(tmp, il2cpp_codegen_string_new_wrapper("NaCl export is no longer supported in Unity 5.0+."), NULL);
	}
}
static void RuntimePlatform_t1869584967_CustomAttributesCacheGenerator_FlashPlayer(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m2711473620(tmp, il2cpp_codegen_string_new_wrapper("FlashPlayer export is no longer supported in Unity 5.0+."), NULL);
	}
}
static void RuntimePlatform_t1869584967_CustomAttributesCacheGenerator_MetroPlayerX86(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m2711473620(tmp, il2cpp_codegen_string_new_wrapper("Use WSAPlayerX86 instead"), NULL);
	}
}
static void RuntimePlatform_t1869584967_CustomAttributesCacheGenerator_MetroPlayerX64(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m2711473620(tmp, il2cpp_codegen_string_new_wrapper("Use WSAPlayerX64 instead"), NULL);
	}
}
static void RuntimePlatform_t1869584967_CustomAttributesCacheGenerator_MetroPlayerARM(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m2711473620(tmp, il2cpp_codegen_string_new_wrapper("Use WSAPlayerARM instead"), NULL);
	}
}
static void RuntimePlatform_t1869584967_CustomAttributesCacheGenerator_WP8Player(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m2711473620(tmp, il2cpp_codegen_string_new_wrapper("Windows Phone 8 was removed in 5.3"), NULL);
	}
}
static void RuntimePlatform_t1869584967_CustomAttributesCacheGenerator_BlackBerryPlayer(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m2711473620(tmp, il2cpp_codegen_string_new_wrapper("BlackBerryPlayer export is no longer supported in Unity 5.4+."), NULL);
	}
}
static void Color_t2020392075_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		UsedByNativeCodeAttribute_t3212052468 * tmp = (UsedByNativeCodeAttribute_t3212052468 *)cache->attributes[0];
		UsedByNativeCodeAttribute__ctor_m2459832290(tmp, NULL);
	}
	{
		DefaultMemberAttribute_t889804479 * tmp = (DefaultMemberAttribute_t889804479 *)cache->attributes[1];
		DefaultMemberAttribute__ctor_m2234856827(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void Color32_t874517518_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		IL2CPPStructAlignmentAttribute_t130316838 * tmp = (IL2CPPStructAlignmentAttribute_t130316838 *)cache->attributes[0];
		IL2CPPStructAlignmentAttribute__ctor_m2555798229(tmp, NULL);
		tmp->set_Align_0(4LL);
	}
	{
		UsedByNativeCodeAttribute_t3212052468 * tmp = (UsedByNativeCodeAttribute_t3212052468 *)cache->attributes[1];
		UsedByNativeCodeAttribute__ctor_m2459832290(tmp, NULL);
	}
}
static void SetupCoroutine_t3582942563_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void SetupCoroutine_t3582942563_CustomAttributesCacheGenerator_SetupCoroutine_InvokeMoveNext_m2975616245(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
	{
		SecuritySafeCriticalAttribute_t372031554 * tmp = (SecuritySafeCriticalAttribute_t372031554 *)cache->attributes[1];
		SecuritySafeCriticalAttribute__ctor_m2508714287(tmp, NULL);
	}
}
static void SetupCoroutine_t3582942563_CustomAttributesCacheGenerator_SetupCoroutine_InvokeMember_m1481430263(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void WritableAttribute_t3715198420_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 2048LL, NULL);
		AttributeUsageAttribute_set_AllowMultiple_m683830749(tmp, false, NULL);
	}
}
static void AssemblyIsEditorAssembly_t1557026495_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 1LL, NULL);
	}
}
static void ColorWriteMask_t926634530_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		FlagsAttribute_t859561169 * tmp = (FlagsAttribute_t859561169 *)cache->attributes[0];
		FlagsAttribute__ctor_m1848108622(tmp, NULL);
	}
}
static void SendMouseEvents_t3505065032_CustomAttributesCacheGenerator_SendMouseEvents_SetMouseMoved_m532965689(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void SendMouseEvents_t3505065032_CustomAttributesCacheGenerator_SendMouseEvents_DoSendMouseEvents_m701697135(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void PropertyAttribute_t2606999759_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 256LL, NULL);
		AttributeUsageAttribute_set_Inherited_m4085818998(tmp, true, NULL);
		AttributeUsageAttribute_set_AllowMultiple_m683830749(tmp, false, NULL);
	}
}
static void TooltipAttribute_t4278647215_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 256LL, NULL);
		AttributeUsageAttribute_set_Inherited_m4085818998(tmp, true, NULL);
		AttributeUsageAttribute_set_AllowMultiple_m683830749(tmp, false, NULL);
	}
}
static void SpaceAttribute_t952253354_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 256LL, NULL);
		AttributeUsageAttribute_set_Inherited_m4085818998(tmp, true, NULL);
		AttributeUsageAttribute_set_AllowMultiple_m683830749(tmp, true, NULL);
	}
}
static void RangeAttribute_t3336560921_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 256LL, NULL);
		AttributeUsageAttribute_set_Inherited_m4085818998(tmp, true, NULL);
		AttributeUsageAttribute_set_AllowMultiple_m683830749(tmp, false, NULL);
	}
}
static void TextAreaAttribute_t2454598508_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 256LL, NULL);
		AttributeUsageAttribute_set_Inherited_m4085818998(tmp, true, NULL);
		AttributeUsageAttribute_set_AllowMultiple_m683830749(tmp, false, NULL);
	}
}
static void Rect_t3681755626_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		UsedByNativeCodeAttribute_t3212052468 * tmp = (UsedByNativeCodeAttribute_t3212052468 *)cache->attributes[0];
		UsedByNativeCodeAttribute__ctor_m2459832290(tmp, NULL);
	}
}
static void SelectionBaseAttribute_t936505999_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 4LL, NULL);
		AttributeUsageAttribute_set_Inherited_m4085818998(tmp, true, NULL);
		AttributeUsageAttribute_set_AllowMultiple_m683830749(tmp, false, NULL);
	}
}
static void SerializePrivateVariables_t2241034664_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[1];
		ObsoleteAttribute__ctor_m2711473620(tmp, il2cpp_codegen_string_new_wrapper("Use SerializeField on the private variables that you want to be serialized instead"), NULL);
	}
}
static void SerializeField_t3073427462_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void PreferBinarySerialization_t2472773525_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 4LL, NULL);
	}
}
static void ISerializationCallbackReceiver_t1665913161_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void StackTraceUtility_t1881293839_CustomAttributesCacheGenerator_StackTraceUtility_SetProjectFolder_m2154926761(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void StackTraceUtility_t1881293839_CustomAttributesCacheGenerator_StackTraceUtility_ExtractStackTrace_m1593581205(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
	{
		SecuritySafeCriticalAttribute_t372031554 * tmp = (SecuritySafeCriticalAttribute_t372031554 *)cache->attributes[1];
		SecuritySafeCriticalAttribute__ctor_m2508714287(tmp, NULL);
	}
}
static void StackTraceUtility_t1881293839_CustomAttributesCacheGenerator_StackTraceUtility_ExtractStringFromExceptionInternal_m2568950546(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
	{
		SecuritySafeCriticalAttribute_t372031554 * tmp = (SecuritySafeCriticalAttribute_t372031554 *)cache->attributes[1];
		SecuritySafeCriticalAttribute__ctor_m2508714287(tmp, NULL);
	}
}
static void StackTraceUtility_t1881293839_CustomAttributesCacheGenerator_StackTraceUtility_PostprocessStacktrace_m2866903298(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void StackTraceUtility_t1881293839_CustomAttributesCacheGenerator_StackTraceUtility_ExtractFormattedStackTrace_m2242276521(CustomAttributesCache* cache)
{
	{
		SecuritySafeCriticalAttribute_t372031554 * tmp = (SecuritySafeCriticalAttribute_t372031554 *)cache->attributes[0];
		SecuritySafeCriticalAttribute__ctor_m2508714287(tmp, NULL);
	}
}
static void UnityException_t2687879050_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void SharedBetweenAnimatorsAttribute_t1565472209_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 4LL, NULL);
		AttributeUsageAttribute_set_AllowMultiple_m683830749(tmp, false, NULL);
	}
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[1];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void StateMachineBehaviour_t2151245329_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void ArgumentCache_t4810721_CustomAttributesCacheGenerator_m_ObjectArgument(CustomAttributesCache* cache)
{
	{
		FormerlySerializedAsAttribute_t3673080018 * tmp = (FormerlySerializedAsAttribute_t3673080018 *)cache->attributes[0];
		FormerlySerializedAsAttribute__ctor_m3551035707(tmp, il2cpp_codegen_string_new_wrapper("objectArgument"), NULL);
	}
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[1];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void ArgumentCache_t4810721_CustomAttributesCacheGenerator_m_ObjectArgumentAssemblyTypeName(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
	{
		FormerlySerializedAsAttribute_t3673080018 * tmp = (FormerlySerializedAsAttribute_t3673080018 *)cache->attributes[1];
		FormerlySerializedAsAttribute__ctor_m3551035707(tmp, il2cpp_codegen_string_new_wrapper("objectArgumentAssemblyTypeName"), NULL);
	}
}
static void ArgumentCache_t4810721_CustomAttributesCacheGenerator_m_IntArgument(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
	{
		FormerlySerializedAsAttribute_t3673080018 * tmp = (FormerlySerializedAsAttribute_t3673080018 *)cache->attributes[1];
		FormerlySerializedAsAttribute__ctor_m3551035707(tmp, il2cpp_codegen_string_new_wrapper("intArgument"), NULL);
	}
}
static void ArgumentCache_t4810721_CustomAttributesCacheGenerator_m_FloatArgument(CustomAttributesCache* cache)
{
	{
		FormerlySerializedAsAttribute_t3673080018 * tmp = (FormerlySerializedAsAttribute_t3673080018 *)cache->attributes[0];
		FormerlySerializedAsAttribute__ctor_m3551035707(tmp, il2cpp_codegen_string_new_wrapper("floatArgument"), NULL);
	}
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[1];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void ArgumentCache_t4810721_CustomAttributesCacheGenerator_m_StringArgument(CustomAttributesCache* cache)
{
	{
		FormerlySerializedAsAttribute_t3673080018 * tmp = (FormerlySerializedAsAttribute_t3673080018 *)cache->attributes[0];
		FormerlySerializedAsAttribute__ctor_m3551035707(tmp, il2cpp_codegen_string_new_wrapper("stringArgument"), NULL);
	}
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[1];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void ArgumentCache_t4810721_CustomAttributesCacheGenerator_m_BoolArgument(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void PersistentCall_t3793436469_CustomAttributesCacheGenerator_m_Target(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
	{
		FormerlySerializedAsAttribute_t3673080018 * tmp = (FormerlySerializedAsAttribute_t3673080018 *)cache->attributes[1];
		FormerlySerializedAsAttribute__ctor_m3551035707(tmp, il2cpp_codegen_string_new_wrapper("instance"), NULL);
	}
}
static void PersistentCall_t3793436469_CustomAttributesCacheGenerator_m_MethodName(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
	{
		FormerlySerializedAsAttribute_t3673080018 * tmp = (FormerlySerializedAsAttribute_t3673080018 *)cache->attributes[1];
		FormerlySerializedAsAttribute__ctor_m3551035707(tmp, il2cpp_codegen_string_new_wrapper("methodName"), NULL);
	}
}
static void PersistentCall_t3793436469_CustomAttributesCacheGenerator_m_Mode(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
	{
		FormerlySerializedAsAttribute_t3673080018 * tmp = (FormerlySerializedAsAttribute_t3673080018 *)cache->attributes[1];
		FormerlySerializedAsAttribute__ctor_m3551035707(tmp, il2cpp_codegen_string_new_wrapper("mode"), NULL);
	}
}
static void PersistentCall_t3793436469_CustomAttributesCacheGenerator_m_Arguments(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
	{
		FormerlySerializedAsAttribute_t3673080018 * tmp = (FormerlySerializedAsAttribute_t3673080018 *)cache->attributes[1];
		FormerlySerializedAsAttribute__ctor_m3551035707(tmp, il2cpp_codegen_string_new_wrapper("arguments"), NULL);
	}
}
static void PersistentCall_t3793436469_CustomAttributesCacheGenerator_m_CallState(CustomAttributesCache* cache)
{
	{
		FormerlySerializedAsAttribute_t3673080018 * tmp = (FormerlySerializedAsAttribute_t3673080018 *)cache->attributes[0];
		FormerlySerializedAsAttribute__ctor_m3551035707(tmp, il2cpp_codegen_string_new_wrapper("m_Enabled"), NULL);
	}
	{
		FormerlySerializedAsAttribute_t3673080018 * tmp = (FormerlySerializedAsAttribute_t3673080018 *)cache->attributes[1];
		FormerlySerializedAsAttribute__ctor_m3551035707(tmp, il2cpp_codegen_string_new_wrapper("enabled"), NULL);
	}
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[2];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void PersistentCallGroup_t339478082_CustomAttributesCacheGenerator_m_Calls(CustomAttributesCache* cache)
{
	{
		FormerlySerializedAsAttribute_t3673080018 * tmp = (FormerlySerializedAsAttribute_t3673080018 *)cache->attributes[0];
		FormerlySerializedAsAttribute__ctor_m3551035707(tmp, il2cpp_codegen_string_new_wrapper("m_Listeners"), NULL);
	}
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[1];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void UnityEventBase_t828812576_CustomAttributesCacheGenerator_m_PersistentCalls(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
	{
		FormerlySerializedAsAttribute_t3673080018 * tmp = (FormerlySerializedAsAttribute_t3673080018 *)cache->attributes[1];
		FormerlySerializedAsAttribute__ctor_m3551035707(tmp, il2cpp_codegen_string_new_wrapper("m_PersistentListeners"), NULL);
	}
}
static void UnityEventBase_t828812576_CustomAttributesCacheGenerator_m_TypeName(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void UnityEvent_t408735097_CustomAttributesCacheGenerator_UnityEvent__ctor_m588741179(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void UnityEvent_1_t4075366602_CustomAttributesCacheGenerator_UnityEvent_1__ctor_m152711818(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void UnityEvent_2_t4075366599_CustomAttributesCacheGenerator_UnityEvent_2__ctor_m153825865(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void UnityEvent_3_t4075366600_CustomAttributesCacheGenerator_UnityEvent_3__ctor_m154939912(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void UnityEvent_4_t4075366597_CustomAttributesCacheGenerator_UnityEvent_4__ctor_m156341191(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
}
static void UnityString_t276356480_CustomAttributesCacheGenerator_UnityString_Format_m2949645127____args1(CustomAttributesCache* cache)
{
	{
		ParamArrayAttribute_t2144993728 * tmp = (ParamArrayAttribute_t2144993728 *)cache->attributes[0];
		ParamArrayAttribute__ctor_m2215984741(tmp, NULL);
	}
}
static void Vector2_t2243707579_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		UsedByNativeCodeAttribute_t3212052468 * tmp = (UsedByNativeCodeAttribute_t3212052468 *)cache->attributes[0];
		UsedByNativeCodeAttribute__ctor_m2459832290(tmp, NULL);
	}
	{
		DefaultMemberAttribute_t889804479 * tmp = (DefaultMemberAttribute_t889804479 *)cache->attributes[1];
		DefaultMemberAttribute__ctor_m2234856827(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void Vector4_t2243707581_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		UsedByNativeCodeAttribute_t3212052468 * tmp = (UsedByNativeCodeAttribute_t3212052468 *)cache->attributes[0];
		UsedByNativeCodeAttribute__ctor_m2459832290(tmp, NULL);
	}
	{
		DefaultMemberAttribute_t889804479 * tmp = (DefaultMemberAttribute_t889804479 *)cache->attributes[1];
		DefaultMemberAttribute__ctor_m2234856827(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void DefaultValueAttribute_t1027170048_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 18432LL, NULL);
	}
}
static void ExcludeFromDocsAttribute_t665825653_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 64LL, NULL);
	}
}
static void ILogHandler_t264057413_CustomAttributesCacheGenerator_ILogHandler_LogFormat_m75756134____args3(CustomAttributesCache* cache)
{
	{
		ParamArrayAttribute_t2144993728 * tmp = (ParamArrayAttribute_t2144993728 *)cache->attributes[0];
		ParamArrayAttribute__ctor_m2215984741(tmp, NULL);
	}
}
static void Logger_t3328995178_CustomAttributesCacheGenerator_U3ClogHandlerU3Ek__BackingField(CustomAttributesCache* cache)
{
	{
		DebuggerBrowsableAttribute_t1386379234 * tmp = (DebuggerBrowsableAttribute_t1386379234 *)cache->attributes[0];
		DebuggerBrowsableAttribute__ctor_m3729055103(tmp, 0LL, NULL);
	}
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[1];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void Logger_t3328995178_CustomAttributesCacheGenerator_U3ClogEnabledU3Ek__BackingField(CustomAttributesCache* cache)
{
	{
		DebuggerBrowsableAttribute_t1386379234 * tmp = (DebuggerBrowsableAttribute_t1386379234 *)cache->attributes[0];
		DebuggerBrowsableAttribute__ctor_m3729055103(tmp, 0LL, NULL);
	}
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[1];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void Logger_t3328995178_CustomAttributesCacheGenerator_U3CfilterLogTypeU3Ek__BackingField(CustomAttributesCache* cache)
{
	{
		DebuggerBrowsableAttribute_t1386379234 * tmp = (DebuggerBrowsableAttribute_t1386379234 *)cache->attributes[0];
		DebuggerBrowsableAttribute__ctor_m3729055103(tmp, 0LL, NULL);
	}
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[1];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void Logger_t3328995178_CustomAttributesCacheGenerator_Logger_get_logHandler_m4190583509(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void Logger_t3328995178_CustomAttributesCacheGenerator_Logger_set_logHandler_m2851576632(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void Logger_t3328995178_CustomAttributesCacheGenerator_Logger_get_logEnabled_m3807759477(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void Logger_t3328995178_CustomAttributesCacheGenerator_Logger_set_logEnabled_m3852234466(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void Logger_t3328995178_CustomAttributesCacheGenerator_Logger_get_filterLogType_m3672438698(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void Logger_t3328995178_CustomAttributesCacheGenerator_Logger_set_filterLogType_m1452353615(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void Logger_t3328995178_CustomAttributesCacheGenerator_Logger_LogFormat_m193464629____args3(CustomAttributesCache* cache)
{
	{
		ParamArrayAttribute_t2144993728 * tmp = (ParamArrayAttribute_t2144993728 *)cache->attributes[0];
		ParamArrayAttribute__ctor_m2215984741(tmp, NULL);
	}
}
static void UsedByNativeCodeAttribute_t3212052468_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 1532LL, NULL);
		AttributeUsageAttribute_set_Inherited_m4085818998(tmp, false, NULL);
	}
}
static void RequiredByNativeCodeAttribute_t1913052472_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 1532LL, NULL);
		AttributeUsageAttribute_set_Inherited_m4085818998(tmp, false, NULL);
	}
}
static void FormerlySerializedAsAttribute_t3673080018_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RequiredByNativeCodeAttribute_t1913052472 * tmp = (RequiredByNativeCodeAttribute_t1913052472 *)cache->attributes[0];
		RequiredByNativeCodeAttribute__ctor_m2374853658(tmp, NULL);
	}
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[1];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 256LL, NULL);
		AttributeUsageAttribute_set_AllowMultiple_m683830749(tmp, true, NULL);
		AttributeUsageAttribute_set_Inherited_m4085818998(tmp, false, NULL);
	}
}
static void TypeInferenceRuleAttribute_t1390152093_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AttributeUsageAttribute_t1057435127 * tmp = (AttributeUsageAttribute_t1057435127 *)cache->attributes[0];
		AttributeUsageAttribute__ctor_m2873156923(tmp, 64LL, NULL);
	}
}
static void NetFxCoreExtensions_t4275971970_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ExtensionAttribute_t1840441203 * tmp = (ExtensionAttribute_t1840441203 *)cache->attributes[0];
		ExtensionAttribute__ctor_m1028297080(tmp, NULL);
	}
}
static void NetFxCoreExtensions_t4275971970_CustomAttributesCacheGenerator_NetFxCoreExtensions_CreateDelegate_m2492743074(CustomAttributesCache* cache)
{
	{
		ExtensionAttribute_t1840441203 * tmp = (ExtensionAttribute_t1840441203 *)cache->attributes[0];
		ExtensionAttribute__ctor_m1028297080(tmp, NULL);
	}
}
static void NetFxCoreExtensions_t4275971970_CustomAttributesCacheGenerator_NetFxCoreExtensions_GetMethodInfo_m2715372889(CustomAttributesCache* cache)
{
	{
		ExtensionAttribute_t1840441203 * tmp = (ExtensionAttribute_t1840441203 *)cache->attributes[0];
		ExtensionAttribute__ctor_m1028297080(tmp, NULL);
	}
}
static void g_UnityEngine_UI_Assembly_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AssemblyCompanyAttribute_t2851673381 * tmp = (AssemblyCompanyAttribute_t2851673381 *)cache->attributes[0];
		AssemblyCompanyAttribute__ctor_m1217508649(tmp, il2cpp_codegen_string_new_wrapper("Microsoft"), NULL);
	}
	{
		AssemblyProductAttribute_t1523443169 * tmp = (AssemblyProductAttribute_t1523443169 *)cache->attributes[1];
		AssemblyProductAttribute__ctor_m1807437213(tmp, il2cpp_codegen_string_new_wrapper("guisystem"), NULL);
	}
	{
		AssemblyCopyrightAttribute_t177123295 * tmp = (AssemblyCopyrightAttribute_t177123295 *)cache->attributes[2];
		AssemblyCopyrightAttribute__ctor_m2712202383(tmp, il2cpp_codegen_string_new_wrapper("Copyright © Microsoft 2013"), NULL);
	}
	{
		AssemblyTitleAttribute_t92945912 * tmp = (AssemblyTitleAttribute_t92945912 *)cache->attributes[3];
		AssemblyTitleAttribute__ctor_m1696431446(tmp, il2cpp_codegen_string_new_wrapper("guisystem"), NULL);
	}
	{
		AssemblyDescriptionAttribute_t1018387888 * tmp = (AssemblyDescriptionAttribute_t1018387888 *)cache->attributes[4];
		AssemblyDescriptionAttribute__ctor_m3307088082(tmp, il2cpp_codegen_string_new_wrapper(""), NULL);
	}
	{
		AssemblyConfigurationAttribute_t1678917172 * tmp = (AssemblyConfigurationAttribute_t1678917172 *)cache->attributes[5];
		AssemblyConfigurationAttribute__ctor_m2611941870(tmp, il2cpp_codegen_string_new_wrapper(""), NULL);
	}
	{
		AssemblyTrademarkAttribute_t3740556705 * tmp = (AssemblyTrademarkAttribute_t3740556705 *)cache->attributes[6];
		AssemblyTrademarkAttribute__ctor_m4184045333(tmp, il2cpp_codegen_string_new_wrapper(""), NULL);
	}
	{
		AssemblyFileVersionAttribute_t2897687916 * tmp = (AssemblyFileVersionAttribute_t2897687916 *)cache->attributes[7];
		AssemblyFileVersionAttribute__ctor_m2026149866(tmp, il2cpp_codegen_string_new_wrapper("1.0.0.0"), NULL);
	}
	{
		DebuggableAttribute_t994551506 * tmp = (DebuggableAttribute_t994551506 *)cache->attributes[8];
		DebuggableAttribute__ctor_m1065484869(tmp, 258LL, NULL);
	}
	{
		RuntimeCompatibilityAttribute_t2430705542 * tmp = (RuntimeCompatibilityAttribute_t2430705542 *)cache->attributes[9];
		RuntimeCompatibilityAttribute__ctor_m1331212510(tmp, NULL);
		RuntimeCompatibilityAttribute_set_WrapNonExceptionThrows_m2174793351(tmp, true, NULL);
	}
	{
		InternalsVisibleToAttribute_t1037732567 * tmp = (InternalsVisibleToAttribute_t1037732567 *)cache->attributes[10];
		InternalsVisibleToAttribute__ctor_m573685517(tmp, il2cpp_codegen_string_new_wrapper("UnityEngine.UI.Tests"), NULL);
	}
	{
		ComVisibleAttribute_t2245573759 * tmp = (ComVisibleAttribute_t2245573759 *)cache->attributes[11];
		ComVisibleAttribute__ctor_m1789587486(tmp, false, NULL);
	}
	{
		GuidAttribute_t222072359 * tmp = (GuidAttribute_t222072359 *)cache->attributes[12];
		GuidAttribute__ctor_m1099153635(tmp, il2cpp_codegen_string_new_wrapper("d4f464c7-9b15-460d-b4bc-2cacd1c1df73"), NULL);
	}
}
static void EventHandle_t942672932_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		FlagsAttribute_t859561169 * tmp = (FlagsAttribute_t859561169 *)cache->attributes[0];
		FlagsAttribute__ctor_m1848108622(tmp, NULL);
	}
}
static void EventSystem_t3466835263_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AddComponentMenu_t1099699699 * tmp = (AddComponentMenu_t1099699699 *)cache->attributes[0];
		AddComponentMenu__ctor_m2231330368(tmp, il2cpp_codegen_string_new_wrapper("Event/Event System"), NULL);
	}
}
static void EventSystem_t3466835263_CustomAttributesCacheGenerator_U3CcurrentU3Ek__BackingField(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
	{
		DebuggerBrowsableAttribute_t1386379234 * tmp = (DebuggerBrowsableAttribute_t1386379234 *)cache->attributes[1];
		DebuggerBrowsableAttribute__ctor_m3729055103(tmp, 0LL, NULL);
	}
}
static void EventSystem_t3466835263_CustomAttributesCacheGenerator_m_FirstSelected(CustomAttributesCache* cache)
{
	{
		FormerlySerializedAsAttribute_t3673080018 * tmp = (FormerlySerializedAsAttribute_t3673080018 *)cache->attributes[0];
		FormerlySerializedAsAttribute__ctor_m3551035707(tmp, il2cpp_codegen_string_new_wrapper("m_Selected"), NULL);
	}
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[1];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void EventSystem_t3466835263_CustomAttributesCacheGenerator_m_sendNavigationEvents(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void EventSystem_t3466835263_CustomAttributesCacheGenerator_m_DragThreshold(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void EventSystem_t3466835263_CustomAttributesCacheGenerator_U3CU3Ef__mgU24cache0(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void EventSystem_t3466835263_CustomAttributesCacheGenerator_EventSystem_get_current_m319019811(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void EventSystem_t3466835263_CustomAttributesCacheGenerator_EventSystem_set_current_m1323649628(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void EventSystem_t3466835263_CustomAttributesCacheGenerator_EventSystem_t3466835263____lastSelectedGameObject_PropertyInfo(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m2711473620(tmp, il2cpp_codegen_string_new_wrapper("lastSelectedGameObject is no longer supported"), NULL);
	}
}
static void EventTrigger_t1967201810_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AddComponentMenu_t1099699699 * tmp = (AddComponentMenu_t1099699699 *)cache->attributes[0];
		AddComponentMenu__ctor_m2231330368(tmp, il2cpp_codegen_string_new_wrapper("Event/Event Trigger"), NULL);
	}
}
static void EventTrigger_t1967201810_CustomAttributesCacheGenerator_m_Delegates(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
	{
		FormerlySerializedAsAttribute_t3673080018 * tmp = (FormerlySerializedAsAttribute_t3673080018 *)cache->attributes[1];
		FormerlySerializedAsAttribute__ctor_m3551035707(tmp, il2cpp_codegen_string_new_wrapper("delegates"), NULL);
	}
}
static void EventTrigger_t1967201810_CustomAttributesCacheGenerator_delegates(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m834417715(tmp, il2cpp_codegen_string_new_wrapper("Please use triggers instead (UnityUpgradable) -> triggers"), true, NULL);
	}
}
static void ExecuteEvents_t1693084770_CustomAttributesCacheGenerator_U3CU3Ef__mgU24cache0(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void ExecuteEvents_t1693084770_CustomAttributesCacheGenerator_U3CU3Ef__mgU24cache1(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void ExecuteEvents_t1693084770_CustomAttributesCacheGenerator_U3CU3Ef__mgU24cache2(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void ExecuteEvents_t1693084770_CustomAttributesCacheGenerator_U3CU3Ef__mgU24cache3(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void ExecuteEvents_t1693084770_CustomAttributesCacheGenerator_U3CU3Ef__mgU24cache4(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void ExecuteEvents_t1693084770_CustomAttributesCacheGenerator_U3CU3Ef__mgU24cache5(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void ExecuteEvents_t1693084770_CustomAttributesCacheGenerator_U3CU3Ef__mgU24cache6(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void ExecuteEvents_t1693084770_CustomAttributesCacheGenerator_U3CU3Ef__mgU24cache7(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void ExecuteEvents_t1693084770_CustomAttributesCacheGenerator_U3CU3Ef__mgU24cache8(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void ExecuteEvents_t1693084770_CustomAttributesCacheGenerator_U3CU3Ef__mgU24cache9(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void ExecuteEvents_t1693084770_CustomAttributesCacheGenerator_U3CU3Ef__mgU24cacheA(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void ExecuteEvents_t1693084770_CustomAttributesCacheGenerator_U3CU3Ef__mgU24cacheB(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void ExecuteEvents_t1693084770_CustomAttributesCacheGenerator_U3CU3Ef__mgU24cacheC(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void ExecuteEvents_t1693084770_CustomAttributesCacheGenerator_U3CU3Ef__mgU24cacheD(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void ExecuteEvents_t1693084770_CustomAttributesCacheGenerator_U3CU3Ef__mgU24cacheE(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void ExecuteEvents_t1693084770_CustomAttributesCacheGenerator_U3CU3Ef__mgU24cacheF(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void ExecuteEvents_t1693084770_CustomAttributesCacheGenerator_U3CU3Ef__mgU24cache10(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void ExecuteEvents_t1693084770_CustomAttributesCacheGenerator_ExecuteEvents_U3Cs_HandlerListPoolU3Em__0_m2903690915(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void AxisEventData_t1524870173_CustomAttributesCacheGenerator_U3CmoveVectorU3Ek__BackingField(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
	{
		DebuggerBrowsableAttribute_t1386379234 * tmp = (DebuggerBrowsableAttribute_t1386379234 *)cache->attributes[1];
		DebuggerBrowsableAttribute__ctor_m3729055103(tmp, 0LL, NULL);
	}
}
static void AxisEventData_t1524870173_CustomAttributesCacheGenerator_U3CmoveDirU3Ek__BackingField(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
	{
		DebuggerBrowsableAttribute_t1386379234 * tmp = (DebuggerBrowsableAttribute_t1386379234 *)cache->attributes[1];
		DebuggerBrowsableAttribute__ctor_m3729055103(tmp, 0LL, NULL);
	}
}
static void AxisEventData_t1524870173_CustomAttributesCacheGenerator_AxisEventData_get_moveVector_m1338727516(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void AxisEventData_t1524870173_CustomAttributesCacheGenerator_AxisEventData_set_moveVector_m3227339885(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void AxisEventData_t1524870173_CustomAttributesCacheGenerator_AxisEventData_get_moveDir_m3968662359(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void AxisEventData_t1524870173_CustomAttributesCacheGenerator_AxisEventData_set_moveDir_m254243794(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void PointerEventData_t1599784723_CustomAttributesCacheGenerator_U3CpointerEnterU3Ek__BackingField(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
	{
		DebuggerBrowsableAttribute_t1386379234 * tmp = (DebuggerBrowsableAttribute_t1386379234 *)cache->attributes[1];
		DebuggerBrowsableAttribute__ctor_m3729055103(tmp, 0LL, NULL);
	}
}
static void PointerEventData_t1599784723_CustomAttributesCacheGenerator_U3ClastPressU3Ek__BackingField(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
	{
		DebuggerBrowsableAttribute_t1386379234 * tmp = (DebuggerBrowsableAttribute_t1386379234 *)cache->attributes[1];
		DebuggerBrowsableAttribute__ctor_m3729055103(tmp, 0LL, NULL);
	}
}
static void PointerEventData_t1599784723_CustomAttributesCacheGenerator_U3CrawPointerPressU3Ek__BackingField(CustomAttributesCache* cache)
{
	{
		DebuggerBrowsableAttribute_t1386379234 * tmp = (DebuggerBrowsableAttribute_t1386379234 *)cache->attributes[0];
		DebuggerBrowsableAttribute__ctor_m3729055103(tmp, 0LL, NULL);
	}
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[1];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void PointerEventData_t1599784723_CustomAttributesCacheGenerator_U3CpointerDragU3Ek__BackingField(CustomAttributesCache* cache)
{
	{
		DebuggerBrowsableAttribute_t1386379234 * tmp = (DebuggerBrowsableAttribute_t1386379234 *)cache->attributes[0];
		DebuggerBrowsableAttribute__ctor_m3729055103(tmp, 0LL, NULL);
	}
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[1];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void PointerEventData_t1599784723_CustomAttributesCacheGenerator_U3CpointerCurrentRaycastU3Ek__BackingField(CustomAttributesCache* cache)
{
	{
		DebuggerBrowsableAttribute_t1386379234 * tmp = (DebuggerBrowsableAttribute_t1386379234 *)cache->attributes[0];
		DebuggerBrowsableAttribute__ctor_m3729055103(tmp, 0LL, NULL);
	}
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[1];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void PointerEventData_t1599784723_CustomAttributesCacheGenerator_U3CpointerPressRaycastU3Ek__BackingField(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
	{
		DebuggerBrowsableAttribute_t1386379234 * tmp = (DebuggerBrowsableAttribute_t1386379234 *)cache->attributes[1];
		DebuggerBrowsableAttribute__ctor_m3729055103(tmp, 0LL, NULL);
	}
}
static void PointerEventData_t1599784723_CustomAttributesCacheGenerator_U3CeligibleForClickU3Ek__BackingField(CustomAttributesCache* cache)
{
	{
		DebuggerBrowsableAttribute_t1386379234 * tmp = (DebuggerBrowsableAttribute_t1386379234 *)cache->attributes[0];
		DebuggerBrowsableAttribute__ctor_m3729055103(tmp, 0LL, NULL);
	}
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[1];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void PointerEventData_t1599784723_CustomAttributesCacheGenerator_U3CpointerIdU3Ek__BackingField(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
	{
		DebuggerBrowsableAttribute_t1386379234 * tmp = (DebuggerBrowsableAttribute_t1386379234 *)cache->attributes[1];
		DebuggerBrowsableAttribute__ctor_m3729055103(tmp, 0LL, NULL);
	}
}
static void PointerEventData_t1599784723_CustomAttributesCacheGenerator_U3CpositionU3Ek__BackingField(CustomAttributesCache* cache)
{
	{
		DebuggerBrowsableAttribute_t1386379234 * tmp = (DebuggerBrowsableAttribute_t1386379234 *)cache->attributes[0];
		DebuggerBrowsableAttribute__ctor_m3729055103(tmp, 0LL, NULL);
	}
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[1];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void PointerEventData_t1599784723_CustomAttributesCacheGenerator_U3CdeltaU3Ek__BackingField(CustomAttributesCache* cache)
{
	{
		DebuggerBrowsableAttribute_t1386379234 * tmp = (DebuggerBrowsableAttribute_t1386379234 *)cache->attributes[0];
		DebuggerBrowsableAttribute__ctor_m3729055103(tmp, 0LL, NULL);
	}
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[1];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void PointerEventData_t1599784723_CustomAttributesCacheGenerator_U3CpressPositionU3Ek__BackingField(CustomAttributesCache* cache)
{
	{
		DebuggerBrowsableAttribute_t1386379234 * tmp = (DebuggerBrowsableAttribute_t1386379234 *)cache->attributes[0];
		DebuggerBrowsableAttribute__ctor_m3729055103(tmp, 0LL, NULL);
	}
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[1];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void PointerEventData_t1599784723_CustomAttributesCacheGenerator_U3CworldPositionU3Ek__BackingField(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
	{
		DebuggerBrowsableAttribute_t1386379234 * tmp = (DebuggerBrowsableAttribute_t1386379234 *)cache->attributes[1];
		DebuggerBrowsableAttribute__ctor_m3729055103(tmp, 0LL, NULL);
	}
}
static void PointerEventData_t1599784723_CustomAttributesCacheGenerator_U3CworldNormalU3Ek__BackingField(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
	{
		DebuggerBrowsableAttribute_t1386379234 * tmp = (DebuggerBrowsableAttribute_t1386379234 *)cache->attributes[1];
		DebuggerBrowsableAttribute__ctor_m3729055103(tmp, 0LL, NULL);
	}
}
static void PointerEventData_t1599784723_CustomAttributesCacheGenerator_U3CclickTimeU3Ek__BackingField(CustomAttributesCache* cache)
{
	{
		DebuggerBrowsableAttribute_t1386379234 * tmp = (DebuggerBrowsableAttribute_t1386379234 *)cache->attributes[0];
		DebuggerBrowsableAttribute__ctor_m3729055103(tmp, 0LL, NULL);
	}
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[1];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void PointerEventData_t1599784723_CustomAttributesCacheGenerator_U3CclickCountU3Ek__BackingField(CustomAttributesCache* cache)
{
	{
		DebuggerBrowsableAttribute_t1386379234 * tmp = (DebuggerBrowsableAttribute_t1386379234 *)cache->attributes[0];
		DebuggerBrowsableAttribute__ctor_m3729055103(tmp, 0LL, NULL);
	}
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[1];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void PointerEventData_t1599784723_CustomAttributesCacheGenerator_U3CscrollDeltaU3Ek__BackingField(CustomAttributesCache* cache)
{
	{
		DebuggerBrowsableAttribute_t1386379234 * tmp = (DebuggerBrowsableAttribute_t1386379234 *)cache->attributes[0];
		DebuggerBrowsableAttribute__ctor_m3729055103(tmp, 0LL, NULL);
	}
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[1];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void PointerEventData_t1599784723_CustomAttributesCacheGenerator_U3CuseDragThresholdU3Ek__BackingField(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
	{
		DebuggerBrowsableAttribute_t1386379234 * tmp = (DebuggerBrowsableAttribute_t1386379234 *)cache->attributes[1];
		DebuggerBrowsableAttribute__ctor_m3729055103(tmp, 0LL, NULL);
	}
}
static void PointerEventData_t1599784723_CustomAttributesCacheGenerator_U3CdraggingU3Ek__BackingField(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
	{
		DebuggerBrowsableAttribute_t1386379234 * tmp = (DebuggerBrowsableAttribute_t1386379234 *)cache->attributes[1];
		DebuggerBrowsableAttribute__ctor_m3729055103(tmp, 0LL, NULL);
	}
}
static void PointerEventData_t1599784723_CustomAttributesCacheGenerator_U3CbuttonU3Ek__BackingField(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
	{
		DebuggerBrowsableAttribute_t1386379234 * tmp = (DebuggerBrowsableAttribute_t1386379234 *)cache->attributes[1];
		DebuggerBrowsableAttribute__ctor_m3729055103(tmp, 0LL, NULL);
	}
}
static void PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_get_pointerEnter_m2114522773(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_set_pointerEnter_m1440587006(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_get_lastPress_m3835070463(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_set_lastPress_m882263356(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_get_rawPointerPress_m448871540(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_set_rawPointerPress_m1484888025(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_get_pointerDrag_m2740415629(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_set_pointerDrag_m3543074708(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_get_pointerCurrentRaycast_m1374279130(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_set_pointerCurrentRaycast_m2431897513(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_get_pointerPressRaycast_m3131640124(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_set_pointerPressRaycast_m2551142399(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_get_eligibleForClick_m2497780621(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_set_eligibleForClick_m2036057844(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_get_pointerId_m2835313597(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_set_pointerId_m2349910516(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_get_position_m2131765015(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_set_position_m794507622(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_get_delta_m1072163964(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_set_delta_m3672873329(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_get_pressPosition_m1206276610(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_set_pressPosition_m2094137883(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_get_worldPosition_m3746978956(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_set_worldPosition_m192283671(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_get_worldNormal_m1704987468(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_set_worldNormal_m2025727441(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_get_clickTime_m2587872034(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_set_clickTime_m3931922487(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_get_clickCount_m4064532478(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_set_clickCount_m2095939005(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_get_scrollDelta_m1283145047(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_set_scrollDelta_m4002219844(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_get_useDragThreshold_m1801224989(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_set_useDragThreshold_m2778439880(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_get_dragging_m220490640(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_set_dragging_m915629341(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_get_button_m2339189303(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_set_button_m3279441906(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_t1599784723____worldPosition_PropertyInfo(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m2711473620(tmp, il2cpp_codegen_string_new_wrapper("Use either pointerCurrentRaycast.worldPosition or pointerPressRaycast.worldPosition"), NULL);
	}
}
static void PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_t1599784723____worldNormal_PropertyInfo(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m2711473620(tmp, il2cpp_codegen_string_new_wrapper("Use either pointerCurrentRaycast.worldNormal or pointerPressRaycast.worldNormal"), NULL);
	}
}
extern const Il2CppType* EventSystem_t3466835263_0_0_0_var;
extern const uint32_t BaseInputModule_t1295781545_CustomAttributesCacheGenerator_MetadataUsageId;
static void BaseInputModule_t1295781545_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (BaseInputModule_t1295781545_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		RequireComponent_t864575032 * tmp = (RequireComponent_t864575032 *)cache->attributes[0];
		RequireComponent__ctor_m3475141952(tmp, il2cpp_codegen_type_get_object(EventSystem_t3466835263_0_0_0_var), NULL);
	}
}
static void StandaloneInputModule_t70867863_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AddComponentMenu_t1099699699 * tmp = (AddComponentMenu_t1099699699 *)cache->attributes[0];
		AddComponentMenu__ctor_m2231330368(tmp, il2cpp_codegen_string_new_wrapper("Event/Standalone Input Module"), NULL);
	}
}
static void StandaloneInputModule_t70867863_CustomAttributesCacheGenerator_m_HorizontalAxis(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void StandaloneInputModule_t70867863_CustomAttributesCacheGenerator_m_VerticalAxis(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void StandaloneInputModule_t70867863_CustomAttributesCacheGenerator_m_SubmitButton(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void StandaloneInputModule_t70867863_CustomAttributesCacheGenerator_m_CancelButton(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void StandaloneInputModule_t70867863_CustomAttributesCacheGenerator_m_InputActionsPerSecond(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void StandaloneInputModule_t70867863_CustomAttributesCacheGenerator_m_RepeatDelay(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void StandaloneInputModule_t70867863_CustomAttributesCacheGenerator_m_ForceModuleActive(CustomAttributesCache* cache)
{
	{
		FormerlySerializedAsAttribute_t3673080018 * tmp = (FormerlySerializedAsAttribute_t3673080018 *)cache->attributes[0];
		FormerlySerializedAsAttribute__ctor_m3551035707(tmp, il2cpp_codegen_string_new_wrapper("m_AllowActivationOnMobileDevice"), NULL);
	}
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[1];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void StandaloneInputModule_t70867863_CustomAttributesCacheGenerator_StandaloneInputModule_t70867863____inputMode_PropertyInfo(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m834417715(tmp, il2cpp_codegen_string_new_wrapper("Mode is no longer needed on input module as it handles both mouse and keyboard simultaneously."), false, NULL);
	}
}
static void StandaloneInputModule_t70867863_CustomAttributesCacheGenerator_StandaloneInputModule_t70867863____allowActivationOnMobileDevice_PropertyInfo(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m2711473620(tmp, il2cpp_codegen_string_new_wrapper("allowActivationOnMobileDevice has been deprecated. Use forceModuleActive instead (UnityUpgradable) -> forceModuleActive"), NULL);
	}
}
static void InputMode_t2680906638_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m834417715(tmp, il2cpp_codegen_string_new_wrapper("Mode is no longer needed on input module as it handles both mouse and keyboard simultaneously."), false, NULL);
	}
}
static void TouchInputModule_t2561058385_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AddComponentMenu_t1099699699 * tmp = (AddComponentMenu_t1099699699 *)cache->attributes[0];
		AddComponentMenu__ctor_m2231330368(tmp, il2cpp_codegen_string_new_wrapper("Event/Touch Input Module"), NULL);
	}
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[1];
		ObsoleteAttribute__ctor_m2711473620(tmp, il2cpp_codegen_string_new_wrapper("TouchInputModule is no longer required as Touch input is now handled in StandaloneInputModule."), NULL);
	}
}
static void TouchInputModule_t2561058385_CustomAttributesCacheGenerator_m_ForceModuleActive(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
	{
		FormerlySerializedAsAttribute_t3673080018 * tmp = (FormerlySerializedAsAttribute_t3673080018 *)cache->attributes[1];
		FormerlySerializedAsAttribute__ctor_m3551035707(tmp, il2cpp_codegen_string_new_wrapper("m_AllowActivationOnStandalone"), NULL);
	}
}
static void TouchInputModule_t2561058385_CustomAttributesCacheGenerator_TouchInputModule_t2561058385____allowActivationOnStandalone_PropertyInfo(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m2711473620(tmp, il2cpp_codegen_string_new_wrapper("allowActivationOnStandalone has been deprecated. Use forceModuleActive instead (UnityUpgradable) -> forceModuleActive"), NULL);
	}
}
static void BaseRaycaster_t2336171397_CustomAttributesCacheGenerator_BaseRaycaster_t2336171397____priority_PropertyInfo(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m834417715(tmp, il2cpp_codegen_string_new_wrapper("Please use sortOrderPriority and renderOrderPriority"), false, NULL);
	}
}
extern const Il2CppType* Camera_t189460977_0_0_0_var;
extern const uint32_t Physics2DRaycaster_t3236822917_CustomAttributesCacheGenerator_MetadataUsageId;
static void Physics2DRaycaster_t3236822917_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Physics2DRaycaster_t3236822917_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		RequireComponent_t864575032 * tmp = (RequireComponent_t864575032 *)cache->attributes[0];
		RequireComponent__ctor_m3475141952(tmp, il2cpp_codegen_type_get_object(Camera_t189460977_0_0_0_var), NULL);
	}
	{
		AddComponentMenu_t1099699699 * tmp = (AddComponentMenu_t1099699699 *)cache->attributes[1];
		AddComponentMenu__ctor_m2231330368(tmp, il2cpp_codegen_string_new_wrapper("Event/Physics 2D Raycaster"), NULL);
	}
}
extern const Il2CppType* Camera_t189460977_0_0_0_var;
extern const uint32_t PhysicsRaycaster_t249603239_CustomAttributesCacheGenerator_MetadataUsageId;
static void PhysicsRaycaster_t249603239_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (PhysicsRaycaster_t249603239_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		RequireComponent_t864575032 * tmp = (RequireComponent_t864575032 *)cache->attributes[0];
		RequireComponent__ctor_m3475141952(tmp, il2cpp_codegen_type_get_object(Camera_t189460977_0_0_0_var), NULL);
	}
	{
		AddComponentMenu_t1099699699 * tmp = (AddComponentMenu_t1099699699 *)cache->attributes[1];
		AddComponentMenu__ctor_m2231330368(tmp, il2cpp_codegen_string_new_wrapper("Event/Physics Raycaster"), NULL);
	}
}
static void PhysicsRaycaster_t249603239_CustomAttributesCacheGenerator_m_EventMask(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void PhysicsRaycaster_t249603239_CustomAttributesCacheGenerator_U3CU3Ef__amU24cache0(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void PhysicsRaycaster_t249603239_CustomAttributesCacheGenerator_PhysicsRaycaster_U3CRaycastU3Em__0_m267334242(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void TweenRunner_1_t2584777480_CustomAttributesCacheGenerator_TweenRunner_1_Start_m2640577060(CustomAttributesCache* cache)
{
	{
		DebuggerHiddenAttribute_t638884887 * tmp = (DebuggerHiddenAttribute_t638884887 *)cache->attributes[0];
		DebuggerHiddenAttribute__ctor_m2012788180(tmp, NULL);
	}
}
static void U3CStartU3Ec__Iterator0_t3220237554_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void U3CStartU3Ec__Iterator0_t3220237554_CustomAttributesCacheGenerator_U3CStartU3Ec__Iterator0__ctor_m3896495454(CustomAttributesCache* cache)
{
	{
		DebuggerHiddenAttribute_t638884887 * tmp = (DebuggerHiddenAttribute_t638884887 *)cache->attributes[0];
		DebuggerHiddenAttribute__ctor_m2012788180(tmp, NULL);
	}
}
static void U3CStartU3Ec__Iterator0_t3220237554_CustomAttributesCacheGenerator_U3CStartU3Ec__Iterator0_System_Collections_Generic_IEnumeratorU3CobjectU3E_get_Current_m757645588(CustomAttributesCache* cache)
{
	{
		DebuggerHiddenAttribute_t638884887 * tmp = (DebuggerHiddenAttribute_t638884887 *)cache->attributes[0];
		DebuggerHiddenAttribute__ctor_m2012788180(tmp, NULL);
	}
}
static void U3CStartU3Ec__Iterator0_t3220237554_CustomAttributesCacheGenerator_U3CStartU3Ec__Iterator0_System_Collections_IEnumerator_get_Current_m290565900(CustomAttributesCache* cache)
{
	{
		DebuggerHiddenAttribute_t638884887 * tmp = (DebuggerHiddenAttribute_t638884887 *)cache->attributes[0];
		DebuggerHiddenAttribute__ctor_m2012788180(tmp, NULL);
	}
}
static void U3CStartU3Ec__Iterator0_t3220237554_CustomAttributesCacheGenerator_U3CStartU3Ec__Iterator0_Dispose_m3787507231(CustomAttributesCache* cache)
{
	{
		DebuggerHiddenAttribute_t638884887 * tmp = (DebuggerHiddenAttribute_t638884887 *)cache->attributes[0];
		DebuggerHiddenAttribute__ctor_m2012788180(tmp, NULL);
	}
}
static void U3CStartU3Ec__Iterator0_t3220237554_CustomAttributesCacheGenerator_U3CStartU3Ec__Iterator0_Reset_m2824154053(CustomAttributesCache* cache)
{
	{
		DebuggerHiddenAttribute_t638884887 * tmp = (DebuggerHiddenAttribute_t638884887 *)cache->attributes[0];
		DebuggerHiddenAttribute__ctor_m2012788180(tmp, NULL);
	}
}
static void AnimationTriggers_t3244928895_CustomAttributesCacheGenerator_m_NormalTrigger(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
	{
		FormerlySerializedAsAttribute_t3673080018 * tmp = (FormerlySerializedAsAttribute_t3673080018 *)cache->attributes[1];
		FormerlySerializedAsAttribute__ctor_m3551035707(tmp, il2cpp_codegen_string_new_wrapper("normalTrigger"), NULL);
	}
}
static void AnimationTriggers_t3244928895_CustomAttributesCacheGenerator_m_HighlightedTrigger(CustomAttributesCache* cache)
{
	{
		FormerlySerializedAsAttribute_t3673080018 * tmp = (FormerlySerializedAsAttribute_t3673080018 *)cache->attributes[0];
		FormerlySerializedAsAttribute__ctor_m3551035707(tmp, il2cpp_codegen_string_new_wrapper("m_SelectedTrigger"), NULL);
	}
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[1];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
	{
		FormerlySerializedAsAttribute_t3673080018 * tmp = (FormerlySerializedAsAttribute_t3673080018 *)cache->attributes[2];
		FormerlySerializedAsAttribute__ctor_m3551035707(tmp, il2cpp_codegen_string_new_wrapper("highlightedTrigger"), NULL);
	}
}
static void AnimationTriggers_t3244928895_CustomAttributesCacheGenerator_m_PressedTrigger(CustomAttributesCache* cache)
{
	{
		FormerlySerializedAsAttribute_t3673080018 * tmp = (FormerlySerializedAsAttribute_t3673080018 *)cache->attributes[0];
		FormerlySerializedAsAttribute__ctor_m3551035707(tmp, il2cpp_codegen_string_new_wrapper("pressedTrigger"), NULL);
	}
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[1];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void AnimationTriggers_t3244928895_CustomAttributesCacheGenerator_m_DisabledTrigger(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
	{
		FormerlySerializedAsAttribute_t3673080018 * tmp = (FormerlySerializedAsAttribute_t3673080018 *)cache->attributes[1];
		FormerlySerializedAsAttribute__ctor_m3551035707(tmp, il2cpp_codegen_string_new_wrapper("disabledTrigger"), NULL);
	}
}
static void Button_t2872111280_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AddComponentMenu_t1099699699 * tmp = (AddComponentMenu_t1099699699 *)cache->attributes[0];
		AddComponentMenu__ctor_m648737891(tmp, il2cpp_codegen_string_new_wrapper("UI/Button"), 30LL, NULL);
	}
}
static void Button_t2872111280_CustomAttributesCacheGenerator_m_OnClick(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
	{
		FormerlySerializedAsAttribute_t3673080018 * tmp = (FormerlySerializedAsAttribute_t3673080018 *)cache->attributes[1];
		FormerlySerializedAsAttribute__ctor_m3551035707(tmp, il2cpp_codegen_string_new_wrapper("onClick"), NULL);
	}
}
static void Button_t2872111280_CustomAttributesCacheGenerator_Button_OnFinishSubmit_m1646528571(CustomAttributesCache* cache)
{
	{
		DebuggerHiddenAttribute_t638884887 * tmp = (DebuggerHiddenAttribute_t638884887 *)cache->attributes[0];
		DebuggerHiddenAttribute__ctor_m2012788180(tmp, NULL);
	}
}
static void U3COnFinishSubmitU3Ec__Iterator0_t99135383_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void U3COnFinishSubmitU3Ec__Iterator0_t99135383_CustomAttributesCacheGenerator_U3COnFinishSubmitU3Ec__Iterator0__ctor_m1529573737(CustomAttributesCache* cache)
{
	{
		DebuggerHiddenAttribute_t638884887 * tmp = (DebuggerHiddenAttribute_t638884887 *)cache->attributes[0];
		DebuggerHiddenAttribute__ctor_m2012788180(tmp, NULL);
	}
}
static void U3COnFinishSubmitU3Ec__Iterator0_t99135383_CustomAttributesCacheGenerator_U3COnFinishSubmitU3Ec__Iterator0_System_Collections_Generic_IEnumeratorU3CobjectU3E_get_Current_m1823105495(CustomAttributesCache* cache)
{
	{
		DebuggerHiddenAttribute_t638884887 * tmp = (DebuggerHiddenAttribute_t638884887 *)cache->attributes[0];
		DebuggerHiddenAttribute__ctor_m2012788180(tmp, NULL);
	}
}
static void U3COnFinishSubmitU3Ec__Iterator0_t99135383_CustomAttributesCacheGenerator_U3COnFinishSubmitU3Ec__Iterator0_System_Collections_IEnumerator_get_Current_m3369622463(CustomAttributesCache* cache)
{
	{
		DebuggerHiddenAttribute_t638884887 * tmp = (DebuggerHiddenAttribute_t638884887 *)cache->attributes[0];
		DebuggerHiddenAttribute__ctor_m2012788180(tmp, NULL);
	}
}
static void U3COnFinishSubmitU3Ec__Iterator0_t99135383_CustomAttributesCacheGenerator_U3COnFinishSubmitU3Ec__Iterator0_Dispose_m998931244(CustomAttributesCache* cache)
{
	{
		DebuggerHiddenAttribute_t638884887 * tmp = (DebuggerHiddenAttribute_t638884887 *)cache->attributes[0];
		DebuggerHiddenAttribute__ctor_m2012788180(tmp, NULL);
	}
}
static void U3COnFinishSubmitU3Ec__Iterator0_t99135383_CustomAttributesCacheGenerator_U3COnFinishSubmitU3Ec__Iterator0_Reset_m2080388334(CustomAttributesCache* cache)
{
	{
		DebuggerHiddenAttribute_t638884887 * tmp = (DebuggerHiddenAttribute_t638884887 *)cache->attributes[0];
		DebuggerHiddenAttribute__ctor_m2012788180(tmp, NULL);
	}
}
static void CanvasUpdateRegistry_t1780385998_CustomAttributesCacheGenerator_U3CU3Ef__mgU24cache0(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void ColorBlock_t2652774230_CustomAttributesCacheGenerator_m_NormalColor(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
	{
		FormerlySerializedAsAttribute_t3673080018 * tmp = (FormerlySerializedAsAttribute_t3673080018 *)cache->attributes[1];
		FormerlySerializedAsAttribute__ctor_m3551035707(tmp, il2cpp_codegen_string_new_wrapper("normalColor"), NULL);
	}
}
static void ColorBlock_t2652774230_CustomAttributesCacheGenerator_m_HighlightedColor(CustomAttributesCache* cache)
{
	{
		FormerlySerializedAsAttribute_t3673080018 * tmp = (FormerlySerializedAsAttribute_t3673080018 *)cache->attributes[0];
		FormerlySerializedAsAttribute__ctor_m3551035707(tmp, il2cpp_codegen_string_new_wrapper("highlightedColor"), NULL);
	}
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[1];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
	{
		FormerlySerializedAsAttribute_t3673080018 * tmp = (FormerlySerializedAsAttribute_t3673080018 *)cache->attributes[2];
		FormerlySerializedAsAttribute__ctor_m3551035707(tmp, il2cpp_codegen_string_new_wrapper("m_SelectedColor"), NULL);
	}
}
static void ColorBlock_t2652774230_CustomAttributesCacheGenerator_m_PressedColor(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
	{
		FormerlySerializedAsAttribute_t3673080018 * tmp = (FormerlySerializedAsAttribute_t3673080018 *)cache->attributes[1];
		FormerlySerializedAsAttribute__ctor_m3551035707(tmp, il2cpp_codegen_string_new_wrapper("pressedColor"), NULL);
	}
}
static void ColorBlock_t2652774230_CustomAttributesCacheGenerator_m_DisabledColor(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
	{
		FormerlySerializedAsAttribute_t3673080018 * tmp = (FormerlySerializedAsAttribute_t3673080018 *)cache->attributes[1];
		FormerlySerializedAsAttribute__ctor_m3551035707(tmp, il2cpp_codegen_string_new_wrapper("disabledColor"), NULL);
	}
}
static void ColorBlock_t2652774230_CustomAttributesCacheGenerator_m_ColorMultiplier(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
	{
		RangeAttribute_t3336560921 * tmp = (RangeAttribute_t3336560921 *)cache->attributes[1];
		RangeAttribute__ctor_m1657271662(tmp, 1.0f, 5.0f, NULL);
	}
}
static void ColorBlock_t2652774230_CustomAttributesCacheGenerator_m_FadeDuration(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
	{
		FormerlySerializedAsAttribute_t3673080018 * tmp = (FormerlySerializedAsAttribute_t3673080018 *)cache->attributes[1];
		FormerlySerializedAsAttribute__ctor_m3551035707(tmp, il2cpp_codegen_string_new_wrapper("fadeDuration"), NULL);
	}
}
extern const Il2CppType* RectTransform_t3349966182_0_0_0_var;
extern const uint32_t Dropdown_t1985816271_CustomAttributesCacheGenerator_MetadataUsageId;
static void Dropdown_t1985816271_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Dropdown_t1985816271_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		RequireComponent_t864575032 * tmp = (RequireComponent_t864575032 *)cache->attributes[0];
		RequireComponent__ctor_m3475141952(tmp, il2cpp_codegen_type_get_object(RectTransform_t3349966182_0_0_0_var), NULL);
	}
	{
		AddComponentMenu_t1099699699 * tmp = (AddComponentMenu_t1099699699 *)cache->attributes[1];
		AddComponentMenu__ctor_m648737891(tmp, il2cpp_codegen_string_new_wrapper("UI/Dropdown"), 35LL, NULL);
	}
}
static void Dropdown_t1985816271_CustomAttributesCacheGenerator_m_Template(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void Dropdown_t1985816271_CustomAttributesCacheGenerator_m_CaptionText(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void Dropdown_t1985816271_CustomAttributesCacheGenerator_m_CaptionImage(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void Dropdown_t1985816271_CustomAttributesCacheGenerator_m_ItemText(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
	{
		SpaceAttribute_t952253354 * tmp = (SpaceAttribute_t952253354 *)cache->attributes[1];
		SpaceAttribute__ctor_m187290553(tmp, NULL);
	}
}
static void Dropdown_t1985816271_CustomAttributesCacheGenerator_m_ItemImage(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void Dropdown_t1985816271_CustomAttributesCacheGenerator_m_Value(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
	{
		SpaceAttribute_t952253354 * tmp = (SpaceAttribute_t952253354 *)cache->attributes[1];
		SpaceAttribute__ctor_m187290553(tmp, NULL);
	}
}
static void Dropdown_t1985816271_CustomAttributesCacheGenerator_m_Options(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
	{
		SpaceAttribute_t952253354 * tmp = (SpaceAttribute_t952253354 *)cache->attributes[1];
		SpaceAttribute__ctor_m187290553(tmp, NULL);
	}
}
static void Dropdown_t1985816271_CustomAttributesCacheGenerator_m_OnValueChanged(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
	{
		SpaceAttribute_t952253354 * tmp = (SpaceAttribute_t952253354 *)cache->attributes[1];
		SpaceAttribute__ctor_m187290553(tmp, NULL);
	}
}
static void Dropdown_t1985816271_CustomAttributesCacheGenerator_Dropdown_DelayedDestroyDropdownList_m1497053282(CustomAttributesCache* cache)
{
	{
		DebuggerHiddenAttribute_t638884887 * tmp = (DebuggerHiddenAttribute_t638884887 *)cache->attributes[0];
		DebuggerHiddenAttribute__ctor_m2012788180(tmp, NULL);
	}
}
static void DropdownItem_t4139978805_CustomAttributesCacheGenerator_m_Text(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void DropdownItem_t4139978805_CustomAttributesCacheGenerator_m_Image(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void DropdownItem_t4139978805_CustomAttributesCacheGenerator_m_RectTransform(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void DropdownItem_t4139978805_CustomAttributesCacheGenerator_m_Toggle(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void OptionData_t2420267500_CustomAttributesCacheGenerator_m_Text(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void OptionData_t2420267500_CustomAttributesCacheGenerator_m_Image(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void OptionDataList_t2653737080_CustomAttributesCacheGenerator_m_Options(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void U3CShowU3Ec__AnonStorey1_t2089497532_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void U3CDelayedDestroyDropdownListU3Ec__Iterator0_t3461999471_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void U3CDelayedDestroyDropdownListU3Ec__Iterator0_t3461999471_CustomAttributesCacheGenerator_U3CDelayedDestroyDropdownListU3Ec__Iterator0__ctor_m3589639289(CustomAttributesCache* cache)
{
	{
		DebuggerHiddenAttribute_t638884887 * tmp = (DebuggerHiddenAttribute_t638884887 *)cache->attributes[0];
		DebuggerHiddenAttribute__ctor_m2012788180(tmp, NULL);
	}
}
static void U3CDelayedDestroyDropdownListU3Ec__Iterator0_t3461999471_CustomAttributesCacheGenerator_U3CDelayedDestroyDropdownListU3Ec__Iterator0_System_Collections_Generic_IEnumeratorU3CobjectU3E_get_Current_m2099826311(CustomAttributesCache* cache)
{
	{
		DebuggerHiddenAttribute_t638884887 * tmp = (DebuggerHiddenAttribute_t638884887 *)cache->attributes[0];
		DebuggerHiddenAttribute__ctor_m2012788180(tmp, NULL);
	}
}
static void U3CDelayedDestroyDropdownListU3Ec__Iterator0_t3461999471_CustomAttributesCacheGenerator_U3CDelayedDestroyDropdownListU3Ec__Iterator0_System_Collections_IEnumerator_get_Current_m622919791(CustomAttributesCache* cache)
{
	{
		DebuggerHiddenAttribute_t638884887 * tmp = (DebuggerHiddenAttribute_t638884887 *)cache->attributes[0];
		DebuggerHiddenAttribute__ctor_m2012788180(tmp, NULL);
	}
}
static void U3CDelayedDestroyDropdownListU3Ec__Iterator0_t3461999471_CustomAttributesCacheGenerator_U3CDelayedDestroyDropdownListU3Ec__Iterator0_Dispose_m3973609370(CustomAttributesCache* cache)
{
	{
		DebuggerHiddenAttribute_t638884887 * tmp = (DebuggerHiddenAttribute_t638884887 *)cache->attributes[0];
		DebuggerHiddenAttribute__ctor_m2012788180(tmp, NULL);
	}
}
static void U3CDelayedDestroyDropdownListU3Ec__Iterator0_t3461999471_CustomAttributesCacheGenerator_U3CDelayedDestroyDropdownListU3Ec__Iterator0_Reset_m3485957852(CustomAttributesCache* cache)
{
	{
		DebuggerHiddenAttribute_t638884887 * tmp = (DebuggerHiddenAttribute_t638884887 *)cache->attributes[0];
		DebuggerHiddenAttribute__ctor_m2012788180(tmp, NULL);
	}
}
static void FontData_t2614388407_CustomAttributesCacheGenerator_m_Font(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
	{
		FormerlySerializedAsAttribute_t3673080018 * tmp = (FormerlySerializedAsAttribute_t3673080018 *)cache->attributes[1];
		FormerlySerializedAsAttribute__ctor_m3551035707(tmp, il2cpp_codegen_string_new_wrapper("font"), NULL);
	}
}
static void FontData_t2614388407_CustomAttributesCacheGenerator_m_FontSize(CustomAttributesCache* cache)
{
	{
		FormerlySerializedAsAttribute_t3673080018 * tmp = (FormerlySerializedAsAttribute_t3673080018 *)cache->attributes[0];
		FormerlySerializedAsAttribute__ctor_m3551035707(tmp, il2cpp_codegen_string_new_wrapper("fontSize"), NULL);
	}
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[1];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void FontData_t2614388407_CustomAttributesCacheGenerator_m_FontStyle(CustomAttributesCache* cache)
{
	{
		FormerlySerializedAsAttribute_t3673080018 * tmp = (FormerlySerializedAsAttribute_t3673080018 *)cache->attributes[0];
		FormerlySerializedAsAttribute__ctor_m3551035707(tmp, il2cpp_codegen_string_new_wrapper("fontStyle"), NULL);
	}
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[1];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void FontData_t2614388407_CustomAttributesCacheGenerator_m_BestFit(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void FontData_t2614388407_CustomAttributesCacheGenerator_m_MinSize(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void FontData_t2614388407_CustomAttributesCacheGenerator_m_MaxSize(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void FontData_t2614388407_CustomAttributesCacheGenerator_m_Alignment(CustomAttributesCache* cache)
{
	{
		FormerlySerializedAsAttribute_t3673080018 * tmp = (FormerlySerializedAsAttribute_t3673080018 *)cache->attributes[0];
		FormerlySerializedAsAttribute__ctor_m3551035707(tmp, il2cpp_codegen_string_new_wrapper("alignment"), NULL);
	}
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[1];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void FontData_t2614388407_CustomAttributesCacheGenerator_m_AlignByGeometry(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void FontData_t2614388407_CustomAttributesCacheGenerator_m_RichText(CustomAttributesCache* cache)
{
	{
		FormerlySerializedAsAttribute_t3673080018 * tmp = (FormerlySerializedAsAttribute_t3673080018 *)cache->attributes[0];
		FormerlySerializedAsAttribute__ctor_m3551035707(tmp, il2cpp_codegen_string_new_wrapper("richText"), NULL);
	}
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[1];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void FontData_t2614388407_CustomAttributesCacheGenerator_m_HorizontalOverflow(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void FontData_t2614388407_CustomAttributesCacheGenerator_m_VerticalOverflow(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void FontData_t2614388407_CustomAttributesCacheGenerator_m_LineSpacing(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void FontUpdateTracker_t2633059652_CustomAttributesCacheGenerator_U3CU3Ef__mgU24cache0(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void FontUpdateTracker_t2633059652_CustomAttributesCacheGenerator_U3CU3Ef__mgU24cache1(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
extern const Il2CppType* CanvasRenderer_t261436805_0_0_0_var;
extern const Il2CppType* RectTransform_t3349966182_0_0_0_var;
extern const uint32_t Graphic_t2426225576_CustomAttributesCacheGenerator_MetadataUsageId;
static void Graphic_t2426225576_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Graphic_t2426225576_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		RequireComponent_t864575032 * tmp = (RequireComponent_t864575032 *)cache->attributes[0];
		RequireComponent__ctor_m3475141952(tmp, il2cpp_codegen_type_get_object(CanvasRenderer_t261436805_0_0_0_var), NULL);
	}
	{
		ExecuteInEditMode_t3043633143 * tmp = (ExecuteInEditMode_t3043633143 *)cache->attributes[1];
		ExecuteInEditMode__ctor_m495837196(tmp, NULL);
	}
	{
		DisallowMultipleComponent_t2656950 * tmp = (DisallowMultipleComponent_t2656950 *)cache->attributes[2];
		DisallowMultipleComponent__ctor_m533952133(tmp, NULL);
	}
	{
		RequireComponent_t864575032 * tmp = (RequireComponent_t864575032 *)cache->attributes[3];
		RequireComponent__ctor_m3475141952(tmp, il2cpp_codegen_type_get_object(RectTransform_t3349966182_0_0_0_var), NULL);
	}
}
static void Graphic_t2426225576_CustomAttributesCacheGenerator_m_Material(CustomAttributesCache* cache)
{
	{
		FormerlySerializedAsAttribute_t3673080018 * tmp = (FormerlySerializedAsAttribute_t3673080018 *)cache->attributes[0];
		FormerlySerializedAsAttribute__ctor_m3551035707(tmp, il2cpp_codegen_string_new_wrapper("m_Mat"), NULL);
	}
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[1];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void Graphic_t2426225576_CustomAttributesCacheGenerator_m_Color(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void Graphic_t2426225576_CustomAttributesCacheGenerator_m_RaycastTarget(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void Graphic_t2426225576_CustomAttributesCacheGenerator_U3CuseLegacyMeshGenerationU3Ek__BackingField(CustomAttributesCache* cache)
{
	{
		DebuggerBrowsableAttribute_t1386379234 * tmp = (DebuggerBrowsableAttribute_t1386379234 *)cache->attributes[0];
		DebuggerBrowsableAttribute__ctor_m3729055103(tmp, 0LL, NULL);
	}
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[1];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void Graphic_t2426225576_CustomAttributesCacheGenerator_Graphic_get_useLegacyMeshGeneration_m1366444625(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void Graphic_t2426225576_CustomAttributesCacheGenerator_Graphic_set_useLegacyMeshGeneration_m3023904722(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void Graphic_t2426225576_CustomAttributesCacheGenerator_Graphic_OnFillVBO_m1723985607(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m834417715(tmp, il2cpp_codegen_string_new_wrapper("Use OnPopulateMesh instead."), true, NULL);
	}
}
static void Graphic_t2426225576_CustomAttributesCacheGenerator_Graphic_OnPopulateMesh_m2598985015(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m834417715(tmp, il2cpp_codegen_string_new_wrapper("Use OnPopulateMesh(VertexHelper vh) instead."), false, NULL);
	}
}
extern const Il2CppType* Canvas_t209405766_0_0_0_var;
extern const uint32_t GraphicRaycaster_t410733016_CustomAttributesCacheGenerator_MetadataUsageId;
static void GraphicRaycaster_t410733016_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (GraphicRaycaster_t410733016_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		AddComponentMenu_t1099699699 * tmp = (AddComponentMenu_t1099699699 *)cache->attributes[0];
		AddComponentMenu__ctor_m2231330368(tmp, il2cpp_codegen_string_new_wrapper("Event/Graphic Raycaster"), NULL);
	}
	{
		RequireComponent_t864575032 * tmp = (RequireComponent_t864575032 *)cache->attributes[1];
		RequireComponent__ctor_m3475141952(tmp, il2cpp_codegen_type_get_object(Canvas_t209405766_0_0_0_var), NULL);
	}
}
static void GraphicRaycaster_t410733016_CustomAttributesCacheGenerator_m_IgnoreReversedGraphics(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
	{
		FormerlySerializedAsAttribute_t3673080018 * tmp = (FormerlySerializedAsAttribute_t3673080018 *)cache->attributes[1];
		FormerlySerializedAsAttribute__ctor_m3551035707(tmp, il2cpp_codegen_string_new_wrapper("ignoreReversedGraphics"), NULL);
	}
}
static void GraphicRaycaster_t410733016_CustomAttributesCacheGenerator_m_BlockingObjects(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
	{
		FormerlySerializedAsAttribute_t3673080018 * tmp = (FormerlySerializedAsAttribute_t3673080018 *)cache->attributes[1];
		FormerlySerializedAsAttribute__ctor_m3551035707(tmp, il2cpp_codegen_string_new_wrapper("blockingObjects"), NULL);
	}
}
static void GraphicRaycaster_t410733016_CustomAttributesCacheGenerator_m_BlockingMask(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void GraphicRaycaster_t410733016_CustomAttributesCacheGenerator_U3CU3Ef__amU24cache0(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void GraphicRaycaster_t410733016_CustomAttributesCacheGenerator_GraphicRaycaster_U3CRaycastU3Em__0_m3971200721(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void IGraphicEnabledDisabled_t858530280_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m2711473620(tmp, il2cpp_codegen_string_new_wrapper("Not supported anymore"), NULL);
	}
}
static void Image_t2042527209_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AddComponentMenu_t1099699699 * tmp = (AddComponentMenu_t1099699699 *)cache->attributes[0];
		AddComponentMenu__ctor_m648737891(tmp, il2cpp_codegen_string_new_wrapper("UI/Image"), 11LL, NULL);
	}
}
static void Image_t2042527209_CustomAttributesCacheGenerator_m_Sprite(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
	{
		FormerlySerializedAsAttribute_t3673080018 * tmp = (FormerlySerializedAsAttribute_t3673080018 *)cache->attributes[1];
		FormerlySerializedAsAttribute__ctor_m3551035707(tmp, il2cpp_codegen_string_new_wrapper("m_Frame"), NULL);
	}
}
static void Image_t2042527209_CustomAttributesCacheGenerator_m_Type(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void Image_t2042527209_CustomAttributesCacheGenerator_m_PreserveAspect(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void Image_t2042527209_CustomAttributesCacheGenerator_m_FillCenter(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void Image_t2042527209_CustomAttributesCacheGenerator_m_FillMethod(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void Image_t2042527209_CustomAttributesCacheGenerator_m_FillAmount(CustomAttributesCache* cache)
{
	{
		RangeAttribute_t3336560921 * tmp = (RangeAttribute_t3336560921 *)cache->attributes[0];
		RangeAttribute__ctor_m1657271662(tmp, 0.0f, 1.0f, NULL);
	}
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[1];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void Image_t2042527209_CustomAttributesCacheGenerator_m_FillClockwise(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void Image_t2042527209_CustomAttributesCacheGenerator_m_FillOrigin(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void Image_t2042527209_CustomAttributesCacheGenerator_Image_t2042527209____eventAlphaThreshold_PropertyInfo(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m2711473620(tmp, il2cpp_codegen_string_new_wrapper("eventAlphaThreshold has been deprecated. Use eventMinimumAlphaThreshold instead (UnityUpgradable) -> alphaHitTestMinimumThreshold"), NULL);
	}
}
static void IMask_t3205327603_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m834417715(tmp, il2cpp_codegen_string_new_wrapper("Not supported anymore."), true, NULL);
	}
}
static void InputField_t1631627530_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AddComponentMenu_t1099699699 * tmp = (AddComponentMenu_t1099699699 *)cache->attributes[0];
		AddComponentMenu__ctor_m648737891(tmp, il2cpp_codegen_string_new_wrapper("UI/Input Field"), 31LL, NULL);
	}
}
static void InputField_t1631627530_CustomAttributesCacheGenerator_m_TextComponent(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
	{
		FormerlySerializedAsAttribute_t3673080018 * tmp = (FormerlySerializedAsAttribute_t3673080018 *)cache->attributes[1];
		FormerlySerializedAsAttribute__ctor_m3551035707(tmp, il2cpp_codegen_string_new_wrapper("text"), NULL);
	}
}
static void InputField_t1631627530_CustomAttributesCacheGenerator_m_Placeholder(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void InputField_t1631627530_CustomAttributesCacheGenerator_m_ContentType(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void InputField_t1631627530_CustomAttributesCacheGenerator_m_InputType(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
	{
		FormerlySerializedAsAttribute_t3673080018 * tmp = (FormerlySerializedAsAttribute_t3673080018 *)cache->attributes[1];
		FormerlySerializedAsAttribute__ctor_m3551035707(tmp, il2cpp_codegen_string_new_wrapper("inputType"), NULL);
	}
}
static void InputField_t1631627530_CustomAttributesCacheGenerator_m_AsteriskChar(CustomAttributesCache* cache)
{
	{
		FormerlySerializedAsAttribute_t3673080018 * tmp = (FormerlySerializedAsAttribute_t3673080018 *)cache->attributes[0];
		FormerlySerializedAsAttribute__ctor_m3551035707(tmp, il2cpp_codegen_string_new_wrapper("asteriskChar"), NULL);
	}
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[1];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void InputField_t1631627530_CustomAttributesCacheGenerator_m_KeyboardType(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
	{
		FormerlySerializedAsAttribute_t3673080018 * tmp = (FormerlySerializedAsAttribute_t3673080018 *)cache->attributes[1];
		FormerlySerializedAsAttribute__ctor_m3551035707(tmp, il2cpp_codegen_string_new_wrapper("keyboardType"), NULL);
	}
}
static void InputField_t1631627530_CustomAttributesCacheGenerator_m_LineType(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void InputField_t1631627530_CustomAttributesCacheGenerator_m_HideMobileInput(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
	{
		FormerlySerializedAsAttribute_t3673080018 * tmp = (FormerlySerializedAsAttribute_t3673080018 *)cache->attributes[1];
		FormerlySerializedAsAttribute__ctor_m3551035707(tmp, il2cpp_codegen_string_new_wrapper("hideMobileInput"), NULL);
	}
}
static void InputField_t1631627530_CustomAttributesCacheGenerator_m_CharacterValidation(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
	{
		FormerlySerializedAsAttribute_t3673080018 * tmp = (FormerlySerializedAsAttribute_t3673080018 *)cache->attributes[1];
		FormerlySerializedAsAttribute__ctor_m3551035707(tmp, il2cpp_codegen_string_new_wrapper("validation"), NULL);
	}
}
static void InputField_t1631627530_CustomAttributesCacheGenerator_m_CharacterLimit(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
	{
		FormerlySerializedAsAttribute_t3673080018 * tmp = (FormerlySerializedAsAttribute_t3673080018 *)cache->attributes[1];
		FormerlySerializedAsAttribute__ctor_m3551035707(tmp, il2cpp_codegen_string_new_wrapper("characterLimit"), NULL);
	}
}
static void InputField_t1631627530_CustomAttributesCacheGenerator_m_OnEndEdit(CustomAttributesCache* cache)
{
	{
		FormerlySerializedAsAttribute_t3673080018 * tmp = (FormerlySerializedAsAttribute_t3673080018 *)cache->attributes[0];
		FormerlySerializedAsAttribute__ctor_m3551035707(tmp, il2cpp_codegen_string_new_wrapper("m_OnSubmit"), NULL);
	}
	{
		FormerlySerializedAsAttribute_t3673080018 * tmp = (FormerlySerializedAsAttribute_t3673080018 *)cache->attributes[1];
		FormerlySerializedAsAttribute__ctor_m3551035707(tmp, il2cpp_codegen_string_new_wrapper("m_EndEdit"), NULL);
	}
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[2];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
	{
		FormerlySerializedAsAttribute_t3673080018 * tmp = (FormerlySerializedAsAttribute_t3673080018 *)cache->attributes[3];
		FormerlySerializedAsAttribute__ctor_m3551035707(tmp, il2cpp_codegen_string_new_wrapper("onSubmit"), NULL);
	}
}
static void InputField_t1631627530_CustomAttributesCacheGenerator_m_OnValueChanged(CustomAttributesCache* cache)
{
	{
		FormerlySerializedAsAttribute_t3673080018 * tmp = (FormerlySerializedAsAttribute_t3673080018 *)cache->attributes[0];
		FormerlySerializedAsAttribute__ctor_m3551035707(tmp, il2cpp_codegen_string_new_wrapper("m_OnValueChange"), NULL);
	}
	{
		FormerlySerializedAsAttribute_t3673080018 * tmp = (FormerlySerializedAsAttribute_t3673080018 *)cache->attributes[1];
		FormerlySerializedAsAttribute__ctor_m3551035707(tmp, il2cpp_codegen_string_new_wrapper("onValueChange"), NULL);
	}
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[2];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void InputField_t1631627530_CustomAttributesCacheGenerator_m_OnValidateInput(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
	{
		FormerlySerializedAsAttribute_t3673080018 * tmp = (FormerlySerializedAsAttribute_t3673080018 *)cache->attributes[1];
		FormerlySerializedAsAttribute__ctor_m3551035707(tmp, il2cpp_codegen_string_new_wrapper("onValidateInput"), NULL);
	}
}
static void InputField_t1631627530_CustomAttributesCacheGenerator_m_CaretColor(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void InputField_t1631627530_CustomAttributesCacheGenerator_m_CustomCaretColor(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void InputField_t1631627530_CustomAttributesCacheGenerator_m_SelectionColor(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
	{
		FormerlySerializedAsAttribute_t3673080018 * tmp = (FormerlySerializedAsAttribute_t3673080018 *)cache->attributes[1];
		FormerlySerializedAsAttribute__ctor_m3551035707(tmp, il2cpp_codegen_string_new_wrapper("selectionColor"), NULL);
	}
}
static void InputField_t1631627530_CustomAttributesCacheGenerator_m_Text(CustomAttributesCache* cache)
{
	{
		FormerlySerializedAsAttribute_t3673080018 * tmp = (FormerlySerializedAsAttribute_t3673080018 *)cache->attributes[0];
		FormerlySerializedAsAttribute__ctor_m3551035707(tmp, il2cpp_codegen_string_new_wrapper("mValue"), NULL);
	}
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[1];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void InputField_t1631627530_CustomAttributesCacheGenerator_m_CaretBlinkRate(CustomAttributesCache* cache)
{
	{
		RangeAttribute_t3336560921 * tmp = (RangeAttribute_t3336560921 *)cache->attributes[0];
		RangeAttribute__ctor_m1657271662(tmp, 0.0f, 4.0f, NULL);
	}
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[1];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void InputField_t1631627530_CustomAttributesCacheGenerator_m_CaretWidth(CustomAttributesCache* cache)
{
	{
		RangeAttribute_t3336560921 * tmp = (RangeAttribute_t3336560921 *)cache->attributes[0];
		RangeAttribute__ctor_m1657271662(tmp, 1.0f, 5.0f, NULL);
	}
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[1];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void InputField_t1631627530_CustomAttributesCacheGenerator_m_ReadOnly(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void InputField_t1631627530_CustomAttributesCacheGenerator_InputField_CaretBlink_m3960486606(CustomAttributesCache* cache)
{
	{
		DebuggerHiddenAttribute_t638884887 * tmp = (DebuggerHiddenAttribute_t638884887 *)cache->attributes[0];
		DebuggerHiddenAttribute__ctor_m2012788180(tmp, NULL);
	}
}
static void InputField_t1631627530_CustomAttributesCacheGenerator_InputField_ScreenToLocal_m2281574224(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m2711473620(tmp, il2cpp_codegen_string_new_wrapper("This function is no longer used. Please use RectTransformUtility.ScreenPointToLocalPointInRectangle() instead."), NULL);
	}
}
static void InputField_t1631627530_CustomAttributesCacheGenerator_InputField_MouseDragOutsideRect_m3758282095(CustomAttributesCache* cache)
{
	{
		DebuggerHiddenAttribute_t638884887 * tmp = (DebuggerHiddenAttribute_t638884887 *)cache->attributes[0];
		DebuggerHiddenAttribute__ctor_m2012788180(tmp, NULL);
	}
}
static void InputField_t1631627530_CustomAttributesCacheGenerator_InputField_SetToCustomIfContentTypeIsNot_m2121105067____allowedContentTypes0(CustomAttributesCache* cache)
{
	{
		ParamArrayAttribute_t2144993728 * tmp = (ParamArrayAttribute_t2144993728 *)cache->attributes[0];
		ParamArrayAttribute__ctor_m2215984741(tmp, NULL);
	}
}
static void InputField_t1631627530_CustomAttributesCacheGenerator_InputField_t1631627530____onValueChange_PropertyInfo(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m2711473620(tmp, il2cpp_codegen_string_new_wrapper("onValueChange has been renamed to onValueChanged"), NULL);
	}
}
static void U3CCaretBlinkU3Ec__Iterator0_t906898126_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void U3CCaretBlinkU3Ec__Iterator0_t906898126_CustomAttributesCacheGenerator_U3CCaretBlinkU3Ec__Iterator0__ctor_m3164435928(CustomAttributesCache* cache)
{
	{
		DebuggerHiddenAttribute_t638884887 * tmp = (DebuggerHiddenAttribute_t638884887 *)cache->attributes[0];
		DebuggerHiddenAttribute__ctor_m2012788180(tmp, NULL);
	}
}
static void U3CCaretBlinkU3Ec__Iterator0_t906898126_CustomAttributesCacheGenerator_U3CCaretBlinkU3Ec__Iterator0_System_Collections_Generic_IEnumeratorU3CobjectU3E_get_Current_m3541562536(CustomAttributesCache* cache)
{
	{
		DebuggerHiddenAttribute_t638884887 * tmp = (DebuggerHiddenAttribute_t638884887 *)cache->attributes[0];
		DebuggerHiddenAttribute__ctor_m2012788180(tmp, NULL);
	}
}
static void U3CCaretBlinkU3Ec__Iterator0_t906898126_CustomAttributesCacheGenerator_U3CCaretBlinkU3Ec__Iterator0_System_Collections_IEnumerator_get_Current_m2309548992(CustomAttributesCache* cache)
{
	{
		DebuggerHiddenAttribute_t638884887 * tmp = (DebuggerHiddenAttribute_t638884887 *)cache->attributes[0];
		DebuggerHiddenAttribute__ctor_m2012788180(tmp, NULL);
	}
}
static void U3CCaretBlinkU3Ec__Iterator0_t906898126_CustomAttributesCacheGenerator_U3CCaretBlinkU3Ec__Iterator0_Dispose_m3699146813(CustomAttributesCache* cache)
{
	{
		DebuggerHiddenAttribute_t638884887 * tmp = (DebuggerHiddenAttribute_t638884887 *)cache->attributes[0];
		DebuggerHiddenAttribute__ctor_m2012788180(tmp, NULL);
	}
}
static void U3CCaretBlinkU3Ec__Iterator0_t906898126_CustomAttributesCacheGenerator_U3CCaretBlinkU3Ec__Iterator0_Reset_m2035249179(CustomAttributesCache* cache)
{
	{
		DebuggerHiddenAttribute_t638884887 * tmp = (DebuggerHiddenAttribute_t638884887 *)cache->attributes[0];
		DebuggerHiddenAttribute__ctor_m2012788180(tmp, NULL);
	}
}
static void U3CMouseDragOutsideRectU3Ec__Iterator1_t2599668326_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void U3CMouseDragOutsideRectU3Ec__Iterator1_t2599668326_CustomAttributesCacheGenerator_U3CMouseDragOutsideRectU3Ec__Iterator1__ctor_m1439320044(CustomAttributesCache* cache)
{
	{
		DebuggerHiddenAttribute_t638884887 * tmp = (DebuggerHiddenAttribute_t638884887 *)cache->attributes[0];
		DebuggerHiddenAttribute__ctor_m2012788180(tmp, NULL);
	}
}
static void U3CMouseDragOutsideRectU3Ec__Iterator1_t2599668326_CustomAttributesCacheGenerator_U3CMouseDragOutsideRectU3Ec__Iterator1_System_Collections_Generic_IEnumeratorU3CobjectU3E_get_Current_m2602955272(CustomAttributesCache* cache)
{
	{
		DebuggerHiddenAttribute_t638884887 * tmp = (DebuggerHiddenAttribute_t638884887 *)cache->attributes[0];
		DebuggerHiddenAttribute__ctor_m2012788180(tmp, NULL);
	}
}
static void U3CMouseDragOutsideRectU3Ec__Iterator1_t2599668326_CustomAttributesCacheGenerator_U3CMouseDragOutsideRectU3Ec__Iterator1_System_Collections_IEnumerator_get_Current_m561728752(CustomAttributesCache* cache)
{
	{
		DebuggerHiddenAttribute_t638884887 * tmp = (DebuggerHiddenAttribute_t638884887 *)cache->attributes[0];
		DebuggerHiddenAttribute__ctor_m2012788180(tmp, NULL);
	}
}
static void U3CMouseDragOutsideRectU3Ec__Iterator1_t2599668326_CustomAttributesCacheGenerator_U3CMouseDragOutsideRectU3Ec__Iterator1_Dispose_m2134284531(CustomAttributesCache* cache)
{
	{
		DebuggerHiddenAttribute_t638884887 * tmp = (DebuggerHiddenAttribute_t638884887 *)cache->attributes[0];
		DebuggerHiddenAttribute__ctor_m2012788180(tmp, NULL);
	}
}
static void U3CMouseDragOutsideRectU3Ec__Iterator1_t2599668326_CustomAttributesCacheGenerator_U3CMouseDragOutsideRectU3Ec__Iterator1_Reset_m3690615953(CustomAttributesCache* cache)
{
	{
		DebuggerHiddenAttribute_t638884887 * tmp = (DebuggerHiddenAttribute_t638884887 *)cache->attributes[0];
		DebuggerHiddenAttribute__ctor_m2012788180(tmp, NULL);
	}
}
extern const Il2CppType* RectTransform_t3349966182_0_0_0_var;
extern const uint32_t Mask_t2977958238_CustomAttributesCacheGenerator_MetadataUsageId;
static void Mask_t2977958238_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Mask_t2977958238_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		AddComponentMenu_t1099699699 * tmp = (AddComponentMenu_t1099699699 *)cache->attributes[0];
		AddComponentMenu__ctor_m648737891(tmp, il2cpp_codegen_string_new_wrapper("UI/Mask"), 13LL, NULL);
	}
	{
		DisallowMultipleComponent_t2656950 * tmp = (DisallowMultipleComponent_t2656950 *)cache->attributes[1];
		DisallowMultipleComponent__ctor_m533952133(tmp, NULL);
	}
	{
		RequireComponent_t864575032 * tmp = (RequireComponent_t864575032 *)cache->attributes[2];
		RequireComponent__ctor_m3475141952(tmp, il2cpp_codegen_type_get_object(RectTransform_t3349966182_0_0_0_var), NULL);
	}
	{
		ExecuteInEditMode_t3043633143 * tmp = (ExecuteInEditMode_t3043633143 *)cache->attributes[3];
		ExecuteInEditMode__ctor_m495837196(tmp, NULL);
	}
}
static void Mask_t2977958238_CustomAttributesCacheGenerator_m_ShowMaskGraphic(CustomAttributesCache* cache)
{
	{
		FormerlySerializedAsAttribute_t3673080018 * tmp = (FormerlySerializedAsAttribute_t3673080018 *)cache->attributes[0];
		FormerlySerializedAsAttribute__ctor_m3551035707(tmp, il2cpp_codegen_string_new_wrapper("m_ShowGraphic"), NULL);
	}
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[1];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void Mask_t2977958238_CustomAttributesCacheGenerator_Mask_OnSiblingGraphicEnabledDisabled_m865494155(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m2711473620(tmp, il2cpp_codegen_string_new_wrapper("Not used anymore."), NULL);
	}
}
static void MaskableGraphic_t540192618_CustomAttributesCacheGenerator_m_IncludeForMasking(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m834417715(tmp, il2cpp_codegen_string_new_wrapper("Not used anymore."), true, NULL);
	}
}
static void MaskableGraphic_t540192618_CustomAttributesCacheGenerator_m_OnCullStateChanged(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void MaskableGraphic_t540192618_CustomAttributesCacheGenerator_m_ShouldRecalculate(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m834417715(tmp, il2cpp_codegen_string_new_wrapper("Not used anymore"), true, NULL);
	}
}
static void MaskableGraphic_t540192618_CustomAttributesCacheGenerator_MaskableGraphic_ParentMaskStateChanged_m3643747340(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m834417715(tmp, il2cpp_codegen_string_new_wrapper("Not used anymore."), true, NULL);
	}
}
static void Navigation_t1571958496_CustomAttributesCacheGenerator_m_Mode(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
	{
		FormerlySerializedAsAttribute_t3673080018 * tmp = (FormerlySerializedAsAttribute_t3673080018 *)cache->attributes[1];
		FormerlySerializedAsAttribute__ctor_m3551035707(tmp, il2cpp_codegen_string_new_wrapper("mode"), NULL);
	}
}
static void Navigation_t1571958496_CustomAttributesCacheGenerator_m_SelectOnUp(CustomAttributesCache* cache)
{
	{
		FormerlySerializedAsAttribute_t3673080018 * tmp = (FormerlySerializedAsAttribute_t3673080018 *)cache->attributes[0];
		FormerlySerializedAsAttribute__ctor_m3551035707(tmp, il2cpp_codegen_string_new_wrapper("selectOnUp"), NULL);
	}
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[1];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void Navigation_t1571958496_CustomAttributesCacheGenerator_m_SelectOnDown(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
	{
		FormerlySerializedAsAttribute_t3673080018 * tmp = (FormerlySerializedAsAttribute_t3673080018 *)cache->attributes[1];
		FormerlySerializedAsAttribute__ctor_m3551035707(tmp, il2cpp_codegen_string_new_wrapper("selectOnDown"), NULL);
	}
}
static void Navigation_t1571958496_CustomAttributesCacheGenerator_m_SelectOnLeft(CustomAttributesCache* cache)
{
	{
		FormerlySerializedAsAttribute_t3673080018 * tmp = (FormerlySerializedAsAttribute_t3673080018 *)cache->attributes[0];
		FormerlySerializedAsAttribute__ctor_m3551035707(tmp, il2cpp_codegen_string_new_wrapper("selectOnLeft"), NULL);
	}
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[1];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void Navigation_t1571958496_CustomAttributesCacheGenerator_m_SelectOnRight(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
	{
		FormerlySerializedAsAttribute_t3673080018 * tmp = (FormerlySerializedAsAttribute_t3673080018 *)cache->attributes[1];
		FormerlySerializedAsAttribute__ctor_m3551035707(tmp, il2cpp_codegen_string_new_wrapper("selectOnRight"), NULL);
	}
}
static void Mode_t1081683921_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		FlagsAttribute_t859561169 * tmp = (FlagsAttribute_t859561169 *)cache->attributes[0];
		FlagsAttribute__ctor_m1848108622(tmp, NULL);
	}
}
static void RawImage_t2749640213_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AddComponentMenu_t1099699699 * tmp = (AddComponentMenu_t1099699699 *)cache->attributes[0];
		AddComponentMenu__ctor_m648737891(tmp, il2cpp_codegen_string_new_wrapper("UI/Raw Image"), 12LL, NULL);
	}
}
static void RawImage_t2749640213_CustomAttributesCacheGenerator_m_Texture(CustomAttributesCache* cache)
{
	{
		FormerlySerializedAsAttribute_t3673080018 * tmp = (FormerlySerializedAsAttribute_t3673080018 *)cache->attributes[0];
		FormerlySerializedAsAttribute__ctor_m3551035707(tmp, il2cpp_codegen_string_new_wrapper("m_Tex"), NULL);
	}
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[1];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void RawImage_t2749640213_CustomAttributesCacheGenerator_m_UVRect(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
extern const Il2CppType* RectTransform_t3349966182_0_0_0_var;
extern const uint32_t RectMask2D_t1156185964_CustomAttributesCacheGenerator_MetadataUsageId;
static void RectMask2D_t1156185964_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (RectMask2D_t1156185964_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		DisallowMultipleComponent_t2656950 * tmp = (DisallowMultipleComponent_t2656950 *)cache->attributes[0];
		DisallowMultipleComponent__ctor_m533952133(tmp, NULL);
	}
	{
		RequireComponent_t864575032 * tmp = (RequireComponent_t864575032 *)cache->attributes[1];
		RequireComponent__ctor_m3475141952(tmp, il2cpp_codegen_type_get_object(RectTransform_t3349966182_0_0_0_var), NULL);
	}
	{
		ExecuteInEditMode_t3043633143 * tmp = (ExecuteInEditMode_t3043633143 *)cache->attributes[2];
		ExecuteInEditMode__ctor_m495837196(tmp, NULL);
	}
	{
		AddComponentMenu_t1099699699 * tmp = (AddComponentMenu_t1099699699 *)cache->attributes[3];
		AddComponentMenu__ctor_m648737891(tmp, il2cpp_codegen_string_new_wrapper("UI/Rect Mask 2D"), 13LL, NULL);
	}
}
extern const Il2CppType* RectTransform_t3349966182_0_0_0_var;
extern const uint32_t Scrollbar_t3248359358_CustomAttributesCacheGenerator_MetadataUsageId;
static void Scrollbar_t3248359358_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Scrollbar_t3248359358_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		RequireComponent_t864575032 * tmp = (RequireComponent_t864575032 *)cache->attributes[0];
		RequireComponent__ctor_m3475141952(tmp, il2cpp_codegen_type_get_object(RectTransform_t3349966182_0_0_0_var), NULL);
	}
	{
		AddComponentMenu_t1099699699 * tmp = (AddComponentMenu_t1099699699 *)cache->attributes[1];
		AddComponentMenu__ctor_m648737891(tmp, il2cpp_codegen_string_new_wrapper("UI/Scrollbar"), 34LL, NULL);
	}
}
static void Scrollbar_t3248359358_CustomAttributesCacheGenerator_m_HandleRect(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void Scrollbar_t3248359358_CustomAttributesCacheGenerator_m_Direction(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void Scrollbar_t3248359358_CustomAttributesCacheGenerator_m_Value(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
	{
		RangeAttribute_t3336560921 * tmp = (RangeAttribute_t3336560921 *)cache->attributes[1];
		RangeAttribute__ctor_m1657271662(tmp, 0.0f, 1.0f, NULL);
	}
}
static void Scrollbar_t3248359358_CustomAttributesCacheGenerator_m_Size(CustomAttributesCache* cache)
{
	{
		RangeAttribute_t3336560921 * tmp = (RangeAttribute_t3336560921 *)cache->attributes[0];
		RangeAttribute__ctor_m1657271662(tmp, 0.0f, 1.0f, NULL);
	}
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[1];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void Scrollbar_t3248359358_CustomAttributesCacheGenerator_m_NumberOfSteps(CustomAttributesCache* cache)
{
	{
		RangeAttribute_t3336560921 * tmp = (RangeAttribute_t3336560921 *)cache->attributes[0];
		RangeAttribute__ctor_m1657271662(tmp, 0.0f, 11.0f, NULL);
	}
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[1];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void Scrollbar_t3248359358_CustomAttributesCacheGenerator_m_OnValueChanged(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
	{
		SpaceAttribute_t952253354 * tmp = (SpaceAttribute_t952253354 *)cache->attributes[1];
		SpaceAttribute__ctor_m1444406696(tmp, 6.0f, NULL);
	}
}
static void Scrollbar_t3248359358_CustomAttributesCacheGenerator_Scrollbar_ClickRepeat_m3403943364(CustomAttributesCache* cache)
{
	{
		DebuggerHiddenAttribute_t638884887 * tmp = (DebuggerHiddenAttribute_t638884887 *)cache->attributes[0];
		DebuggerHiddenAttribute__ctor_m2012788180(tmp, NULL);
	}
}
static void U3CClickRepeatU3Ec__Iterator0_t4156771994_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void U3CClickRepeatU3Ec__Iterator0_t4156771994_CustomAttributesCacheGenerator_U3CClickRepeatU3Ec__Iterator0__ctor_m1515509136(CustomAttributesCache* cache)
{
	{
		DebuggerHiddenAttribute_t638884887 * tmp = (DebuggerHiddenAttribute_t638884887 *)cache->attributes[0];
		DebuggerHiddenAttribute__ctor_m2012788180(tmp, NULL);
	}
}
static void U3CClickRepeatU3Ec__Iterator0_t4156771994_CustomAttributesCacheGenerator_U3CClickRepeatU3Ec__Iterator0_System_Collections_Generic_IEnumeratorU3CobjectU3E_get_Current_m3444627780(CustomAttributesCache* cache)
{
	{
		DebuggerHiddenAttribute_t638884887 * tmp = (DebuggerHiddenAttribute_t638884887 *)cache->attributes[0];
		DebuggerHiddenAttribute__ctor_m2012788180(tmp, NULL);
	}
}
static void U3CClickRepeatU3Ec__Iterator0_t4156771994_CustomAttributesCacheGenerator_U3CClickRepeatU3Ec__Iterator0_System_Collections_IEnumerator_get_Current_m4049780396(CustomAttributesCache* cache)
{
	{
		DebuggerHiddenAttribute_t638884887 * tmp = (DebuggerHiddenAttribute_t638884887 *)cache->attributes[0];
		DebuggerHiddenAttribute__ctor_m2012788180(tmp, NULL);
	}
}
static void U3CClickRepeatU3Ec__Iterator0_t4156771994_CustomAttributesCacheGenerator_U3CClickRepeatU3Ec__Iterator0_Dispose_m684116271(CustomAttributesCache* cache)
{
	{
		DebuggerHiddenAttribute_t638884887 * tmp = (DebuggerHiddenAttribute_t638884887 *)cache->attributes[0];
		DebuggerHiddenAttribute__ctor_m2012788180(tmp, NULL);
	}
}
static void U3CClickRepeatU3Ec__Iterator0_t4156771994_CustomAttributesCacheGenerator_U3CClickRepeatU3Ec__Iterator0_Reset_m1177396749(CustomAttributesCache* cache)
{
	{
		DebuggerHiddenAttribute_t638884887 * tmp = (DebuggerHiddenAttribute_t638884887 *)cache->attributes[0];
		DebuggerHiddenAttribute__ctor_m2012788180(tmp, NULL);
	}
}
extern const Il2CppType* RectTransform_t3349966182_0_0_0_var;
extern const uint32_t ScrollRect_t1199013257_CustomAttributesCacheGenerator_MetadataUsageId;
static void ScrollRect_t1199013257_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ScrollRect_t1199013257_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		SelectionBaseAttribute_t936505999 * tmp = (SelectionBaseAttribute_t936505999 *)cache->attributes[0];
		SelectionBaseAttribute__ctor_m1487697870(tmp, NULL);
	}
	{
		AddComponentMenu_t1099699699 * tmp = (AddComponentMenu_t1099699699 *)cache->attributes[1];
		AddComponentMenu__ctor_m648737891(tmp, il2cpp_codegen_string_new_wrapper("UI/Scroll Rect"), 37LL, NULL);
	}
	{
		ExecuteInEditMode_t3043633143 * tmp = (ExecuteInEditMode_t3043633143 *)cache->attributes[2];
		ExecuteInEditMode__ctor_m495837196(tmp, NULL);
	}
	{
		RequireComponent_t864575032 * tmp = (RequireComponent_t864575032 *)cache->attributes[3];
		RequireComponent__ctor_m3475141952(tmp, il2cpp_codegen_type_get_object(RectTransform_t3349966182_0_0_0_var), NULL);
	}
	{
		DisallowMultipleComponent_t2656950 * tmp = (DisallowMultipleComponent_t2656950 *)cache->attributes[4];
		DisallowMultipleComponent__ctor_m533952133(tmp, NULL);
	}
}
static void ScrollRect_t1199013257_CustomAttributesCacheGenerator_m_Content(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void ScrollRect_t1199013257_CustomAttributesCacheGenerator_m_Horizontal(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void ScrollRect_t1199013257_CustomAttributesCacheGenerator_m_Vertical(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void ScrollRect_t1199013257_CustomAttributesCacheGenerator_m_MovementType(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void ScrollRect_t1199013257_CustomAttributesCacheGenerator_m_Elasticity(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void ScrollRect_t1199013257_CustomAttributesCacheGenerator_m_Inertia(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void ScrollRect_t1199013257_CustomAttributesCacheGenerator_m_DecelerationRate(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void ScrollRect_t1199013257_CustomAttributesCacheGenerator_m_ScrollSensitivity(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void ScrollRect_t1199013257_CustomAttributesCacheGenerator_m_Viewport(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void ScrollRect_t1199013257_CustomAttributesCacheGenerator_m_HorizontalScrollbar(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void ScrollRect_t1199013257_CustomAttributesCacheGenerator_m_VerticalScrollbar(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void ScrollRect_t1199013257_CustomAttributesCacheGenerator_m_HorizontalScrollbarVisibility(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void ScrollRect_t1199013257_CustomAttributesCacheGenerator_m_VerticalScrollbarVisibility(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void ScrollRect_t1199013257_CustomAttributesCacheGenerator_m_HorizontalScrollbarSpacing(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void ScrollRect_t1199013257_CustomAttributesCacheGenerator_m_VerticalScrollbarSpacing(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void ScrollRect_t1199013257_CustomAttributesCacheGenerator_m_OnValueChanged(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void Selectable_t1490392188_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AddComponentMenu_t1099699699 * tmp = (AddComponentMenu_t1099699699 *)cache->attributes[0];
		AddComponentMenu__ctor_m648737891(tmp, il2cpp_codegen_string_new_wrapper("UI/Selectable"), 70LL, NULL);
	}
	{
		ExecuteInEditMode_t3043633143 * tmp = (ExecuteInEditMode_t3043633143 *)cache->attributes[1];
		ExecuteInEditMode__ctor_m495837196(tmp, NULL);
	}
	{
		SelectionBaseAttribute_t936505999 * tmp = (SelectionBaseAttribute_t936505999 *)cache->attributes[2];
		SelectionBaseAttribute__ctor_m1487697870(tmp, NULL);
	}
	{
		DisallowMultipleComponent_t2656950 * tmp = (DisallowMultipleComponent_t2656950 *)cache->attributes[3];
		DisallowMultipleComponent__ctor_m533952133(tmp, NULL);
	}
}
static void Selectable_t1490392188_CustomAttributesCacheGenerator_m_Navigation(CustomAttributesCache* cache)
{
	{
		FormerlySerializedAsAttribute_t3673080018 * tmp = (FormerlySerializedAsAttribute_t3673080018 *)cache->attributes[0];
		FormerlySerializedAsAttribute__ctor_m3551035707(tmp, il2cpp_codegen_string_new_wrapper("navigation"), NULL);
	}
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[1];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void Selectable_t1490392188_CustomAttributesCacheGenerator_m_Transition(CustomAttributesCache* cache)
{
	{
		FormerlySerializedAsAttribute_t3673080018 * tmp = (FormerlySerializedAsAttribute_t3673080018 *)cache->attributes[0];
		FormerlySerializedAsAttribute__ctor_m3551035707(tmp, il2cpp_codegen_string_new_wrapper("transition"), NULL);
	}
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[1];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void Selectable_t1490392188_CustomAttributesCacheGenerator_m_Colors(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
	{
		FormerlySerializedAsAttribute_t3673080018 * tmp = (FormerlySerializedAsAttribute_t3673080018 *)cache->attributes[1];
		FormerlySerializedAsAttribute__ctor_m3551035707(tmp, il2cpp_codegen_string_new_wrapper("colors"), NULL);
	}
}
static void Selectable_t1490392188_CustomAttributesCacheGenerator_m_SpriteState(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
	{
		FormerlySerializedAsAttribute_t3673080018 * tmp = (FormerlySerializedAsAttribute_t3673080018 *)cache->attributes[1];
		FormerlySerializedAsAttribute__ctor_m3551035707(tmp, il2cpp_codegen_string_new_wrapper("spriteState"), NULL);
	}
}
static void Selectable_t1490392188_CustomAttributesCacheGenerator_m_AnimationTriggers(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
	{
		FormerlySerializedAsAttribute_t3673080018 * tmp = (FormerlySerializedAsAttribute_t3673080018 *)cache->attributes[1];
		FormerlySerializedAsAttribute__ctor_m3551035707(tmp, il2cpp_codegen_string_new_wrapper("animationTriggers"), NULL);
	}
}
static void Selectable_t1490392188_CustomAttributesCacheGenerator_m_Interactable(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
	{
		TooltipAttribute_t4278647215 * tmp = (TooltipAttribute_t4278647215 *)cache->attributes[1];
		TooltipAttribute__ctor_m2640804852(tmp, il2cpp_codegen_string_new_wrapper("Can the Selectable be interacted with?"), NULL);
	}
}
static void Selectable_t1490392188_CustomAttributesCacheGenerator_m_TargetGraphic(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
	{
		FormerlySerializedAsAttribute_t3673080018 * tmp = (FormerlySerializedAsAttribute_t3673080018 *)cache->attributes[1];
		FormerlySerializedAsAttribute__ctor_m3551035707(tmp, il2cpp_codegen_string_new_wrapper("m_HighlightGraphic"), NULL);
	}
	{
		FormerlySerializedAsAttribute_t3673080018 * tmp = (FormerlySerializedAsAttribute_t3673080018 *)cache->attributes[2];
		FormerlySerializedAsAttribute__ctor_m3551035707(tmp, il2cpp_codegen_string_new_wrapper("highlightGraphic"), NULL);
	}
}
static void Selectable_t1490392188_CustomAttributesCacheGenerator_U3CisPointerInsideU3Ek__BackingField(CustomAttributesCache* cache)
{
	{
		DebuggerBrowsableAttribute_t1386379234 * tmp = (DebuggerBrowsableAttribute_t1386379234 *)cache->attributes[0];
		DebuggerBrowsableAttribute__ctor_m3729055103(tmp, 0LL, NULL);
	}
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[1];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void Selectable_t1490392188_CustomAttributesCacheGenerator_U3CisPointerDownU3Ek__BackingField(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
	{
		DebuggerBrowsableAttribute_t1386379234 * tmp = (DebuggerBrowsableAttribute_t1386379234 *)cache->attributes[1];
		DebuggerBrowsableAttribute__ctor_m3729055103(tmp, 0LL, NULL);
	}
}
static void Selectable_t1490392188_CustomAttributesCacheGenerator_U3ChasSelectionU3Ek__BackingField(CustomAttributesCache* cache)
{
	{
		DebuggerBrowsableAttribute_t1386379234 * tmp = (DebuggerBrowsableAttribute_t1386379234 *)cache->attributes[0];
		DebuggerBrowsableAttribute__ctor_m3729055103(tmp, 0LL, NULL);
	}
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[1];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void Selectable_t1490392188_CustomAttributesCacheGenerator_Selectable_get_isPointerInside_m3162215687(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void Selectable_t1490392188_CustomAttributesCacheGenerator_Selectable_set_isPointerInside_m375338048(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void Selectable_t1490392188_CustomAttributesCacheGenerator_Selectable_get_isPointerDown_m774209881(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void Selectable_t1490392188_CustomAttributesCacheGenerator_Selectable_set_isPointerDown_m2177301980(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void Selectable_t1490392188_CustomAttributesCacheGenerator_Selectable_get_hasSelection_m307792052(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void Selectable_t1490392188_CustomAttributesCacheGenerator_Selectable_set_hasSelection_m2076391827(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void Selectable_t1490392188_CustomAttributesCacheGenerator_Selectable_IsPressed_m3349168065(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m834417715(tmp, il2cpp_codegen_string_new_wrapper("Is Pressed no longer requires eventData"), false, NULL);
	}
}
extern const Il2CppType* RectTransform_t3349966182_0_0_0_var;
extern const uint32_t Slider_t297367283_CustomAttributesCacheGenerator_MetadataUsageId;
static void Slider_t297367283_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Slider_t297367283_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		AddComponentMenu_t1099699699 * tmp = (AddComponentMenu_t1099699699 *)cache->attributes[0];
		AddComponentMenu__ctor_m648737891(tmp, il2cpp_codegen_string_new_wrapper("UI/Slider"), 33LL, NULL);
	}
	{
		RequireComponent_t864575032 * tmp = (RequireComponent_t864575032 *)cache->attributes[1];
		RequireComponent__ctor_m3475141952(tmp, il2cpp_codegen_type_get_object(RectTransform_t3349966182_0_0_0_var), NULL);
	}
}
static void Slider_t297367283_CustomAttributesCacheGenerator_m_FillRect(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void Slider_t297367283_CustomAttributesCacheGenerator_m_HandleRect(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void Slider_t297367283_CustomAttributesCacheGenerator_m_Direction(CustomAttributesCache* cache)
{
	{
		SpaceAttribute_t952253354 * tmp = (SpaceAttribute_t952253354 *)cache->attributes[0];
		SpaceAttribute__ctor_m187290553(tmp, NULL);
	}
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[1];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void Slider_t297367283_CustomAttributesCacheGenerator_m_MinValue(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void Slider_t297367283_CustomAttributesCacheGenerator_m_MaxValue(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void Slider_t297367283_CustomAttributesCacheGenerator_m_WholeNumbers(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void Slider_t297367283_CustomAttributesCacheGenerator_m_Value(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void Slider_t297367283_CustomAttributesCacheGenerator_m_OnValueChanged(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
	{
		SpaceAttribute_t952253354 * tmp = (SpaceAttribute_t952253354 *)cache->attributes[1];
		SpaceAttribute__ctor_m187290553(tmp, NULL);
	}
}
static void SpriteState_t1353336012_CustomAttributesCacheGenerator_m_HighlightedSprite(CustomAttributesCache* cache)
{
	{
		FormerlySerializedAsAttribute_t3673080018 * tmp = (FormerlySerializedAsAttribute_t3673080018 *)cache->attributes[0];
		FormerlySerializedAsAttribute__ctor_m3551035707(tmp, il2cpp_codegen_string_new_wrapper("highlightedSprite"), NULL);
	}
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[1];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
	{
		FormerlySerializedAsAttribute_t3673080018 * tmp = (FormerlySerializedAsAttribute_t3673080018 *)cache->attributes[2];
		FormerlySerializedAsAttribute__ctor_m3551035707(tmp, il2cpp_codegen_string_new_wrapper("m_SelectedSprite"), NULL);
	}
}
static void SpriteState_t1353336012_CustomAttributesCacheGenerator_m_PressedSprite(CustomAttributesCache* cache)
{
	{
		FormerlySerializedAsAttribute_t3673080018 * tmp = (FormerlySerializedAsAttribute_t3673080018 *)cache->attributes[0];
		FormerlySerializedAsAttribute__ctor_m3551035707(tmp, il2cpp_codegen_string_new_wrapper("pressedSprite"), NULL);
	}
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[1];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void SpriteState_t1353336012_CustomAttributesCacheGenerator_m_DisabledSprite(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
	{
		FormerlySerializedAsAttribute_t3673080018 * tmp = (FormerlySerializedAsAttribute_t3673080018 *)cache->attributes[1];
		FormerlySerializedAsAttribute__ctor_m3551035707(tmp, il2cpp_codegen_string_new_wrapper("disabledSprite"), NULL);
	}
}
static void StencilMaterial_t1630303189_CustomAttributesCacheGenerator_StencilMaterial_Add_m1745413071(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m834417715(tmp, il2cpp_codegen_string_new_wrapper("Use Material.Add instead."), true, NULL);
	}
}
static void Text_t356221433_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AddComponentMenu_t1099699699 * tmp = (AddComponentMenu_t1099699699 *)cache->attributes[0];
		AddComponentMenu__ctor_m648737891(tmp, il2cpp_codegen_string_new_wrapper("UI/Text"), 10LL, NULL);
	}
}
static void Text_t356221433_CustomAttributesCacheGenerator_m_FontData(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void Text_t356221433_CustomAttributesCacheGenerator_m_Text(CustomAttributesCache* cache)
{
	{
		TextAreaAttribute_t2454598508 * tmp = (TextAreaAttribute_t2454598508 *)cache->attributes[0];
		TextAreaAttribute__ctor_m2320572467(tmp, 3LL, 10LL, NULL);
	}
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[1];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
extern const Il2CppType* RectTransform_t3349966182_0_0_0_var;
extern const uint32_t Toggle_t3976754468_CustomAttributesCacheGenerator_MetadataUsageId;
static void Toggle_t3976754468_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (Toggle_t3976754468_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		AddComponentMenu_t1099699699 * tmp = (AddComponentMenu_t1099699699 *)cache->attributes[0];
		AddComponentMenu__ctor_m648737891(tmp, il2cpp_codegen_string_new_wrapper("UI/Toggle"), 31LL, NULL);
	}
	{
		RequireComponent_t864575032 * tmp = (RequireComponent_t864575032 *)cache->attributes[1];
		RequireComponent__ctor_m3475141952(tmp, il2cpp_codegen_type_get_object(RectTransform_t3349966182_0_0_0_var), NULL);
	}
}
static void Toggle_t3976754468_CustomAttributesCacheGenerator_m_Group(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void Toggle_t3976754468_CustomAttributesCacheGenerator_m_IsOn(CustomAttributesCache* cache)
{
	{
		FormerlySerializedAsAttribute_t3673080018 * tmp = (FormerlySerializedAsAttribute_t3673080018 *)cache->attributes[0];
		FormerlySerializedAsAttribute__ctor_m3551035707(tmp, il2cpp_codegen_string_new_wrapper("m_IsActive"), NULL);
	}
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[1];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
	{
		TooltipAttribute_t4278647215 * tmp = (TooltipAttribute_t4278647215 *)cache->attributes[2];
		TooltipAttribute__ctor_m2640804852(tmp, il2cpp_codegen_string_new_wrapper("Is the toggle currently on or off?"), NULL);
	}
}
static void ToggleGroup_t1030026315_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DisallowMultipleComponent_t2656950 * tmp = (DisallowMultipleComponent_t2656950 *)cache->attributes[0];
		DisallowMultipleComponent__ctor_m533952133(tmp, NULL);
	}
	{
		AddComponentMenu_t1099699699 * tmp = (AddComponentMenu_t1099699699 *)cache->attributes[1];
		AddComponentMenu__ctor_m648737891(tmp, il2cpp_codegen_string_new_wrapper("UI/Toggle Group"), 32LL, NULL);
	}
}
static void ToggleGroup_t1030026315_CustomAttributesCacheGenerator_m_AllowSwitchOff(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void ToggleGroup_t1030026315_CustomAttributesCacheGenerator_U3CU3Ef__amU24cache0(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void ToggleGroup_t1030026315_CustomAttributesCacheGenerator_U3CU3Ef__amU24cache1(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void ToggleGroup_t1030026315_CustomAttributesCacheGenerator_ToggleGroup_U3CAnyTogglesOnU3Em__0_m1218114300(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void ToggleGroup_t1030026315_CustomAttributesCacheGenerator_ToggleGroup_U3CActiveTogglesU3Em__1_m4052653494(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
extern const Il2CppType* RectTransform_t3349966182_0_0_0_var;
extern const uint32_t AspectRatioFitter_t3114550109_CustomAttributesCacheGenerator_MetadataUsageId;
static void AspectRatioFitter_t3114550109_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (AspectRatioFitter_t3114550109_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ExecuteInEditMode_t3043633143 * tmp = (ExecuteInEditMode_t3043633143 *)cache->attributes[0];
		ExecuteInEditMode__ctor_m495837196(tmp, NULL);
	}
	{
		AddComponentMenu_t1099699699 * tmp = (AddComponentMenu_t1099699699 *)cache->attributes[1];
		AddComponentMenu__ctor_m648737891(tmp, il2cpp_codegen_string_new_wrapper("Layout/Aspect Ratio Fitter"), 142LL, NULL);
	}
	{
		DisallowMultipleComponent_t2656950 * tmp = (DisallowMultipleComponent_t2656950 *)cache->attributes[2];
		DisallowMultipleComponent__ctor_m533952133(tmp, NULL);
	}
	{
		RequireComponent_t864575032 * tmp = (RequireComponent_t864575032 *)cache->attributes[3];
		RequireComponent__ctor_m3475141952(tmp, il2cpp_codegen_type_get_object(RectTransform_t3349966182_0_0_0_var), NULL);
	}
}
static void AspectRatioFitter_t3114550109_CustomAttributesCacheGenerator_m_AspectMode(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void AspectRatioFitter_t3114550109_CustomAttributesCacheGenerator_m_AspectRatio(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
extern const Il2CppType* Canvas_t209405766_0_0_0_var;
extern const uint32_t CanvasScaler_t2574720772_CustomAttributesCacheGenerator_MetadataUsageId;
static void CanvasScaler_t2574720772_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (CanvasScaler_t2574720772_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		AddComponentMenu_t1099699699 * tmp = (AddComponentMenu_t1099699699 *)cache->attributes[0];
		AddComponentMenu__ctor_m648737891(tmp, il2cpp_codegen_string_new_wrapper("Layout/Canvas Scaler"), 101LL, NULL);
	}
	{
		ExecuteInEditMode_t3043633143 * tmp = (ExecuteInEditMode_t3043633143 *)cache->attributes[1];
		ExecuteInEditMode__ctor_m495837196(tmp, NULL);
	}
	{
		RequireComponent_t864575032 * tmp = (RequireComponent_t864575032 *)cache->attributes[2];
		RequireComponent__ctor_m3475141952(tmp, il2cpp_codegen_type_get_object(Canvas_t209405766_0_0_0_var), NULL);
	}
}
static void CanvasScaler_t2574720772_CustomAttributesCacheGenerator_m_UiScaleMode(CustomAttributesCache* cache)
{
	{
		TooltipAttribute_t4278647215 * tmp = (TooltipAttribute_t4278647215 *)cache->attributes[0];
		TooltipAttribute__ctor_m2640804852(tmp, il2cpp_codegen_string_new_wrapper("Determines how UI elements in the Canvas are scaled."), NULL);
	}
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[1];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void CanvasScaler_t2574720772_CustomAttributesCacheGenerator_m_ReferencePixelsPerUnit(CustomAttributesCache* cache)
{
	{
		TooltipAttribute_t4278647215 * tmp = (TooltipAttribute_t4278647215 *)cache->attributes[0];
		TooltipAttribute__ctor_m2640804852(tmp, il2cpp_codegen_string_new_wrapper("If a sprite has this 'Pixels Per Unit' setting, then one pixel in the sprite will cover one unit in the UI."), NULL);
	}
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[1];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void CanvasScaler_t2574720772_CustomAttributesCacheGenerator_m_ScaleFactor(CustomAttributesCache* cache)
{
	{
		TooltipAttribute_t4278647215 * tmp = (TooltipAttribute_t4278647215 *)cache->attributes[0];
		TooltipAttribute__ctor_m2640804852(tmp, il2cpp_codegen_string_new_wrapper("Scales all UI elements in the Canvas by this factor."), NULL);
	}
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[1];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void CanvasScaler_t2574720772_CustomAttributesCacheGenerator_m_ReferenceResolution(CustomAttributesCache* cache)
{
	{
		TooltipAttribute_t4278647215 * tmp = (TooltipAttribute_t4278647215 *)cache->attributes[0];
		TooltipAttribute__ctor_m2640804852(tmp, il2cpp_codegen_string_new_wrapper("The resolution the UI layout is designed for. If the screen resolution is larger, the UI will be scaled up, and if it's smaller, the UI will be scaled down. This is done in accordance with the Screen Match Mode."), NULL);
	}
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[1];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void CanvasScaler_t2574720772_CustomAttributesCacheGenerator_m_ScreenMatchMode(CustomAttributesCache* cache)
{
	{
		TooltipAttribute_t4278647215 * tmp = (TooltipAttribute_t4278647215 *)cache->attributes[0];
		TooltipAttribute__ctor_m2640804852(tmp, il2cpp_codegen_string_new_wrapper("A mode used to scale the canvas area if the aspect ratio of the current resolution doesn't fit the reference resolution."), NULL);
	}
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[1];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void CanvasScaler_t2574720772_CustomAttributesCacheGenerator_m_MatchWidthOrHeight(CustomAttributesCache* cache)
{
	{
		TooltipAttribute_t4278647215 * tmp = (TooltipAttribute_t4278647215 *)cache->attributes[0];
		TooltipAttribute__ctor_m2640804852(tmp, il2cpp_codegen_string_new_wrapper("Determines if the scaling is using the width or height as reference, or a mix in between."), NULL);
	}
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[1];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
	{
		RangeAttribute_t3336560921 * tmp = (RangeAttribute_t3336560921 *)cache->attributes[2];
		RangeAttribute__ctor_m1657271662(tmp, 0.0f, 1.0f, NULL);
	}
}
static void CanvasScaler_t2574720772_CustomAttributesCacheGenerator_m_PhysicalUnit(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
	{
		TooltipAttribute_t4278647215 * tmp = (TooltipAttribute_t4278647215 *)cache->attributes[1];
		TooltipAttribute__ctor_m2640804852(tmp, il2cpp_codegen_string_new_wrapper("The physical unit to specify positions and sizes in."), NULL);
	}
}
static void CanvasScaler_t2574720772_CustomAttributesCacheGenerator_m_FallbackScreenDPI(CustomAttributesCache* cache)
{
	{
		TooltipAttribute_t4278647215 * tmp = (TooltipAttribute_t4278647215 *)cache->attributes[0];
		TooltipAttribute__ctor_m2640804852(tmp, il2cpp_codegen_string_new_wrapper("The DPI to assume if the screen DPI is not known."), NULL);
	}
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[1];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void CanvasScaler_t2574720772_CustomAttributesCacheGenerator_m_DefaultSpriteDPI(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
	{
		TooltipAttribute_t4278647215 * tmp = (TooltipAttribute_t4278647215 *)cache->attributes[1];
		TooltipAttribute__ctor_m2640804852(tmp, il2cpp_codegen_string_new_wrapper("The pixels per inch to use for sprites that have a 'Pixels Per Unit' setting that matches the 'Reference Pixels Per Unit' setting."), NULL);
	}
}
static void CanvasScaler_t2574720772_CustomAttributesCacheGenerator_m_DynamicPixelsPerUnit(CustomAttributesCache* cache)
{
	{
		TooltipAttribute_t4278647215 * tmp = (TooltipAttribute_t4278647215 *)cache->attributes[0];
		TooltipAttribute__ctor_m2640804852(tmp, il2cpp_codegen_string_new_wrapper("The amount of pixels per unit to use for dynamically created bitmaps in the UI, such as Text."), NULL);
	}
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[1];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
extern const Il2CppType* RectTransform_t3349966182_0_0_0_var;
extern const uint32_t ContentSizeFitter_t1325211874_CustomAttributesCacheGenerator_MetadataUsageId;
static void ContentSizeFitter_t1325211874_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (ContentSizeFitter_t1325211874_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		AddComponentMenu_t1099699699 * tmp = (AddComponentMenu_t1099699699 *)cache->attributes[0];
		AddComponentMenu__ctor_m648737891(tmp, il2cpp_codegen_string_new_wrapper("Layout/Content Size Fitter"), 141LL, NULL);
	}
	{
		RequireComponent_t864575032 * tmp = (RequireComponent_t864575032 *)cache->attributes[1];
		RequireComponent__ctor_m3475141952(tmp, il2cpp_codegen_type_get_object(RectTransform_t3349966182_0_0_0_var), NULL);
	}
	{
		ExecuteInEditMode_t3043633143 * tmp = (ExecuteInEditMode_t3043633143 *)cache->attributes[2];
		ExecuteInEditMode__ctor_m495837196(tmp, NULL);
	}
}
static void ContentSizeFitter_t1325211874_CustomAttributesCacheGenerator_m_HorizontalFit(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void ContentSizeFitter_t1325211874_CustomAttributesCacheGenerator_m_VerticalFit(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void GridLayoutGroup_t1515633077_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AddComponentMenu_t1099699699 * tmp = (AddComponentMenu_t1099699699 *)cache->attributes[0];
		AddComponentMenu__ctor_m648737891(tmp, il2cpp_codegen_string_new_wrapper("Layout/Grid Layout Group"), 152LL, NULL);
	}
}
static void GridLayoutGroup_t1515633077_CustomAttributesCacheGenerator_m_StartCorner(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void GridLayoutGroup_t1515633077_CustomAttributesCacheGenerator_m_StartAxis(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void GridLayoutGroup_t1515633077_CustomAttributesCacheGenerator_m_CellSize(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void GridLayoutGroup_t1515633077_CustomAttributesCacheGenerator_m_Spacing(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void GridLayoutGroup_t1515633077_CustomAttributesCacheGenerator_m_Constraint(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void GridLayoutGroup_t1515633077_CustomAttributesCacheGenerator_m_ConstraintCount(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void HorizontalLayoutGroup_t2875670365_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AddComponentMenu_t1099699699 * tmp = (AddComponentMenu_t1099699699 *)cache->attributes[0];
		AddComponentMenu__ctor_m648737891(tmp, il2cpp_codegen_string_new_wrapper("Layout/Horizontal Layout Group"), 150LL, NULL);
	}
}
static void HorizontalOrVerticalLayoutGroup_t1968298610_CustomAttributesCacheGenerator_m_Spacing(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void HorizontalOrVerticalLayoutGroup_t1968298610_CustomAttributesCacheGenerator_m_ChildForceExpandWidth(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void HorizontalOrVerticalLayoutGroup_t1968298610_CustomAttributesCacheGenerator_m_ChildForceExpandHeight(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void HorizontalOrVerticalLayoutGroup_t1968298610_CustomAttributesCacheGenerator_m_ChildControlWidth(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void HorizontalOrVerticalLayoutGroup_t1968298610_CustomAttributesCacheGenerator_m_ChildControlHeight(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
extern const Il2CppType* RectTransform_t3349966182_0_0_0_var;
extern const uint32_t LayoutElement_t2808691390_CustomAttributesCacheGenerator_MetadataUsageId;
static void LayoutElement_t2808691390_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (LayoutElement_t2808691390_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ExecuteInEditMode_t3043633143 * tmp = (ExecuteInEditMode_t3043633143 *)cache->attributes[0];
		ExecuteInEditMode__ctor_m495837196(tmp, NULL);
	}
	{
		AddComponentMenu_t1099699699 * tmp = (AddComponentMenu_t1099699699 *)cache->attributes[1];
		AddComponentMenu__ctor_m648737891(tmp, il2cpp_codegen_string_new_wrapper("Layout/Layout Element"), 140LL, NULL);
	}
	{
		RequireComponent_t864575032 * tmp = (RequireComponent_t864575032 *)cache->attributes[2];
		RequireComponent__ctor_m3475141952(tmp, il2cpp_codegen_type_get_object(RectTransform_t3349966182_0_0_0_var), NULL);
	}
}
static void LayoutElement_t2808691390_CustomAttributesCacheGenerator_m_IgnoreLayout(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void LayoutElement_t2808691390_CustomAttributesCacheGenerator_m_MinWidth(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void LayoutElement_t2808691390_CustomAttributesCacheGenerator_m_MinHeight(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void LayoutElement_t2808691390_CustomAttributesCacheGenerator_m_PreferredWidth(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void LayoutElement_t2808691390_CustomAttributesCacheGenerator_m_PreferredHeight(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void LayoutElement_t2808691390_CustomAttributesCacheGenerator_m_FlexibleWidth(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void LayoutElement_t2808691390_CustomAttributesCacheGenerator_m_FlexibleHeight(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
extern const Il2CppType* RectTransform_t3349966182_0_0_0_var;
extern const uint32_t LayoutGroup_t3962498969_CustomAttributesCacheGenerator_MetadataUsageId;
static void LayoutGroup_t3962498969_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	static bool s_Il2CppMethodInitialized;
	if (!s_Il2CppMethodInitialized)
	{
		il2cpp_codegen_initialize_method (LayoutGroup_t3962498969_CustomAttributesCacheGenerator_MetadataUsageId);
		s_Il2CppMethodInitialized = true;
	}
	{
		ExecuteInEditMode_t3043633143 * tmp = (ExecuteInEditMode_t3043633143 *)cache->attributes[0];
		ExecuteInEditMode__ctor_m495837196(tmp, NULL);
	}
	{
		RequireComponent_t864575032 * tmp = (RequireComponent_t864575032 *)cache->attributes[1];
		RequireComponent__ctor_m3475141952(tmp, il2cpp_codegen_type_get_object(RectTransform_t3349966182_0_0_0_var), NULL);
	}
	{
		DisallowMultipleComponent_t2656950 * tmp = (DisallowMultipleComponent_t2656950 *)cache->attributes[2];
		DisallowMultipleComponent__ctor_m533952133(tmp, NULL);
	}
}
static void LayoutGroup_t3962498969_CustomAttributesCacheGenerator_m_Padding(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void LayoutGroup_t3962498969_CustomAttributesCacheGenerator_m_ChildAlignment(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
	{
		FormerlySerializedAsAttribute_t3673080018 * tmp = (FormerlySerializedAsAttribute_t3673080018 *)cache->attributes[1];
		FormerlySerializedAsAttribute__ctor_m3551035707(tmp, il2cpp_codegen_string_new_wrapper("m_Alignment"), NULL);
	}
}
static void LayoutGroup_t3962498969_CustomAttributesCacheGenerator_LayoutGroup_DelayedSetDirty_m4276695617(CustomAttributesCache* cache)
{
	{
		DebuggerHiddenAttribute_t638884887 * tmp = (DebuggerHiddenAttribute_t638884887 *)cache->attributes[0];
		DebuggerHiddenAttribute__ctor_m2012788180(tmp, NULL);
	}
}
static void U3CDelayedSetDirtyU3Ec__Iterator0_t3228926346_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void U3CDelayedSetDirtyU3Ec__Iterator0_t3228926346_CustomAttributesCacheGenerator_U3CDelayedSetDirtyU3Ec__Iterator0__ctor_m1917915688(CustomAttributesCache* cache)
{
	{
		DebuggerHiddenAttribute_t638884887 * tmp = (DebuggerHiddenAttribute_t638884887 *)cache->attributes[0];
		DebuggerHiddenAttribute__ctor_m2012788180(tmp, NULL);
	}
}
static void U3CDelayedSetDirtyU3Ec__Iterator0_t3228926346_CustomAttributesCacheGenerator_U3CDelayedSetDirtyU3Ec__Iterator0_System_Collections_Generic_IEnumeratorU3CobjectU3E_get_Current_m2210283424(CustomAttributesCache* cache)
{
	{
		DebuggerHiddenAttribute_t638884887 * tmp = (DebuggerHiddenAttribute_t638884887 *)cache->attributes[0];
		DebuggerHiddenAttribute__ctor_m2012788180(tmp, NULL);
	}
}
static void U3CDelayedSetDirtyU3Ec__Iterator0_t3228926346_CustomAttributesCacheGenerator_U3CDelayedSetDirtyU3Ec__Iterator0_System_Collections_IEnumerator_get_Current_m851854792(CustomAttributesCache* cache)
{
	{
		DebuggerHiddenAttribute_t638884887 * tmp = (DebuggerHiddenAttribute_t638884887 *)cache->attributes[0];
		DebuggerHiddenAttribute__ctor_m2012788180(tmp, NULL);
	}
}
static void U3CDelayedSetDirtyU3Ec__Iterator0_t3228926346_CustomAttributesCacheGenerator_U3CDelayedSetDirtyU3Ec__Iterator0_Dispose_m950529291(CustomAttributesCache* cache)
{
	{
		DebuggerHiddenAttribute_t638884887 * tmp = (DebuggerHiddenAttribute_t638884887 *)cache->attributes[0];
		DebuggerHiddenAttribute__ctor_m2012788180(tmp, NULL);
	}
}
static void U3CDelayedSetDirtyU3Ec__Iterator0_t3228926346_CustomAttributesCacheGenerator_U3CDelayedSetDirtyU3Ec__Iterator0_Reset_m955604653(CustomAttributesCache* cache)
{
	{
		DebuggerHiddenAttribute_t638884887 * tmp = (DebuggerHiddenAttribute_t638884887 *)cache->attributes[0];
		DebuggerHiddenAttribute__ctor_m2012788180(tmp, NULL);
	}
}
static void LayoutRebuilder_t2155218138_CustomAttributesCacheGenerator_U3CU3Ef__mgU24cache0(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void LayoutRebuilder_t2155218138_CustomAttributesCacheGenerator_U3CU3Ef__amU24cache0(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void LayoutRebuilder_t2155218138_CustomAttributesCacheGenerator_U3CU3Ef__amU24cache1(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void LayoutRebuilder_t2155218138_CustomAttributesCacheGenerator_U3CU3Ef__amU24cache2(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void LayoutRebuilder_t2155218138_CustomAttributesCacheGenerator_U3CU3Ef__amU24cache3(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void LayoutRebuilder_t2155218138_CustomAttributesCacheGenerator_U3CU3Ef__amU24cache4(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void LayoutRebuilder_t2155218138_CustomAttributesCacheGenerator_LayoutRebuilder_U3Cs_RebuildersU3Em__0_m3768099182(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void LayoutRebuilder_t2155218138_CustomAttributesCacheGenerator_LayoutRebuilder_U3CStripDisabledBehavioursFromListU3Em__1_m3569508057(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void LayoutRebuilder_t2155218138_CustomAttributesCacheGenerator_LayoutRebuilder_U3CRebuildU3Em__2_m3239837417(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void LayoutRebuilder_t2155218138_CustomAttributesCacheGenerator_LayoutRebuilder_U3CRebuildU3Em__3_m777184612(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void LayoutRebuilder_t2155218138_CustomAttributesCacheGenerator_LayoutRebuilder_U3CRebuildU3Em__4_m2524920159(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void LayoutRebuilder_t2155218138_CustomAttributesCacheGenerator_LayoutRebuilder_U3CRebuildU3Em__5_m863475162(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void LayoutUtility_t4076838048_CustomAttributesCacheGenerator_U3CU3Ef__amU24cache0(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void LayoutUtility_t4076838048_CustomAttributesCacheGenerator_U3CU3Ef__amU24cache1(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void LayoutUtility_t4076838048_CustomAttributesCacheGenerator_U3CU3Ef__amU24cache2(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void LayoutUtility_t4076838048_CustomAttributesCacheGenerator_U3CU3Ef__amU24cache3(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void LayoutUtility_t4076838048_CustomAttributesCacheGenerator_U3CU3Ef__amU24cache4(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void LayoutUtility_t4076838048_CustomAttributesCacheGenerator_U3CU3Ef__amU24cache5(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void LayoutUtility_t4076838048_CustomAttributesCacheGenerator_U3CU3Ef__amU24cache6(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void LayoutUtility_t4076838048_CustomAttributesCacheGenerator_U3CU3Ef__amU24cache7(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void LayoutUtility_t4076838048_CustomAttributesCacheGenerator_LayoutUtility_U3CGetMinWidthU3Em__0_m2819807638(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void LayoutUtility_t4076838048_CustomAttributesCacheGenerator_LayoutUtility_U3CGetPreferredWidthU3Em__1_m858056744(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void LayoutUtility_t4076838048_CustomAttributesCacheGenerator_LayoutUtility_U3CGetPreferredWidthU3Em__2_m2944504345(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void LayoutUtility_t4076838048_CustomAttributesCacheGenerator_LayoutUtility_U3CGetFlexibleWidthU3Em__3_m3345200332(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void LayoutUtility_t4076838048_CustomAttributesCacheGenerator_LayoutUtility_U3CGetMinHeightU3Em__4_m1769295917(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void LayoutUtility_t4076838048_CustomAttributesCacheGenerator_LayoutUtility_U3CGetPreferredHeightU3Em__5_m1524880643(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void LayoutUtility_t4076838048_CustomAttributesCacheGenerator_LayoutUtility_U3CGetPreferredHeightU3Em__6_m72173670(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void LayoutUtility_t4076838048_CustomAttributesCacheGenerator_LayoutUtility_U3CGetFlexibleHeightU3Em__7_m947156537(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void VerticalLayoutGroup_t2468316403_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AddComponentMenu_t1099699699 * tmp = (AddComponentMenu_t1099699699 *)cache->attributes[0];
		AddComponentMenu__ctor_m648737891(tmp, il2cpp_codegen_string_new_wrapper("Layout/Vertical Layout Group"), 151LL, NULL);
	}
}
static void IndexedSet_1_t573160278_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		DefaultMemberAttribute_t889804479 * tmp = (DefaultMemberAttribute_t889804479 *)cache->attributes[0];
		DefaultMemberAttribute__ctor_m2234856827(tmp, il2cpp_codegen_string_new_wrapper("Item"), NULL);
	}
}
static void ListPool_1_t1984115411_CustomAttributesCacheGenerator_ListPool_1_U3Cs_ListPoolU3Em__0_m2509427629(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void ObjectPool_1_t4265859154_CustomAttributesCacheGenerator_U3CcountAllU3Ek__BackingField(CustomAttributesCache* cache)
{
	{
		DebuggerBrowsableAttribute_t1386379234 * tmp = (DebuggerBrowsableAttribute_t1386379234 *)cache->attributes[0];
		DebuggerBrowsableAttribute__ctor_m3729055103(tmp, 0LL, NULL);
	}
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[1];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void ObjectPool_1_t4265859154_CustomAttributesCacheGenerator_ObjectPool_1_get_countAll_m794975934(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void ObjectPool_1_t4265859154_CustomAttributesCacheGenerator_ObjectPool_1_set_countAll_m1508336803(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void BaseVertexEffect_t2504093552_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m834417715(tmp, il2cpp_codegen_string_new_wrapper("Use BaseMeshEffect instead"), true, NULL);
	}
}
static void BaseVertexEffect_t2504093552_CustomAttributesCacheGenerator_BaseVertexEffect_ModifyVertices_m3446986347(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m834417715(tmp, il2cpp_codegen_string_new_wrapper("Use BaseMeshEffect.ModifyMeshes instead"), true, NULL);
	}
}
static void BaseMeshEffect_t1728560551_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ExecuteInEditMode_t3043633143 * tmp = (ExecuteInEditMode_t3043633143 *)cache->attributes[0];
		ExecuteInEditMode__ctor_m495837196(tmp, NULL);
	}
}
static void IVertexModifier_t3366215544_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m834417715(tmp, il2cpp_codegen_string_new_wrapper("Use IMeshModifier instead"), true, NULL);
	}
}
static void IVertexModifier_t3366215544_CustomAttributesCacheGenerator_IVertexModifier_ModifyVertices_m3143607399(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m834417715(tmp, il2cpp_codegen_string_new_wrapper("use IMeshModifier.ModifyMesh (VertexHelper verts)  instead"), true, NULL);
	}
}
static void IMeshModifier_t2303987655_CustomAttributesCacheGenerator_IMeshModifier_ModifyMesh_m1735210671(CustomAttributesCache* cache)
{
	{
		ObsoleteAttribute_t3878847927 * tmp = (ObsoleteAttribute_t3878847927 *)cache->attributes[0];
		ObsoleteAttribute__ctor_m834417715(tmp, il2cpp_codegen_string_new_wrapper("use IMeshModifier.ModifyMesh (VertexHelper verts) instead"), false, NULL);
	}
}
static void Outline_t1417504278_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AddComponentMenu_t1099699699 * tmp = (AddComponentMenu_t1099699699 *)cache->attributes[0];
		AddComponentMenu__ctor_m648737891(tmp, il2cpp_codegen_string_new_wrapper("UI/Effects/Outline"), 15LL, NULL);
	}
}
static void PositionAsUV1_t1102546563_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AddComponentMenu_t1099699699 * tmp = (AddComponentMenu_t1099699699 *)cache->attributes[0];
		AddComponentMenu__ctor_m648737891(tmp, il2cpp_codegen_string_new_wrapper("UI/Effects/Position As UV1"), 16LL, NULL);
	}
}
static void Shadow_t4269599528_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		AddComponentMenu_t1099699699 * tmp = (AddComponentMenu_t1099699699 *)cache->attributes[0];
		AddComponentMenu__ctor_m648737891(tmp, il2cpp_codegen_string_new_wrapper("UI/Effects/Shadow"), 14LL, NULL);
	}
}
static void Shadow_t4269599528_CustomAttributesCacheGenerator_m_EffectColor(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void Shadow_t4269599528_CustomAttributesCacheGenerator_m_EffectDistance(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void Shadow_t4269599528_CustomAttributesCacheGenerator_m_UseGraphicAlpha(CustomAttributesCache* cache)
{
	{
		SerializeField_t3073427462 * tmp = (SerializeField_t3073427462 *)cache->attributes[0];
		SerializeField__ctor_m994129777(tmp, NULL);
	}
}
static void U3CPrivateImplementationDetailsU3E_t1486305141_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		CompilerGeneratedAttribute_t497097752 * tmp = (CompilerGeneratedAttribute_t497097752 *)cache->attributes[0];
		CompilerGeneratedAttribute__ctor_m3017743394(tmp, NULL);
	}
}
static void g_AssemblyU2DCSharp_Assembly_CustomAttributesCacheGenerator(CustomAttributesCache* cache)
{
	{
		RuntimeCompatibilityAttribute_t2430705542 * tmp = (RuntimeCompatibilityAttribute_t2430705542 *)cache->attributes[0];
		RuntimeCompatibilityAttribute__ctor_m1331212510(tmp, NULL);
		RuntimeCompatibilityAttribute_set_WrapNonExceptionThrows_m2174793351(tmp, true, NULL);
	}
	{
		DebuggableAttribute_t994551506 * tmp = (DebuggableAttribute_t994551506 *)cache->attributes[1];
		DebuggableAttribute__ctor_m1065484869(tmp, 2LL, NULL);
	}
}
extern const CustomAttributesCacheGenerator g_AttributeGenerators[1977] = 
{
	NULL,
	g_mscorlib_Assembly_CustomAttributesCacheGenerator,
	Il2CppObject_CustomAttributesCacheGenerator,
	Il2CppObject_CustomAttributesCacheGenerator_Object__ctor_m2551263788,
	Il2CppObject_CustomAttributesCacheGenerator_Object_Finalize_m4087144328,
	Il2CppObject_CustomAttributesCacheGenerator_Object_ReferenceEquals_m3900584722,
	ValueType_t3507792607_CustomAttributesCacheGenerator,
	Attribute_t542643598_CustomAttributesCacheGenerator,
	_Attribute_t1557664299_CustomAttributesCacheGenerator,
	Int32_t2071877448_CustomAttributesCacheGenerator,
	IFormattable_t1523031934_CustomAttributesCacheGenerator,
	IConvertible_t908092482_CustomAttributesCacheGenerator,
	IComparable_t1857082765_CustomAttributesCacheGenerator,
	SerializableAttribute_t2780967079_CustomAttributesCacheGenerator,
	AttributeUsageAttribute_t1057435127_CustomAttributesCacheGenerator,
	ComVisibleAttribute_t2245573759_CustomAttributesCacheGenerator,
	Int64_t909078037_CustomAttributesCacheGenerator,
	UInt32_t2149682021_CustomAttributesCacheGenerator,
	UInt32_t2149682021_CustomAttributesCacheGenerator_UInt32_Parse_m3371984903,
	UInt32_t2149682021_CustomAttributesCacheGenerator_UInt32_Parse_m3339354106,
	UInt32_t2149682021_CustomAttributesCacheGenerator_UInt32_TryParse_m4283512434,
	UInt32_t2149682021_CustomAttributesCacheGenerator_UInt32_TryParse_m3987111861,
	CLSCompliantAttribute_t809966061_CustomAttributesCacheGenerator,
	UInt64_t2909196914_CustomAttributesCacheGenerator,
	UInt64_t2909196914_CustomAttributesCacheGenerator_UInt64_Parse_m834741018,
	UInt64_t2909196914_CustomAttributesCacheGenerator_UInt64_Parse_m1414377767,
	UInt64_t2909196914_CustomAttributesCacheGenerator_UInt64_TryParse_m3722071442,
	Byte_t3683104436_CustomAttributesCacheGenerator,
	SByte_t454417549_CustomAttributesCacheGenerator,
	SByte_t454417549_CustomAttributesCacheGenerator_SByte_Parse_m1620039654,
	SByte_t454417549_CustomAttributesCacheGenerator_SByte_Parse_m2544167007,
	SByte_t454417549_CustomAttributesCacheGenerator_SByte_TryParse_m1263156074,
	Int16_t4041245914_CustomAttributesCacheGenerator,
	UInt16_t986882611_CustomAttributesCacheGenerator,
	UInt16_t986882611_CustomAttributesCacheGenerator_UInt16_Parse_m3560204090,
	UInt16_t986882611_CustomAttributesCacheGenerator_UInt16_Parse_m3815892167,
	UInt16_t986882611_CustomAttributesCacheGenerator_UInt16_TryParse_m4241404978,
	UInt16_t986882611_CustomAttributesCacheGenerator_UInt16_TryParse_m1818885113,
	IEnumerator_t1466026749_CustomAttributesCacheGenerator,
	IEnumerable_t2911409499_CustomAttributesCacheGenerator,
	IEnumerable_t2911409499_CustomAttributesCacheGenerator_IEnumerable_GetEnumerator_m1462532911,
	IDisposable_t2427283555_CustomAttributesCacheGenerator,
	Char_t3454481338_CustomAttributesCacheGenerator,
	String_t_CustomAttributesCacheGenerator,
	String_t_CustomAttributesCacheGenerator_String__ctor_m2041020387,
	String_t_CustomAttributesCacheGenerator_String_Equals_m406432531,
	String_t_CustomAttributesCacheGenerator_String_Equals_m2633592423,
	String_t_CustomAttributesCacheGenerator_String_Split_m3326265864____separator0,
	String_t_CustomAttributesCacheGenerator_String_Split_m1779268055,
	String_t_CustomAttributesCacheGenerator_String_Split_m394273024,
	String_t_CustomAttributesCacheGenerator_String_Split_m3927740091,
	String_t_CustomAttributesCacheGenerator_String_Trim_m3982520224____trimChars0,
	String_t_CustomAttributesCacheGenerator_String_TrimStart_m710830036____trimChars0,
	String_t_CustomAttributesCacheGenerator_String_TrimEnd_m3153143011____trimChars0,
	String_t_CustomAttributesCacheGenerator_String_Format_m1263743648____args1,
	String_t_CustomAttributesCacheGenerator_String_Format_m876527052____args2,
	String_t_CustomAttributesCacheGenerator_String_FormatHelper_m1513692144____args3,
	String_t_CustomAttributesCacheGenerator_String_Concat_m3881798623____args0,
	String_t_CustomAttributesCacheGenerator_String_Concat_m626692867____values0,
	String_t_CustomAttributesCacheGenerator_String_GetHashCode_m931956593,
	ICloneable_t3853279282_CustomAttributesCacheGenerator,
	Single_t2076509932_CustomAttributesCacheGenerator,
	Single_t2076509932_CustomAttributesCacheGenerator_Single_IsNaN_m2349591895,
	Double_t4078015681_CustomAttributesCacheGenerator,
	Double_t4078015681_CustomAttributesCacheGenerator_Double_IsNaN_m2289494211,
	Decimal_t724701077_CustomAttributesCacheGenerator,
	Decimal_t724701077_CustomAttributesCacheGenerator_MinValue,
	Decimal_t724701077_CustomAttributesCacheGenerator_MaxValue,
	Decimal_t724701077_CustomAttributesCacheGenerator_MinusOne,
	Decimal_t724701077_CustomAttributesCacheGenerator_One,
	Decimal_t724701077_CustomAttributesCacheGenerator_Decimal__ctor_m1376049078,
	Decimal_t724701077_CustomAttributesCacheGenerator_Decimal__ctor_m569480123,
	Decimal_t724701077_CustomAttributesCacheGenerator_Decimal_Compare_m1330176085,
	Decimal_t724701077_CustomAttributesCacheGenerator_Decimal_op_Explicit_m2135374155,
	Decimal_t724701077_CustomAttributesCacheGenerator_Decimal_op_Explicit_m1986696267,
	Decimal_t724701077_CustomAttributesCacheGenerator_Decimal_op_Explicit_m714968249,
	Decimal_t724701077_CustomAttributesCacheGenerator_Decimal_op_Explicit_m383920456,
	Decimal_t724701077_CustomAttributesCacheGenerator_Decimal_op_Implicit_m623319612,
	Decimal_t724701077_CustomAttributesCacheGenerator_Decimal_op_Implicit_m233687092,
	Decimal_t724701077_CustomAttributesCacheGenerator_Decimal_op_Implicit_m4246329390,
	Decimal_t724701077_CustomAttributesCacheGenerator_Decimal_op_Implicit_m2135798419,
	Boolean_t3825574718_CustomAttributesCacheGenerator,
	IntPtr_t_CustomAttributesCacheGenerator,
	IntPtr_t_CustomAttributesCacheGenerator_IntPtr__ctor_m2996690883,
	IntPtr_t_CustomAttributesCacheGenerator_IntPtr__ctor_m3803259710,
	IntPtr_t_CustomAttributesCacheGenerator_IntPtr__ctor_m3033286303,
	IntPtr_t_CustomAttributesCacheGenerator_IntPtr_get_Size_m3339807560,
	IntPtr_t_CustomAttributesCacheGenerator_IntPtr_ToInt64_m39971741,
	IntPtr_t_CustomAttributesCacheGenerator_IntPtr_ToPointer_m1888290092,
	IntPtr_t_CustomAttributesCacheGenerator_IntPtr_op_Equality_m1573482188,
	IntPtr_t_CustomAttributesCacheGenerator_IntPtr_op_Inequality_m3044532593,
	IntPtr_t_CustomAttributesCacheGenerator_IntPtr_op_Explicit_m3896766622,
	IntPtr_t_CustomAttributesCacheGenerator_IntPtr_op_Explicit_m3090197667,
	IntPtr_t_CustomAttributesCacheGenerator_IntPtr_op_Explicit_m1401226878,
	IntPtr_t_CustomAttributesCacheGenerator_IntPtr_op_Explicit_m1073656736,
	ISerializable_t1245643778_CustomAttributesCacheGenerator,
	UIntPtr_t_CustomAttributesCacheGenerator,
	UIntPtr_t_CustomAttributesCacheGenerator_UIntPtr__ctor_m2836115166,
	UIntPtr_t_CustomAttributesCacheGenerator_UIntPtr_ToPointer_m2844280029,
	UIntPtr_t_CustomAttributesCacheGenerator_UIntPtr_op_Explicit_m2497276212,
	UIntPtr_t_CustomAttributesCacheGenerator_UIntPtr_op_Explicit_m2011523904,
	MulticastDelegate_t3201952435_CustomAttributesCacheGenerator,
	Delegate_t3022476291_CustomAttributesCacheGenerator,
	Delegate_t3022476291_CustomAttributesCacheGenerator_Delegate_Combine_m1976351882,
	Delegate_t3022476291_CustomAttributesCacheGenerator_Delegate_Combine_m1976351882____delegates0,
	Enum_t2459695545_CustomAttributesCacheGenerator,
	Enum_t2459695545_CustomAttributesCacheGenerator_Enum_GetName_m1226611481,
	Enum_t2459695545_CustomAttributesCacheGenerator_Enum_IsDefined_m92789062,
	Enum_t2459695545_CustomAttributesCacheGenerator_Enum_GetUnderlyingType_m3513899012,
	Enum_t2459695545_CustomAttributesCacheGenerator_Enum_Parse_m982704874,
	Enum_t2459695545_CustomAttributesCacheGenerator_Enum_ToString_m3754726711,
	Enum_t2459695545_CustomAttributesCacheGenerator_Enum_ToString_m662345249,
	Enum_t2459695545_CustomAttributesCacheGenerator_Enum_ToObject_m1688724857,
	Enum_t2459695545_CustomAttributesCacheGenerator_Enum_ToObject_m604645223,
	Enum_t2459695545_CustomAttributesCacheGenerator_Enum_ToObject_m322320225,
	Enum_t2459695545_CustomAttributesCacheGenerator_Enum_ToObject_m745807726,
	Enum_t2459695545_CustomAttributesCacheGenerator_Enum_ToObject_m2460371738,
	Enum_t2459695545_CustomAttributesCacheGenerator_Enum_ToObject_m2216605710,
	Enum_t2459695545_CustomAttributesCacheGenerator_Enum_ToObject_m275924358,
	Enum_t2459695545_CustomAttributesCacheGenerator_Enum_ToObject_m2601523252,
	Enum_t2459695545_CustomAttributesCacheGenerator_Enum_ToObject_m1438724003,
	Enum_t2459695545_CustomAttributesCacheGenerator_Enum_Format_m2294492821,
	Il2CppArray_CustomAttributesCacheGenerator,
	Il2CppArray_CustomAttributesCacheGenerator_Array_System_Collections_IList_IndexOf_m3525625060,
	Il2CppArray_CustomAttributesCacheGenerator_Array_get_Length_m1498215565,
	Il2CppArray_CustomAttributesCacheGenerator_Array_get_LongLength_m2538298538,
	Il2CppArray_CustomAttributesCacheGenerator_Array_get_Rank_m3837250695,
	Il2CppArray_CustomAttributesCacheGenerator_Array_GetLongLength_m3005360186,
	Il2CppArray_CustomAttributesCacheGenerator_Array_GetLowerBound_m3733237204,
	Il2CppArray_CustomAttributesCacheGenerator_Array_GetValue_m3550694941____indices0,
	Il2CppArray_CustomAttributesCacheGenerator_Array_SetValue_m2421438042____indices1,
	Il2CppArray_CustomAttributesCacheGenerator_Array_GetUpperBound_m1352329707,
	Il2CppArray_CustomAttributesCacheGenerator_Array_GetValue_m152202090,
	Il2CppArray_CustomAttributesCacheGenerator_Array_GetValue_m518505780,
	Il2CppArray_CustomAttributesCacheGenerator_Array_GetValue_m3182152438,
	Il2CppArray_CustomAttributesCacheGenerator_Array_SetValue_m1489959987,
	Il2CppArray_CustomAttributesCacheGenerator_Array_SetValue_m2671138705,
	Il2CppArray_CustomAttributesCacheGenerator_Array_SetValue_m2039608971,
	Il2CppArray_CustomAttributesCacheGenerator_Array_CreateInstance_m3327690220____lengths1,
	Il2CppArray_CustomAttributesCacheGenerator_Array_CreateInstance_m679102425____lengths1,
	Il2CppArray_CustomAttributesCacheGenerator_Array_GetValue_m1507415734,
	Il2CppArray_CustomAttributesCacheGenerator_Array_GetValue_m1507415734____indices0,
	Il2CppArray_CustomAttributesCacheGenerator_Array_SetValue_m169741241,
	Il2CppArray_CustomAttributesCacheGenerator_Array_SetValue_m169741241____indices1,
	Il2CppArray_CustomAttributesCacheGenerator_Array_BinarySearch_m3522310993,
	Il2CppArray_CustomAttributesCacheGenerator_Array_BinarySearch_m1368352453,
	Il2CppArray_CustomAttributesCacheGenerator_Array_BinarySearch_m2287427837,
	Il2CppArray_CustomAttributesCacheGenerator_Array_BinarySearch_m3270245097,
	Il2CppArray_CustomAttributesCacheGenerator_Array_Clear_m782967417,
	Il2CppArray_CustomAttributesCacheGenerator_Array_Copy_m2363740072,
	Il2CppArray_CustomAttributesCacheGenerator_Array_Copy_m3808317496,
	Il2CppArray_CustomAttributesCacheGenerator_Array_Copy_m1969461849,
	Il2CppArray_CustomAttributesCacheGenerator_Array_Copy_m1557170853,
	Il2CppArray_CustomAttributesCacheGenerator_Array_IndexOf_m77084779,
	Il2CppArray_CustomAttributesCacheGenerator_Array_IndexOf_m2819632474,
	Il2CppArray_CustomAttributesCacheGenerator_Array_IndexOf_m2447301431,
	Il2CppArray_CustomAttributesCacheGenerator_Array_LastIndexOf_m229510321,
	Il2CppArray_CustomAttributesCacheGenerator_Array_LastIndexOf_m4096535198,
	Il2CppArray_CustomAttributesCacheGenerator_Array_LastIndexOf_m512887013,
	Il2CppArray_CustomAttributesCacheGenerator_Array_Reverse_m3883292526,
	Il2CppArray_CustomAttributesCacheGenerator_Array_Reverse_m3433347928,
	Il2CppArray_CustomAttributesCacheGenerator_Array_Sort_m2994254654,
	Il2CppArray_CustomAttributesCacheGenerator_Array_Sort_m3002148658,
	Il2CppArray_CustomAttributesCacheGenerator_Array_Sort_m1417611156,
	Il2CppArray_CustomAttributesCacheGenerator_Array_Sort_m3645766612,
	Il2CppArray_CustomAttributesCacheGenerator_Array_Sort_m4096942812,
	Il2CppArray_CustomAttributesCacheGenerator_Array_Sort_m3500510484,
	Il2CppArray_CustomAttributesCacheGenerator_Array_Sort_m2323017822,
	Il2CppArray_CustomAttributesCacheGenerator_Array_Sort_m3742784266,
	Il2CppArray_CustomAttributesCacheGenerator_Array_Sort_m1730553742,
	Il2CppArray_CustomAttributesCacheGenerator_Array_Sort_m3106198730,
	Il2CppArray_CustomAttributesCacheGenerator_Array_Sort_m2090966156,
	Il2CppArray_CustomAttributesCacheGenerator_Array_Sort_m1985772939,
	Il2CppArray_CustomAttributesCacheGenerator_Array_Sort_m2736815140,
	Il2CppArray_CustomAttributesCacheGenerator_Array_Sort_m2468799988,
	Il2CppArray_CustomAttributesCacheGenerator_Array_Sort_m2587948790,
	Il2CppArray_CustomAttributesCacheGenerator_Array_Sort_m1279015767,
	Il2CppArray_CustomAttributesCacheGenerator_Array_CopyTo_m1950502352,
	Il2CppArray_CustomAttributesCacheGenerator_Array_Resize_m1201602141,
	Il2CppArray_CustomAttributesCacheGenerator_Array_BinarySearch_m525402987,
	Il2CppArray_CustomAttributesCacheGenerator_Array_BinarySearch_m3577113407,
	Il2CppArray_CustomAttributesCacheGenerator_Array_BinarySearch_m1033585031,
	Il2CppArray_CustomAttributesCacheGenerator_Array_BinarySearch_m3052238307,
	Il2CppArray_CustomAttributesCacheGenerator_Array_ConstrainedCopy_m1922927602,
	Il2CppArray_CustomAttributesCacheGenerator_Il2CppArray____LongLength_PropertyInfo,
	ArrayReadOnlyList_1_t3367196019_CustomAttributesCacheGenerator,
	ArrayReadOnlyList_1_t3367196019_CustomAttributesCacheGenerator_ArrayReadOnlyList_1_GetEnumerator_m3031680693,
	U3CGetEnumeratorU3Ec__Iterator0_t1667190089_CustomAttributesCacheGenerator,
	U3CGetEnumeratorU3Ec__Iterator0_t1667190089_CustomAttributesCacheGenerator_U3CGetEnumeratorU3Ec__Iterator0_System_Collections_Generic_IEnumeratorU3CTU3E_get_Current_m2965013776,
	U3CGetEnumeratorU3Ec__Iterator0_t1667190089_CustomAttributesCacheGenerator_U3CGetEnumeratorU3Ec__Iterator0_System_Collections_IEnumerator_get_Current_m1649432893,
	U3CGetEnumeratorU3Ec__Iterator0_t1667190089_CustomAttributesCacheGenerator_U3CGetEnumeratorU3Ec__Iterator0_Dispose_m3682973538,
	U3CGetEnumeratorU3Ec__Iterator0_t1667190089_CustomAttributesCacheGenerator_U3CGetEnumeratorU3Ec__Iterator0_Reset_m669313508,
	ICollection_t91669223_CustomAttributesCacheGenerator,
	IList_t3321498491_CustomAttributesCacheGenerator,
	IList_1_t3737699284_CustomAttributesCacheGenerator,
	Void_t1841601450_CustomAttributesCacheGenerator,
	Type_t_CustomAttributesCacheGenerator,
	Type_t_CustomAttributesCacheGenerator_Type_IsSubclassOf_m2450899481,
	Type_t_CustomAttributesCacheGenerator_Type_GetConstructor_m132234455,
	Type_t_CustomAttributesCacheGenerator_Type_GetConstructor_m663514781,
	Type_t_CustomAttributesCacheGenerator_Type_GetConstructor_m835344477,
	Type_t_CustomAttributesCacheGenerator_Type_GetConstructors_m2314877651,
	Type_t_CustomAttributesCacheGenerator_Type_MakeGenericType_m2765875033____typeArguments0,
	MemberInfo_t_CustomAttributesCacheGenerator,
	ICustomAttributeProvider_t502202687_CustomAttributesCacheGenerator,
	_MemberInfo_t332722161_CustomAttributesCacheGenerator,
	IReflect_t3412036974_CustomAttributesCacheGenerator,
	_Type_t102776839_CustomAttributesCacheGenerator,
	Exception_t1927440687_CustomAttributesCacheGenerator,
	_Exception_t3026971024_CustomAttributesCacheGenerator,
	RuntimeFieldHandle_t2331729674_CustomAttributesCacheGenerator,
	RuntimeFieldHandle_t2331729674_CustomAttributesCacheGenerator_RuntimeFieldHandle_Equals_m1202966418,
	RuntimeTypeHandle_t2330101084_CustomAttributesCacheGenerator,
	RuntimeTypeHandle_t2330101084_CustomAttributesCacheGenerator_RuntimeTypeHandle_Equals_m452760426,
	ParamArrayAttribute_t2144993728_CustomAttributesCacheGenerator,
	OutAttribute_t1539424546_CustomAttributesCacheGenerator,
	ObsoleteAttribute_t3878847927_CustomAttributesCacheGenerator,
	DllImportAttribute_t3000813225_CustomAttributesCacheGenerator,
	MarshalAsAttribute_t2900773360_CustomAttributesCacheGenerator,
	MarshalAsAttribute_t2900773360_CustomAttributesCacheGenerator_MarshalType,
	MarshalAsAttribute_t2900773360_CustomAttributesCacheGenerator_MarshalTypeRef,
	InAttribute_t1394050551_CustomAttributesCacheGenerator,
	GuidAttribute_t222072359_CustomAttributesCacheGenerator,
	ComImportAttribute_t468083054_CustomAttributesCacheGenerator,
	OptionalAttribute_t827982902_CustomAttributesCacheGenerator,
	CompilerGeneratedAttribute_t497097752_CustomAttributesCacheGenerator,
	InternalsVisibleToAttribute_t1037732567_CustomAttributesCacheGenerator,
	RuntimeCompatibilityAttribute_t2430705542_CustomAttributesCacheGenerator,
	DebuggerHiddenAttribute_t638884887_CustomAttributesCacheGenerator,
	DefaultMemberAttribute_t889804479_CustomAttributesCacheGenerator,
	DecimalConstantAttribute_t569828555_CustomAttributesCacheGenerator,
	DecimalConstantAttribute_t569828555_CustomAttributesCacheGenerator_DecimalConstantAttribute__ctor_m71487003,
	FieldOffsetAttribute_t1553145711_CustomAttributesCacheGenerator,
	RuntimeArgumentHandle_t3259266975_CustomAttributesCacheGenerator,
	AsyncCallback_t163412349_CustomAttributesCacheGenerator,
	IAsyncResult_t1999651008_CustomAttributesCacheGenerator,
	TypedReference_t1025199857_CustomAttributesCacheGenerator,
	MarshalByRefObject_t1285298191_CustomAttributesCacheGenerator,
	Locale_t4255929014_CustomAttributesCacheGenerator_Locale_GetText_m2553164138____args1,
	MonoTODOAttribute_t3487514019_CustomAttributesCacheGenerator,
	MonoDocumentationNoteAttribute_t1101545345_CustomAttributesCacheGenerator,
	SafeHandleZeroOrMinusOneIsInvalid_t1177681199_CustomAttributesCacheGenerator_SafeHandleZeroOrMinusOneIsInvalid__ctor_m3340306667,
	SafeWaitHandle_t481461830_CustomAttributesCacheGenerator_SafeWaitHandle__ctor_m1710231470,
	MSCompatUnicodeTable_t1231687219_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map2,
	MSCompatUnicodeTable_t1231687219_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map3,
	MSCompatUnicodeTable_t1231687219_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map4,
	SortKey_t1270563137_CustomAttributesCacheGenerator,
	PKCS12_t1362584794_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map8,
	PKCS12_t1362584794_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map9,
	PKCS12_t1362584794_CustomAttributesCacheGenerator_U3CU3Ef__switchU24mapA,
	PKCS12_t1362584794_CustomAttributesCacheGenerator_U3CU3Ef__switchU24mapB,
	PKCS12_t1362584794_CustomAttributesCacheGenerator_U3CU3Ef__switchU24mapF,
	X509CertificateCollection_t3592472865_CustomAttributesCacheGenerator,
	X509ExtensionCollection_t1640144839_CustomAttributesCacheGenerator,
	ASN1_t924533535_CustomAttributesCacheGenerator,
	SmallXmlParser_t3549787957_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map18,
	Dictionary_2_t2276497324_CustomAttributesCacheGenerator,
	Dictionary_2_t2276497324_CustomAttributesCacheGenerator_U3CU3Ef__amU24cacheB,
	Dictionary_2_t2276497324_CustomAttributesCacheGenerator_Dictionary_2_U3CCopyToU3Em__0_m3609630743,
	ValueCollection_t2262344653_CustomAttributesCacheGenerator,
	IDictionary_2_t3502329323_CustomAttributesCacheGenerator,
	KeyNotFoundException_t1722175009_CustomAttributesCacheGenerator,
	KeyValuePair_2_t1988958766_CustomAttributesCacheGenerator,
	List_1_t1169184319_CustomAttributesCacheGenerator,
	Collection_1_t686054069_CustomAttributesCacheGenerator,
	ReadOnlyCollection_1_t3540981679_CustomAttributesCacheGenerator,
	ArrayList_t4252133567_CustomAttributesCacheGenerator,
	ArrayListWrapper_t3918858854_CustomAttributesCacheGenerator,
	SynchronizedArrayListWrapper_t3317806524_CustomAttributesCacheGenerator,
	ReadOnlyArrayListWrapper_t4044524772_CustomAttributesCacheGenerator,
	BitArray_t4180138994_CustomAttributesCacheGenerator,
	CaseInsensitiveComparer_t157661140_CustomAttributesCacheGenerator,
	CaseInsensitiveHashCodeProvider_t2307530285_CustomAttributesCacheGenerator,
	CollectionBase_t1101587467_CustomAttributesCacheGenerator,
	Comparer_t3673668605_CustomAttributesCacheGenerator,
	DictionaryEntry_t3048875398_CustomAttributesCacheGenerator,
	Hashtable_t909839986_CustomAttributesCacheGenerator,
	Hashtable_t909839986_CustomAttributesCacheGenerator_Hashtable__ctor_m846339375,
	Hashtable_t909839986_CustomAttributesCacheGenerator_Hashtable__ctor_m4106078798,
	Hashtable_t909839986_CustomAttributesCacheGenerator_Hashtable__ctor_m2894679847,
	Hashtable_t909839986_CustomAttributesCacheGenerator_Hashtable__ctor_m3742489710,
	Hashtable_t909839986_CustomAttributesCacheGenerator_Hashtable__ctor_m2337481811,
	Hashtable_t909839986_CustomAttributesCacheGenerator_Hashtable_Clear_m3672070813,
	Hashtable_t909839986_CustomAttributesCacheGenerator_Hashtable_Remove_m607079606,
	Hashtable_t909839986_CustomAttributesCacheGenerator_Hashtable_OnDeserialization_m4192849898,
	Hashtable_t909839986_CustomAttributesCacheGenerator_Hashtable_t909839986____comparer_PropertyInfo,
	Hashtable_t909839986_CustomAttributesCacheGenerator_Hashtable_t909839986____hcp_PropertyInfo,
	HashKeys_t187688763_CustomAttributesCacheGenerator,
	HashValues_t2390200547_CustomAttributesCacheGenerator,
	SyncHashtable_t1343674558_CustomAttributesCacheGenerator,
	IComparer_t3952557350_CustomAttributesCacheGenerator,
	IDictionary_t596158605_CustomAttributesCacheGenerator,
	IDictionaryEnumerator_t259680273_CustomAttributesCacheGenerator,
	IEqualityComparer_t2716208158_CustomAttributesCacheGenerator,
	IHashCodeProvider_t1980576455_CustomAttributesCacheGenerator,
	Queue_t1288490777_CustomAttributesCacheGenerator,
	SortedList_t3004938869_CustomAttributesCacheGenerator,
	Stack_t1043988394_CustomAttributesCacheGenerator,
	AssemblyHashAlgorithm_t4147282775_CustomAttributesCacheGenerator,
	AssemblyVersionCompatibility_t1223556284_CustomAttributesCacheGenerator,
	DebuggableAttribute_t994551506_CustomAttributesCacheGenerator,
	DebuggingModes_t2073970606_CustomAttributesCacheGenerator,
	DebuggerBrowsableAttribute_t1386379234_CustomAttributesCacheGenerator,
	DebuggerBrowsableState_t944457511_CustomAttributesCacheGenerator,
	DebuggerDisplayAttribute_t1528914581_CustomAttributesCacheGenerator,
	DebuggerStepThroughAttribute_t518825354_CustomAttributesCacheGenerator,
	DebuggerTypeProxyAttribute_t970972087_CustomAttributesCacheGenerator,
	StackFrame_t2050294881_CustomAttributesCacheGenerator,
	StackTrace_t2500644597_CustomAttributesCacheGenerator,
	Calendar_t585061108_CustomAttributesCacheGenerator,
	Calendar_t585061108_CustomAttributesCacheGenerator_Calendar_Clone_m3159430630,
	CompareInfo_t2310920157_CustomAttributesCacheGenerator,
	CompareOptions_t2829943955_CustomAttributesCacheGenerator,
	CultureInfo_t3500843524_CustomAttributesCacheGenerator,
	CultureInfo_t3500843524_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map19,
	CultureInfo_t3500843524_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map1A,
	DateTimeFormatFlags_t3140910561_CustomAttributesCacheGenerator,
	DateTimeFormatInfo_t2187473504_CustomAttributesCacheGenerator,
	DateTimeStyles_t370343085_CustomAttributesCacheGenerator,
	DaylightTime_t3800227331_CustomAttributesCacheGenerator,
	GregorianCalendar_t3361245568_CustomAttributesCacheGenerator,
	GregorianCalendarTypes_t3080789929_CustomAttributesCacheGenerator,
	NumberFormatInfo_t104580544_CustomAttributesCacheGenerator,
	NumberStyles_t3408984435_CustomAttributesCacheGenerator,
	TextInfo_t3620182823_CustomAttributesCacheGenerator,
	TextInfo_t3620182823_CustomAttributesCacheGenerator_TextInfo_System_Runtime_Serialization_IDeserializationCallback_OnDeserialization_m4238883895,
	TextInfo_t3620182823_CustomAttributesCacheGenerator_TextInfo_Clone_m1096841305,
	TextInfo_t3620182823_CustomAttributesCacheGenerator_TextInfo_t3620182823____CultureName_PropertyInfo,
	UnicodeCategory_t682236799_CustomAttributesCacheGenerator,
	IsolatedStorageException_t2011779685_CustomAttributesCacheGenerator,
	BinaryReader_t2491843768_CustomAttributesCacheGenerator,
	BinaryReader_t2491843768_CustomAttributesCacheGenerator_BinaryReader_ReadSByte_m1712621355,
	BinaryReader_t2491843768_CustomAttributesCacheGenerator_BinaryReader_ReadUInt16_m2664161107,
	BinaryReader_t2491843768_CustomAttributesCacheGenerator_BinaryReader_ReadUInt32_m1363572147,
	BinaryReader_t2491843768_CustomAttributesCacheGenerator_BinaryReader_ReadUInt64_m1893783375,
	Directory_t3318511961_CustomAttributesCacheGenerator,
	DirectoryInfo_t1934446453_CustomAttributesCacheGenerator,
	DirectoryNotFoundException_t373523477_CustomAttributesCacheGenerator,
	EndOfStreamException_t1711658693_CustomAttributesCacheGenerator,
	File_t1930543328_CustomAttributesCacheGenerator,
	FileAccess_t4282042064_CustomAttributesCacheGenerator,
	FileAttributes_t3843045335_CustomAttributesCacheGenerator,
	FileLoadException_t3198361301_CustomAttributesCacheGenerator,
	FileMode_t236403845_CustomAttributesCacheGenerator,
	FileNotFoundException_t4200667904_CustomAttributesCacheGenerator,
	FileOptions_t3144759768_CustomAttributesCacheGenerator,
	FileShare_t3362491215_CustomAttributesCacheGenerator,
	FileStream_t1695958676_CustomAttributesCacheGenerator,
	FileSystemInfo_t2360991899_CustomAttributesCacheGenerator,
	FileSystemInfo_t2360991899_CustomAttributesCacheGenerator_FileSystemInfo_GetObjectData_m1755848054,
	IOException_t2458421087_CustomAttributesCacheGenerator,
	MemoryStream_t743994179_CustomAttributesCacheGenerator,
	Path_t41728875_CustomAttributesCacheGenerator,
	Path_t41728875_CustomAttributesCacheGenerator_InvalidPathChars,
	PathTooLongException_t2469314706_CustomAttributesCacheGenerator,
	SeekOrigin_t2475945306_CustomAttributesCacheGenerator,
	Stream_t3255436806_CustomAttributesCacheGenerator,
	StreamReader_t2360341767_CustomAttributesCacheGenerator,
	StreamWriter_t3858580635_CustomAttributesCacheGenerator,
	StringReader_t1480123486_CustomAttributesCacheGenerator,
	TextReader_t1561828458_CustomAttributesCacheGenerator,
	TextWriter_t4027217640_CustomAttributesCacheGenerator,
	UnmanagedMemoryStream_t822875729_CustomAttributesCacheGenerator,
	AssemblyBuilder_t1646117627_CustomAttributesCacheGenerator,
	ConstructorBuilder_t700974433_CustomAttributesCacheGenerator,
	ConstructorBuilder_t700974433_CustomAttributesCacheGenerator_ConstructorBuilder_t700974433____CallingConvention_PropertyInfo,
	DerivedType_t1016359113_CustomAttributesCacheGenerator_DerivedType_MakeGenericType_m742223168____typeArguments0,
	EnumBuilder_t2808714468_CustomAttributesCacheGenerator,
	EnumBuilder_t2808714468_CustomAttributesCacheGenerator_EnumBuilder_GetConstructors_m3240699827,
	FieldBuilder_t2784804005_CustomAttributesCacheGenerator,
	GenericTypeParameterBuilder_t1370236603_CustomAttributesCacheGenerator,
	GenericTypeParameterBuilder_t1370236603_CustomAttributesCacheGenerator_GenericTypeParameterBuilder_IsSubclassOf_m563999142,
	GenericTypeParameterBuilder_t1370236603_CustomAttributesCacheGenerator_GenericTypeParameterBuilder_GetConstructors_m103067670,
	GenericTypeParameterBuilder_t1370236603_CustomAttributesCacheGenerator_GenericTypeParameterBuilder_Equals_m2498927509,
	GenericTypeParameterBuilder_t1370236603_CustomAttributesCacheGenerator_GenericTypeParameterBuilder_GetHashCode_m867619899,
	GenericTypeParameterBuilder_t1370236603_CustomAttributesCacheGenerator_GenericTypeParameterBuilder_MakeGenericType_m2955814622,
	GenericTypeParameterBuilder_t1370236603_CustomAttributesCacheGenerator_GenericTypeParameterBuilder_MakeGenericType_m2955814622____typeArguments0,
	ILGenerator_t99948092_CustomAttributesCacheGenerator,
	ILGenerator_t99948092_CustomAttributesCacheGenerator_ILGenerator_Emit_m116557729,
	ILGenerator_t99948092_CustomAttributesCacheGenerator_ILGenerator_Mono_GetCurrentOffset_m3553856682,
	MethodBuilder_t644187984_CustomAttributesCacheGenerator,
	MethodBuilder_t644187984_CustomAttributesCacheGenerator_MethodBuilder_Equals_m1205580640,
	MethodBuilder_t644187984_CustomAttributesCacheGenerator_MethodBuilder_MakeGenericMethod_m303913412____typeArguments0,
	MethodToken_t3991686330_CustomAttributesCacheGenerator,
	ModuleBuilder_t4156028127_CustomAttributesCacheGenerator,
	OpCode_t2247480392_CustomAttributesCacheGenerator,
	OpCodes_t3494785031_CustomAttributesCacheGenerator,
	OpCodes_t3494785031_CustomAttributesCacheGenerator_Castclass,
	ParameterBuilder_t3344728474_CustomAttributesCacheGenerator,
	StackBehaviour_t1390406961_CustomAttributesCacheGenerator,
	TypeBuilder_t3308873219_CustomAttributesCacheGenerator,
	TypeBuilder_t3308873219_CustomAttributesCacheGenerator_TypeBuilder_DefineConstructor_m3431248509,
	TypeBuilder_t3308873219_CustomAttributesCacheGenerator_TypeBuilder_DefineConstructor_m2972481149,
	TypeBuilder_t3308873219_CustomAttributesCacheGenerator_TypeBuilder_DefineDefaultConstructor_m2225828699,
	TypeBuilder_t3308873219_CustomAttributesCacheGenerator_TypeBuilder_GetConstructors_m774120094,
	TypeBuilder_t3308873219_CustomAttributesCacheGenerator_TypeBuilder_MakeGenericType_m4282022646,
	TypeBuilder_t3308873219_CustomAttributesCacheGenerator_TypeBuilder_MakeGenericType_m4282022646____typeArguments0,
	TypeBuilder_t3308873219_CustomAttributesCacheGenerator_TypeBuilder_IsAssignableFrom_m212977480,
	TypeBuilder_t3308873219_CustomAttributesCacheGenerator_TypeBuilder_IsSubclassOf_m428846622,
	TypeBuilder_t3308873219_CustomAttributesCacheGenerator_TypeBuilder_IsAssignableTo_m3210661829,
	UnmanagedMarshal_t4270021860_CustomAttributesCacheGenerator,
	AmbiguousMatchException_t1406414556_CustomAttributesCacheGenerator,
	Assembly_t4268412390_CustomAttributesCacheGenerator,
	Assembly_t4268412390_CustomAttributesCacheGenerator_Assembly_GetName_m3984565618,
	AssemblyCompanyAttribute_t2851673381_CustomAttributesCacheGenerator,
	AssemblyConfigurationAttribute_t1678917172_CustomAttributesCacheGenerator,
	AssemblyCopyrightAttribute_t177123295_CustomAttributesCacheGenerator,
	AssemblyDefaultAliasAttribute_t1774139159_CustomAttributesCacheGenerator,
	AssemblyDelaySignAttribute_t2705758496_CustomAttributesCacheGenerator,
	AssemblyDescriptionAttribute_t1018387888_CustomAttributesCacheGenerator,
	AssemblyFileVersionAttribute_t2897687916_CustomAttributesCacheGenerator,
	AssemblyInformationalVersionAttribute_t3037389657_CustomAttributesCacheGenerator,
	AssemblyKeyFileAttribute_t605245443_CustomAttributesCacheGenerator,
	AssemblyName_t894705941_CustomAttributesCacheGenerator,
	AssemblyNameFlags_t1794031440_CustomAttributesCacheGenerator,
	AssemblyProductAttribute_t1523443169_CustomAttributesCacheGenerator,
	AssemblyTitleAttribute_t92945912_CustomAttributesCacheGenerator,
	AssemblyTrademarkAttribute_t3740556705_CustomAttributesCacheGenerator,
	Binder_t3404612058_CustomAttributesCacheGenerator,
	Default_t3956931304_CustomAttributesCacheGenerator_Default_ReorderArgumentArray_m3980835731,
	BindingFlags_t1082350898_CustomAttributesCacheGenerator,
	CallingConventions_t1097349142_CustomAttributesCacheGenerator,
	ConstructorInfo_t2851816542_CustomAttributesCacheGenerator,
	ConstructorInfo_t2851816542_CustomAttributesCacheGenerator_ConstructorName,
	ConstructorInfo_t2851816542_CustomAttributesCacheGenerator_TypeConstructorName,
	ConstructorInfo_t2851816542_CustomAttributesCacheGenerator_ConstructorInfo_Invoke_m2144827141,
	ConstructorInfo_t2851816542_CustomAttributesCacheGenerator_ConstructorInfo_t2851816542____MemberType_PropertyInfo,
	CustomAttributeData_t3093286891_CustomAttributesCacheGenerator,
	CustomAttributeData_t3093286891_CustomAttributesCacheGenerator_CustomAttributeData_t3093286891____Constructor_PropertyInfo,
	CustomAttributeData_t3093286891_CustomAttributesCacheGenerator_CustomAttributeData_t3093286891____ConstructorArguments_PropertyInfo,
	CustomAttributeNamedArgument_t94157543_CustomAttributesCacheGenerator,
	CustomAttributeTypedArgument_t1498197914_CustomAttributesCacheGenerator,
	EventAttributes_t2989788983_CustomAttributesCacheGenerator,
	EventInfo_t_CustomAttributesCacheGenerator,
	FieldAttributes_t1122705193_CustomAttributesCacheGenerator,
	FieldInfo_t_CustomAttributesCacheGenerator,
	FieldInfo_t_CustomAttributesCacheGenerator_FieldInfo_SetValue_m2504255891,
	MemberTypes_t3343038963_CustomAttributesCacheGenerator,
	MethodAttributes_t790385034_CustomAttributesCacheGenerator,
	MethodBase_t904190842_CustomAttributesCacheGenerator,
	MethodBase_t904190842_CustomAttributesCacheGenerator_MethodBase_Invoke_m1075809207,
	MethodBase_t904190842_CustomAttributesCacheGenerator_MethodBase_GetGenericArguments_m1277035033,
	MethodImplAttributes_t1541361196_CustomAttributesCacheGenerator,
	MethodInfo_t_CustomAttributesCacheGenerator,
	MethodInfo_t_CustomAttributesCacheGenerator_MethodInfo_MakeGenericMethod_m3327556920____typeArguments0,
	MethodInfo_t_CustomAttributesCacheGenerator_MethodInfo_GetGenericArguments_m3393347888,
	Missing_t1033855606_CustomAttributesCacheGenerator,
	Missing_t1033855606_CustomAttributesCacheGenerator_Missing_System_Runtime_Serialization_ISerializable_GetObjectData_m3092937593,
	Module_t4282841206_CustomAttributesCacheGenerator,
	PInfo_t957350482_CustomAttributesCacheGenerator,
	ParameterAttributes_t1266705348_CustomAttributesCacheGenerator,
	ParameterInfo_t2249040075_CustomAttributesCacheGenerator,
	ParameterModifier_t1820634920_CustomAttributesCacheGenerator,
	Pointer_t937075087_CustomAttributesCacheGenerator,
	ProcessorArchitecture_t1620065459_CustomAttributesCacheGenerator,
	PropertyAttributes_t883448530_CustomAttributesCacheGenerator,
	PropertyInfo_t_CustomAttributesCacheGenerator,
	PropertyInfo_t_CustomAttributesCacheGenerator_PropertyInfo_GetValue_m3655964945,
	PropertyInfo_t_CustomAttributesCacheGenerator_PropertyInfo_SetValue_m2961483868,
	StrongNameKeyPair_t4090869089_CustomAttributesCacheGenerator,
	TargetException_t1572104820_CustomAttributesCacheGenerator,
	TargetInvocationException_t4098620458_CustomAttributesCacheGenerator,
	TargetParameterCountException_t1554451430_CustomAttributesCacheGenerator,
	TypeAttributes_t2229518203_CustomAttributesCacheGenerator,
	IResourceReader_t3222588482_CustomAttributesCacheGenerator,
	NeutralResourcesLanguageAttribute_t3267676636_CustomAttributesCacheGenerator,
	ResourceManager_t264715885_CustomAttributesCacheGenerator,
	ResourceReader_t2463923611_CustomAttributesCacheGenerator,
	ResourceSet_t1348327650_CustomAttributesCacheGenerator,
	ResourceSet_t1348327650_CustomAttributesCacheGenerator_ResourceSet_GetEnumerator_m1363893992,
	SatelliteContractVersionAttribute_t2989984391_CustomAttributesCacheGenerator,
	CompilationRelaxations_t4211964247_CustomAttributesCacheGenerator,
	CompilationRelaxationsAttribute_t238494011_CustomAttributesCacheGenerator,
	DefaultDependencyAttribute_t3858269114_CustomAttributesCacheGenerator,
	IsVolatile_t700755342_CustomAttributesCacheGenerator,
	StringFreezingAttribute_t2691375565_CustomAttributesCacheGenerator,
	CriticalFinalizerObject_t1920899984_CustomAttributesCacheGenerator,
	CriticalFinalizerObject_t1920899984_CustomAttributesCacheGenerator_CriticalFinalizerObject__ctor_m229488711,
	CriticalFinalizerObject_t1920899984_CustomAttributesCacheGenerator_CriticalFinalizerObject_Finalize_m2361345429,
	ReliabilityContractAttribute_t1625655220_CustomAttributesCacheGenerator,
	ActivationArguments_t640021366_CustomAttributesCacheGenerator,
	COMException_t1790481504_CustomAttributesCacheGenerator,
	CallingConvention_t3354538265_CustomAttributesCacheGenerator,
	CharSet_t2778376310_CustomAttributesCacheGenerator,
	ClassInterfaceAttribute_t910653559_CustomAttributesCacheGenerator,
	ClassInterfaceType_t295178211_CustomAttributesCacheGenerator,
	ComDefaultInterfaceAttribute_t347642415_CustomAttributesCacheGenerator,
	ComInterfaceType_t1898221498_CustomAttributesCacheGenerator,
	DispIdAttribute_t607560947_CustomAttributesCacheGenerator,
	ErrorWrapper_t2775489663_CustomAttributesCacheGenerator,
	ExternalException_t1252662682_CustomAttributesCacheGenerator,
	GCHandle_t3409268066_CustomAttributesCacheGenerator,
	GCHandleType_t1970708122_CustomAttributesCacheGenerator,
	InterfaceTypeAttribute_t4113096249_CustomAttributesCacheGenerator,
	Marshal_t785896760_CustomAttributesCacheGenerator,
	Marshal_t785896760_CustomAttributesCacheGenerator_Marshal_GetLastWin32Error_m4162683157,
	MarshalDirectiveException_t1326890414_CustomAttributesCacheGenerator,
	PreserveSigAttribute_t1564965109_CustomAttributesCacheGenerator,
	SafeHandle_t2733794115_CustomAttributesCacheGenerator_SafeHandle__ctor_m1890452380,
	SafeHandle_t2733794115_CustomAttributesCacheGenerator_SafeHandle_Close_m1146946803,
	SafeHandle_t2733794115_CustomAttributesCacheGenerator_SafeHandle_DangerousAddRef_m3138941540,
	SafeHandle_t2733794115_CustomAttributesCacheGenerator_SafeHandle_DangerousGetHandle_m1328172664,
	SafeHandle_t2733794115_CustomAttributesCacheGenerator_SafeHandle_DangerousRelease_m2167699172,
	SafeHandle_t2733794115_CustomAttributesCacheGenerator_SafeHandle_Dispose_m1233016688,
	SafeHandle_t2733794115_CustomAttributesCacheGenerator_SafeHandle_Dispose_m3871883741,
	SafeHandle_t2733794115_CustomAttributesCacheGenerator_SafeHandle_ReleaseHandle_m1505220038,
	SafeHandle_t2733794115_CustomAttributesCacheGenerator_SafeHandle_SetHandle_m1980208835,
	SafeHandle_t2733794115_CustomAttributesCacheGenerator_SafeHandle_get_IsInvalid_m3910183075,
	TypeLibImportClassAttribute_t2390314680_CustomAttributesCacheGenerator,
	TypeLibVersionAttribute_t3346496961_CustomAttributesCacheGenerator,
	UnmanagedType_t2550630890_CustomAttributesCacheGenerator,
	_Activator_t3825585294_CustomAttributesCacheGenerator,
	_Assembly_t2937922309_CustomAttributesCacheGenerator,
	_AssemblyBuilder_t418776366_CustomAttributesCacheGenerator,
	_AssemblyName_t582342236_CustomAttributesCacheGenerator,
	_ConstructorBuilder_t1236878896_CustomAttributesCacheGenerator,
	_ConstructorInfo_t3269099341_CustomAttributesCacheGenerator,
	_EnumBuilder_t1044146361_CustomAttributesCacheGenerator,
	_EventInfo_t2430923913_CustomAttributesCacheGenerator,
	_FieldBuilder_t1895266044_CustomAttributesCacheGenerator,
	_FieldInfo_t2511231167_CustomAttributesCacheGenerator,
	_ILGenerator_t4199470953_CustomAttributesCacheGenerator,
	_MethodBase_t1935530873_CustomAttributesCacheGenerator,
	_MethodBuilder_t3932949077_CustomAttributesCacheGenerator,
	_MethodInfo_t3642518830_CustomAttributesCacheGenerator,
	_Module_t2144668161_CustomAttributesCacheGenerator,
	_ModuleBuilder_t1075102050_CustomAttributesCacheGenerator,
	_ParameterBuilder_t2251638747_CustomAttributesCacheGenerator,
	_ParameterInfo_t470209990_CustomAttributesCacheGenerator,
	_PropertyInfo_t1567586598_CustomAttributesCacheGenerator,
	_Thread_t1894135853_CustomAttributesCacheGenerator,
	_TypeBuilder_t2783404358_CustomAttributesCacheGenerator,
	IActivator_t1538980900_CustomAttributesCacheGenerator,
	IConstructionCallMessage_t2459197515_CustomAttributesCacheGenerator,
	UrlAttribute_t1544437301_CustomAttributesCacheGenerator,
	UrlAttribute_t1544437301_CustomAttributesCacheGenerator_UrlAttribute_GetPropertiesForNewContext_m1831666581,
	UrlAttribute_t1544437301_CustomAttributesCacheGenerator_UrlAttribute_IsContextOK_m3121915198,
	ChannelServices_t2007814595_CustomAttributesCacheGenerator,
	ChannelServices_t2007814595_CustomAttributesCacheGenerator_ChannelServices_RegisterChannel_m3832858065,
	CrossAppDomainSink_t2368859578_CustomAttributesCacheGenerator,
	IChannel_t321318132_CustomAttributesCacheGenerator,
	IChannelDataStore_t1307999835_CustomAttributesCacheGenerator,
	IChannelReceiver_t2788889625_CustomAttributesCacheGenerator,
	IChannelSender_t714647579_CustomAttributesCacheGenerator,
	IClientChannelSinkProvider_t2522474175_CustomAttributesCacheGenerator,
	IServerChannelSinkProvider_t2060956099_CustomAttributesCacheGenerator,
	SinkProviderData_t2645445792_CustomAttributesCacheGenerator,
	Context_t502196753_CustomAttributesCacheGenerator,
	ContextAttribute_t197102333_CustomAttributesCacheGenerator,
	IContextAttribute_t2439121372_CustomAttributesCacheGenerator,
	IContextProperty_t287246399_CustomAttributesCacheGenerator,
	IContributeClientContextSink_t3409105893_CustomAttributesCacheGenerator,
	IContributeDynamicSink_t486956128_CustomAttributesCacheGenerator,
	IContributeEnvoySink_t4106549430_CustomAttributesCacheGenerator,
	IContributeObjectSink_t2326363786_CustomAttributesCacheGenerator,
	IContributeServerContextSink_t1849145353_CustomAttributesCacheGenerator,
	IDynamicMessageSink_t3056162262_CustomAttributesCacheGenerator,
	IDynamicProperty_t603529997_CustomAttributesCacheGenerator,
	SynchronizationAttribute_t3073724998_CustomAttributesCacheGenerator,
	SynchronizationAttribute_t3073724998_CustomAttributesCacheGenerator_SynchronizationAttribute_GetPropertiesForNewContext_m2175864602,
	SynchronizationAttribute_t3073724998_CustomAttributesCacheGenerator_SynchronizationAttribute_IsContextOK_m525966365,
	LifetimeServices_t2939669377_CustomAttributesCacheGenerator,
	AsyncResult_t2232356043_CustomAttributesCacheGenerator,
	ConstructionCall_t1254994451_CustomAttributesCacheGenerator,
	ConstructionCall_t1254994451_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map20,
	ConstructionCallDictionary_t2993650247_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map23,
	ConstructionCallDictionary_t2993650247_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map24,
	Header_t2756440555_CustomAttributesCacheGenerator,
	IMessage_t3044378324_CustomAttributesCacheGenerator,
	IMessageCtrl_t2081697019_CustomAttributesCacheGenerator,
	IMessageSink_t2189618969_CustomAttributesCacheGenerator,
	IMethodCallMessage_t645865707_CustomAttributesCacheGenerator,
	IMethodMessage_t1899389025_CustomAttributesCacheGenerator,
	IMethodReturnMessage_t323645523_CustomAttributesCacheGenerator,
	IRemotingFormatter_t4112065742_CustomAttributesCacheGenerator,
	LogicalCallContext_t725724420_CustomAttributesCacheGenerator,
	MethodCall_t2461541281_CustomAttributesCacheGenerator,
	MethodCall_t2461541281_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map1F,
	MethodDictionary_t1742974787_CustomAttributesCacheGenerator,
	MethodDictionary_t1742974787_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map21,
	MethodDictionary_t1742974787_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map22,
	RemotingSurrogateSelector_t2821375126_CustomAttributesCacheGenerator,
	ReturnMessage_t3411975905_CustomAttributesCacheGenerator,
	SoapAttribute_t1982224933_CustomAttributesCacheGenerator,
	SoapFieldAttribute_t3073759685_CustomAttributesCacheGenerator,
	SoapMethodAttribute_t2381910676_CustomAttributesCacheGenerator,
	SoapParameterAttribute_t2780084514_CustomAttributesCacheGenerator,
	SoapTypeAttribute_t3444503085_CustomAttributesCacheGenerator,
	ProxyAttribute_t4031752430_CustomAttributesCacheGenerator,
	ProxyAttribute_t4031752430_CustomAttributesCacheGenerator_ProxyAttribute_GetPropertiesForNewContext_m3587421540,
	ProxyAttribute_t4031752430_CustomAttributesCacheGenerator_ProxyAttribute_IsContextOK_m2391079277,
	RealProxy_t298428346_CustomAttributesCacheGenerator,
	ITrackingHandler_t2759960940_CustomAttributesCacheGenerator,
	TrackingServices_t3722365321_CustomAttributesCacheGenerator,
	ActivatedClientTypeEntry_t4060499430_CustomAttributesCacheGenerator,
	ActivatedServiceTypeEntry_t3934090848_CustomAttributesCacheGenerator,
	IChannelInfo_t185176048_CustomAttributesCacheGenerator,
	IEnvoyInfo_t503256512_CustomAttributesCacheGenerator,
	IRemotingTypeInfo_t1105948144_CustomAttributesCacheGenerator,
	InternalRemotingServices_t3953136710_CustomAttributesCacheGenerator,
	ObjRef_t318414488_CustomAttributesCacheGenerator,
	ObjRef_t318414488_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map26,
	ObjRef_t318414488_CustomAttributesCacheGenerator_ObjRef_get_ChannelInfo_m53840305,
	RemotingConfiguration_t438177651_CustomAttributesCacheGenerator,
	ConfigHandler_t2180714860_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map27,
	ConfigHandler_t2180714860_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map28,
	ConfigHandler_t2180714860_CustomAttributesCacheGenerator_ConfigHandler_ValidatePath_m3188987489____paths1,
	RemotingException_t109604560_CustomAttributesCacheGenerator,
	RemotingServices_t2399536837_CustomAttributesCacheGenerator,
	RemotingServices_t2399536837_CustomAttributesCacheGenerator_RemotingServices_IsTransparentProxy_m162250343,
	RemotingServices_t2399536837_CustomAttributesCacheGenerator_RemotingServices_GetRealProxy_m620317996,
	SoapServices_t3397513225_CustomAttributesCacheGenerator,
	TypeEntry_t3321373506_CustomAttributesCacheGenerator,
	WellKnownClientTypeEntry_t3314744170_CustomAttributesCacheGenerator,
	WellKnownObjectMode_t2630225581_CustomAttributesCacheGenerator,
	WellKnownServiceTypeEntry_t1712728956_CustomAttributesCacheGenerator,
	BinaryFormatter_t1866979105_CustomAttributesCacheGenerator,
	BinaryFormatter_t1866979105_CustomAttributesCacheGenerator_U3CDefaultSurrogateSelectorU3Ek__BackingField,
	BinaryFormatter_t1866979105_CustomAttributesCacheGenerator_BinaryFormatter_get_DefaultSurrogateSelector_m219714691,
	FormatterAssemblyStyle_t999493661_CustomAttributesCacheGenerator,
	FormatterTypeStyle_t943306207_CustomAttributesCacheGenerator,
	TypeFilterLevel_t1182459634_CustomAttributesCacheGenerator,
	FormatterConverter_t764140214_CustomAttributesCacheGenerator,
	FormatterServices_t3161112612_CustomAttributesCacheGenerator,
	IDeserializationCallback_t327125377_CustomAttributesCacheGenerator,
	IFormatter_t936711909_CustomAttributesCacheGenerator,
	IFormatterConverter_t1473156697_CustomAttributesCacheGenerator,
	IObjectReference_t2936130011_CustomAttributesCacheGenerator,
	ISerializationSurrogate_t1282780357_CustomAttributesCacheGenerator,
	ISurrogateSelector_t1912587528_CustomAttributesCacheGenerator,
	ObjectManager_t2645893724_CustomAttributesCacheGenerator,
	OnDeserializedAttribute_t3172265744_CustomAttributesCacheGenerator,
	OnDeserializingAttribute_t484921187_CustomAttributesCacheGenerator,
	OnSerializedAttribute_t3742956097_CustomAttributesCacheGenerator,
	OnSerializingAttribute_t2011372116_CustomAttributesCacheGenerator,
	SerializationBinder_t3985864818_CustomAttributesCacheGenerator,
	SerializationEntry_t3485203212_CustomAttributesCacheGenerator,
	SerializationException_t753258759_CustomAttributesCacheGenerator,
	SerializationInfo_t228987430_CustomAttributesCacheGenerator,
	SerializationInfo_t228987430_CustomAttributesCacheGenerator_SerializationInfo__ctor_m4016423422,
	SerializationInfo_t228987430_CustomAttributesCacheGenerator_SerializationInfo_AddValue_m4254971664,
	SerializationInfoEnumerator_t589103770_CustomAttributesCacheGenerator,
	StreamingContext_t1417235061_CustomAttributesCacheGenerator,
	StreamingContextStates_t4264247603_CustomAttributesCacheGenerator,
	X509Certificate_t283079845_CustomAttributesCacheGenerator,
	X509Certificate_t283079845_CustomAttributesCacheGenerator_X509Certificate_GetIssuerName_m3607271213,
	X509Certificate_t283079845_CustomAttributesCacheGenerator_X509Certificate_GetName_m2354987368,
	X509Certificate_t283079845_CustomAttributesCacheGenerator_X509Certificate_Equals_m4141136939,
	X509Certificate_t283079845_CustomAttributesCacheGenerator_X509Certificate_Import_m562956152,
	X509Certificate_t283079845_CustomAttributesCacheGenerator_X509Certificate_Reset_m1676863543,
	X509KeyStorageFlags_t1216946873_CustomAttributesCacheGenerator,
	AsymmetricAlgorithm_t784058677_CustomAttributesCacheGenerator,
	AsymmetricKeyExchangeFormatter_t3339648384_CustomAttributesCacheGenerator,
	AsymmetricSignatureDeformatter_t3580832979_CustomAttributesCacheGenerator,
	AsymmetricSignatureFormatter_t4058014248_CustomAttributesCacheGenerator,
	CipherMode_t162592484_CustomAttributesCacheGenerator,
	CryptoConfig_t896479599_CustomAttributesCacheGenerator,
	CryptoConfig_t896479599_CustomAttributesCacheGenerator_CryptoConfig_CreateFromName_m2169102076____args1,
	CryptographicException_t3349726436_CustomAttributesCacheGenerator,
	CryptographicUnexpectedOperationException_t4184064416_CustomAttributesCacheGenerator,
	CspParameters_t46065560_CustomAttributesCacheGenerator,
	CspProviderFlags_t105264000_CustomAttributesCacheGenerator,
	DES_t1353513560_CustomAttributesCacheGenerator,
	DESCryptoServiceProvider_t933603253_CustomAttributesCacheGenerator,
	DSA_t903174880_CustomAttributesCacheGenerator,
	DSACryptoServiceProvider_t2915171657_CustomAttributesCacheGenerator,
	DSACryptoServiceProvider_t2915171657_CustomAttributesCacheGenerator_DSACryptoServiceProvider_t2915171657____PublicOnly_PropertyInfo,
	DSAParameters_t1872138834_CustomAttributesCacheGenerator,
	DSASignatureDeformatter_t2187578719_CustomAttributesCacheGenerator,
	DSASignatureFormatter_t1065727064_CustomAttributesCacheGenerator,
	HMAC_t130461695_CustomAttributesCacheGenerator,
	HMACMD5_t2214610803_CustomAttributesCacheGenerator,
	HMACRIPEMD160_t131410643_CustomAttributesCacheGenerator,
	HMACSHA1_t1958407246_CustomAttributesCacheGenerator,
	HMACSHA256_t2622794722_CustomAttributesCacheGenerator,
	HMACSHA384_t3026079344_CustomAttributesCacheGenerator,
	HMACSHA512_t653426285_CustomAttributesCacheGenerator,
	HashAlgorithm_t2624936259_CustomAttributesCacheGenerator,
	ICryptoTransform_t281704372_CustomAttributesCacheGenerator,
	ICspAsymmetricAlgorithm_t662762374_CustomAttributesCacheGenerator,
	KeyedHashAlgorithm_t1374150027_CustomAttributesCacheGenerator,
	MACTripleDES_t442445873_CustomAttributesCacheGenerator,
	MD5_t1507972490_CustomAttributesCacheGenerator,
	MD5CryptoServiceProvider_t4009738925_CustomAttributesCacheGenerator,
	PaddingMode_t3032142640_CustomAttributesCacheGenerator,
	RC2_t3410342145_CustomAttributesCacheGenerator,
	RC2CryptoServiceProvider_t663781682_CustomAttributesCacheGenerator,
	RIPEMD160_t1732039966_CustomAttributesCacheGenerator,
	RIPEMD160Managed_t1613307429_CustomAttributesCacheGenerator,
	RSA_t3719518354_CustomAttributesCacheGenerator,
	RSACryptoServiceProvider_t4229286967_CustomAttributesCacheGenerator,
	RSACryptoServiceProvider_t4229286967_CustomAttributesCacheGenerator_RSACryptoServiceProvider_t4229286967____PublicOnly_PropertyInfo,
	RSAPKCS1KeyExchangeFormatter_t4167037264_CustomAttributesCacheGenerator,
	RSAPKCS1SignatureDeformatter_t145198701_CustomAttributesCacheGenerator,
	RSAPKCS1SignatureFormatter_t925064184_CustomAttributesCacheGenerator,
	RSAParameters_t1462703416_CustomAttributesCacheGenerator,
	Rijndael_t2154803531_CustomAttributesCacheGenerator,
	RijndaelManaged_t1034060848_CustomAttributesCacheGenerator,
	RijndaelManagedTransform_t135163252_CustomAttributesCacheGenerator,
	SHA1_t3336793149_CustomAttributesCacheGenerator,
	SHA1CryptoServiceProvider_t3913997830_CustomAttributesCacheGenerator,
	SHA1Managed_t7268864_CustomAttributesCacheGenerator,
	SHA256_t582564463_CustomAttributesCacheGenerator,
	SHA256Managed_t2029745292_CustomAttributesCacheGenerator,
	SHA384_t535510267_CustomAttributesCacheGenerator,
	SHA384Managed_t741627254_CustomAttributesCacheGenerator,
	SHA512_t2908163326_CustomAttributesCacheGenerator,
	SHA512Managed_t3949709369_CustomAttributesCacheGenerator,
	SignatureDescription_t89145500_CustomAttributesCacheGenerator,
	SymmetricAlgorithm_t1108166522_CustomAttributesCacheGenerator,
	ToBase64Transform_t625739466_CustomAttributesCacheGenerator,
	TripleDES_t243950698_CustomAttributesCacheGenerator,
	TripleDESCryptoServiceProvider_t2380467305_CustomAttributesCacheGenerator,
	IUnrestrictedPermission_t3323397702_CustomAttributesCacheGenerator,
	SecurityPermission_t502442079_CustomAttributesCacheGenerator,
	SecurityPermissionFlag_t1642245049_CustomAttributesCacheGenerator,
	StrongNamePublicKeyBlob_t2860422703_CustomAttributesCacheGenerator,
	ApplicationTrust_t3968282840_CustomAttributesCacheGenerator,
	Evidence_t1407710183_CustomAttributesCacheGenerator,
	Evidence_t1407710183_CustomAttributesCacheGenerator_Evidence_Equals_m2325859915,
	Evidence_t1407710183_CustomAttributesCacheGenerator_Evidence_GetHashCode_m1260371757,
	Hash_t2681437964_CustomAttributesCacheGenerator,
	IIdentityPermissionFactory_t2988326850_CustomAttributesCacheGenerator,
	StrongName_t2988747270_CustomAttributesCacheGenerator,
	IIdentity_t2445095625_CustomAttributesCacheGenerator,
	IPrincipal_t783141777_CustomAttributesCacheGenerator,
	PrincipalPolicy_t289802916_CustomAttributesCacheGenerator,
	WindowsAccountType_t4179100204_CustomAttributesCacheGenerator,
	WindowsIdentity_t373339331_CustomAttributesCacheGenerator,
	WindowsIdentity_t373339331_CustomAttributesCacheGenerator_WindowsIdentity_Dispose_m2649088337,
	CodeAccessPermission_t3468021764_CustomAttributesCacheGenerator,
	CodeAccessPermission_t3468021764_CustomAttributesCacheGenerator_CodeAccessPermission_Equals_m1762790716,
	CodeAccessPermission_t3468021764_CustomAttributesCacheGenerator_CodeAccessPermission_GetHashCode_m3295132136,
	IPermission_t182075948_CustomAttributesCacheGenerator,
	ISecurityEncodable_t2815109328_CustomAttributesCacheGenerator,
	IStackWalk_t1717744784_CustomAttributesCacheGenerator,
	PermissionSet_t1941658161_CustomAttributesCacheGenerator_U3CDeclarativeSecurityU3Ek__BackingField,
	PermissionSet_t1941658161_CustomAttributesCacheGenerator_PermissionSet_set_DeclarativeSecurity_m3993468766,
	SecurityElement_t2325568386_CustomAttributesCacheGenerator,
	SecurityException_t887327375_CustomAttributesCacheGenerator,
	SecurityException_t887327375_CustomAttributesCacheGenerator_SecurityException_t887327375____Demanded_PropertyInfo,
	SecurityManager_t3191249573_CustomAttributesCacheGenerator,
	SecurityManager_t3191249573_CustomAttributesCacheGenerator_SecurityManager_t3191249573____SecurityEnabled_PropertyInfo,
	SecuritySafeCriticalAttribute_t372031554_CustomAttributesCacheGenerator,
	SuppressUnmanagedCodeSecurityAttribute_t39244474_CustomAttributesCacheGenerator,
	UnverifiableCodeAttribute_t765455733_CustomAttributesCacheGenerator,
	ASCIIEncoding_t3022927988_CustomAttributesCacheGenerator,
	ASCIIEncoding_t3022927988_CustomAttributesCacheGenerator_ASCIIEncoding_GetBytes_m3744562901,
	ASCIIEncoding_t3022927988_CustomAttributesCacheGenerator_ASCIIEncoding_GetByteCount_m1396020051,
	ASCIIEncoding_t3022927988_CustomAttributesCacheGenerator_ASCIIEncoding_GetDecoder_m3693600923,
	Decoder_t3792697818_CustomAttributesCacheGenerator,
	Decoder_t3792697818_CustomAttributesCacheGenerator_Decoder_t3792697818____Fallback_PropertyInfo,
	Decoder_t3792697818_CustomAttributesCacheGenerator_Decoder_t3792697818____FallbackBuffer_PropertyInfo,
	DecoderReplacementFallback_t3042394152_CustomAttributesCacheGenerator_DecoderReplacementFallback__ctor_m2344783488,
	EncoderReplacementFallback_t4228544112_CustomAttributesCacheGenerator_EncoderReplacementFallback__ctor_m517300448,
	Encoding_t663144255_CustomAttributesCacheGenerator,
	Encoding_t663144255_CustomAttributesCacheGenerator_Encoding_InvokeI18N_m4199316552____args1,
	Encoding_t663144255_CustomAttributesCacheGenerator_Encoding_Clone_m2663608141,
	Encoding_t663144255_CustomAttributesCacheGenerator_Encoding_GetByteCount_m4104502544,
	Encoding_t663144255_CustomAttributesCacheGenerator_Encoding_GetBytes_m3820493744,
	Encoding_t663144255_CustomAttributesCacheGenerator_Encoding_t663144255____IsReadOnly_PropertyInfo,
	Encoding_t663144255_CustomAttributesCacheGenerator_Encoding_t663144255____DecoderFallback_PropertyInfo,
	Encoding_t663144255_CustomAttributesCacheGenerator_Encoding_t663144255____EncoderFallback_PropertyInfo,
	StringBuilder_t1221177846_CustomAttributesCacheGenerator,
	StringBuilder_t1221177846_CustomAttributesCacheGenerator_StringBuilder_AppendLine_m1686706871,
	StringBuilder_t1221177846_CustomAttributesCacheGenerator_StringBuilder_AppendLine_m2033101329,
	StringBuilder_t1221177846_CustomAttributesCacheGenerator_StringBuilder_AppendFormat_m1879616656____args1,
	StringBuilder_t1221177846_CustomAttributesCacheGenerator_StringBuilder_AppendFormat_m3178887408____args2,
	UTF32Encoding_t549530865_CustomAttributesCacheGenerator_UTF32Encoding_GetByteCount_m3183615393,
	UTF32Encoding_t549530865_CustomAttributesCacheGenerator_UTF32Encoding_GetBytes_m2290150495,
	UTF32Encoding_t549530865_CustomAttributesCacheGenerator_UTF32Encoding_GetByteCount_m77034086,
	UTF32Encoding_t549530865_CustomAttributesCacheGenerator_UTF32Encoding_GetBytes_m2093416998,
	UTF7Encoding_t741406939_CustomAttributesCacheGenerator,
	UTF7Encoding_t741406939_CustomAttributesCacheGenerator_UTF7Encoding_GetHashCode_m359766848,
	UTF7Encoding_t741406939_CustomAttributesCacheGenerator_UTF7Encoding_Equals_m3706778156,
	UTF7Encoding_t741406939_CustomAttributesCacheGenerator_UTF7Encoding_GetByteCount_m273209154,
	UTF7Encoding_t741406939_CustomAttributesCacheGenerator_UTF7Encoding_GetByteCount_m1588484494,
	UTF7Encoding_t741406939_CustomAttributesCacheGenerator_UTF7Encoding_GetBytes_m3015176946,
	UTF7Encoding_t741406939_CustomAttributesCacheGenerator_UTF7Encoding_GetBytes_m3033375614,
	UTF7Encoding_t741406939_CustomAttributesCacheGenerator_UTF7Encoding_GetString_m4263430344,
	UTF8Encoding_t111055448_CustomAttributesCacheGenerator,
	UTF8Encoding_t111055448_CustomAttributesCacheGenerator_UTF8Encoding_GetByteCount_m2547312609,
	UTF8Encoding_t111055448_CustomAttributesCacheGenerator_UTF8Encoding_GetBytes_m2973831055,
	UTF8Encoding_t111055448_CustomAttributesCacheGenerator_UTF8Encoding_GetString_m1836344205,
	UnicodeEncoding_t4081757012_CustomAttributesCacheGenerator,
	UnicodeEncoding_t4081757012_CustomAttributesCacheGenerator_UnicodeEncoding_GetByteCount_m662995793,
	UnicodeEncoding_t4081757012_CustomAttributesCacheGenerator_UnicodeEncoding_GetBytes_m1575298215,
	UnicodeEncoding_t4081757012_CustomAttributesCacheGenerator_UnicodeEncoding_GetString_m542738941,
	CompressedStack_t1568001503_CustomAttributesCacheGenerator_CompressedStack_CreateCopy_m3321727874,
	CompressedStack_t1568001503_CustomAttributesCacheGenerator_CompressedStack_GetObjectData_m2387204186,
	EventResetMode_t4116945436_CustomAttributesCacheGenerator,
	EventWaitHandle_t2091316307_CustomAttributesCacheGenerator,
	ExecutionContext_t1392266323_CustomAttributesCacheGenerator_ExecutionContext__ctor_m573218565,
	ExecutionContext_t1392266323_CustomAttributesCacheGenerator_ExecutionContext_GetObjectData_m1456913356,
	Interlocked_t1625106012_CustomAttributesCacheGenerator_Interlocked_CompareExchange_m3339239614,
	Interlocked_t1625106012_CustomAttributesCacheGenerator_Interlocked_CompareExchange_m3263020936,
	ManualResetEvent_t926074657_CustomAttributesCacheGenerator,
	Monitor_t3228523394_CustomAttributesCacheGenerator,
	Monitor_t3228523394_CustomAttributesCacheGenerator_Monitor_Exit_m2677760297,
	Mutex_t297030111_CustomAttributesCacheGenerator,
	Mutex_t297030111_CustomAttributesCacheGenerator_Mutex__ctor_m2649008317,
	Mutex_t297030111_CustomAttributesCacheGenerator_Mutex_ReleaseMutex_m2143813124,
	SynchronizationLockException_t117698316_CustomAttributesCacheGenerator,
	Thread_t241561612_CustomAttributesCacheGenerator,
	Thread_t241561612_CustomAttributesCacheGenerator_local_slots,
	Thread_t241561612_CustomAttributesCacheGenerator__ec,
	Thread_t241561612_CustomAttributesCacheGenerator_Thread_get_CurrentThread_m3667342817,
	Thread_t241561612_CustomAttributesCacheGenerator_Thread_Finalize_m3231208127,
	Thread_t241561612_CustomAttributesCacheGenerator_Thread_get_ExecutionContext_m922067206,
	Thread_t241561612_CustomAttributesCacheGenerator_Thread_get_ManagedThreadId_m1995754972,
	Thread_t241561612_CustomAttributesCacheGenerator_Thread_GetHashCode_m2038641494,
	Thread_t241561612_CustomAttributesCacheGenerator_Thread_GetCompressedStack_m1220107123,
	Thread_t241561612_CustomAttributesCacheGenerator_Thread_t241561612____ExecutionContext_PropertyInfo,
	ThreadAbortException_t1150575753_CustomAttributesCacheGenerator,
	ThreadInterruptedException_t63303933_CustomAttributesCacheGenerator,
	ThreadState_t1158972609_CustomAttributesCacheGenerator,
	ThreadStateException_t1404755912_CustomAttributesCacheGenerator,
	Timer_t791717973_CustomAttributesCacheGenerator,
	WaitHandle_t677569169_CustomAttributesCacheGenerator,
	WaitHandle_t677569169_CustomAttributesCacheGenerator_WaitHandle_t677569169____Handle_PropertyInfo,
	AccessViolationException_t182079320_CustomAttributesCacheGenerator,
	ActivationContext_t1572332809_CustomAttributesCacheGenerator,
	ActivationContext_t1572332809_CustomAttributesCacheGenerator_ActivationContext_System_Runtime_Serialization_ISerializable_GetObjectData_m775951299,
	Activator_t1850728717_CustomAttributesCacheGenerator,
	Activator_t1850728717_CustomAttributesCacheGenerator_Activator_CreateInstance_m1465989661____args1,
	AppDomain_t2719102437_CustomAttributesCacheGenerator,
	AppDomain_t2719102437_CustomAttributesCacheGenerator_type_resolve_in_progress,
	AppDomain_t2719102437_CustomAttributesCacheGenerator_assembly_resolve_in_progress,
	AppDomain_t2719102437_CustomAttributesCacheGenerator_assembly_resolve_in_progress_refonly,
	AppDomain_t2719102437_CustomAttributesCacheGenerator__principal,
	AppDomainManager_t54965696_CustomAttributesCacheGenerator,
	AppDomainSetup_t611332832_CustomAttributesCacheGenerator,
	ApplicationException_t474868623_CustomAttributesCacheGenerator,
	ApplicationIdentity_t3292367950_CustomAttributesCacheGenerator,
	ApplicationIdentity_t3292367950_CustomAttributesCacheGenerator_ApplicationIdentity_System_Runtime_Serialization_ISerializable_GetObjectData_m77567264,
	ArgumentException_t3259014390_CustomAttributesCacheGenerator,
	ArgumentNullException_t628810857_CustomAttributesCacheGenerator,
	ArgumentOutOfRangeException_t279959794_CustomAttributesCacheGenerator,
	ArithmeticException_t3261462543_CustomAttributesCacheGenerator,
	ArrayTypeMismatchException_t2071164632_CustomAttributesCacheGenerator,
	AssemblyLoadEventArgs_t4233815743_CustomAttributesCacheGenerator,
	AttributeTargets_t1984597432_CustomAttributesCacheGenerator,
	Buffer_t3497320070_CustomAttributesCacheGenerator,
	CharEnumerator_t1926099410_CustomAttributesCacheGenerator,
	ContextBoundObject_t4264702438_CustomAttributesCacheGenerator,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToBoolean_m3882815225,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToBoolean_m2188088811,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToBoolean_m3169319766,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToBoolean_m2470413809,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToByte_m2303223565,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToByte_m509311047,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToByte_m932798552,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToByte_m791636053,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToChar_m541258017,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToChar_m528169935,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToChar_m951657444,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToChar_m245844937,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToDateTime_m1020507389,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToDateTime_m3528521877,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToDateTime_m3810846875,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToDateTime_m1626410554,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToDecimal_m2736745817,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToDecimal_m777781771,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToDecimal_m354294262,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToDecimal_m1060106769,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToDouble_m2226915533,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToDouble_m4236754739,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToDouble_m923018402,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToDouble_m3954429733,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToInt16_m960783641,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToInt16_m1536565067,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToInt16_m1113077558,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToInt16_m1818890065,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToInt32_m2209788057,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToInt32_m1523194571,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToInt32_m1099707062,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToInt32_m1805519569,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToInt64_m1009422297,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToInt64_m4057339019,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToInt64_m3633851510,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToInt64_m44696721,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToSByte_m615207682,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToSByte_m2470292806,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToSByte_m2665932200,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToSByte_m3295168715,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToSByte_m3768984293,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToSByte_m1183867428,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToSByte_m3208712702,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToSByte_m2045913061,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToSByte_m883113940,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToSByte_m1570938941,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToSByte_m2303634571,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToSByte_m1880147062,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToSByte_m2585959569,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToSByte_m1972336057,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToSingle_m3186653037,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToSingle_m2156102599,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToSingle_m2579590104,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToSingle_m2438427605,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt16_m1043031438,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt16_m3860123086,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt16_m36213644,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt16_m588378195,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt16_m3265369225,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt16_m3866680988,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt16_m1665900934,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt16_m2828700513,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt16_m3982177821,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt16_m3991499696,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt16_m1058302913,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt16_m2130758075,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt16_m4241289050,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt16_m590399293,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt32_m3686071170,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt32_m3492113030,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt32_m797503336,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt32_m610956619,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt32_m1336475941,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt32_m3394039268,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt32_m3085255294,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt32_m1922455781,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt32_m671585177,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt32_m759656532,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt32_m776714429,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt32_m4090244982,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt32_m3391339025,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt32_m817681977,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt64_m1479404080,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt64_m1568624612,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt64_m1319798722,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt64_m3944965503,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt64_m3559662221,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt64_m2215781574,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt64_m1691869628,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt64_m2498438645,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt64_m2643825617,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt64_m3661238030,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt64_m3596570605,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt64_m1109896503,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt64_m827571497,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt64_m1896191125,
	Convert_t2607082565_CustomAttributesCacheGenerator_Convert_ToUInt64_m345450801,
	DBNull_t972229383_CustomAttributesCacheGenerator,
	DateTimeKind_t2186819611_CustomAttributesCacheGenerator,
	DateTimeOffset_t1362988906_CustomAttributesCacheGenerator_DateTimeOffset_System_Runtime_Serialization_IDeserializationCallback_OnDeserialization_m1059347059,
	DayOfWeek_t721777893_CustomAttributesCacheGenerator,
	DivideByZeroException_t1660837001_CustomAttributesCacheGenerator,
	DllNotFoundException_t3636280042_CustomAttributesCacheGenerator,
	EntryPointNotFoundException_t3956266210_CustomAttributesCacheGenerator,
	MonoEnumInfo_t2335995564_CustomAttributesCacheGenerator_cache,
	Environment_t3662374671_CustomAttributesCacheGenerator,
	SpecialFolder_t1519540278_CustomAttributesCacheGenerator,
	EventArgs_t3289624707_CustomAttributesCacheGenerator,
	ExecutionEngineException_t1360775125_CustomAttributesCacheGenerator,
	FieldAccessException_t1797813379_CustomAttributesCacheGenerator,
	FlagsAttribute_t859561169_CustomAttributesCacheGenerator,
	FormatException_t2948921286_CustomAttributesCacheGenerator,
	GC_t2902933594_CustomAttributesCacheGenerator_GC_SuppressFinalize_m953228702,
	Guid_t2533601593_CustomAttributesCacheGenerator,
	ICustomFormatter_t2344731076_CustomAttributesCacheGenerator,
	IFormatProvider_t2849799027_CustomAttributesCacheGenerator,
	IndexOutOfRangeException_t3527622107_CustomAttributesCacheGenerator,
	InvalidCastException_t3625212209_CustomAttributesCacheGenerator,
	InvalidOperationException_t721527559_CustomAttributesCacheGenerator,
	LoaderOptimization_t1143026982_CustomAttributesCacheGenerator,
	LoaderOptimization_t1143026982_CustomAttributesCacheGenerator_DomainMask,
	LoaderOptimization_t1143026982_CustomAttributesCacheGenerator_DisallowBindings,
	LocalDataStoreSlot_t486331200_CustomAttributesCacheGenerator,
	Math_t2022911894_CustomAttributesCacheGenerator_Math_Max_m2671311541,
	Math_t2022911894_CustomAttributesCacheGenerator_Math_Min_m4290821911,
	Math_t2022911894_CustomAttributesCacheGenerator_Math_Sqrt_m932242488,
	MemberAccessException_t2005094827_CustomAttributesCacheGenerator,
	MethodAccessException_t4093255254_CustomAttributesCacheGenerator,
	MissingFieldException_t3702079619_CustomAttributesCacheGenerator,
	MissingMemberException_t1839900847_CustomAttributesCacheGenerator,
	MissingMethodException_t3441205986_CustomAttributesCacheGenerator,
	MulticastNotSupportedException_t1815247018_CustomAttributesCacheGenerator,
	NonSerializedAttribute_t399263003_CustomAttributesCacheGenerator,
	NotImplementedException_t2785117854_CustomAttributesCacheGenerator,
	NotSupportedException_t1793819818_CustomAttributesCacheGenerator,
	NullReferenceException_t3156209119_CustomAttributesCacheGenerator,
	NumberFormatter_t2933946347_CustomAttributesCacheGenerator_threadNumberFormatter,
	ObjectDisposedException_t2695136451_CustomAttributesCacheGenerator,
	OperatingSystem_t290860502_CustomAttributesCacheGenerator,
	OutOfMemoryException_t1181064283_CustomAttributesCacheGenerator,
	OverflowException_t1075868493_CustomAttributesCacheGenerator,
	PlatformID_t1006634368_CustomAttributesCacheGenerator,
	PlatformNotSupportedException_t3778770305_CustomAttributesCacheGenerator,
	RankException_t1539875949_CustomAttributesCacheGenerator,
	ResolveEventArgs_t1859808873_CustomAttributesCacheGenerator,
	RuntimeMethodHandle_t894824333_CustomAttributesCacheGenerator,
	RuntimeMethodHandle_t894824333_CustomAttributesCacheGenerator_RuntimeMethodHandle_Equals_m813356023,
	StringComparer_t1574862926_CustomAttributesCacheGenerator,
	StringComparison_t2376310518_CustomAttributesCacheGenerator,
	StringSplitOptions_t2996162939_CustomAttributesCacheGenerator,
	SystemException_t3877406272_CustomAttributesCacheGenerator,
	ThreadStaticAttribute_t1787731584_CustomAttributesCacheGenerator,
	TimeSpan_t3430258949_CustomAttributesCacheGenerator,
	TimeZone_t4008205267_CustomAttributesCacheGenerator,
	TypeCode_t2536926201_CustomAttributesCacheGenerator,
	TypeInitializationException_t3654642183_CustomAttributesCacheGenerator,
	TypeLoadException_t723359155_CustomAttributesCacheGenerator,
	UnauthorizedAccessException_t886535555_CustomAttributesCacheGenerator,
	UnhandledExceptionEventArgs_t3067050131_CustomAttributesCacheGenerator,
	UnhandledExceptionEventArgs_t3067050131_CustomAttributesCacheGenerator_UnhandledExceptionEventArgs_get_ExceptionObject_m2339769046,
	UnhandledExceptionEventArgs_t3067050131_CustomAttributesCacheGenerator_UnhandledExceptionEventArgs_get_IsTerminating_m2266550949,
	Version_t1755874712_CustomAttributesCacheGenerator,
	WeakReference_t1077405567_CustomAttributesCacheGenerator,
	MemberFilter_t3405857066_CustomAttributesCacheGenerator,
	TypeFilter_t2905709404_CustomAttributesCacheGenerator,
	CrossContextDelegate_t754146990_CustomAttributesCacheGenerator,
	HeaderHandler_t324204131_CustomAttributesCacheGenerator,
	ThreadStart_t3437517264_CustomAttributesCacheGenerator,
	TimerCallback_t1684927372_CustomAttributesCacheGenerator,
	WaitCallback_t2798937288_CustomAttributesCacheGenerator,
	AppDomainInitializer_t3898244613_CustomAttributesCacheGenerator,
	AssemblyLoadEventHandler_t2169307382_CustomAttributesCacheGenerator,
	EventHandler_t277755526_CustomAttributesCacheGenerator,
	ResolveEventHandler_t3842432458_CustomAttributesCacheGenerator,
	UnhandledExceptionEventHandler_t1916531888_CustomAttributesCacheGenerator,
	U3CPrivateImplementationDetailsU3E_t1486305137_CustomAttributesCacheGenerator,
	g_System_Assembly_CustomAttributesCacheGenerator,
	Locale_t4255929015_CustomAttributesCacheGenerator_Locale_GetText_m1445803604____args1,
	MonoTODOAttribute_t3487514020_CustomAttributesCacheGenerator,
	Stack_1_t4016656541_CustomAttributesCacheGenerator,
	HybridDictionary_t290043810_CustomAttributesCacheGenerator,
	ListDictionary_t3458713452_CustomAttributesCacheGenerator,
	NameObjectCollectionBase_t2034248631_CustomAttributesCacheGenerator_NameObjectCollectionBase_FindFirstMatchedItem_m2460648656,
	KeysCollection_t633582367_CustomAttributesCacheGenerator,
	NameValueCollection_t3047564564_CustomAttributesCacheGenerator,
	EditorBrowsableAttribute_t1050682502_CustomAttributesCacheGenerator,
	TypeConverter_t745995970_CustomAttributesCacheGenerator,
	TypeConverterAttribute_t252469870_CustomAttributesCacheGenerator,
	Win32Exception_t1708275760_CustomAttributesCacheGenerator,
	SslPolicyErrors_t1928581431_CustomAttributesCacheGenerator,
	Socket_t3821512045_CustomAttributesCacheGenerator_Socket_t3821512045____SupportsIPv6_PropertyInfo,
	SocketFlags_t2353657790_CustomAttributesCacheGenerator,
	Dns_t1335526197_CustomAttributesCacheGenerator_Dns_GetHostByName_m3673230969,
	FileWebRequest_t1571840111_CustomAttributesCacheGenerator_FileWebRequest__ctor_m4003648606,
	FtpWebRequest_t3120721823_CustomAttributesCacheGenerator_U3CU3Ef__amU24cache1C,
	FtpWebRequest_t3120721823_CustomAttributesCacheGenerator_FtpWebRequest_U3CcallbackU3Em__B_m4153123054,
	GlobalProxySelection_t2251180943_CustomAttributesCacheGenerator,
	HttpWebRequest_t1951404513_CustomAttributesCacheGenerator_HttpWebRequest__ctor_m1248252412,
	IPv6Address_t2596635879_CustomAttributesCacheGenerator,
	SecurityProtocolType_t3099771628_CustomAttributesCacheGenerator,
	ServicePointManager_t745663000_CustomAttributesCacheGenerator_ServicePointManager_t745663000____CertificatePolicy_PropertyInfo,
	ServicePointManager_t745663000_CustomAttributesCacheGenerator_ServicePointManager_t745663000____CheckCertificateRevocationList_PropertyInfo,
	SocketAddress_t838303055_CustomAttributesCacheGenerator,
	WebHeaderCollection_t3028142837_CustomAttributesCacheGenerator,
	WebProxy_t1169192840_CustomAttributesCacheGenerator_WebProxy_t1169192840____UseDefaultCredentials_PropertyInfo,
	WebRequest_t1365124353_CustomAttributesCacheGenerator_WebRequest_GetDefaultWebProxy_m1479642708,
	OpenFlags_t2370524385_CustomAttributesCacheGenerator,
	PublicKey_t870392_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map9,
	X500DistinguishedName_t452415348_CustomAttributesCacheGenerator,
	X500DistinguishedNameFlags_t2005802885_CustomAttributesCacheGenerator,
	X509Certificate2_t4056456767_CustomAttributesCacheGenerator_X509Certificate2_GetNameInfo_m402390219,
	X509Certificate2_t4056456767_CustomAttributesCacheGenerator_X509Certificate2_Import_m3813388542,
	X509Certificate2_t4056456767_CustomAttributesCacheGenerator_X509Certificate2_Verify_m1574874641,
	X509Certificate2Collection_t1108969367_CustomAttributesCacheGenerator,
	X509Certificate2Collection_t1108969367_CustomAttributesCacheGenerator_X509Certificate2Collection_AddRange_m1503879780,
	X509Certificate2Collection_t1108969367_CustomAttributesCacheGenerator_X509Certificate2Collection_Find_m1629908635,
	X509CertificateCollection_t1197680765_CustomAttributesCacheGenerator,
	X509Chain_t777637347_CustomAttributesCacheGenerator_U3CU3Ef__switchU24mapB,
	X509Chain_t777637347_CustomAttributesCacheGenerator_U3CU3Ef__switchU24mapC,
	X509Chain_t777637347_CustomAttributesCacheGenerator_U3CU3Ef__switchU24mapD,
	X509Chain_t777637347_CustomAttributesCacheGenerator_X509Chain_Build_m1140429528,
	X509ChainElementCollection_t2081831987_CustomAttributesCacheGenerator,
	X509ChainStatusFlags_t480677120_CustomAttributesCacheGenerator,
	X509EnhancedKeyUsageExtension_t2099881051_CustomAttributesCacheGenerator_U3CU3Ef__switchU24mapE,
	X509ExtensionCollection_t650873211_CustomAttributesCacheGenerator,
	X509KeyUsageFlags_t2461349531_CustomAttributesCacheGenerator,
	X509Store_t1617430119_CustomAttributesCacheGenerator_U3CU3Ef__switchU24mapF,
	X509VerificationFlags_t2169036324_CustomAttributesCacheGenerator,
	AsnEncodedData_t463456204_CustomAttributesCacheGenerator_U3CU3Ef__switchU24mapA,
	Oid_t3221867120_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map10,
	OidCollection_t3790243618_CustomAttributesCacheGenerator,
	CaptureCollection_t1671345504_CustomAttributesCacheGenerator,
	GroupCollection_t939014605_CustomAttributesCacheGenerator,
	MatchCollection_t3718216671_CustomAttributesCacheGenerator,
	RegexOptions_t2418259727_CustomAttributesCacheGenerator,
	OpFlags_t378191910_CustomAttributesCacheGenerator,
	IntervalCollection_t4130821325_CustomAttributesCacheGenerator,
	ExpressionCollection_t238836340_CustomAttributesCacheGenerator,
	Uri_t19570940_CustomAttributesCacheGenerator,
	Uri_t19570940_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map14,
	Uri_t19570940_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map15,
	Uri_t19570940_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map16,
	Uri_t19570940_CustomAttributesCacheGenerator_Uri__ctor_m3854873816,
	Uri_t19570940_CustomAttributesCacheGenerator_Uri_EscapeString_m1753508368,
	Uri_t19570940_CustomAttributesCacheGenerator_Uri_Unescape_m3356737110,
	UriParser_t1012511323_CustomAttributesCacheGenerator_UriParser_OnRegister_m4010407891,
	U3CPrivateImplementationDetailsU3E_t1486305138_CustomAttributesCacheGenerator,
	g_Mono_Security_Assembly_CustomAttributesCacheGenerator,
	BigInteger_t925946153_CustomAttributesCacheGenerator_BigInteger__ctor_m4013661868,
	BigInteger_t925946153_CustomAttributesCacheGenerator_BigInteger__ctor_m3239748086,
	BigInteger_t925946153_CustomAttributesCacheGenerator_BigInteger__ctor_m3787562545,
	BigInteger_t925946153_CustomAttributesCacheGenerator_BigInteger_SetBit_m426619300,
	BigInteger_t925946153_CustomAttributesCacheGenerator_BigInteger_SetBit_m576108355,
	BigInteger_t925946153_CustomAttributesCacheGenerator_BigInteger_ToString_m1842353154,
	BigInteger_t925946153_CustomAttributesCacheGenerator_BigInteger_ToString_m2878297110,
	BigInteger_t925946153_CustomAttributesCacheGenerator_BigInteger_op_Implicit_m622924526,
	BigInteger_t925946153_CustomAttributesCacheGenerator_BigInteger_op_Modulus_m2895726170,
	BigInteger_t925946153_CustomAttributesCacheGenerator_BigInteger_op_Equality_m2683055762,
	BigInteger_t925946153_CustomAttributesCacheGenerator_BigInteger_op_Inequality_m744282323,
	ModulusRing_t80355992_CustomAttributesCacheGenerator_ModulusRing_Pow_m661630322,
	ASN1_t924533536_CustomAttributesCacheGenerator,
	PKCS12_t1362584795_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map5,
	PKCS12_t1362584795_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map6,
	PKCS12_t1362584795_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map7,
	PKCS12_t1362584795_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map8,
	PKCS12_t1362584795_CustomAttributesCacheGenerator_U3CU3Ef__switchU24mapC,
	X509Certificate_t324051958_CustomAttributesCacheGenerator_U3CU3Ef__switchU24mapF,
	X509Certificate_t324051958_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map10,
	X509Certificate_t324051958_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map11,
	X509CertificateCollection_t3592472866_CustomAttributesCacheGenerator,
	X509ChainStatusFlags_t2843686920_CustomAttributesCacheGenerator,
	X509Crl_t1699034837_CustomAttributesCacheGenerator,
	X509Crl_t1699034837_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map13,
	X509ExtensionCollection_t1640144840_CustomAttributesCacheGenerator,
	ExtendedKeyUsageExtension_t3816993686_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map14,
	KeyUsages_t530589947_CustomAttributesCacheGenerator,
	CertTypes_t3955735183_CustomAttributesCacheGenerator,
	CipherSuiteCollection_t2431504453_CustomAttributesCacheGenerator,
	HttpsClientStream_t3823629320_CustomAttributesCacheGenerator_U3CU3Ef__amU24cache2,
	HttpsClientStream_t3823629320_CustomAttributesCacheGenerator_U3CU3Ef__amU24cache3,
	HttpsClientStream_t3823629320_CustomAttributesCacheGenerator_HttpsClientStream_U3CHttpsClientStreamU3Em__0_m3176353714,
	HttpsClientStream_t3823629320_CustomAttributesCacheGenerator_HttpsClientStream_U3CHttpsClientStreamU3Em__1_m4293802471,
	RSASslSignatureDeformatter_t389653629_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map15,
	RSASslSignatureFormatter_t1282301050_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map16,
	SecurityProtocolType_t155967584_CustomAttributesCacheGenerator,
	U3CPrivateImplementationDetailsU3E_t1486305139_CustomAttributesCacheGenerator,
	g_System_Core_Assembly_CustomAttributesCacheGenerator,
	ExtensionAttribute_t1840441203_CustomAttributesCacheGenerator,
	Locale_t4255929017_CustomAttributesCacheGenerator_Locale_GetText_m512920887____args1,
	MonoTODOAttribute_t3487514021_CustomAttributesCacheGenerator,
	HashSet_1_t2624254809_CustomAttributesCacheGenerator_HashSet_1_GetObjectData_m2015489021,
	HashSet_1_t2624254809_CustomAttributesCacheGenerator_HashSet_1_OnDeserialization_m627602129,
	Enumerable_t2148412300_CustomAttributesCacheGenerator,
	Enumerable_t2148412300_CustomAttributesCacheGenerator_Enumerable_Where_m2409552823,
	Enumerable_t2148412300_CustomAttributesCacheGenerator_Enumerable_CreateWhereIterator_m2714912225,
	U3CCreateWhereIteratorU3Ec__Iterator1D_1_t2523986802_CustomAttributesCacheGenerator,
	U3CCreateWhereIteratorU3Ec__Iterator1D_1_t2523986802_CustomAttributesCacheGenerator_U3CCreateWhereIteratorU3Ec__Iterator1D_1_System_Collections_Generic_IEnumeratorU3CTSourceU3E_get_Current_m517722874,
	U3CCreateWhereIteratorU3Ec__Iterator1D_1_t2523986802_CustomAttributesCacheGenerator_U3CCreateWhereIteratorU3Ec__Iterator1D_1_System_Collections_IEnumerator_get_Current_m1354814095,
	U3CCreateWhereIteratorU3Ec__Iterator1D_1_t2523986802_CustomAttributesCacheGenerator_U3CCreateWhereIteratorU3Ec__Iterator1D_1_System_Collections_IEnumerable_GetEnumerator_m3687475306,
	U3CCreateWhereIteratorU3Ec__Iterator1D_1_t2523986802_CustomAttributesCacheGenerator_U3CCreateWhereIteratorU3Ec__Iterator1D_1_System_Collections_Generic_IEnumerableU3CTSourceU3E_GetEnumerator_m2392330777,
	U3CCreateWhereIteratorU3Ec__Iterator1D_1_t2523986802_CustomAttributesCacheGenerator_U3CCreateWhereIteratorU3Ec__Iterator1D_1_Dispose_m3152287270,
	U3CCreateWhereIteratorU3Ec__Iterator1D_1_t2523986802_CustomAttributesCacheGenerator_U3CCreateWhereIteratorU3Ec__Iterator1D_1_Reset_m3335334056,
	U3CPrivateImplementationDetailsU3E_t1486305140_CustomAttributesCacheGenerator,
	g_UnityEngine_Assembly_CustomAttributesCacheGenerator,
	Application_t354826772_CustomAttributesCacheGenerator_Application_CallLogCallback_m3408386792,
	Application_t354826772_CustomAttributesCacheGenerator_Application_LoadLevel_m3450161284,
	Application_t354826772_CustomAttributesCacheGenerator_Application_t354826772____platform_PropertyInfo,
	AssetBundleCreateRequest_t1038783543_CustomAttributesCacheGenerator,
	AssetBundleRequest_t2674559435_CustomAttributesCacheGenerator,
	AsyncOperation_t3814632279_CustomAttributesCacheGenerator,
	AsyncOperation_t3814632279_CustomAttributesCacheGenerator_AsyncOperation_InternalDestroy_m3312061823,
	WaitForSeconds_t3839502067_CustomAttributesCacheGenerator,
	WaitForFixedUpdate_t3968615785_CustomAttributesCacheGenerator,
	WaitForEndOfFrame_t1785723201_CustomAttributesCacheGenerator,
	Coroutine_t2299508840_CustomAttributesCacheGenerator,
	Coroutine_t2299508840_CustomAttributesCacheGenerator_Coroutine_ReleaseCoroutine_m833118514,
	ScriptableObject_t1975622470_CustomAttributesCacheGenerator,
	ScriptableObject_t1975622470_CustomAttributesCacheGenerator_ScriptableObject_Internal_CreateScriptableObject_m1778903390,
	ScriptableObject_t1975622470_CustomAttributesCacheGenerator_ScriptableObject_Internal_CreateScriptableObject_m1778903390____self0,
	Camera_t189460977_CustomAttributesCacheGenerator,
	Camera_t189460977_CustomAttributesCacheGenerator_Camera_FireOnPreCull_m1679634170,
	Camera_t189460977_CustomAttributesCacheGenerator_Camera_FireOnPreRender_m24116662,
	Camera_t189460977_CustomAttributesCacheGenerator_Camera_FireOnPostRender_m94860165,
	Camera_t189460977_CustomAttributesCacheGenerator_Camera_RaycastTry_m3412198936,
	Component_t3819376471_CustomAttributesCacheGenerator,
	Component_t3819376471_CustomAttributesCacheGenerator_Component_GetComponent_m4225719715,
	Component_t3819376471_CustomAttributesCacheGenerator_Component_GetComponent_m3720754210,
	Component_t3819376471_CustomAttributesCacheGenerator_Component_GetComponentInChildren_m3925629424,
	Component_t3819376471_CustomAttributesCacheGenerator_Component_GetComponentInChildren_m3985003615,
	Component_t3819376471_CustomAttributesCacheGenerator_Component_GetComponentInChildren_m3417738402,
	Component_t3819376471_CustomAttributesCacheGenerator_Component_GetComponentInChildren_m2730561359____includeInactive0,
	Component_t3819376471_CustomAttributesCacheGenerator_Component_GetComponentsInChildren_m843288020,
	Component_t3819376471_CustomAttributesCacheGenerator_Component_GetComponentsInChildren_m908027537____includeInactive1,
	Component_t3819376471_CustomAttributesCacheGenerator_Component_GetComponentInParent_m2799402500,
	Component_t3819376471_CustomAttributesCacheGenerator_Component_GetComponentsInParent_m4192184629,
	Component_t3819376471_CustomAttributesCacheGenerator_Component_GetComponentsInParent_m1920178904____includeInactive1,
	Component_t3819376471_CustomAttributesCacheGenerator_Component_SendMessageUpwards_m2584088787____value1,
	Component_t3819376471_CustomAttributesCacheGenerator_Component_SendMessageUpwards_m2584088787____options2,
	Component_t3819376471_CustomAttributesCacheGenerator_Component_SendMessageUpwards_m325086847,
	Component_t3819376471_CustomAttributesCacheGenerator_Component_SendMessageUpwards_m2041012277,
	Component_t3819376471_CustomAttributesCacheGenerator_Component_SendMessage_m2241432133____value1,
	Component_t3819376471_CustomAttributesCacheGenerator_Component_SendMessage_m2241432133____options2,
	Component_t3819376471_CustomAttributesCacheGenerator_Component_SendMessage_m913946877,
	Component_t3819376471_CustomAttributesCacheGenerator_Component_SendMessage_m3615678587,
	Component_t3819376471_CustomAttributesCacheGenerator_Component_BroadcastMessage_m2230184532____parameter1,
	Component_t3819376471_CustomAttributesCacheGenerator_Component_BroadcastMessage_m2230184532____options2,
	Component_t3819376471_CustomAttributesCacheGenerator_Component_BroadcastMessage_m1308086896,
	Component_t3819376471_CustomAttributesCacheGenerator_Component_BroadcastMessage_m1706240890,
	CullingGroup_t1091689465_CustomAttributesCacheGenerator_CullingGroup_SendEvents_m1292564468,
	CullingGroup_t1091689465_CustomAttributesCacheGenerator_CullingGroup_FinalizerFailure_m3675513936,
	DebugLogHandler_t865810509_CustomAttributesCacheGenerator_DebugLogHandler_Internal_Log_m3491540823,
	DebugLogHandler_t865810509_CustomAttributesCacheGenerator_DebugLogHandler_Internal_Log_m3491540823____obj2,
	DebugLogHandler_t865810509_CustomAttributesCacheGenerator_DebugLogHandler_Internal_LogException_m317712981,
	DebugLogHandler_t865810509_CustomAttributesCacheGenerator_DebugLogHandler_Internal_LogException_m317712981____obj1,
	DebugLogHandler_t865810509_CustomAttributesCacheGenerator_DebugLogHandler_LogFormat_m177245518____args3,
	Debug_t1368543263_CustomAttributesCacheGenerator_Debug_LogErrorFormat_m60495267____args2,
	Debug_t1368543263_CustomAttributesCacheGenerator_Debug_LogWarningFormat_m79553173____args2,
	Display_t3666191348_CustomAttributesCacheGenerator,
	Display_t3666191348_CustomAttributesCacheGenerator_Display_RecreateDisplayList_m3412638488,
	Display_t3666191348_CustomAttributesCacheGenerator_Display_FireDisplaysUpdated_m3557250167,
	GameObject_t1756533147_CustomAttributesCacheGenerator_GameObject_GetComponent_m306258075,
	GameObject_t1756533147_CustomAttributesCacheGenerator_GameObject_GetComponent_m1986025102,
	GameObject_t1756533147_CustomAttributesCacheGenerator_GameObject_GetComponentInChildren_m4263325740,
	GameObject_t1756533147_CustomAttributesCacheGenerator_GameObject_GetComponentInChildren_m3844288190,
	GameObject_t1756533147_CustomAttributesCacheGenerator_GameObject_GetComponentInChildren_m252895367____includeInactive0,
	GameObject_t1756533147_CustomAttributesCacheGenerator_GameObject_GetComponentInParent_m1235194528,
	GameObject_t1756533147_CustomAttributesCacheGenerator_GameObject_GetComponentsInChildren_m993725821____includeInactive1,
	GameObject_t1756533147_CustomAttributesCacheGenerator_GameObject_GetComponentsInParent_m1568786844____includeInactive1,
	GameObject_t1756533147_CustomAttributesCacheGenerator_GameObject_SendMessage_m71956653____value1,
	GameObject_t1756533147_CustomAttributesCacheGenerator_GameObject_SendMessage_m71956653____options2,
	GameObject_t1756533147_CustomAttributesCacheGenerator_GameObject_AddComponent_m3757565614,
	GameObject_t1756533147_CustomAttributesCacheGenerator_GameObject_Internal_CreateGameObject_m3428198595____mono0,
	Gradient_t3600583008_CustomAttributesCacheGenerator,
	Gradient_t3600583008_CustomAttributesCacheGenerator_Gradient__ctor_m954570311,
	Gradient_t3600583008_CustomAttributesCacheGenerator_Gradient_Init_m4156899649,
	Gradient_t3600583008_CustomAttributesCacheGenerator_Gradient_Cleanup_m3573871739,
	Screen_t786852042_CustomAttributesCacheGenerator_Screen_t786852042____width_PropertyInfo,
	Screen_t786852042_CustomAttributesCacheGenerator_Screen_t786852042____height_PropertyInfo,
	RectOffset_t3387826427_CustomAttributesCacheGenerator,
	RectOffset_t3387826427_CustomAttributesCacheGenerator_RectOffset_Init_m4361650,
	RectOffset_t3387826427_CustomAttributesCacheGenerator_RectOffset_Cleanup_m3198970074,
	TouchScreenKeyboard_t601950206_CustomAttributesCacheGenerator_TouchScreenKeyboard_Open_m2760130151,
	TouchScreenKeyboard_t601950206_CustomAttributesCacheGenerator_TouchScreenKeyboard_Open_m913506328,
	TouchScreenKeyboard_t601950206_CustomAttributesCacheGenerator_TouchScreenKeyboard_Open_m3410222954____keyboardType1,
	TouchScreenKeyboard_t601950206_CustomAttributesCacheGenerator_TouchScreenKeyboard_Open_m3410222954____autocorrection2,
	TouchScreenKeyboard_t601950206_CustomAttributesCacheGenerator_TouchScreenKeyboard_Open_m3410222954____multiline3,
	TouchScreenKeyboard_t601950206_CustomAttributesCacheGenerator_TouchScreenKeyboard_Open_m3410222954____secure4,
	TouchScreenKeyboard_t601950206_CustomAttributesCacheGenerator_TouchScreenKeyboard_Open_m3410222954____alert5,
	TouchScreenKeyboard_t601950206_CustomAttributesCacheGenerator_TouchScreenKeyboard_Open_m3410222954____textPlaceholder6,
	LayerMask_t3188175821_CustomAttributesCacheGenerator,
	Vector3_t2243707580_CustomAttributesCacheGenerator,
	Quaternion_t4030073918_CustomAttributesCacheGenerator,
	Matrix4x4_t2933234003_CustomAttributesCacheGenerator,
	Bounds_t3033363703_CustomAttributesCacheGenerator,
	Mathf_t2336485820_CustomAttributesCacheGenerator_Mathf_SmoothDamp_m1604773625____maxSpeed4,
	Mathf_t2336485820_CustomAttributesCacheGenerator_Mathf_SmoothDamp_m1604773625____deltaTime5,
	Keyframe_t1449471340_CustomAttributesCacheGenerator,
	AnimationCurve_t3306541151_CustomAttributesCacheGenerator,
	AnimationCurve_t3306541151_CustomAttributesCacheGenerator_AnimationCurve__ctor_m2814448007____keys0,
	AnimationCurve_t3306541151_CustomAttributesCacheGenerator_AnimationCurve__ctor_m3707994114,
	AnimationCurve_t3306541151_CustomAttributesCacheGenerator_AnimationCurve_Cleanup_m2190142678,
	AnimationCurve_t3306541151_CustomAttributesCacheGenerator_AnimationCurve_Init_m1486386337,
	Mesh_t1356156583_CustomAttributesCacheGenerator_Mesh_Internal_Create_m1486058998____mono0,
	Mesh_t1356156583_CustomAttributesCacheGenerator_Mesh_Clear_m3100797454____keepVertexLayout0,
	Mesh_t1356156583_CustomAttributesCacheGenerator_Mesh_Clear_m231813403,
	Mesh_t1356156583_CustomAttributesCacheGenerator_Mesh_SetTrianglesImpl_m2743099196____calculateBounds3,
	Mesh_t1356156583_CustomAttributesCacheGenerator_Mesh_SetTriangles_m2017297103,
	Mesh_t1356156583_CustomAttributesCacheGenerator_Mesh_SetTriangles_m2506325172____calculateBounds2,
	MonoBehaviour_t1158329972_CustomAttributesCacheGenerator,
	MonoBehaviour_t1158329972_CustomAttributesCacheGenerator_MonoBehaviour_StartCoroutine_Auto_m1744905232,
	MonoBehaviour_t1158329972_CustomAttributesCacheGenerator_MonoBehaviour_StartCoroutine_m296997955____value1,
	MonoBehaviour_t1158329972_CustomAttributesCacheGenerator_MonoBehaviour_StartCoroutine_m1399371129,
	DrivenTransformProperties_t2488747555_CustomAttributesCacheGenerator,
	RectTransform_t3349966182_CustomAttributesCacheGenerator_RectTransform_SendReapplyDrivenProperties_m90487700,
	ResourceRequest_t2560315377_CustomAttributesCacheGenerator,
	Resources_t339470017_CustomAttributesCacheGenerator_Resources_Load_m243305716,
	Resources_t339470017_CustomAttributesCacheGenerator_Resources_GetBuiltinResource_m582410469,
	Material_t193706927_CustomAttributesCacheGenerator_Material_Internal_CreateWithMaterial_m2907597451____mono0,
	Texture2D_t3542995729_CustomAttributesCacheGenerator_Texture2D_Internal_Create_m3012183307____mono0,
	Texture2D_t3542995729_CustomAttributesCacheGenerator_Texture2D_Apply_m3753817130____updateMipmaps0,
	Texture2D_t3542995729_CustomAttributesCacheGenerator_Texture2D_Apply_m3753817130____makeNoLongerReadable1,
	Texture2D_t3542995729_CustomAttributesCacheGenerator_Texture2D_Apply_m3543341930,
	Texture2D_t3542995729_CustomAttributesCacheGenerator_Texture2D_ReadPixels_m1120832672,
	RenderTexture_t2666733923_CustomAttributesCacheGenerator,
	Transform_t3275118058_CustomAttributesCacheGenerator_Transform_Translate_m423862381____relativeTo1,
	Transform_t3275118058_CustomAttributesCacheGenerator_Transform_Rotate_m2612876682____relativeTo1,
	HideFlags_t1434274199_CustomAttributesCacheGenerator,
	Object_t1021602117_CustomAttributesCacheGenerator,
	Object_t1021602117_CustomAttributesCacheGenerator_Object_Internal_InstantiateSingle_m2776302597,
	Object_t1021602117_CustomAttributesCacheGenerator_Object_GetOffsetOfInstanceIDInCPlusPlusObject_m1587840561,
	Object_t1021602117_CustomAttributesCacheGenerator_Object_EnsureRunningOnMainThread_m3042842193,
	Object_t1021602117_CustomAttributesCacheGenerator_Object_Destroy_m4279412553____t1,
	Object_t1021602117_CustomAttributesCacheGenerator_Object_Destroy_m4145850038,
	Object_t1021602117_CustomAttributesCacheGenerator_Object_DestroyImmediate_m3563317232____allowDestroyingAssets1,
	Object_t1021602117_CustomAttributesCacheGenerator_Object_DestroyImmediate_m95027445,
	Object_t1021602117_CustomAttributesCacheGenerator_Object_FindObjectsOfType_m2121813744,
	Object_t1021602117_CustomAttributesCacheGenerator_Object_DestroyObject_m282495858____t1,
	Object_t1021602117_CustomAttributesCacheGenerator_Object_DestroyObject_m2343493981,
	Object_t1021602117_CustomAttributesCacheGenerator_Object_FindSceneObjectsOfType_m1833688338,
	Object_t1021602117_CustomAttributesCacheGenerator_Object_FindObjectsOfTypeIncludingAssets_m3988851426,
	Object_t1021602117_CustomAttributesCacheGenerator_Object_DoesObjectWithInstanceIDExist_m2570795274,
	Object_t1021602117_CustomAttributesCacheGenerator_Object_GetInstanceID_m1920497914,
	Object_t1021602117_CustomAttributesCacheGenerator_Object_Instantiate_m938141395,
	Object_t1021602117_CustomAttributesCacheGenerator_Object_Instantiate_m2160322936,
	Object_t1021602117_CustomAttributesCacheGenerator_Object_Instantiate_m2439155489,
	Object_t1021602117_CustomAttributesCacheGenerator_Object_Instantiate_m2177117080,
	Object_t1021602117_CustomAttributesCacheGenerator_Object_Instantiate_m2489341053,
	Object_t1021602117_CustomAttributesCacheGenerator_Object_FindObjectOfType_m2330404063,
	Playable_t3667545548_CustomAttributesCacheGenerator,
	GenericMixerPlayable_t788733994_CustomAttributesCacheGenerator,
	ScriptPlayable_t4067966717_CustomAttributesCacheGenerator,
	SceneManager_t90660965_CustomAttributesCacheGenerator,
	SceneManager_t90660965_CustomAttributesCacheGenerator_SceneManager_LoadScene_m592643733____mode1,
	SceneManager_t90660965_CustomAttributesCacheGenerator_SceneManager_Internal_SceneLoaded_m4005732915,
	SceneManager_t90660965_CustomAttributesCacheGenerator_SceneManager_Internal_SceneUnloaded_m4108957131,
	SceneManager_t90660965_CustomAttributesCacheGenerator_SceneManager_Internal_ActiveSceneChanged_m1162592635,
	ControllerColliderHit_t4070855101_CustomAttributesCacheGenerator,
	Collision_t2876846408_CustomAttributesCacheGenerator,
	Collision_t2876846408_CustomAttributesCacheGenerator_Collision_t2876846408____impactForceSum_PropertyInfo,
	Collision_t2876846408_CustomAttributesCacheGenerator_Collision_t2876846408____frictionForceSum_PropertyInfo,
	Collision_t2876846408_CustomAttributesCacheGenerator_Collision_t2876846408____other_PropertyInfo,
	Physics_t634932869_CustomAttributesCacheGenerator_Physics_Raycast_m2874007225,
	Physics_t634932869_CustomAttributesCacheGenerator_Physics_Raycast_m89212106,
	Physics_t634932869_CustomAttributesCacheGenerator_Physics_Raycast_m2667915561,
	Physics_t634932869_CustomAttributesCacheGenerator_Physics_Raycast_m3475924638____maxDistance2,
	Physics_t634932869_CustomAttributesCacheGenerator_Physics_Raycast_m3475924638____layerMask3,
	Physics_t634932869_CustomAttributesCacheGenerator_Physics_Raycast_m3475924638____queryTriggerInteraction4,
	Physics_t634932869_CustomAttributesCacheGenerator_Physics_Raycast_m1929115794,
	Physics_t634932869_CustomAttributesCacheGenerator_Physics_Raycast_m2994111303,
	Physics_t634932869_CustomAttributesCacheGenerator_Physics_Raycast_m4027183840,
	Physics_t634932869_CustomAttributesCacheGenerator_Physics_Raycast_m2036777053____maxDistance3,
	Physics_t634932869_CustomAttributesCacheGenerator_Physics_Raycast_m2036777053____layerMask4,
	Physics_t634932869_CustomAttributesCacheGenerator_Physics_Raycast_m2036777053____queryTriggerInteraction5,
	Physics_t634932869_CustomAttributesCacheGenerator_Physics_Raycast_m2691929452,
	Physics_t634932869_CustomAttributesCacheGenerator_Physics_Raycast_m780162053,
	Physics_t634932869_CustomAttributesCacheGenerator_Physics_Raycast_m2686676054,
	Physics_t634932869_CustomAttributesCacheGenerator_Physics_Raycast_m1844392139____maxDistance1,
	Physics_t634932869_CustomAttributesCacheGenerator_Physics_Raycast_m1844392139____layerMask2,
	Physics_t634932869_CustomAttributesCacheGenerator_Physics_Raycast_m1844392139____queryTriggerInteraction3,
	Physics_t634932869_CustomAttributesCacheGenerator_Physics_Raycast_m2009151399,
	Physics_t634932869_CustomAttributesCacheGenerator_Physics_Raycast_m2308457076,
	Physics_t634932869_CustomAttributesCacheGenerator_Physics_Raycast_m2736931691,
	Physics_t634932869_CustomAttributesCacheGenerator_Physics_Raycast_m233619224____maxDistance2,
	Physics_t634932869_CustomAttributesCacheGenerator_Physics_Raycast_m233619224____layerMask3,
	Physics_t634932869_CustomAttributesCacheGenerator_Physics_Raycast_m233619224____queryTriggerInteraction4,
	Physics_t634932869_CustomAttributesCacheGenerator_Physics_RaycastAll_m233036521,
	Physics_t634932869_CustomAttributesCacheGenerator_Physics_RaycastAll_m3928448900,
	Physics_t634932869_CustomAttributesCacheGenerator_Physics_RaycastAll_m1246652201,
	Physics_t634932869_CustomAttributesCacheGenerator_Physics_RaycastAll_m410413656____maxDistance1,
	Physics_t634932869_CustomAttributesCacheGenerator_Physics_RaycastAll_m410413656____layerMask2,
	Physics_t634932869_CustomAttributesCacheGenerator_Physics_RaycastAll_m410413656____queryTriggerInteraction3,
	Physics_t634932869_CustomAttributesCacheGenerator_Physics_RaycastAll_m3908263591____maxDistance2,
	Physics_t634932869_CustomAttributesCacheGenerator_Physics_RaycastAll_m3908263591____layermask3,
	Physics_t634932869_CustomAttributesCacheGenerator_Physics_RaycastAll_m3908263591____queryTriggerInteraction4,
	Physics_t634932869_CustomAttributesCacheGenerator_Physics_RaycastAll_m3256436970,
	Physics_t634932869_CustomAttributesCacheGenerator_Physics_RaycastAll_m3484190429,
	Physics_t634932869_CustomAttributesCacheGenerator_Physics_RaycastAll_m3650851272,
	ContactPoint_t1376425630_CustomAttributesCacheGenerator,
	RaycastHit_t87180320_CustomAttributesCacheGenerator,
	RaycastHit2D_t4063908774_CustomAttributesCacheGenerator,
	Physics2D_t2540166467_CustomAttributesCacheGenerator_Physics2D_Raycast_m1220041042,
	Physics2D_t2540166467_CustomAttributesCacheGenerator_Physics2D_Raycast_m122312471,
	Physics2D_t2540166467_CustomAttributesCacheGenerator_Physics2D_Raycast_m3913913442,
	Physics2D_t2540166467_CustomAttributesCacheGenerator_Physics2D_Raycast_m2560154475,
	Physics2D_t2540166467_CustomAttributesCacheGenerator_Physics2D_Raycast_m2303387255____distance2,
	Physics2D_t2540166467_CustomAttributesCacheGenerator_Physics2D_Raycast_m2303387255____layerMask3,
	Physics2D_t2540166467_CustomAttributesCacheGenerator_Physics2D_Raycast_m2303387255____minDepth4,
	Physics2D_t2540166467_CustomAttributesCacheGenerator_Physics2D_Raycast_m2303387255____maxDepth5,
	Physics2D_t2540166467_CustomAttributesCacheGenerator_Physics2D_GetRayIntersectionAll_m253330691,
	Physics2D_t2540166467_CustomAttributesCacheGenerator_Physics2D_GetRayIntersectionAll_m253330691____distance1,
	Physics2D_t2540166467_CustomAttributesCacheGenerator_Physics2D_GetRayIntersectionAll_m253330691____layerMask2,
	Physics2D_t2540166467_CustomAttributesCacheGenerator_Physics2D_GetRayIntersectionAll_m2808325432,
	Physics2D_t2540166467_CustomAttributesCacheGenerator_Physics2D_GetRayIntersectionAll_m120415839,
	ContactPoint2D_t3659330976_CustomAttributesCacheGenerator,
	Collision2D_t1539500754_CustomAttributesCacheGenerator,
	AudioSettings_t3144015719_CustomAttributesCacheGenerator_AudioSettings_InvokeOnAudioConfigurationChanged_m3225073778,
	AudioClip_t1932558630_CustomAttributesCacheGenerator_AudioClip_InvokePCMReaderCallback_Internal_m1966286598,
	AudioClip_t1932558630_CustomAttributesCacheGenerator_AudioClip_InvokePCMSetPositionCallback_Internal_m2304858844,
	AnimationEvent_t2428323300_CustomAttributesCacheGenerator,
	AnimationEvent_t2428323300_CustomAttributesCacheGenerator_AnimationEvent_t2428323300____data_PropertyInfo,
	AnimationState_t1303741697_CustomAttributesCacheGenerator,
	AnimatorClipInfo_t3905751349_CustomAttributesCacheGenerator,
	AnimatorStateInfo_t2577870592_CustomAttributesCacheGenerator,
	AnimatorStateInfo_t2577870592_CustomAttributesCacheGenerator_AnimatorStateInfo_t2577870592____nameHash_PropertyInfo,
	AnimatorTransitionInfo_t2410896200_CustomAttributesCacheGenerator,
	Animator_t69676727_CustomAttributesCacheGenerator,
	Animator_t69676727_CustomAttributesCacheGenerator_Animator_StringToHash_m3313850714,
	SkeletonBone_t345082847_CustomAttributesCacheGenerator,
	SkeletonBone_t345082847_CustomAttributesCacheGenerator_SkeletonBone_t345082847____transformModified_PropertyInfo,
	HumanBone_t1529896151_CustomAttributesCacheGenerator,
	AnimatorControllerPlayable_t4078305555_CustomAttributesCacheGenerator,
	AnimationPlayable_t1693994278_CustomAttributesCacheGenerator,
	CustomAnimationPlayable_t3423099547_CustomAttributesCacheGenerator,
	TextGenerationError_t780770201_CustomAttributesCacheGenerator,
	TextGenerator_t647235000_CustomAttributesCacheGenerator,
	TextGenerator_t647235000_CustomAttributesCacheGenerator_TextGenerator_Dispose_cpp_m1755131202,
	Font_t4239498691_CustomAttributesCacheGenerator_Font_InvokeTextureRebuilt_Internal_m2007522718,
	FontTextureRebuildCallback_t1272078033_CustomAttributesCacheGenerator,
	UICharInfo_t3056636800_CustomAttributesCacheGenerator,
	UILineInfo_t3621277874_CustomAttributesCacheGenerator,
	UIVertex_t1204258818_CustomAttributesCacheGenerator,
	Canvas_t209405766_CustomAttributesCacheGenerator_Canvas_SendWillRenderCanvases_m3796535067,
	Event_t3028476042_CustomAttributesCacheGenerator_U3CU3Ef__switchU24map0,
	Event_t3028476042_CustomAttributesCacheGenerator_Event_Internal_MakeMasterEventCurrent_m1829330051,
	Event_t3028476042_CustomAttributesCacheGenerator_Event_Init_m3901382626,
	Event_t3028476042_CustomAttributesCacheGenerator_Event_Cleanup_m1195902101,
	EventModifiers_t2690251474_CustomAttributesCacheGenerator,
	GUI_t4082743951_CustomAttributesCacheGenerator_U3CnextScrollStepTimeU3Ek__BackingField,
	GUI_t4082743951_CustomAttributesCacheGenerator_GUI_set_nextScrollStepTime_m2724006954,
	GUI_t4082743951_CustomAttributesCacheGenerator_GUI_CallWindowDelegate_m634477008,
	ScrollViewState_t2792222924_CustomAttributesCacheGenerator_ScrollViewState__ctor_m853546402,
	GUIContent_t4210063000_CustomAttributesCacheGenerator_m_Text,
	GUIContent_t4210063000_CustomAttributesCacheGenerator_m_Image,
	GUIContent_t4210063000_CustomAttributesCacheGenerator_m_Tooltip,
	GUIScrollGroup_t755788567_CustomAttributesCacheGenerator_GUIScrollGroup__ctor_m3551718706,
	GUISettings_t622856320_CustomAttributesCacheGenerator_m_DoubleClickSelectsWord,
	GUISettings_t622856320_CustomAttributesCacheGenerator_m_TripleClickSelectsLine,
	GUISettings_t622856320_CustomAttributesCacheGenerator_m_CursorColor,
	GUISettings_t622856320_CustomAttributesCacheGenerator_m_CursorFlashSpeed,
	GUISettings_t622856320_CustomAttributesCacheGenerator_m_SelectionColor,
	GUISkin_t1436893342_CustomAttributesCacheGenerator,
	GUISkin_t1436893342_CustomAttributesCacheGenerator_m_Font,
	GUISkin_t1436893342_CustomAttributesCacheGenerator_m_box,
	GUISkin_t1436893342_CustomAttributesCacheGenerator_m_button,
	GUISkin_t1436893342_CustomAttributesCacheGenerator_m_toggle,
	GUISkin_t1436893342_CustomAttributesCacheGenerator_m_label,
	GUISkin_t1436893342_CustomAttributesCacheGenerator_m_textField,
	GUISkin_t1436893342_CustomAttributesCacheGenerator_m_textArea,
	GUISkin_t1436893342_CustomAttributesCacheGenerator_m_window,
	GUISkin_t1436893342_CustomAttributesCacheGenerator_m_horizontalSlider,
	GUISkin_t1436893342_CustomAttributesCacheGenerator_m_horizontalSliderThumb,
	GUISkin_t1436893342_CustomAttributesCacheGenerator_m_verticalSlider,
	GUISkin_t1436893342_CustomAttributesCacheGenerator_m_verticalSliderThumb,
	GUISkin_t1436893342_CustomAttributesCacheGenerator_m_horizontalScrollbar,
	GUISkin_t1436893342_CustomAttributesCacheGenerator_m_horizontalScrollbarThumb,
	GUISkin_t1436893342_CustomAttributesCacheGenerator_m_horizontalScrollbarLeftButton,
	GUISkin_t1436893342_CustomAttributesCacheGenerator_m_horizontalScrollbarRightButton,
	GUISkin_t1436893342_CustomAttributesCacheGenerator_m_verticalScrollbar,
	GUISkin_t1436893342_CustomAttributesCacheGenerator_m_verticalScrollbarThumb,
	GUISkin_t1436893342_CustomAttributesCacheGenerator_m_verticalScrollbarUpButton,
	GUISkin_t1436893342_CustomAttributesCacheGenerator_m_verticalScrollbarDownButton,
	GUISkin_t1436893342_CustomAttributesCacheGenerator_m_ScrollView,
	GUISkin_t1436893342_CustomAttributesCacheGenerator_m_CustomStyles,
	GUISkin_t1436893342_CustomAttributesCacheGenerator_m_Settings,
	GUIStyleState_t3801000545_CustomAttributesCacheGenerator_GUIStyleState_Init_m2434147050,
	GUIStyleState_t3801000545_CustomAttributesCacheGenerator_GUIStyleState_Cleanup_m705006206,
	GUIStyleState_t3801000545_CustomAttributesCacheGenerator_GUIStyleState_GetBackgroundInternalFromDeserialization_m1892089769,
	GUIStyle_t1799908754_CustomAttributesCacheGenerator,
	GUIStyle_t1799908754_CustomAttributesCacheGenerator_GUIStyle_Init_m3872198731,
	GUIStyle_t1799908754_CustomAttributesCacheGenerator_GUIStyle_InitCopy_m3676786505,
	GUIStyle_t1799908754_CustomAttributesCacheGenerator_GUIStyle_Cleanup_m1915255373,
	GUIStyle_t1799908754_CustomAttributesCacheGenerator_GUIStyle_GetStyleStatePtr_m1972527409,
	GUIStyle_t1799908754_CustomAttributesCacheGenerator_GUIStyle_GetFontInternalDuringLoadingThread_m229734483,
	GUIStyle_t1799908754_CustomAttributesCacheGenerator_GUIStyle_t1799908754____clipOffset_PropertyInfo,
	GUITargetAttribute_t863467180_CustomAttributesCacheGenerator,
	GUITargetAttribute_t863467180_CustomAttributesCacheGenerator_GUITargetAttribute_GetGUITargetAttrValue_m3740620102,
	GUIUtility_t3275770671_CustomAttributesCacheGenerator_U3CguiIsExitingU3Ek__BackingField,
	GUIUtility_t3275770671_CustomAttributesCacheGenerator_GUIUtility_set_guiIsExiting_m2362636745,
	GUIUtility_t3275770671_CustomAttributesCacheGenerator_GUIUtility_BeginGUI_m2907220931,
	GUIUtility_t3275770671_CustomAttributesCacheGenerator_GUIUtility_EndGUI_m3538781391,
	GUIUtility_t3275770671_CustomAttributesCacheGenerator_GUIUtility_EndGUIFromException_m2091524531,
	SliderState_t1595681032_CustomAttributesCacheGenerator,
	TextEditor_t3975561390_CustomAttributesCacheGenerator_TextEditor__ctor_m1990252461,
	WebRequestUtils_t4100941042_CustomAttributesCacheGenerator_WebRequestUtils_RedirectTo_m3803295888,
	RemoteSettings_t392466225_CustomAttributesCacheGenerator_RemoteSettings_CallOnUpdate_m1624968574,
	AttributeHelperEngine_t958797062_CustomAttributesCacheGenerator_AttributeHelperEngine_GetParentTypeDisallowingMultipleInclusion_m685343645,
	AttributeHelperEngine_t958797062_CustomAttributesCacheGenerator_AttributeHelperEngine_GetRequiredComponents_m120894667,
	AttributeHelperEngine_t958797062_CustomAttributesCacheGenerator_AttributeHelperEngine_CheckIsEditorScript_m2980171478,
	AttributeHelperEngine_t958797062_CustomAttributesCacheGenerator_AttributeHelperEngine_GetDefaultExecutionOrderFor_m451063166,
	DisallowMultipleComponent_t2656950_CustomAttributesCacheGenerator,
	RequireComponent_t864575032_CustomAttributesCacheGenerator,
	DefaultExecutionOrder_t2717914595_CustomAttributesCacheGenerator,
	DefaultExecutionOrder_t2717914595_CustomAttributesCacheGenerator_U3CorderU3Ek__BackingField,
	DefaultExecutionOrder_t2717914595_CustomAttributesCacheGenerator_DefaultExecutionOrder_get_order_m1561221759,
	IL2CPPStructAlignmentAttribute_t130316838_CustomAttributesCacheGenerator,
	RuntimePlatform_t1869584967_CustomAttributesCacheGenerator_OSXWebPlayer,
	RuntimePlatform_t1869584967_CustomAttributesCacheGenerator_WindowsWebPlayer,
	RuntimePlatform_t1869584967_CustomAttributesCacheGenerator_XBOX360,
	RuntimePlatform_t1869584967_CustomAttributesCacheGenerator_PS3,
	RuntimePlatform_t1869584967_CustomAttributesCacheGenerator_NaCl,
	RuntimePlatform_t1869584967_CustomAttributesCacheGenerator_FlashPlayer,
	RuntimePlatform_t1869584967_CustomAttributesCacheGenerator_MetroPlayerX86,
	RuntimePlatform_t1869584967_CustomAttributesCacheGenerator_MetroPlayerX64,
	RuntimePlatform_t1869584967_CustomAttributesCacheGenerator_MetroPlayerARM,
	RuntimePlatform_t1869584967_CustomAttributesCacheGenerator_WP8Player,
	RuntimePlatform_t1869584967_CustomAttributesCacheGenerator_BlackBerryPlayer,
	Color_t2020392075_CustomAttributesCacheGenerator,
	Color32_t874517518_CustomAttributesCacheGenerator,
	SetupCoroutine_t3582942563_CustomAttributesCacheGenerator,
	SetupCoroutine_t3582942563_CustomAttributesCacheGenerator_SetupCoroutine_InvokeMoveNext_m2975616245,
	SetupCoroutine_t3582942563_CustomAttributesCacheGenerator_SetupCoroutine_InvokeMember_m1481430263,
	WritableAttribute_t3715198420_CustomAttributesCacheGenerator,
	AssemblyIsEditorAssembly_t1557026495_CustomAttributesCacheGenerator,
	ColorWriteMask_t926634530_CustomAttributesCacheGenerator,
	SendMouseEvents_t3505065032_CustomAttributesCacheGenerator_SendMouseEvents_SetMouseMoved_m532965689,
	SendMouseEvents_t3505065032_CustomAttributesCacheGenerator_SendMouseEvents_DoSendMouseEvents_m701697135,
	PropertyAttribute_t2606999759_CustomAttributesCacheGenerator,
	TooltipAttribute_t4278647215_CustomAttributesCacheGenerator,
	SpaceAttribute_t952253354_CustomAttributesCacheGenerator,
	RangeAttribute_t3336560921_CustomAttributesCacheGenerator,
	TextAreaAttribute_t2454598508_CustomAttributesCacheGenerator,
	Rect_t3681755626_CustomAttributesCacheGenerator,
	SelectionBaseAttribute_t936505999_CustomAttributesCacheGenerator,
	SerializePrivateVariables_t2241034664_CustomAttributesCacheGenerator,
	SerializeField_t3073427462_CustomAttributesCacheGenerator,
	PreferBinarySerialization_t2472773525_CustomAttributesCacheGenerator,
	ISerializationCallbackReceiver_t1665913161_CustomAttributesCacheGenerator,
	StackTraceUtility_t1881293839_CustomAttributesCacheGenerator_StackTraceUtility_SetProjectFolder_m2154926761,
	StackTraceUtility_t1881293839_CustomAttributesCacheGenerator_StackTraceUtility_ExtractStackTrace_m1593581205,
	StackTraceUtility_t1881293839_CustomAttributesCacheGenerator_StackTraceUtility_ExtractStringFromExceptionInternal_m2568950546,
	StackTraceUtility_t1881293839_CustomAttributesCacheGenerator_StackTraceUtility_PostprocessStacktrace_m2866903298,
	StackTraceUtility_t1881293839_CustomAttributesCacheGenerator_StackTraceUtility_ExtractFormattedStackTrace_m2242276521,
	UnityException_t2687879050_CustomAttributesCacheGenerator,
	SharedBetweenAnimatorsAttribute_t1565472209_CustomAttributesCacheGenerator,
	StateMachineBehaviour_t2151245329_CustomAttributesCacheGenerator,
	ArgumentCache_t4810721_CustomAttributesCacheGenerator_m_ObjectArgument,
	ArgumentCache_t4810721_CustomAttributesCacheGenerator_m_ObjectArgumentAssemblyTypeName,
	ArgumentCache_t4810721_CustomAttributesCacheGenerator_m_IntArgument,
	ArgumentCache_t4810721_CustomAttributesCacheGenerator_m_FloatArgument,
	ArgumentCache_t4810721_CustomAttributesCacheGenerator_m_StringArgument,
	ArgumentCache_t4810721_CustomAttributesCacheGenerator_m_BoolArgument,
	PersistentCall_t3793436469_CustomAttributesCacheGenerator_m_Target,
	PersistentCall_t3793436469_CustomAttributesCacheGenerator_m_MethodName,
	PersistentCall_t3793436469_CustomAttributesCacheGenerator_m_Mode,
	PersistentCall_t3793436469_CustomAttributesCacheGenerator_m_Arguments,
	PersistentCall_t3793436469_CustomAttributesCacheGenerator_m_CallState,
	PersistentCallGroup_t339478082_CustomAttributesCacheGenerator_m_Calls,
	UnityEventBase_t828812576_CustomAttributesCacheGenerator_m_PersistentCalls,
	UnityEventBase_t828812576_CustomAttributesCacheGenerator_m_TypeName,
	UnityEvent_t408735097_CustomAttributesCacheGenerator_UnityEvent__ctor_m588741179,
	UnityEvent_1_t4075366602_CustomAttributesCacheGenerator_UnityEvent_1__ctor_m152711818,
	UnityEvent_2_t4075366599_CustomAttributesCacheGenerator_UnityEvent_2__ctor_m153825865,
	UnityEvent_3_t4075366600_CustomAttributesCacheGenerator_UnityEvent_3__ctor_m154939912,
	UnityEvent_4_t4075366597_CustomAttributesCacheGenerator_UnityEvent_4__ctor_m156341191,
	UnityString_t276356480_CustomAttributesCacheGenerator_UnityString_Format_m2949645127____args1,
	Vector2_t2243707579_CustomAttributesCacheGenerator,
	Vector4_t2243707581_CustomAttributesCacheGenerator,
	DefaultValueAttribute_t1027170048_CustomAttributesCacheGenerator,
	ExcludeFromDocsAttribute_t665825653_CustomAttributesCacheGenerator,
	ILogHandler_t264057413_CustomAttributesCacheGenerator_ILogHandler_LogFormat_m75756134____args3,
	Logger_t3328995178_CustomAttributesCacheGenerator_U3ClogHandlerU3Ek__BackingField,
	Logger_t3328995178_CustomAttributesCacheGenerator_U3ClogEnabledU3Ek__BackingField,
	Logger_t3328995178_CustomAttributesCacheGenerator_U3CfilterLogTypeU3Ek__BackingField,
	Logger_t3328995178_CustomAttributesCacheGenerator_Logger_get_logHandler_m4190583509,
	Logger_t3328995178_CustomAttributesCacheGenerator_Logger_set_logHandler_m2851576632,
	Logger_t3328995178_CustomAttributesCacheGenerator_Logger_get_logEnabled_m3807759477,
	Logger_t3328995178_CustomAttributesCacheGenerator_Logger_set_logEnabled_m3852234466,
	Logger_t3328995178_CustomAttributesCacheGenerator_Logger_get_filterLogType_m3672438698,
	Logger_t3328995178_CustomAttributesCacheGenerator_Logger_set_filterLogType_m1452353615,
	Logger_t3328995178_CustomAttributesCacheGenerator_Logger_LogFormat_m193464629____args3,
	UsedByNativeCodeAttribute_t3212052468_CustomAttributesCacheGenerator,
	RequiredByNativeCodeAttribute_t1913052472_CustomAttributesCacheGenerator,
	FormerlySerializedAsAttribute_t3673080018_CustomAttributesCacheGenerator,
	TypeInferenceRuleAttribute_t1390152093_CustomAttributesCacheGenerator,
	NetFxCoreExtensions_t4275971970_CustomAttributesCacheGenerator,
	NetFxCoreExtensions_t4275971970_CustomAttributesCacheGenerator_NetFxCoreExtensions_CreateDelegate_m2492743074,
	NetFxCoreExtensions_t4275971970_CustomAttributesCacheGenerator_NetFxCoreExtensions_GetMethodInfo_m2715372889,
	g_UnityEngine_UI_Assembly_CustomAttributesCacheGenerator,
	EventHandle_t942672932_CustomAttributesCacheGenerator,
	EventSystem_t3466835263_CustomAttributesCacheGenerator,
	EventSystem_t3466835263_CustomAttributesCacheGenerator_U3CcurrentU3Ek__BackingField,
	EventSystem_t3466835263_CustomAttributesCacheGenerator_m_FirstSelected,
	EventSystem_t3466835263_CustomAttributesCacheGenerator_m_sendNavigationEvents,
	EventSystem_t3466835263_CustomAttributesCacheGenerator_m_DragThreshold,
	EventSystem_t3466835263_CustomAttributesCacheGenerator_U3CU3Ef__mgU24cache0,
	EventSystem_t3466835263_CustomAttributesCacheGenerator_EventSystem_get_current_m319019811,
	EventSystem_t3466835263_CustomAttributesCacheGenerator_EventSystem_set_current_m1323649628,
	EventSystem_t3466835263_CustomAttributesCacheGenerator_EventSystem_t3466835263____lastSelectedGameObject_PropertyInfo,
	EventTrigger_t1967201810_CustomAttributesCacheGenerator,
	EventTrigger_t1967201810_CustomAttributesCacheGenerator_m_Delegates,
	EventTrigger_t1967201810_CustomAttributesCacheGenerator_delegates,
	ExecuteEvents_t1693084770_CustomAttributesCacheGenerator_U3CU3Ef__mgU24cache0,
	ExecuteEvents_t1693084770_CustomAttributesCacheGenerator_U3CU3Ef__mgU24cache1,
	ExecuteEvents_t1693084770_CustomAttributesCacheGenerator_U3CU3Ef__mgU24cache2,
	ExecuteEvents_t1693084770_CustomAttributesCacheGenerator_U3CU3Ef__mgU24cache3,
	ExecuteEvents_t1693084770_CustomAttributesCacheGenerator_U3CU3Ef__mgU24cache4,
	ExecuteEvents_t1693084770_CustomAttributesCacheGenerator_U3CU3Ef__mgU24cache5,
	ExecuteEvents_t1693084770_CustomAttributesCacheGenerator_U3CU3Ef__mgU24cache6,
	ExecuteEvents_t1693084770_CustomAttributesCacheGenerator_U3CU3Ef__mgU24cache7,
	ExecuteEvents_t1693084770_CustomAttributesCacheGenerator_U3CU3Ef__mgU24cache8,
	ExecuteEvents_t1693084770_CustomAttributesCacheGenerator_U3CU3Ef__mgU24cache9,
	ExecuteEvents_t1693084770_CustomAttributesCacheGenerator_U3CU3Ef__mgU24cacheA,
	ExecuteEvents_t1693084770_CustomAttributesCacheGenerator_U3CU3Ef__mgU24cacheB,
	ExecuteEvents_t1693084770_CustomAttributesCacheGenerator_U3CU3Ef__mgU24cacheC,
	ExecuteEvents_t1693084770_CustomAttributesCacheGenerator_U3CU3Ef__mgU24cacheD,
	ExecuteEvents_t1693084770_CustomAttributesCacheGenerator_U3CU3Ef__mgU24cacheE,
	ExecuteEvents_t1693084770_CustomAttributesCacheGenerator_U3CU3Ef__mgU24cacheF,
	ExecuteEvents_t1693084770_CustomAttributesCacheGenerator_U3CU3Ef__mgU24cache10,
	ExecuteEvents_t1693084770_CustomAttributesCacheGenerator_ExecuteEvents_U3Cs_HandlerListPoolU3Em__0_m2903690915,
	AxisEventData_t1524870173_CustomAttributesCacheGenerator_U3CmoveVectorU3Ek__BackingField,
	AxisEventData_t1524870173_CustomAttributesCacheGenerator_U3CmoveDirU3Ek__BackingField,
	AxisEventData_t1524870173_CustomAttributesCacheGenerator_AxisEventData_get_moveVector_m1338727516,
	AxisEventData_t1524870173_CustomAttributesCacheGenerator_AxisEventData_set_moveVector_m3227339885,
	AxisEventData_t1524870173_CustomAttributesCacheGenerator_AxisEventData_get_moveDir_m3968662359,
	AxisEventData_t1524870173_CustomAttributesCacheGenerator_AxisEventData_set_moveDir_m254243794,
	PointerEventData_t1599784723_CustomAttributesCacheGenerator_U3CpointerEnterU3Ek__BackingField,
	PointerEventData_t1599784723_CustomAttributesCacheGenerator_U3ClastPressU3Ek__BackingField,
	PointerEventData_t1599784723_CustomAttributesCacheGenerator_U3CrawPointerPressU3Ek__BackingField,
	PointerEventData_t1599784723_CustomAttributesCacheGenerator_U3CpointerDragU3Ek__BackingField,
	PointerEventData_t1599784723_CustomAttributesCacheGenerator_U3CpointerCurrentRaycastU3Ek__BackingField,
	PointerEventData_t1599784723_CustomAttributesCacheGenerator_U3CpointerPressRaycastU3Ek__BackingField,
	PointerEventData_t1599784723_CustomAttributesCacheGenerator_U3CeligibleForClickU3Ek__BackingField,
	PointerEventData_t1599784723_CustomAttributesCacheGenerator_U3CpointerIdU3Ek__BackingField,
	PointerEventData_t1599784723_CustomAttributesCacheGenerator_U3CpositionU3Ek__BackingField,
	PointerEventData_t1599784723_CustomAttributesCacheGenerator_U3CdeltaU3Ek__BackingField,
	PointerEventData_t1599784723_CustomAttributesCacheGenerator_U3CpressPositionU3Ek__BackingField,
	PointerEventData_t1599784723_CustomAttributesCacheGenerator_U3CworldPositionU3Ek__BackingField,
	PointerEventData_t1599784723_CustomAttributesCacheGenerator_U3CworldNormalU3Ek__BackingField,
	PointerEventData_t1599784723_CustomAttributesCacheGenerator_U3CclickTimeU3Ek__BackingField,
	PointerEventData_t1599784723_CustomAttributesCacheGenerator_U3CclickCountU3Ek__BackingField,
	PointerEventData_t1599784723_CustomAttributesCacheGenerator_U3CscrollDeltaU3Ek__BackingField,
	PointerEventData_t1599784723_CustomAttributesCacheGenerator_U3CuseDragThresholdU3Ek__BackingField,
	PointerEventData_t1599784723_CustomAttributesCacheGenerator_U3CdraggingU3Ek__BackingField,
	PointerEventData_t1599784723_CustomAttributesCacheGenerator_U3CbuttonU3Ek__BackingField,
	PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_get_pointerEnter_m2114522773,
	PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_set_pointerEnter_m1440587006,
	PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_get_lastPress_m3835070463,
	PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_set_lastPress_m882263356,
	PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_get_rawPointerPress_m448871540,
	PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_set_rawPointerPress_m1484888025,
	PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_get_pointerDrag_m2740415629,
	PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_set_pointerDrag_m3543074708,
	PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_get_pointerCurrentRaycast_m1374279130,
	PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_set_pointerCurrentRaycast_m2431897513,
	PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_get_pointerPressRaycast_m3131640124,
	PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_set_pointerPressRaycast_m2551142399,
	PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_get_eligibleForClick_m2497780621,
	PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_set_eligibleForClick_m2036057844,
	PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_get_pointerId_m2835313597,
	PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_set_pointerId_m2349910516,
	PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_get_position_m2131765015,
	PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_set_position_m794507622,
	PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_get_delta_m1072163964,
	PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_set_delta_m3672873329,
	PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_get_pressPosition_m1206276610,
	PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_set_pressPosition_m2094137883,
	PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_get_worldPosition_m3746978956,
	PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_set_worldPosition_m192283671,
	PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_get_worldNormal_m1704987468,
	PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_set_worldNormal_m2025727441,
	PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_get_clickTime_m2587872034,
	PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_set_clickTime_m3931922487,
	PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_get_clickCount_m4064532478,
	PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_set_clickCount_m2095939005,
	PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_get_scrollDelta_m1283145047,
	PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_set_scrollDelta_m4002219844,
	PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_get_useDragThreshold_m1801224989,
	PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_set_useDragThreshold_m2778439880,
	PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_get_dragging_m220490640,
	PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_set_dragging_m915629341,
	PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_get_button_m2339189303,
	PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_set_button_m3279441906,
	PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_t1599784723____worldPosition_PropertyInfo,
	PointerEventData_t1599784723_CustomAttributesCacheGenerator_PointerEventData_t1599784723____worldNormal_PropertyInfo,
	BaseInputModule_t1295781545_CustomAttributesCacheGenerator,
	StandaloneInputModule_t70867863_CustomAttributesCacheGenerator,
	StandaloneInputModule_t70867863_CustomAttributesCacheGenerator_m_HorizontalAxis,
	StandaloneInputModule_t70867863_CustomAttributesCacheGenerator_m_VerticalAxis,
	StandaloneInputModule_t70867863_CustomAttributesCacheGenerator_m_SubmitButton,
	StandaloneInputModule_t70867863_CustomAttributesCacheGenerator_m_CancelButton,
	StandaloneInputModule_t70867863_CustomAttributesCacheGenerator_m_InputActionsPerSecond,
	StandaloneInputModule_t70867863_CustomAttributesCacheGenerator_m_RepeatDelay,
	StandaloneInputModule_t70867863_CustomAttributesCacheGenerator_m_ForceModuleActive,
	StandaloneInputModule_t70867863_CustomAttributesCacheGenerator_StandaloneInputModule_t70867863____inputMode_PropertyInfo,
	StandaloneInputModule_t70867863_CustomAttributesCacheGenerator_StandaloneInputModule_t70867863____allowActivationOnMobileDevice_PropertyInfo,
	InputMode_t2680906638_CustomAttributesCacheGenerator,
	TouchInputModule_t2561058385_CustomAttributesCacheGenerator,
	TouchInputModule_t2561058385_CustomAttributesCacheGenerator_m_ForceModuleActive,
	TouchInputModule_t2561058385_CustomAttributesCacheGenerator_TouchInputModule_t2561058385____allowActivationOnStandalone_PropertyInfo,
	BaseRaycaster_t2336171397_CustomAttributesCacheGenerator_BaseRaycaster_t2336171397____priority_PropertyInfo,
	Physics2DRaycaster_t3236822917_CustomAttributesCacheGenerator,
	PhysicsRaycaster_t249603239_CustomAttributesCacheGenerator,
	PhysicsRaycaster_t249603239_CustomAttributesCacheGenerator_m_EventMask,
	PhysicsRaycaster_t249603239_CustomAttributesCacheGenerator_U3CU3Ef__amU24cache0,
	PhysicsRaycaster_t249603239_CustomAttributesCacheGenerator_PhysicsRaycaster_U3CRaycastU3Em__0_m267334242,
	TweenRunner_1_t2584777480_CustomAttributesCacheGenerator_TweenRunner_1_Start_m2640577060,
	U3CStartU3Ec__Iterator0_t3220237554_CustomAttributesCacheGenerator,
	U3CStartU3Ec__Iterator0_t3220237554_CustomAttributesCacheGenerator_U3CStartU3Ec__Iterator0__ctor_m3896495454,
	U3CStartU3Ec__Iterator0_t3220237554_CustomAttributesCacheGenerator_U3CStartU3Ec__Iterator0_System_Collections_Generic_IEnumeratorU3CobjectU3E_get_Current_m757645588,
	U3CStartU3Ec__Iterator0_t3220237554_CustomAttributesCacheGenerator_U3CStartU3Ec__Iterator0_System_Collections_IEnumerator_get_Current_m290565900,
	U3CStartU3Ec__Iterator0_t3220237554_CustomAttributesCacheGenerator_U3CStartU3Ec__Iterator0_Dispose_m3787507231,
	U3CStartU3Ec__Iterator0_t3220237554_CustomAttributesCacheGenerator_U3CStartU3Ec__Iterator0_Reset_m2824154053,
	AnimationTriggers_t3244928895_CustomAttributesCacheGenerator_m_NormalTrigger,
	AnimationTriggers_t3244928895_CustomAttributesCacheGenerator_m_HighlightedTrigger,
	AnimationTriggers_t3244928895_CustomAttributesCacheGenerator_m_PressedTrigger,
	AnimationTriggers_t3244928895_CustomAttributesCacheGenerator_m_DisabledTrigger,
	Button_t2872111280_CustomAttributesCacheGenerator,
	Button_t2872111280_CustomAttributesCacheGenerator_m_OnClick,
	Button_t2872111280_CustomAttributesCacheGenerator_Button_OnFinishSubmit_m1646528571,
	U3COnFinishSubmitU3Ec__Iterator0_t99135383_CustomAttributesCacheGenerator,
	U3COnFinishSubmitU3Ec__Iterator0_t99135383_CustomAttributesCacheGenerator_U3COnFinishSubmitU3Ec__Iterator0__ctor_m1529573737,
	U3COnFinishSubmitU3Ec__Iterator0_t99135383_CustomAttributesCacheGenerator_U3COnFinishSubmitU3Ec__Iterator0_System_Collections_Generic_IEnumeratorU3CobjectU3E_get_Current_m1823105495,
	U3COnFinishSubmitU3Ec__Iterator0_t99135383_CustomAttributesCacheGenerator_U3COnFinishSubmitU3Ec__Iterator0_System_Collections_IEnumerator_get_Current_m3369622463,
	U3COnFinishSubmitU3Ec__Iterator0_t99135383_CustomAttributesCacheGenerator_U3COnFinishSubmitU3Ec__Iterator0_Dispose_m998931244,
	U3COnFinishSubmitU3Ec__Iterator0_t99135383_CustomAttributesCacheGenerator_U3COnFinishSubmitU3Ec__Iterator0_Reset_m2080388334,
	CanvasUpdateRegistry_t1780385998_CustomAttributesCacheGenerator_U3CU3Ef__mgU24cache0,
	ColorBlock_t2652774230_CustomAttributesCacheGenerator_m_NormalColor,
	ColorBlock_t2652774230_CustomAttributesCacheGenerator_m_HighlightedColor,
	ColorBlock_t2652774230_CustomAttributesCacheGenerator_m_PressedColor,
	ColorBlock_t2652774230_CustomAttributesCacheGenerator_m_DisabledColor,
	ColorBlock_t2652774230_CustomAttributesCacheGenerator_m_ColorMultiplier,
	ColorBlock_t2652774230_CustomAttributesCacheGenerator_m_FadeDuration,
	Dropdown_t1985816271_CustomAttributesCacheGenerator,
	Dropdown_t1985816271_CustomAttributesCacheGenerator_m_Template,
	Dropdown_t1985816271_CustomAttributesCacheGenerator_m_CaptionText,
	Dropdown_t1985816271_CustomAttributesCacheGenerator_m_CaptionImage,
	Dropdown_t1985816271_CustomAttributesCacheGenerator_m_ItemText,
	Dropdown_t1985816271_CustomAttributesCacheGenerator_m_ItemImage,
	Dropdown_t1985816271_CustomAttributesCacheGenerator_m_Value,
	Dropdown_t1985816271_CustomAttributesCacheGenerator_m_Options,
	Dropdown_t1985816271_CustomAttributesCacheGenerator_m_OnValueChanged,
	Dropdown_t1985816271_CustomAttributesCacheGenerator_Dropdown_DelayedDestroyDropdownList_m1497053282,
	DropdownItem_t4139978805_CustomAttributesCacheGenerator_m_Text,
	DropdownItem_t4139978805_CustomAttributesCacheGenerator_m_Image,
	DropdownItem_t4139978805_CustomAttributesCacheGenerator_m_RectTransform,
	DropdownItem_t4139978805_CustomAttributesCacheGenerator_m_Toggle,
	OptionData_t2420267500_CustomAttributesCacheGenerator_m_Text,
	OptionData_t2420267500_CustomAttributesCacheGenerator_m_Image,
	OptionDataList_t2653737080_CustomAttributesCacheGenerator_m_Options,
	U3CShowU3Ec__AnonStorey1_t2089497532_CustomAttributesCacheGenerator,
	U3CDelayedDestroyDropdownListU3Ec__Iterator0_t3461999471_CustomAttributesCacheGenerator,
	U3CDelayedDestroyDropdownListU3Ec__Iterator0_t3461999471_CustomAttributesCacheGenerator_U3CDelayedDestroyDropdownListU3Ec__Iterator0__ctor_m3589639289,
	U3CDelayedDestroyDropdownListU3Ec__Iterator0_t3461999471_CustomAttributesCacheGenerator_U3CDelayedDestroyDropdownListU3Ec__Iterator0_System_Collections_Generic_IEnumeratorU3CobjectU3E_get_Current_m2099826311,
	U3CDelayedDestroyDropdownListU3Ec__Iterator0_t3461999471_CustomAttributesCacheGenerator_U3CDelayedDestroyDropdownListU3Ec__Iterator0_System_Collections_IEnumerator_get_Current_m622919791,
	U3CDelayedDestroyDropdownListU3Ec__Iterator0_t3461999471_CustomAttributesCacheGenerator_U3CDelayedDestroyDropdownListU3Ec__Iterator0_Dispose_m3973609370,
	U3CDelayedDestroyDropdownListU3Ec__Iterator0_t3461999471_CustomAttributesCacheGenerator_U3CDelayedDestroyDropdownListU3Ec__Iterator0_Reset_m3485957852,
	FontData_t2614388407_CustomAttributesCacheGenerator_m_Font,
	FontData_t2614388407_CustomAttributesCacheGenerator_m_FontSize,
	FontData_t2614388407_CustomAttributesCacheGenerator_m_FontStyle,
	FontData_t2614388407_CustomAttributesCacheGenerator_m_BestFit,
	FontData_t2614388407_CustomAttributesCacheGenerator_m_MinSize,
	FontData_t2614388407_CustomAttributesCacheGenerator_m_MaxSize,
	FontData_t2614388407_CustomAttributesCacheGenerator_m_Alignment,
	FontData_t2614388407_CustomAttributesCacheGenerator_m_AlignByGeometry,
	FontData_t2614388407_CustomAttributesCacheGenerator_m_RichText,
	FontData_t2614388407_CustomAttributesCacheGenerator_m_HorizontalOverflow,
	FontData_t2614388407_CustomAttributesCacheGenerator_m_VerticalOverflow,
	FontData_t2614388407_CustomAttributesCacheGenerator_m_LineSpacing,
	FontUpdateTracker_t2633059652_CustomAttributesCacheGenerator_U3CU3Ef__mgU24cache0,
	FontUpdateTracker_t2633059652_CustomAttributesCacheGenerator_U3CU3Ef__mgU24cache1,
	Graphic_t2426225576_CustomAttributesCacheGenerator,
	Graphic_t2426225576_CustomAttributesCacheGenerator_m_Material,
	Graphic_t2426225576_CustomAttributesCacheGenerator_m_Color,
	Graphic_t2426225576_CustomAttributesCacheGenerator_m_RaycastTarget,
	Graphic_t2426225576_CustomAttributesCacheGenerator_U3CuseLegacyMeshGenerationU3Ek__BackingField,
	Graphic_t2426225576_CustomAttributesCacheGenerator_Graphic_get_useLegacyMeshGeneration_m1366444625,
	Graphic_t2426225576_CustomAttributesCacheGenerator_Graphic_set_useLegacyMeshGeneration_m3023904722,
	Graphic_t2426225576_CustomAttributesCacheGenerator_Graphic_OnFillVBO_m1723985607,
	Graphic_t2426225576_CustomAttributesCacheGenerator_Graphic_OnPopulateMesh_m2598985015,
	GraphicRaycaster_t410733016_CustomAttributesCacheGenerator,
	GraphicRaycaster_t410733016_CustomAttributesCacheGenerator_m_IgnoreReversedGraphics,
	GraphicRaycaster_t410733016_CustomAttributesCacheGenerator_m_BlockingObjects,
	GraphicRaycaster_t410733016_CustomAttributesCacheGenerator_m_BlockingMask,
	GraphicRaycaster_t410733016_CustomAttributesCacheGenerator_U3CU3Ef__amU24cache0,
	GraphicRaycaster_t410733016_CustomAttributesCacheGenerator_GraphicRaycaster_U3CRaycastU3Em__0_m3971200721,
	IGraphicEnabledDisabled_t858530280_CustomAttributesCacheGenerator,
	Image_t2042527209_CustomAttributesCacheGenerator,
	Image_t2042527209_CustomAttributesCacheGenerator_m_Sprite,
	Image_t2042527209_CustomAttributesCacheGenerator_m_Type,
	Image_t2042527209_CustomAttributesCacheGenerator_m_PreserveAspect,
	Image_t2042527209_CustomAttributesCacheGenerator_m_FillCenter,
	Image_t2042527209_CustomAttributesCacheGenerator_m_FillMethod,
	Image_t2042527209_CustomAttributesCacheGenerator_m_FillAmount,
	Image_t2042527209_CustomAttributesCacheGenerator_m_FillClockwise,
	Image_t2042527209_CustomAttributesCacheGenerator_m_FillOrigin,
	Image_t2042527209_CustomAttributesCacheGenerator_Image_t2042527209____eventAlphaThreshold_PropertyInfo,
	IMask_t3205327603_CustomAttributesCacheGenerator,
	InputField_t1631627530_CustomAttributesCacheGenerator,
	InputField_t1631627530_CustomAttributesCacheGenerator_m_TextComponent,
	InputField_t1631627530_CustomAttributesCacheGenerator_m_Placeholder,
	InputField_t1631627530_CustomAttributesCacheGenerator_m_ContentType,
	InputField_t1631627530_CustomAttributesCacheGenerator_m_InputType,
	InputField_t1631627530_CustomAttributesCacheGenerator_m_AsteriskChar,
	InputField_t1631627530_CustomAttributesCacheGenerator_m_KeyboardType,
	InputField_t1631627530_CustomAttributesCacheGenerator_m_LineType,
	InputField_t1631627530_CustomAttributesCacheGenerator_m_HideMobileInput,
	InputField_t1631627530_CustomAttributesCacheGenerator_m_CharacterValidation,
	InputField_t1631627530_CustomAttributesCacheGenerator_m_CharacterLimit,
	InputField_t1631627530_CustomAttributesCacheGenerator_m_OnEndEdit,
	InputField_t1631627530_CustomAttributesCacheGenerator_m_OnValueChanged,
	InputField_t1631627530_CustomAttributesCacheGenerator_m_OnValidateInput,
	InputField_t1631627530_CustomAttributesCacheGenerator_m_CaretColor,
	InputField_t1631627530_CustomAttributesCacheGenerator_m_CustomCaretColor,
	InputField_t1631627530_CustomAttributesCacheGenerator_m_SelectionColor,
	InputField_t1631627530_CustomAttributesCacheGenerator_m_Text,
	InputField_t1631627530_CustomAttributesCacheGenerator_m_CaretBlinkRate,
	InputField_t1631627530_CustomAttributesCacheGenerator_m_CaretWidth,
	InputField_t1631627530_CustomAttributesCacheGenerator_m_ReadOnly,
	InputField_t1631627530_CustomAttributesCacheGenerator_InputField_CaretBlink_m3960486606,
	InputField_t1631627530_CustomAttributesCacheGenerator_InputField_ScreenToLocal_m2281574224,
	InputField_t1631627530_CustomAttributesCacheGenerator_InputField_MouseDragOutsideRect_m3758282095,
	InputField_t1631627530_CustomAttributesCacheGenerator_InputField_SetToCustomIfContentTypeIsNot_m2121105067____allowedContentTypes0,
	InputField_t1631627530_CustomAttributesCacheGenerator_InputField_t1631627530____onValueChange_PropertyInfo,
	U3CCaretBlinkU3Ec__Iterator0_t906898126_CustomAttributesCacheGenerator,
	U3CCaretBlinkU3Ec__Iterator0_t906898126_CustomAttributesCacheGenerator_U3CCaretBlinkU3Ec__Iterator0__ctor_m3164435928,
	U3CCaretBlinkU3Ec__Iterator0_t906898126_CustomAttributesCacheGenerator_U3CCaretBlinkU3Ec__Iterator0_System_Collections_Generic_IEnumeratorU3CobjectU3E_get_Current_m3541562536,
	U3CCaretBlinkU3Ec__Iterator0_t906898126_CustomAttributesCacheGenerator_U3CCaretBlinkU3Ec__Iterator0_System_Collections_IEnumerator_get_Current_m2309548992,
	U3CCaretBlinkU3Ec__Iterator0_t906898126_CustomAttributesCacheGenerator_U3CCaretBlinkU3Ec__Iterator0_Dispose_m3699146813,
	U3CCaretBlinkU3Ec__Iterator0_t906898126_CustomAttributesCacheGenerator_U3CCaretBlinkU3Ec__Iterator0_Reset_m2035249179,
	U3CMouseDragOutsideRectU3Ec__Iterator1_t2599668326_CustomAttributesCacheGenerator,
	U3CMouseDragOutsideRectU3Ec__Iterator1_t2599668326_CustomAttributesCacheGenerator_U3CMouseDragOutsideRectU3Ec__Iterator1__ctor_m1439320044,
	U3CMouseDragOutsideRectU3Ec__Iterator1_t2599668326_CustomAttributesCacheGenerator_U3CMouseDragOutsideRectU3Ec__Iterator1_System_Collections_Generic_IEnumeratorU3CobjectU3E_get_Current_m2602955272,
	U3CMouseDragOutsideRectU3Ec__Iterator1_t2599668326_CustomAttributesCacheGenerator_U3CMouseDragOutsideRectU3Ec__Iterator1_System_Collections_IEnumerator_get_Current_m561728752,
	U3CMouseDragOutsideRectU3Ec__Iterator1_t2599668326_CustomAttributesCacheGenerator_U3CMouseDragOutsideRectU3Ec__Iterator1_Dispose_m2134284531,
	U3CMouseDragOutsideRectU3Ec__Iterator1_t2599668326_CustomAttributesCacheGenerator_U3CMouseDragOutsideRectU3Ec__Iterator1_Reset_m3690615953,
	Mask_t2977958238_CustomAttributesCacheGenerator,
	Mask_t2977958238_CustomAttributesCacheGenerator_m_ShowMaskGraphic,
	Mask_t2977958238_CustomAttributesCacheGenerator_Mask_OnSiblingGraphicEnabledDisabled_m865494155,
	MaskableGraphic_t540192618_CustomAttributesCacheGenerator_m_IncludeForMasking,
	MaskableGraphic_t540192618_CustomAttributesCacheGenerator_m_OnCullStateChanged,
	MaskableGraphic_t540192618_CustomAttributesCacheGenerator_m_ShouldRecalculate,
	MaskableGraphic_t540192618_CustomAttributesCacheGenerator_MaskableGraphic_ParentMaskStateChanged_m3643747340,
	Navigation_t1571958496_CustomAttributesCacheGenerator_m_Mode,
	Navigation_t1571958496_CustomAttributesCacheGenerator_m_SelectOnUp,
	Navigation_t1571958496_CustomAttributesCacheGenerator_m_SelectOnDown,
	Navigation_t1571958496_CustomAttributesCacheGenerator_m_SelectOnLeft,
	Navigation_t1571958496_CustomAttributesCacheGenerator_m_SelectOnRight,
	Mode_t1081683921_CustomAttributesCacheGenerator,
	RawImage_t2749640213_CustomAttributesCacheGenerator,
	RawImage_t2749640213_CustomAttributesCacheGenerator_m_Texture,
	RawImage_t2749640213_CustomAttributesCacheGenerator_m_UVRect,
	RectMask2D_t1156185964_CustomAttributesCacheGenerator,
	Scrollbar_t3248359358_CustomAttributesCacheGenerator,
	Scrollbar_t3248359358_CustomAttributesCacheGenerator_m_HandleRect,
	Scrollbar_t3248359358_CustomAttributesCacheGenerator_m_Direction,
	Scrollbar_t3248359358_CustomAttributesCacheGenerator_m_Value,
	Scrollbar_t3248359358_CustomAttributesCacheGenerator_m_Size,
	Scrollbar_t3248359358_CustomAttributesCacheGenerator_m_NumberOfSteps,
	Scrollbar_t3248359358_CustomAttributesCacheGenerator_m_OnValueChanged,
	Scrollbar_t3248359358_CustomAttributesCacheGenerator_Scrollbar_ClickRepeat_m3403943364,
	U3CClickRepeatU3Ec__Iterator0_t4156771994_CustomAttributesCacheGenerator,
	U3CClickRepeatU3Ec__Iterator0_t4156771994_CustomAttributesCacheGenerator_U3CClickRepeatU3Ec__Iterator0__ctor_m1515509136,
	U3CClickRepeatU3Ec__Iterator0_t4156771994_CustomAttributesCacheGenerator_U3CClickRepeatU3Ec__Iterator0_System_Collections_Generic_IEnumeratorU3CobjectU3E_get_Current_m3444627780,
	U3CClickRepeatU3Ec__Iterator0_t4156771994_CustomAttributesCacheGenerator_U3CClickRepeatU3Ec__Iterator0_System_Collections_IEnumerator_get_Current_m4049780396,
	U3CClickRepeatU3Ec__Iterator0_t4156771994_CustomAttributesCacheGenerator_U3CClickRepeatU3Ec__Iterator0_Dispose_m684116271,
	U3CClickRepeatU3Ec__Iterator0_t4156771994_CustomAttributesCacheGenerator_U3CClickRepeatU3Ec__Iterator0_Reset_m1177396749,
	ScrollRect_t1199013257_CustomAttributesCacheGenerator,
	ScrollRect_t1199013257_CustomAttributesCacheGenerator_m_Content,
	ScrollRect_t1199013257_CustomAttributesCacheGenerator_m_Horizontal,
	ScrollRect_t1199013257_CustomAttributesCacheGenerator_m_Vertical,
	ScrollRect_t1199013257_CustomAttributesCacheGenerator_m_MovementType,
	ScrollRect_t1199013257_CustomAttributesCacheGenerator_m_Elasticity,
	ScrollRect_t1199013257_CustomAttributesCacheGenerator_m_Inertia,
	ScrollRect_t1199013257_CustomAttributesCacheGenerator_m_DecelerationRate,
	ScrollRect_t1199013257_CustomAttributesCacheGenerator_m_ScrollSensitivity,
	ScrollRect_t1199013257_CustomAttributesCacheGenerator_m_Viewport,
	ScrollRect_t1199013257_CustomAttributesCacheGenerator_m_HorizontalScrollbar,
	ScrollRect_t1199013257_CustomAttributesCacheGenerator_m_VerticalScrollbar,
	ScrollRect_t1199013257_CustomAttributesCacheGenerator_m_HorizontalScrollbarVisibility,
	ScrollRect_t1199013257_CustomAttributesCacheGenerator_m_VerticalScrollbarVisibility,
	ScrollRect_t1199013257_CustomAttributesCacheGenerator_m_HorizontalScrollbarSpacing,
	ScrollRect_t1199013257_CustomAttributesCacheGenerator_m_VerticalScrollbarSpacing,
	ScrollRect_t1199013257_CustomAttributesCacheGenerator_m_OnValueChanged,
	Selectable_t1490392188_CustomAttributesCacheGenerator,
	Selectable_t1490392188_CustomAttributesCacheGenerator_m_Navigation,
	Selectable_t1490392188_CustomAttributesCacheGenerator_m_Transition,
	Selectable_t1490392188_CustomAttributesCacheGenerator_m_Colors,
	Selectable_t1490392188_CustomAttributesCacheGenerator_m_SpriteState,
	Selectable_t1490392188_CustomAttributesCacheGenerator_m_AnimationTriggers,
	Selectable_t1490392188_CustomAttributesCacheGenerator_m_Interactable,
	Selectable_t1490392188_CustomAttributesCacheGenerator_m_TargetGraphic,
	Selectable_t1490392188_CustomAttributesCacheGenerator_U3CisPointerInsideU3Ek__BackingField,
	Selectable_t1490392188_CustomAttributesCacheGenerator_U3CisPointerDownU3Ek__BackingField,
	Selectable_t1490392188_CustomAttributesCacheGenerator_U3ChasSelectionU3Ek__BackingField,
	Selectable_t1490392188_CustomAttributesCacheGenerator_Selectable_get_isPointerInside_m3162215687,
	Selectable_t1490392188_CustomAttributesCacheGenerator_Selectable_set_isPointerInside_m375338048,
	Selectable_t1490392188_CustomAttributesCacheGenerator_Selectable_get_isPointerDown_m774209881,
	Selectable_t1490392188_CustomAttributesCacheGenerator_Selectable_set_isPointerDown_m2177301980,
	Selectable_t1490392188_CustomAttributesCacheGenerator_Selectable_get_hasSelection_m307792052,
	Selectable_t1490392188_CustomAttributesCacheGenerator_Selectable_set_hasSelection_m2076391827,
	Selectable_t1490392188_CustomAttributesCacheGenerator_Selectable_IsPressed_m3349168065,
	Slider_t297367283_CustomAttributesCacheGenerator,
	Slider_t297367283_CustomAttributesCacheGenerator_m_FillRect,
	Slider_t297367283_CustomAttributesCacheGenerator_m_HandleRect,
	Slider_t297367283_CustomAttributesCacheGenerator_m_Direction,
	Slider_t297367283_CustomAttributesCacheGenerator_m_MinValue,
	Slider_t297367283_CustomAttributesCacheGenerator_m_MaxValue,
	Slider_t297367283_CustomAttributesCacheGenerator_m_WholeNumbers,
	Slider_t297367283_CustomAttributesCacheGenerator_m_Value,
	Slider_t297367283_CustomAttributesCacheGenerator_m_OnValueChanged,
	SpriteState_t1353336012_CustomAttributesCacheGenerator_m_HighlightedSprite,
	SpriteState_t1353336012_CustomAttributesCacheGenerator_m_PressedSprite,
	SpriteState_t1353336012_CustomAttributesCacheGenerator_m_DisabledSprite,
	StencilMaterial_t1630303189_CustomAttributesCacheGenerator_StencilMaterial_Add_m1745413071,
	Text_t356221433_CustomAttributesCacheGenerator,
	Text_t356221433_CustomAttributesCacheGenerator_m_FontData,
	Text_t356221433_CustomAttributesCacheGenerator_m_Text,
	Toggle_t3976754468_CustomAttributesCacheGenerator,
	Toggle_t3976754468_CustomAttributesCacheGenerator_m_Group,
	Toggle_t3976754468_CustomAttributesCacheGenerator_m_IsOn,
	ToggleGroup_t1030026315_CustomAttributesCacheGenerator,
	ToggleGroup_t1030026315_CustomAttributesCacheGenerator_m_AllowSwitchOff,
	ToggleGroup_t1030026315_CustomAttributesCacheGenerator_U3CU3Ef__amU24cache0,
	ToggleGroup_t1030026315_CustomAttributesCacheGenerator_U3CU3Ef__amU24cache1,
	ToggleGroup_t1030026315_CustomAttributesCacheGenerator_ToggleGroup_U3CAnyTogglesOnU3Em__0_m1218114300,
	ToggleGroup_t1030026315_CustomAttributesCacheGenerator_ToggleGroup_U3CActiveTogglesU3Em__1_m4052653494,
	AspectRatioFitter_t3114550109_CustomAttributesCacheGenerator,
	AspectRatioFitter_t3114550109_CustomAttributesCacheGenerator_m_AspectMode,
	AspectRatioFitter_t3114550109_CustomAttributesCacheGenerator_m_AspectRatio,
	CanvasScaler_t2574720772_CustomAttributesCacheGenerator,
	CanvasScaler_t2574720772_CustomAttributesCacheGenerator_m_UiScaleMode,
	CanvasScaler_t2574720772_CustomAttributesCacheGenerator_m_ReferencePixelsPerUnit,
	CanvasScaler_t2574720772_CustomAttributesCacheGenerator_m_ScaleFactor,
	CanvasScaler_t2574720772_CustomAttributesCacheGenerator_m_ReferenceResolution,
	CanvasScaler_t2574720772_CustomAttributesCacheGenerator_m_ScreenMatchMode,
	CanvasScaler_t2574720772_CustomAttributesCacheGenerator_m_MatchWidthOrHeight,
	CanvasScaler_t2574720772_CustomAttributesCacheGenerator_m_PhysicalUnit,
	CanvasScaler_t2574720772_CustomAttributesCacheGenerator_m_FallbackScreenDPI,
	CanvasScaler_t2574720772_CustomAttributesCacheGenerator_m_DefaultSpriteDPI,
	CanvasScaler_t2574720772_CustomAttributesCacheGenerator_m_DynamicPixelsPerUnit,
	ContentSizeFitter_t1325211874_CustomAttributesCacheGenerator,
	ContentSizeFitter_t1325211874_CustomAttributesCacheGenerator_m_HorizontalFit,
	ContentSizeFitter_t1325211874_CustomAttributesCacheGenerator_m_VerticalFit,
	GridLayoutGroup_t1515633077_CustomAttributesCacheGenerator,
	GridLayoutGroup_t1515633077_CustomAttributesCacheGenerator_m_StartCorner,
	GridLayoutGroup_t1515633077_CustomAttributesCacheGenerator_m_StartAxis,
	GridLayoutGroup_t1515633077_CustomAttributesCacheGenerator_m_CellSize,
	GridLayoutGroup_t1515633077_CustomAttributesCacheGenerator_m_Spacing,
	GridLayoutGroup_t1515633077_CustomAttributesCacheGenerator_m_Constraint,
	GridLayoutGroup_t1515633077_CustomAttributesCacheGenerator_m_ConstraintCount,
	HorizontalLayoutGroup_t2875670365_CustomAttributesCacheGenerator,
	HorizontalOrVerticalLayoutGroup_t1968298610_CustomAttributesCacheGenerator_m_Spacing,
	HorizontalOrVerticalLayoutGroup_t1968298610_CustomAttributesCacheGenerator_m_ChildForceExpandWidth,
	HorizontalOrVerticalLayoutGroup_t1968298610_CustomAttributesCacheGenerator_m_ChildForceExpandHeight,
	HorizontalOrVerticalLayoutGroup_t1968298610_CustomAttributesCacheGenerator_m_ChildControlWidth,
	HorizontalOrVerticalLayoutGroup_t1968298610_CustomAttributesCacheGenerator_m_ChildControlHeight,
	LayoutElement_t2808691390_CustomAttributesCacheGenerator,
	LayoutElement_t2808691390_CustomAttributesCacheGenerator_m_IgnoreLayout,
	LayoutElement_t2808691390_CustomAttributesCacheGenerator_m_MinWidth,
	LayoutElement_t2808691390_CustomAttributesCacheGenerator_m_MinHeight,
	LayoutElement_t2808691390_CustomAttributesCacheGenerator_m_PreferredWidth,
	LayoutElement_t2808691390_CustomAttributesCacheGenerator_m_PreferredHeight,
	LayoutElement_t2808691390_CustomAttributesCacheGenerator_m_FlexibleWidth,
	LayoutElement_t2808691390_CustomAttributesCacheGenerator_m_FlexibleHeight,
	LayoutGroup_t3962498969_CustomAttributesCacheGenerator,
	LayoutGroup_t3962498969_CustomAttributesCacheGenerator_m_Padding,
	LayoutGroup_t3962498969_CustomAttributesCacheGenerator_m_ChildAlignment,
	LayoutGroup_t3962498969_CustomAttributesCacheGenerator_LayoutGroup_DelayedSetDirty_m4276695617,
	U3CDelayedSetDirtyU3Ec__Iterator0_t3228926346_CustomAttributesCacheGenerator,
	U3CDelayedSetDirtyU3Ec__Iterator0_t3228926346_CustomAttributesCacheGenerator_U3CDelayedSetDirtyU3Ec__Iterator0__ctor_m1917915688,
	U3CDelayedSetDirtyU3Ec__Iterator0_t3228926346_CustomAttributesCacheGenerator_U3CDelayedSetDirtyU3Ec__Iterator0_System_Collections_Generic_IEnumeratorU3CobjectU3E_get_Current_m2210283424,
	U3CDelayedSetDirtyU3Ec__Iterator0_t3228926346_CustomAttributesCacheGenerator_U3CDelayedSetDirtyU3Ec__Iterator0_System_Collections_IEnumerator_get_Current_m851854792,
	U3CDelayedSetDirtyU3Ec__Iterator0_t3228926346_CustomAttributesCacheGenerator_U3CDelayedSetDirtyU3Ec__Iterator0_Dispose_m950529291,
	U3CDelayedSetDirtyU3Ec__Iterator0_t3228926346_CustomAttributesCacheGenerator_U3CDelayedSetDirtyU3Ec__Iterator0_Reset_m955604653,
	LayoutRebuilder_t2155218138_CustomAttributesCacheGenerator_U3CU3Ef__mgU24cache0,
	LayoutRebuilder_t2155218138_CustomAttributesCacheGenerator_U3CU3Ef__amU24cache0,
	LayoutRebuilder_t2155218138_CustomAttributesCacheGenerator_U3CU3Ef__amU24cache1,
	LayoutRebuilder_t2155218138_CustomAttributesCacheGenerator_U3CU3Ef__amU24cache2,
	LayoutRebuilder_t2155218138_CustomAttributesCacheGenerator_U3CU3Ef__amU24cache3,
	LayoutRebuilder_t2155218138_CustomAttributesCacheGenerator_U3CU3Ef__amU24cache4,
	LayoutRebuilder_t2155218138_CustomAttributesCacheGenerator_LayoutRebuilder_U3Cs_RebuildersU3Em__0_m3768099182,
	LayoutRebuilder_t2155218138_CustomAttributesCacheGenerator_LayoutRebuilder_U3CStripDisabledBehavioursFromListU3Em__1_m3569508057,
	LayoutRebuilder_t2155218138_CustomAttributesCacheGenerator_LayoutRebuilder_U3CRebuildU3Em__2_m3239837417,
	LayoutRebuilder_t2155218138_CustomAttributesCacheGenerator_LayoutRebuilder_U3CRebuildU3Em__3_m777184612,
	LayoutRebuilder_t2155218138_CustomAttributesCacheGenerator_LayoutRebuilder_U3CRebuildU3Em__4_m2524920159,
	LayoutRebuilder_t2155218138_CustomAttributesCacheGenerator_LayoutRebuilder_U3CRebuildU3Em__5_m863475162,
	LayoutUtility_t4076838048_CustomAttributesCacheGenerator_U3CU3Ef__amU24cache0,
	LayoutUtility_t4076838048_CustomAttributesCacheGenerator_U3CU3Ef__amU24cache1,
	LayoutUtility_t4076838048_CustomAttributesCacheGenerator_U3CU3Ef__amU24cache2,
	LayoutUtility_t4076838048_CustomAttributesCacheGenerator_U3CU3Ef__amU24cache3,
	LayoutUtility_t4076838048_CustomAttributesCacheGenerator_U3CU3Ef__amU24cache4,
	LayoutUtility_t4076838048_CustomAttributesCacheGenerator_U3CU3Ef__amU24cache5,
	LayoutUtility_t4076838048_CustomAttributesCacheGenerator_U3CU3Ef__amU24cache6,
	LayoutUtility_t4076838048_CustomAttributesCacheGenerator_U3CU3Ef__amU24cache7,
	LayoutUtility_t4076838048_CustomAttributesCacheGenerator_LayoutUtility_U3CGetMinWidthU3Em__0_m2819807638,
	LayoutUtility_t4076838048_CustomAttributesCacheGenerator_LayoutUtility_U3CGetPreferredWidthU3Em__1_m858056744,
	LayoutUtility_t4076838048_CustomAttributesCacheGenerator_LayoutUtility_U3CGetPreferredWidthU3Em__2_m2944504345,
	LayoutUtility_t4076838048_CustomAttributesCacheGenerator_LayoutUtility_U3CGetFlexibleWidthU3Em__3_m3345200332,
	LayoutUtility_t4076838048_CustomAttributesCacheGenerator_LayoutUtility_U3CGetMinHeightU3Em__4_m1769295917,
	LayoutUtility_t4076838048_CustomAttributesCacheGenerator_LayoutUtility_U3CGetPreferredHeightU3Em__5_m1524880643,
	LayoutUtility_t4076838048_CustomAttributesCacheGenerator_LayoutUtility_U3CGetPreferredHeightU3Em__6_m72173670,
	LayoutUtility_t4076838048_CustomAttributesCacheGenerator_LayoutUtility_U3CGetFlexibleHeightU3Em__7_m947156537,
	VerticalLayoutGroup_t2468316403_CustomAttributesCacheGenerator,
	IndexedSet_1_t573160278_CustomAttributesCacheGenerator,
	ListPool_1_t1984115411_CustomAttributesCacheGenerator_ListPool_1_U3Cs_ListPoolU3Em__0_m2509427629,
	ObjectPool_1_t4265859154_CustomAttributesCacheGenerator_U3CcountAllU3Ek__BackingField,
	ObjectPool_1_t4265859154_CustomAttributesCacheGenerator_ObjectPool_1_get_countAll_m794975934,
	ObjectPool_1_t4265859154_CustomAttributesCacheGenerator_ObjectPool_1_set_countAll_m1508336803,
	BaseVertexEffect_t2504093552_CustomAttributesCacheGenerator,
	BaseVertexEffect_t2504093552_CustomAttributesCacheGenerator_BaseVertexEffect_ModifyVertices_m3446986347,
	BaseMeshEffect_t1728560551_CustomAttributesCacheGenerator,
	IVertexModifier_t3366215544_CustomAttributesCacheGenerator,
	IVertexModifier_t3366215544_CustomAttributesCacheGenerator_IVertexModifier_ModifyVertices_m3143607399,
	IMeshModifier_t2303987655_CustomAttributesCacheGenerator_IMeshModifier_ModifyMesh_m1735210671,
	Outline_t1417504278_CustomAttributesCacheGenerator,
	PositionAsUV1_t1102546563_CustomAttributesCacheGenerator,
	Shadow_t4269599528_CustomAttributesCacheGenerator,
	Shadow_t4269599528_CustomAttributesCacheGenerator_m_EffectColor,
	Shadow_t4269599528_CustomAttributesCacheGenerator_m_EffectDistance,
	Shadow_t4269599528_CustomAttributesCacheGenerator_m_UseGraphicAlpha,
	U3CPrivateImplementationDetailsU3E_t1486305141_CustomAttributesCacheGenerator,
	g_AssemblyU2DCSharp_Assembly_CustomAttributesCacheGenerator,
};
