﻿#pragma once

#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <stdint.h>

// System.Net.Sockets.Socket
struct Socket_t3821512045;
// System.Byte[]
struct ByteU5BU5D_t3397334013;
// System.Text.StringBuilder
struct StringBuilder_t1221177846;

#include "mscorlib_System_Object2689449295.h"

#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// StateObject
struct  StateObject_t1293687898  : public Il2CppObject
{
public:
	// System.Net.Sockets.Socket StateObject::workSocket
	Socket_t3821512045 * ___workSocket_0;
	// System.Byte[] StateObject::buffer
	ByteU5BU5D_t3397334013* ___buffer_2;
	// System.Text.StringBuilder StateObject::sb
	StringBuilder_t1221177846 * ___sb_3;

public:
	inline static int32_t get_offset_of_workSocket_0() { return static_cast<int32_t>(offsetof(StateObject_t1293687898, ___workSocket_0)); }
	inline Socket_t3821512045 * get_workSocket_0() const { return ___workSocket_0; }
	inline Socket_t3821512045 ** get_address_of_workSocket_0() { return &___workSocket_0; }
	inline void set_workSocket_0(Socket_t3821512045 * value)
	{
		___workSocket_0 = value;
		Il2CppCodeGenWriteBarrier(&___workSocket_0, value);
	}

	inline static int32_t get_offset_of_buffer_2() { return static_cast<int32_t>(offsetof(StateObject_t1293687898, ___buffer_2)); }
	inline ByteU5BU5D_t3397334013* get_buffer_2() const { return ___buffer_2; }
	inline ByteU5BU5D_t3397334013** get_address_of_buffer_2() { return &___buffer_2; }
	inline void set_buffer_2(ByteU5BU5D_t3397334013* value)
	{
		___buffer_2 = value;
		Il2CppCodeGenWriteBarrier(&___buffer_2, value);
	}

	inline static int32_t get_offset_of_sb_3() { return static_cast<int32_t>(offsetof(StateObject_t1293687898, ___sb_3)); }
	inline StringBuilder_t1221177846 * get_sb_3() const { return ___sb_3; }
	inline StringBuilder_t1221177846 ** get_address_of_sb_3() { return &___sb_3; }
	inline void set_sb_3(StringBuilder_t1221177846 * value)
	{
		___sb_3 = value;
		Il2CppCodeGenWriteBarrier(&___sb_3, value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
