﻿#pragma once

#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <stdint.h>
#include <assert.h>
#include <exception>

// Mono.Globalization.Unicode.Level2Map
struct Level2Map_t3322505726;

#include "codegen/il2cpp-codegen.h"

// System.Void Mono.Globalization.Unicode.Level2Map::.ctor(System.Byte,System.Byte)
extern "C"  void Level2Map__ctor_m542306287 (Level2Map_t3322505726 * __this, uint8_t ___source0, uint8_t ___replace1, const MethodInfo* method) IL2CPP_METHOD_ATTR;
