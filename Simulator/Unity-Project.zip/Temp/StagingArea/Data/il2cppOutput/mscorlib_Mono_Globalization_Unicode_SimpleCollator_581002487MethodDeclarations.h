﻿#pragma once

#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <stdint.h>
#include <assert.h>
#include <exception>

// Mono.Globalization.Unicode.SimpleCollator/PreviousInfo
struct PreviousInfo_t581002487;
struct PreviousInfo_t581002487_marshaled_pinvoke;
struct PreviousInfo_t581002487_marshaled_com;

#include "codegen/il2cpp-codegen.h"
#include "mscorlib_Mono_Globalization_Unicode_SimpleCollator_581002487.h"

// System.Void Mono.Globalization.Unicode.SimpleCollator/PreviousInfo::.ctor(System.Boolean)
extern "C"  void PreviousInfo__ctor_m1442166472 (PreviousInfo_t581002487 * __this, bool ___dummy0, const MethodInfo* method) IL2CPP_METHOD_ATTR;

// Methods for marshaling
struct PreviousInfo_t581002487;
struct PreviousInfo_t581002487_marshaled_pinvoke;

extern "C" void PreviousInfo_t581002487_marshal_pinvoke(const PreviousInfo_t581002487& unmarshaled, PreviousInfo_t581002487_marshaled_pinvoke& marshaled);
extern "C" void PreviousInfo_t581002487_marshal_pinvoke_back(const PreviousInfo_t581002487_marshaled_pinvoke& marshaled, PreviousInfo_t581002487& unmarshaled);
extern "C" void PreviousInfo_t581002487_marshal_pinvoke_cleanup(PreviousInfo_t581002487_marshaled_pinvoke& marshaled);

// Methods for marshaling
struct PreviousInfo_t581002487;
struct PreviousInfo_t581002487_marshaled_com;

extern "C" void PreviousInfo_t581002487_marshal_com(const PreviousInfo_t581002487& unmarshaled, PreviousInfo_t581002487_marshaled_com& marshaled);
extern "C" void PreviousInfo_t581002487_marshal_com_back(const PreviousInfo_t581002487_marshaled_com& marshaled, PreviousInfo_t581002487& unmarshaled);
extern "C" void PreviousInfo_t581002487_marshal_com_cleanup(PreviousInfo_t581002487_marshaled_com& marshaled);
