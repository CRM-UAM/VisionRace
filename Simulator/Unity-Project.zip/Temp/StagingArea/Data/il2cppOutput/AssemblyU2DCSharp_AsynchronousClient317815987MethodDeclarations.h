﻿#pragma once

#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <stdint.h>
#include <assert.h>
#include <exception>

// AsynchronousClient
struct AsynchronousClient_t317815987;
// System.IAsyncResult
struct IAsyncResult_t1999651008;
// System.Net.Sockets.Socket
struct Socket_t3821512045;
// System.String
struct String_t;

#include "codegen/il2cpp-codegen.h"
#include "System_System_Net_Sockets_Socket3821512045.h"
#include "mscorlib_System_String2029220233.h"

// System.Void AsynchronousClient::.ctor()
extern "C"  void AsynchronousClient__ctor_m1866306922 (AsynchronousClient_t317815987 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void AsynchronousClient::StartClient()
extern "C"  void AsynchronousClient_StartClient_m2553350183 (Il2CppObject * __this /* static, unused */, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void AsynchronousClient::ConnectCallback(System.IAsyncResult)
extern "C"  void AsynchronousClient_ConnectCallback_m2950626480 (Il2CppObject * __this /* static, unused */, Il2CppObject * ___ar0, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void AsynchronousClient::Receive(System.Net.Sockets.Socket)
extern "C"  void AsynchronousClient_Receive_m1349460330 (Il2CppObject * __this /* static, unused */, Socket_t3821512045 * ___client0, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void AsynchronousClient::ReceiveCallback(System.IAsyncResult)
extern "C"  void AsynchronousClient_ReceiveCallback_m1498010861 (Il2CppObject * __this /* static, unused */, Il2CppObject * ___ar0, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void AsynchronousClient::Send(System.Net.Sockets.Socket,System.String)
extern "C"  void AsynchronousClient_Send_m2116773511 (Il2CppObject * __this /* static, unused */, Socket_t3821512045 * ___client0, String_t* ___data1, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void AsynchronousClient::SendCallback(System.IAsyncResult)
extern "C"  void AsynchronousClient_SendCallback_m2860036470 (Il2CppObject * __this /* static, unused */, Il2CppObject * ___ar0, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Void AsynchronousClient::.cctor()
extern "C"  void AsynchronousClient__cctor_m1515036749 (Il2CppObject * __this /* static, unused */, const MethodInfo* method) IL2CPP_METHOD_ATTR;
