﻿#pragma once

#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <stdint.h>
#include <assert.h>
#include <exception>

// System.Array
struct Il2CppArray;
// System.Object
struct Il2CppObject;

#include "codegen/il2cpp-codegen.h"
#include "mscorlib_System_Array_InternalEnumerator_1_gen1191988411.h"
#include "mscorlib_System_Array3829468939.h"
#include "mscorlib_System_Resources_ResourceReader_ResourceCa333236149.h"

// System.Void System.Array/InternalEnumerator`1<System.Resources.ResourceReader/ResourceCacheItem>::.ctor(System.Array)
extern "C"  void InternalEnumerator_1__ctor_m1182539814_gshared (InternalEnumerator_1_t1191988411 * __this, Il2CppArray * ___array0, const MethodInfo* method);
#define InternalEnumerator_1__ctor_m1182539814(__this, ___array0, method) ((  void (*) (InternalEnumerator_1_t1191988411 *, Il2CppArray *, const MethodInfo*))InternalEnumerator_1__ctor_m1182539814_gshared)(__this, ___array0, method)
// System.Void System.Array/InternalEnumerator`1<System.Resources.ResourceReader/ResourceCacheItem>::System.Collections.IEnumerator.Reset()
extern "C"  void InternalEnumerator_1_System_Collections_IEnumerator_Reset_m2821513122_gshared (InternalEnumerator_1_t1191988411 * __this, const MethodInfo* method);
#define InternalEnumerator_1_System_Collections_IEnumerator_Reset_m2821513122(__this, method) ((  void (*) (InternalEnumerator_1_t1191988411 *, const MethodInfo*))InternalEnumerator_1_System_Collections_IEnumerator_Reset_m2821513122_gshared)(__this, method)
// System.Object System.Array/InternalEnumerator`1<System.Resources.ResourceReader/ResourceCacheItem>::System.Collections.IEnumerator.get_Current()
extern "C"  Il2CppObject * InternalEnumerator_1_System_Collections_IEnumerator_get_Current_m1049770044_gshared (InternalEnumerator_1_t1191988411 * __this, const MethodInfo* method);
#define InternalEnumerator_1_System_Collections_IEnumerator_get_Current_m1049770044(__this, method) ((  Il2CppObject * (*) (InternalEnumerator_1_t1191988411 *, const MethodInfo*))InternalEnumerator_1_System_Collections_IEnumerator_get_Current_m1049770044_gshared)(__this, method)
// System.Void System.Array/InternalEnumerator`1<System.Resources.ResourceReader/ResourceCacheItem>::Dispose()
extern "C"  void InternalEnumerator_1_Dispose_m4175113225_gshared (InternalEnumerator_1_t1191988411 * __this, const MethodInfo* method);
#define InternalEnumerator_1_Dispose_m4175113225(__this, method) ((  void (*) (InternalEnumerator_1_t1191988411 *, const MethodInfo*))InternalEnumerator_1_Dispose_m4175113225_gshared)(__this, method)
// System.Boolean System.Array/InternalEnumerator`1<System.Resources.ResourceReader/ResourceCacheItem>::MoveNext()
extern "C"  bool InternalEnumerator_1_MoveNext_m2302237510_gshared (InternalEnumerator_1_t1191988411 * __this, const MethodInfo* method);
#define InternalEnumerator_1_MoveNext_m2302237510(__this, method) ((  bool (*) (InternalEnumerator_1_t1191988411 *, const MethodInfo*))InternalEnumerator_1_MoveNext_m2302237510_gshared)(__this, method)
// T System.Array/InternalEnumerator`1<System.Resources.ResourceReader/ResourceCacheItem>::get_Current()
extern "C"  ResourceCacheItem_t333236149  InternalEnumerator_1_get_Current_m789289033_gshared (InternalEnumerator_1_t1191988411 * __this, const MethodInfo* method);
#define InternalEnumerator_1_get_Current_m789289033(__this, method) ((  ResourceCacheItem_t333236149  (*) (InternalEnumerator_1_t1191988411 *, const MethodInfo*))InternalEnumerator_1_get_Current_m789289033_gshared)(__this, method)
