﻿#pragma once

#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <stdint.h>
#include <assert.h>
#include <exception>

// System.Byte[]
struct ByteU5BU5D_t3397334013;
// System.Object
struct Il2CppObject;

#include "codegen/il2cpp-codegen.h"
#include "mscorlib_System_ArraySegment_1_gen2594217482.h"
#include "mscorlib_System_Object2689449295.h"

// T[] System.ArraySegment`1<System.Byte>::get_Array()
extern "C"  ByteU5BU5D_t3397334013* ArraySegment_1_get_Array_m3660490680_gshared (ArraySegment_1_t2594217482 * __this, const MethodInfo* method);
#define ArraySegment_1_get_Array_m3660490680(__this, method) ((  ByteU5BU5D_t3397334013* (*) (ArraySegment_1_t2594217482 *, const MethodInfo*))ArraySegment_1_get_Array_m3660490680_gshared)(__this, method)
// System.Int32 System.ArraySegment`1<System.Byte>::get_Offset()
extern "C"  int32_t ArraySegment_1_get_Offset_m211308369_gshared (ArraySegment_1_t2594217482 * __this, const MethodInfo* method);
#define ArraySegment_1_get_Offset_m211308369(__this, method) ((  int32_t (*) (ArraySegment_1_t2594217482 *, const MethodInfo*))ArraySegment_1_get_Offset_m211308369_gshared)(__this, method)
// System.Int32 System.ArraySegment`1<System.Byte>::get_Count()
extern "C"  int32_t ArraySegment_1_get_Count_m4010248531_gshared (ArraySegment_1_t2594217482 * __this, const MethodInfo* method);
#define ArraySegment_1_get_Count_m4010248531(__this, method) ((  int32_t (*) (ArraySegment_1_t2594217482 *, const MethodInfo*))ArraySegment_1_get_Count_m4010248531_gshared)(__this, method)
// System.Boolean System.ArraySegment`1<System.Byte>::Equals(System.Object)
extern "C"  bool ArraySegment_1_Equals_m3670425628_gshared (ArraySegment_1_t2594217482 * __this, Il2CppObject * ___obj0, const MethodInfo* method);
#define ArraySegment_1_Equals_m3670425628(__this, ___obj0, method) ((  bool (*) (ArraySegment_1_t2594217482 *, Il2CppObject *, const MethodInfo*))ArraySegment_1_Equals_m3670425628_gshared)(__this, ___obj0, method)
// System.Boolean System.ArraySegment`1<System.Byte>::Equals(System.ArraySegment`1<T>)
extern "C"  bool ArraySegment_1_Equals_m4189829166_gshared (ArraySegment_1_t2594217482 * __this, ArraySegment_1_t2594217482  ___obj0, const MethodInfo* method);
#define ArraySegment_1_Equals_m4189829166(__this, ___obj0, method) ((  bool (*) (ArraySegment_1_t2594217482 *, ArraySegment_1_t2594217482 , const MethodInfo*))ArraySegment_1_Equals_m4189829166_gshared)(__this, ___obj0, method)
// System.Int32 System.ArraySegment`1<System.Byte>::GetHashCode()
extern "C"  int32_t ArraySegment_1_GetHashCode_m1471616956_gshared (ArraySegment_1_t2594217482 * __this, const MethodInfo* method);
#define ArraySegment_1_GetHashCode_m1471616956(__this, method) ((  int32_t (*) (ArraySegment_1_t2594217482 *, const MethodInfo*))ArraySegment_1_GetHashCode_m1471616956_gshared)(__this, method)
