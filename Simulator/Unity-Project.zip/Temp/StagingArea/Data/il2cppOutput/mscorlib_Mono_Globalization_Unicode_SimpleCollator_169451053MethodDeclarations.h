﻿#pragma once

#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <stdint.h>
#include <assert.h>
#include <exception>

// Mono.Globalization.Unicode.SimpleCollator/Escape
struct Escape_t169451053;
struct Escape_t169451053_marshaled_pinvoke;
struct Escape_t169451053_marshaled_com;

#include "codegen/il2cpp-codegen.h"


// Methods for marshaling
struct Escape_t169451053;
struct Escape_t169451053_marshaled_pinvoke;

extern "C" void Escape_t169451053_marshal_pinvoke(const Escape_t169451053& unmarshaled, Escape_t169451053_marshaled_pinvoke& marshaled);
extern "C" void Escape_t169451053_marshal_pinvoke_back(const Escape_t169451053_marshaled_pinvoke& marshaled, Escape_t169451053& unmarshaled);
extern "C" void Escape_t169451053_marshal_pinvoke_cleanup(Escape_t169451053_marshaled_pinvoke& marshaled);

// Methods for marshaling
struct Escape_t169451053;
struct Escape_t169451053_marshaled_com;

extern "C" void Escape_t169451053_marshal_com(const Escape_t169451053& unmarshaled, Escape_t169451053_marshaled_com& marshaled);
extern "C" void Escape_t169451053_marshal_com_back(const Escape_t169451053_marshaled_com& marshaled, Escape_t169451053& unmarshaled);
extern "C" void Escape_t169451053_marshal_com_cleanup(Escape_t169451053_marshaled_com& marshaled);
