﻿#pragma once

#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <stdint.h>
#include <assert.h>
#include <exception>

// Microsoft.Win32.SafeHandles.SafeHandleZeroOrMinusOneIsInvalid
struct SafeHandleZeroOrMinusOneIsInvalid_t1177681199;

#include "codegen/il2cpp-codegen.h"

// System.Void Microsoft.Win32.SafeHandles.SafeHandleZeroOrMinusOneIsInvalid::.ctor(System.Boolean)
extern "C"  void SafeHandleZeroOrMinusOneIsInvalid__ctor_m3340306667 (SafeHandleZeroOrMinusOneIsInvalid_t1177681199 * __this, bool ___ownsHandle0, const MethodInfo* method) IL2CPP_METHOD_ATTR;
// System.Boolean Microsoft.Win32.SafeHandles.SafeHandleZeroOrMinusOneIsInvalid::get_IsInvalid()
extern "C"  bool SafeHandleZeroOrMinusOneIsInvalid_get_IsInvalid_m2033528032 (SafeHandleZeroOrMinusOneIsInvalid_t1177681199 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
