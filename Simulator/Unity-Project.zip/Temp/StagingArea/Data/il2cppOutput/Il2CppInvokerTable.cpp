﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


// System.Object
struct Il2CppObject;
// System.Object[]
struct ObjectU5BU5D_t3614634134;
// System.Exception
struct Exception_t1927440687;
// System.String
struct String_t;
// System.MulticastDelegate
struct MulticastDelegate_t3201952435;
// Mono.Globalization.Unicode.Contraction[]
struct ContractionU5BU5D_t4233480993;
// Mono.Globalization.Unicode.Level2Map[]
struct Level2MapU5BU5D_t2838259787;
// Mono.Globalization.Unicode.CodePointIndexer
struct CodePointIndexer_t1073906970;
// Mono.Globalization.Unicode.Contraction
struct Contraction_t1673853792;
// System.Byte[]
struct ByteU5BU5D_t3397334013;
// System.Reflection.MethodBase
struct MethodBase_t904190842;
// System.Reflection.Module
struct Module_t4282841206;
// System.Runtime.Serialization.ISurrogateSelector
struct ISurrogateSelector_t1912587528;
// System.Runtime.Remoting.Messaging.Header[]
struct HeaderU5BU5D_t2408360458;
// System.Runtime.Serialization.SerializationInfo
struct SerializationInfo_t228987430;
// System.Text.StringBuilder
struct StringBuilder_t1221177846;
// System.Text.EncoderFallbackBuffer
struct EncoderFallbackBuffer_t3883615514;
// System.Char[]
struct CharU5BU5D_t1328083999;
// System.Text.DecoderFallbackBuffer
struct DecoderFallbackBuffer_t4206371382;
// System.Int64[]
struct Int64U5BU5D_t717125112;
// System.String[]
struct StringU5BU5D_t1642385972;
// System.Collections.Specialized.ListDictionary/DictionaryNode
struct DictionaryNode_t2725637098;
// System.Net.SocketAddress
struct SocketAddress_t838303055;
// System.Net.EndPoint
struct EndPoint_t4156119363;
// System.Net.IPAddress
struct IPAddress_t1399971723;
// System.Net.IPv6Address
struct IPv6Address_t2596635879;
// System.UriFormatException
struct UriFormatException_t3682083048;
// UnityEngine.EventSystems.PointerEventData
struct PointerEventData_t1599784723;
// UnityEngine.UI.ILayoutElement
struct ILayoutElement_t1975293769;
// System.Int32[]
struct Int32U5BU5D_t3030399641;
// System.Reflection.CustomAttributeNamedArgument[]
struct CustomAttributeNamedArgumentU5BU5D_t3304067486;
// System.Reflection.CustomAttributeTypedArgument[]
struct CustomAttributeTypedArgumentU5BU5D_t1075686591;
// UnityEngine.Color32[]
struct Color32U5BU5D_t30278651;
// UnityEngine.EventSystems.RaycastResult[]
struct RaycastResultU5BU5D_t603556505;
// UnityEngine.Experimental.Director.Playable[]
struct PlayableU5BU5D_t4034110853;
// UnityEngine.UICharInfo[]
struct UICharInfoU5BU5D_t2749705857;
// UnityEngine.UILineInfo[]
struct UILineInfoU5BU5D_t3471944775;
// UnityEngine.UIVertex[]
struct UIVertexU5BU5D_t3048644023;
// UnityEngine.Vector2[]
struct Vector2U5BU5D_t686124026;
// UnityEngine.Vector3[]
struct Vector3U5BU5D_t1172311765;
// UnityEngine.Vector4[]
struct Vector4U5BU5D_t1658499504;

#include "class-internals.h"
#include "codegen/il2cpp-codegen.h"
#include "mscorlib_System_Object2689449295.h"
#include "mscorlib_System_Void1841601450.h"
#include "mscorlib_System_Boolean3825574718.h"
#include "mscorlib_System_Int322071877448.h"
#include "mscorlib_ArrayTypes.h"
#include "mscorlib_System_SByte454417549.h"
#include "mscorlib_System_Byte3683104436.h"
#include "mscorlib_System_Char3454481338.h"
#include "mscorlib_System_DateTime693205669.h"
#include "mscorlib_System_Decimal724701077.h"
#include "mscorlib_System_Double4078015681.h"
#include "mscorlib_System_Int164041245914.h"
#include "mscorlib_System_Int64909078037.h"
#include "mscorlib_System_Single2076509932.h"
#include "mscorlib_System_UInt16986882611.h"
#include "mscorlib_System_UInt322149682021.h"
#include "mscorlib_System_UInt642909196914.h"
#include "mscorlib_System_Exception1927440687.h"
#include "mscorlib_System_TypeCode2536926201.h"
#include "mscorlib_System_Globalization_UnicodeCategory682236799.h"
#include "mscorlib_System_String2029220233.h"
#include "mscorlib_System_Runtime_Serialization_StreamingCon1417235061.h"
#include "mscorlib_System_IntPtr2504060609.h"
#include "mscorlib_System_UIntPtr1549717846.h"
#include "mscorlib_System_MulticastDelegate3201952435.h"
#include "mscorlib_System_Reflection_TypeAttributes2229518203.h"
#include "mscorlib_System_Reflection_MemberTypes3343038963.h"
#include "mscorlib_System_RuntimeTypeHandle2330101084.h"
#include "mscorlib_System_RuntimeFieldHandle2331729674.h"
#include "mscorlib_Mono_Globalization_Unicode_CodePointIndex1073906970.h"
#include "mscorlib_Mono_Globalization_Unicode_SimpleCollator1556892101.h"
#include "mscorlib_Mono_Globalization_Unicode_SimpleCollator2636657155.h"
#include "mscorlib_Mono_Globalization_Unicode_Contraction1673853792.h"
#include "mscorlib_Mono_Math_Prime_ConfidenceFactor1997037801.h"
#include "mscorlib_Mono_Math_BigInteger_Sign874893935.h"
#include "mscorlib_System_Security_Cryptography_DSAParameter1872138834.h"
#include "mscorlib_System_Security_Cryptography_RSAParameter1462703416.h"
#include "mscorlib_System_Collections_DictionaryEntry3048875398.h"
#include "mscorlib_System_Reflection_MethodBase904190842.h"
#include "mscorlib_System_DayOfWeek721777893.h"
#include "mscorlib_System_TimeSpan3430258949.h"
#include "mscorlib_System_IO_MonoIOError733012845.h"
#include "mscorlib_System_IO_FileAttributes3843045335.h"
#include "mscorlib_System_IO_MonoFileType3095218325.h"
#include "mscorlib_System_IO_MonoIOStat1621921065.h"
#include "mscorlib_System_Reflection_CallingConventions1097349142.h"
#include "mscorlib_System_RuntimeMethodHandle894824333.h"
#include "mscorlib_System_Reflection_MethodAttributes790385034.h"
#include "mscorlib_System_Reflection_Emit_MethodToken3991686330.h"
#include "mscorlib_System_Reflection_FieldAttributes1122705193.h"
#include "mscorlib_System_Reflection_Emit_OpCode2247480392.h"
#include "mscorlib_System_Reflection_Emit_StackBehaviour1390406961.h"
#include "mscorlib_System_Reflection_Module4282841206.h"
#include "mscorlib_System_Reflection_AssemblyNameFlags1794031440.h"
#include "mscorlib_System_Reflection_EventAttributes2989788983.h"
#include "mscorlib_System_Reflection_MonoEventInfo2190036573.h"
#include "mscorlib_System_Reflection_MonoMethodInfo3646562144.h"
#include "mscorlib_System_Reflection_MonoPropertyInfo486106184.h"
#include "mscorlib_System_Reflection_PropertyAttributes883448530.h"
#include "mscorlib_System_Reflection_ParameterAttributes1266705348.h"
#include "mscorlib_System_Resources_ResourceReader_ResourceI3933049236.h"
#include "mscorlib_System_Runtime_InteropServices_GCHandle3409268066.h"
#include "mscorlib_System_Runtime_Remoting_WellKnownObjectMo2630225581.h"
#include "mscorlib_System_Runtime_Serialization_Formatters_T1182459634.h"
#include "mscorlib_System_Runtime_Serialization_Serialization228987430.h"
#include "mscorlib_System_Runtime_Serialization_Serializatio3485203212.h"
#include "mscorlib_System_Runtime_Serialization_StreamingCon4264247603.h"
#include "mscorlib_System_Security_Cryptography_CspProviderFl105264000.h"
#include "mscorlib_System_Security_Cryptography_CipherMode162592484.h"
#include "mscorlib_System_Security_Cryptography_PaddingMode3032142640.h"
#include "mscorlib_System_Text_StringBuilder1221177846.h"
#include "mscorlib_System_Text_EncoderFallbackBuffer3883615514.h"
#include "mscorlib_System_Text_DecoderFallbackBuffer4206371382.h"
#include "mscorlib_System_DateTimeKind2186819611.h"
#include "mscorlib_System_DateTimeOffset1362988906.h"
#include "mscorlib_System_Nullable_1_gen1693325264.h"
#include "mscorlib_System_MonoEnumInfo2335995564.h"
#include "mscorlib_System_PlatformID1006634368.h"
#include "mscorlib_System_Guid2533601593.h"
#include "System_System_Collections_Specialized_ListDictiona2725637098.h"
#include "System_System_ComponentModel_EditorBrowsableState373498655.h"
#include "System_System_Net_Sockets_SocketType1143498533.h"
#include "System_System_Net_Sockets_SocketError307542793.h"
#include "System_System_Net_SocketAddress838303055.h"
#include "System_System_Net_EndPoint4156119363.h"
#include "System_System_Net_Sockets_AddressFamily303362630.h"
#include "System_System_Net_IPAddress1399971723.h"
#include "System_System_Net_IPv6Address2596635879.h"
#include "System_System_Net_SecurityProtocolType3099771628.h"
#include "System_System_Security_Cryptography_AsnDecodeStatu1962003286.h"
#include "System_System_Security_Cryptography_X509Certificate480677120.h"
#include "System_System_Security_Cryptography_X509Certificat2166064554.h"
#include "System_System_Security_Cryptography_X509Certificat2065307963.h"
#include "System_System_Security_Cryptography_X509Certificat2169036324.h"
#include "System_System_Security_Cryptography_X509Certificat2461349531.h"
#include "System_System_Text_RegularExpressions_RegexOptions2418259727.h"
#include "System_System_Text_RegularExpressions_Category1984577050.h"
#include "System_System_Text_RegularExpressions_OpFlags378191910.h"
#include "System_System_Text_RegularExpressions_Interval2354235237.h"
#include "System_System_Text_RegularExpressions_Position3781184359.h"
#include "System_System_UriHostNameType2148127109.h"
#include "System_System_UriFormatException3682083048.h"
#include "Mono_Security_Mono_Math_BigInteger_Sign874893935.h"
#include "Mono_Security_Mono_Math_Prime_ConfidenceFactor1997037801.h"
#include "Mono_Security_Mono_Security_X509_X509ChainStatusFl2843686920.h"
#include "Mono_Security_Mono_Security_Protocol_Tls_AlertLeve1706602846.h"
#include "Mono_Security_Mono_Security_Protocol_Tls_AlertDescr844791462.h"
#include "Mono_Security_Mono_Security_Protocol_Tls_CipherAlg4212518094.h"
#include "Mono_Security_Mono_Security_Protocol_Tls_HashAlgor1654661965.h"
#include "Mono_Security_Mono_Security_Protocol_Tls_ExchangeAl954949548.h"
#include "Mono_Security_Mono_Security_Protocol_Tls_SecurityPr155967584.h"
#include "Mono_Security_Mono_Security_Protocol_Tls_SecurityC3722381418.h"
#include "Mono_Security_Mono_Security_Protocol_Tls_Handshake2540099417.h"
#include "Mono_Security_Mono_Security_Protocol_Tls_Handshake1820731088.h"
#include "Mono_Security_Mono_Security_Protocol_Tls_ContentTyp859870085.h"
#include "UnityEngine_UnityEngine_RuntimePlatform1869584967.h"
#include "UnityEngine_UnityEngine_OperatingSystemFamily1896948788.h"
#include "UnityEngine_UnityEngine_Rect3681755626.h"
#include "UnityEngine_UnityEngine_CameraClearFlags452084705.h"
#include "UnityEngine_UnityEngine_Vector32243707580.h"
#include "UnityEngine_UnityEngine_Ray2469606224.h"
#include "UnityEngine_UnityEngine_CullingGroupEvent1057617917.h"
#include "UnityEngine_UnityEngine_CursorLockMode3372615096.h"
#include "UnityEngine_UnityEngine_Vector22243707579.h"
#include "UnityEngine_UnityEngine_TouchPhase2458120420.h"
#include "UnityEngine_UnityEngine_TouchType2732027771.h"
#include "UnityEngine_UnityEngine_Touch407273883.h"
#include "UnityEngine_UnityEngine_IMECompositionMode1898275508.h"
#include "UnityEngine_UnityEngine_LayerMask3188175821.h"
#include "UnityEngine_UnityEngine_Quaternion4030073918.h"
#include "UnityEngine_UnityEngine_Vector42243707581.h"
#include "UnityEngine_UnityEngine_Bounds3033363703.h"
#include "UnityEngine_UnityEngine_Mesh_InternalShaderChannel3331827198.h"
#include "UnityEngine_UnityEngine_TextureWrapMode3683976566.h"
#include "UnityEngine_UnityEngine_Color2020392075.h"
#include "UnityEngine_UnityEngine_Matrix4x42933234003.h"
#include "UnityEngine_UnityEngine_HideFlags1434274199.h"
#include "UnityEngine_UnityEngine_Experimental_Director_Play3667545548.h"
#include "UnityEngine_UnityEngine_Experimental_Director_Play3250302433.h"
#include "UnityEngine_UnityEngine_Experimental_Director_Gener788733994.h"
#include "UnityEngine_UnityEngine_SceneManagement_Scene1684909666.h"
#include "UnityEngine_UnityEngine_RaycastHit87180320.h"
#include "UnityEngine_UnityEngine_RaycastHit2D4063908774.h"
#include "UnityEngine_UnityEngine_SendMessageOptions1414041951.h"
#include "UnityEngine_UnityEngine_AnimatorStateInfo2577870592.h"
#include "UnityEngine_UnityEngine_AnimatorClipInfo3905751349.h"
#include "UnityEngine_UnityEngine_Experimental_Director_Anim4078305555.h"
#include "UnityEngine_UnityEngine_Experimental_Director_Anim1693994278.h"
#include "UnityEngine_UnityEngine_Experimental_Director_Fram1120735295.h"
#include "UnityEngine_UnityEngine_TextGenerationSettings2543476768.h"
#include "UnityEngine_UnityEngine_TextGenerationError780770201.h"
#include "UnityEngine_UnityEngine_RenderMode4280533217.h"
#include "UnityEngine_UnityEngine_EventType3919834026.h"
#include "UnityEngine_UnityEngine_EventModifiers2690251474.h"
#include "UnityEngine_UnityEngine_KeyCode2283395152.h"
#include "UnityEngine_UnityEngine_ImagePosition3491916276.h"
#include "UnityEngine_UnityEngine_TextAnchor112990806.h"
#include "UnityEngine_UnityEngine_TextClipping2573530411.h"
#include "UnityEngine_UnityEngine_FontStyle2764949590.h"
#include "UnityEngine_UnityEngine_Internal_DrawArguments2834709342.h"
#include "UnityEngine_UnityEngine_Internal_DrawWithTextSelec1327795077.h"
#include "UnityEngine_UnityEngine_Color32874517518.h"
#include "UnityEngine_UnityEngine_SendMouseEvents_HitInfo1761367055.h"
#include "UnityEngine_UnityEngine_Events_PersistentListenerMo857969000.h"
#include "UnityEngine_UnityEngine_LogType1559732862.h"
#include "UnityEngine_UI_UnityEngine_EventSystems_RaycastResul21186376.h"
#include "UnityEngine_UI_UnityEngine_EventSystems_MoveDirect1406276862.h"
#include "UnityEngine_UI_UnityEngine_EventSystems_PointerEve2981963041.h"
#include "UnityEngine_UI_UnityEngine_EventSystems_PointerEve1599784723.h"
#include "UnityEngine_UI_UnityEngine_EventSystems_PointerEve1414739712.h"
#include "UnityEngine_UI_UnityEngine_EventSystems_Standalone2680906638.h"
#include "UnityEngine_UI_UnityEngine_UI_CoroutineTween_Color1328781136.h"
#include "UnityEngine_UI_UnityEngine_UI_ColorBlock2652774230.h"
#include "UnityEngine_UI_UnityEngine_UI_DefaultControls_Reso2975512894.h"
#include "UnityEngine_UnityEngine_HorizontalWrapMode2027154177.h"
#include "UnityEngine_UnityEngine_VerticalWrapMode3668245347.h"
#include "UnityEngine_UI_UnityEngine_UI_GraphicRaycaster_Blo2548930813.h"
#include "UnityEngine_UI_UnityEngine_UI_Image_Type3352948571.h"
#include "UnityEngine_UI_UnityEngine_UI_Image_FillMethod1640962579.h"
#include "UnityEngine_UI_UnityEngine_UI_InputField_ContentTy1028629049.h"
#include "UnityEngine_UI_UnityEngine_UI_InputField_LineType2931319356.h"
#include "UnityEngine_UI_UnityEngine_UI_InputField_InputType1274231802.h"
#include "UnityEngine_UnityEngine_TouchScreenKeyboardType875112366.h"
#include "UnityEngine_UI_UnityEngine_UI_InputField_Character3437478890.h"
#include "UnityEngine_UI_UnityEngine_UI_InputField_EditState1111987863.h"
#include "UnityEngine_UI_UnityEngine_UI_Navigation_Mode1081683921.h"
#include "UnityEngine_UI_UnityEngine_UI_Navigation1571958496.h"
#include "UnityEngine_UI_UnityEngine_UI_Scrollbar_Direction3696775921.h"
#include "UnityEngine_UI_UnityEngine_UI_Scrollbar_Axis2427050347.h"
#include "UnityEngine_UI_UnityEngine_UI_ScrollRect_MovementTy905360158.h"
#include "UnityEngine_UI_UnityEngine_UI_ScrollRect_Scrollbar3834843475.h"
#include "UnityEngine_UI_UnityEngine_UI_Selectable_Transition605142169.h"
#include "UnityEngine_UI_UnityEngine_UI_SpriteState1353336012.h"
#include "UnityEngine_UI_UnityEngine_UI_Selectable_Selection3187567897.h"
#include "UnityEngine_UI_UnityEngine_UI_Slider_Direction1525323322.h"
#include "UnityEngine_UI_UnityEngine_UI_Slider_Axis375128448.h"
#include "UnityEngine_UI_UnityEngine_UI_AspectRatioFitter_As1166448724.h"
#include "UnityEngine_UI_UnityEngine_UI_CanvasScaler_ScaleMod987318053.h"
#include "UnityEngine_UI_UnityEngine_UI_CanvasScaler_ScreenM1916789528.h"
#include "UnityEngine_UI_UnityEngine_UI_CanvasScaler_Unit3220761768.h"
#include "UnityEngine_UI_UnityEngine_UI_ContentSizeFitter_Fi4030874534.h"
#include "UnityEngine_UI_UnityEngine_UI_GridLayoutGroup_Corn1077473318.h"
#include "UnityEngine_UI_UnityEngine_UI_GridLayoutGroup_Axis1431825778.h"
#include "UnityEngine_UI_UnityEngine_UI_GridLayoutGroup_Cons3558160636.h"
#include "UnityEngine_UnityEngine_UIVertex1204258818.h"
#include "mscorlib_System_Collections_Generic_KeyValuePair_2_g38854645.h"
#include "mscorlib_System_Collections_Generic_Dictionary_2_E3601534125.h"
#include "mscorlib_System_Collections_Generic_Dictionary_2_V3968042187.h"
#include "mscorlib_System_Collections_Generic_List_1_Enumera1593300101.h"
#include "mscorlib_System_ArraySegment_1_gen1600562341.h"
#include "System_System_Collections_Generic_Stack_1_Enumerato132208513.h"
#include "System_Core_System_Collections_Generic_HashSet_1_E3806193287.h"
#include "mscorlib_System_Collections_Generic_Dictionary_2_V3383807694.h"
#include "mscorlib_System_Collections_Generic_Dictionary_2_E3017299632.h"
#include "mscorlib_System_Collections_Generic_KeyValuePair_23749587448.h"
#include "UnityEngine_UI_UnityEngine_UI_CoroutineTween_Float2986189219.h"
#include "UnityEngine_UI_UnityEngine_UI_CoroutineTween_Color3438117476.h"
#include "mscorlib_Mono_Globalization_Unicode_CodePointIndex2011406615.h"
#include "mscorlib_System_ArraySegment_1_gen2594217482.h"
#include "System_Core_System_Collections_Generic_HashSet_1_Li865133271.h"
#include "mscorlib_System_Collections_Generic_KeyValuePair_21174980068.h"
#include "mscorlib_System_Collections_Generic_KeyValuePair_23716250094.h"
#include "mscorlib_System_Collections_Generic_Link2723257478.h"
#include "mscorlib_System_Collections_Hashtable_Slot2022531261.h"
#include "mscorlib_System_Collections_SortedList_Slot2267560602.h"
#include "mscorlib_System_Reflection_CustomAttributeNamedArgum94157543.h"
#include "mscorlib_System_Reflection_CustomAttributeTypedArg1498197914.h"
#include "mscorlib_System_Reflection_Emit_ILGenerator_LabelD3712112744.h"
#include "mscorlib_System_Reflection_Emit_ILGenerator_LabelF4090909514.h"
#include "mscorlib_System_Reflection_Emit_ILTokenInfo149559338.h"
#include "mscorlib_System_Reflection_ParameterModifier1820634920.h"
#include "mscorlib_System_Resources_ResourceReader_ResourceCa333236149.h"
#include "System_System_Security_Cryptography_X509Certificat4278378721.h"
#include "System_System_Text_RegularExpressions_Mark2724874473.h"
#include "System_System_Uri_UriScheme1876590943.h"
#include "UnityEngine_UnityEngine_ContactPoint1376425630.h"
#include "UnityEngine_UnityEngine_ContactPoint2D3659330976.h"
#include "UnityEngine_UnityEngine_Keyframe1449471340.h"
#include "UnityEngine_UnityEngine_UICharInfo3056636800.h"
#include "UnityEngine_UnityEngine_UILineInfo3621277874.h"
#include "UnityEngine_ArrayTypes.h"
#include "UnityEngine.UI_ArrayTypes.h"
#include "Mono_Security_Mono_Security_Protocol_Tls_Handshake4001384466.h"
#include "mscorlib_System_Runtime_Serialization_Formatters_Bi141209596.h"
#include "mscorlib_System_Collections_Generic_Dictionary_2_Va809200314.h"
#include "mscorlib_System_Collections_Generic_Dictionary_2_V3350470340.h"
#include "mscorlib_System_Collections_Generic_Dictionary_2_En442692252.h"
#include "mscorlib_System_Collections_Generic_Dictionary_2_E2983962278.h"
#include "mscorlib_System_Collections_Generic_List_1_Enumerat975728254.h"
#include "mscorlib_System_Collections_Generic_List_1_Enumera3292975645.h"
#include "mscorlib_System_Collections_Generic_List_1_Enumerat402048720.h"
#include "mscorlib_System_Collections_Generic_List_1_Enumera4073335620.h"
#include "mscorlib_System_Collections_Generic_List_1_Enumera3220004478.h"
#include "mscorlib_System_Collections_Generic_List_1_Enumera2571396354.h"
#include "mscorlib_System_Collections_Generic_List_1_Enumera1960487606.h"
#include "mscorlib_System_Collections_Generic_List_1_Enumera2525128680.h"
#include "mscorlib_System_Collections_Generic_List_1_Enumerat108109624.h"
#include "mscorlib_System_Collections_Generic_List_1_Enumera1147558385.h"
#include "mscorlib_System_Collections_Generic_List_1_Enumera1147558386.h"
#include "mscorlib_System_Collections_Generic_List_1_Enumera1147558387.h"

void* RuntimeInvoker_Void_t1841601450 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, const MethodInfo* method);
	((Func)method->methodPointer)(obj, method);
	return NULL;
}

void* RuntimeInvoker_Boolean_t3825574718_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Il2CppObject * p1, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, method);
	return ret;
}

void* RuntimeInvoker_Int32_t2071877448_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Il2CppObject_ObjectU5BU5DU26_t3223402458 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, ObjectU5BU5D_t3614634134** p3, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], (ObjectU5BU5D_t3614634134**)args[2], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Il2CppObject_ObjectU5BU5DU26_t3223402458 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, ObjectU5BU5D_t3614634134** p2, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (ObjectU5BU5D_t3614634134**)args[1], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], method);
	return NULL;
}

void* RuntimeInvoker_Il2CppObject_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Il2CppObject_Il2CppObject_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, int8_t p3, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], *((int8_t*)args[2]), method);
	return ret;
}

void* RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Il2CppObject_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, int8_t p3, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], *((int8_t*)args[2]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Byte_t3683104436_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef uint8_t (*Func)(void* obj, Il2CppObject * p1, const MethodInfo* method);
	uint8_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Char_t3454481338_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppChar (*Func)(void* obj, Il2CppObject * p1, const MethodInfo* method);
	Il2CppChar ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_DateTime_t693205669_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef DateTime_t693205669  (*Func)(void* obj, Il2CppObject * p1, const MethodInfo* method);
	DateTime_t693205669  ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Decimal_t724701077_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Decimal_t724701077  (*Func)(void* obj, Il2CppObject * p1, const MethodInfo* method);
	Decimal_t724701077  ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Double_t4078015681_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef double (*Func)(void* obj, Il2CppObject * p1, const MethodInfo* method);
	double ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int16_t4041245914_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef int16_t (*Func)(void* obj, Il2CppObject * p1, const MethodInfo* method);
	int16_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int64_t909078037_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef int64_t (*Func)(void* obj, Il2CppObject * p1, const MethodInfo* method);
	int64_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_SByte_t454417549_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef int8_t (*Func)(void* obj, Il2CppObject * p1, const MethodInfo* method);
	int8_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Single_t2076509932_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef float (*Func)(void* obj, Il2CppObject * p1, const MethodInfo* method);
	float ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_UInt16_t986882611_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef uint16_t (*Func)(void* obj, Il2CppObject * p1, const MethodInfo* method);
	uint16_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_UInt32_t2149682021_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef uint32_t (*Func)(void* obj, Il2CppObject * p1, const MethodInfo* method);
	uint32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_UInt64_t2909196914_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef uint64_t (*Func)(void* obj, Il2CppObject * p1, const MethodInfo* method);
	uint64_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, int32_t p1, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, int32_t p1, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_SByte_t454417549_Il2CppObject_Int32_t2071877448_ExceptionU26_t1467204777 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, int8_t p1, Il2CppObject * p2, int32_t p3, Exception_t1927440687 ** p4, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((int8_t*)args[0]), (Il2CppObject *)args[1], *((int32_t*)args[2]), (Exception_t1927440687 **)args[3], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Il2CppObject_SByte_t454417549_Int32U26_t455636984_ExceptionU26_t1467204777 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Il2CppObject * p1, int8_t p2, int32_t* p3, Exception_t1927440687 ** p4, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int8_t*)args[1]), (int32_t*)args[2], (Exception_t1927440687 **)args[3], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Int32_t2071877448_SByte_t454417549_ExceptionU26_t1467204777 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, int32_t p1, int8_t p2, Exception_t1927440687 ** p3, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((int8_t*)args[1]), (Exception_t1927440687 **)args[2], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Int32U26_t455636984_Il2CppObject_SByte_t454417549_SByte_t454417549_ExceptionU26_t1467204777 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, int32_t* p1, Il2CppObject * p2, int8_t p3, int8_t p4, Exception_t1927440687 ** p5, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (int32_t*)args[0], (Il2CppObject *)args[1], *((int8_t*)args[2]), *((int8_t*)args[3]), (Exception_t1927440687 **)args[4], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Int32U26_t455636984_Il2CppObject_Il2CppObject_BooleanU26_t3168250738_BooleanU26_t3168250738 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t* p1, Il2CppObject * p2, Il2CppObject * p3, bool* p4, bool* p5, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (int32_t*)args[0], (Il2CppObject *)args[1], (Il2CppObject *)args[2], (bool*)args[3], (bool*)args[4], method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Int32U26_t455636984_Il2CppObject_Il2CppObject_BooleanU26_t3168250738 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t* p1, Il2CppObject * p2, Il2CppObject * p3, bool* p4, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (int32_t*)args[0], (Il2CppObject *)args[1], (Il2CppObject *)args[2], (bool*)args[3], method);
	return NULL;
}

void* RuntimeInvoker_Boolean_t3825574718_Int32U26_t455636984_Il2CppObject_Int32U26_t455636984_SByte_t454417549_ExceptionU26_t1467204777 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, int32_t* p1, Il2CppObject * p2, int32_t* p3, int8_t p4, Exception_t1927440687 ** p5, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (int32_t*)args[0], (Il2CppObject *)args[1], (int32_t*)args[2], *((int8_t*)args[3]), (Exception_t1927440687 **)args[4], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Int32U26_t455636984_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, int32_t* p1, Il2CppObject * p2, Il2CppObject * p3, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (int32_t*)args[0], (Il2CppObject *)args[1], (Il2CppObject *)args[2], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Int16_t4041245914_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, int16_t p1, int8_t p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((int16_t*)args[0]), *((int8_t*)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Int32_t2071877448_Il2CppObject_SByte_t454417549_Int32U26_t455636984_ExceptionU26_t1467204777 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Il2CppObject * p1, int32_t p2, Il2CppObject * p3, int8_t p4, int32_t* p5, Exception_t1927440687 ** p6, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), (Il2CppObject *)args[2], *((int8_t*)args[3]), (int32_t*)args[4], (Exception_t1927440687 **)args[5], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, int32_t p2, Il2CppObject * p3, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), (Il2CppObject *)args[2], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Int32U26_t455636984 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Il2CppObject * p1, int32_t* p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (int32_t*)args[1], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Int32_t2071877448_Il2CppObject_Int32U26_t455636984 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Il2CppObject * p1, int32_t p2, Il2CppObject * p3, int32_t* p4, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), (Il2CppObject *)args[2], (int32_t*)args[3], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Il2CppObject * p1, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], method);
	return ret;
}

void* RuntimeInvoker_TypeCode_t2536926201 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), method);
	return NULL;
}

void* RuntimeInvoker_Boolean_t3825574718 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int8_t p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int8_t*)args[0]), method);
	return NULL;
}

void* RuntimeInvoker_Int32_t2071877448_Int64_t909078037 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, int64_t p1, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((int64_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Int64_t909078037 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, int64_t p1, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((int64_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Il2CppObject_SByte_t454417549_Int64U26_t763825331_ExceptionU26_t1467204777 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Il2CppObject * p1, int8_t p2, int64_t* p3, Exception_t1927440687 ** p4, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int8_t*)args[1]), (int64_t*)args[2], (Exception_t1927440687 **)args[3], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int64_t909078037_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef int64_t (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, const MethodInfo* method);
	int64_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Int32_t2071877448_Il2CppObject_SByte_t454417549_Int64U26_t763825331_ExceptionU26_t1467204777 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Il2CppObject * p1, int32_t p2, Il2CppObject * p3, int8_t p4, int64_t* p5, Exception_t1927440687 ** p6, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), (Il2CppObject *)args[2], *((int8_t*)args[3]), (int64_t*)args[4], (Exception_t1927440687 **)args[5], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int64_t909078037_Il2CppObject_Int32_t2071877448_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef int64_t (*Func)(void* obj, Il2CppObject * p1, int32_t p2, Il2CppObject * p3, const MethodInfo* method);
	int64_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), (Il2CppObject *)args[2], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Int64U26_t763825331 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Il2CppObject * p1, int64_t* p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (int64_t*)args[1], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Int32_t2071877448_Il2CppObject_Int64U26_t763825331 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Il2CppObject * p1, int32_t p2, Il2CppObject * p3, int64_t* p4, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), (Il2CppObject *)args[2], (int64_t*)args[3], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Il2CppObject_SByte_t454417549_UInt32U26_t2197289955_ExceptionU26_t1467204777 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Il2CppObject * p1, int8_t p2, uint32_t* p3, Exception_t1927440687 ** p4, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int8_t*)args[1]), (uint32_t*)args[2], (Exception_t1927440687 **)args[3], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Int32_t2071877448_Il2CppObject_SByte_t454417549_UInt32U26_t2197289955_ExceptionU26_t1467204777 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Il2CppObject * p1, int32_t p2, Il2CppObject * p3, int8_t p4, uint32_t* p5, Exception_t1927440687 ** p6, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), (Il2CppObject *)args[2], *((int8_t*)args[3]), (uint32_t*)args[4], (Exception_t1927440687 **)args[5], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_UInt32_t2149682021_Il2CppObject_Int32_t2071877448_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef uint32_t (*Func)(void* obj, Il2CppObject * p1, int32_t p2, Il2CppObject * p3, const MethodInfo* method);
	uint32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), (Il2CppObject *)args[2], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_UInt32_t2149682021_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef uint32_t (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, const MethodInfo* method);
	uint32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Il2CppObject_UInt32U26_t2197289955 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Il2CppObject * p1, uint32_t* p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (uint32_t*)args[1], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Int32_t2071877448_Il2CppObject_UInt32U26_t2197289955 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Il2CppObject * p1, int32_t p2, Il2CppObject * p3, uint32_t* p4, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), (Il2CppObject *)args[2], (uint32_t*)args[3], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_UInt64_t2909196914_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef uint64_t (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, const MethodInfo* method);
	uint64_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Int32_t2071877448_Il2CppObject_SByte_t454417549_UInt64U26_t1611942494_ExceptionU26_t1467204777 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Il2CppObject * p1, int32_t p2, Il2CppObject * p3, int8_t p4, uint64_t* p5, Exception_t1927440687 ** p6, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), (Il2CppObject *)args[2], *((int8_t*)args[3]), (uint64_t*)args[4], (Exception_t1927440687 **)args[5], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_UInt64_t2909196914_Il2CppObject_Int32_t2071877448_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef uint64_t (*Func)(void* obj, Il2CppObject * p1, int32_t p2, Il2CppObject * p3, const MethodInfo* method);
	uint64_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), (Il2CppObject *)args[2], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Il2CppObject_UInt64U26_t1611942494 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Il2CppObject * p1, uint64_t* p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (uint64_t*)args[1], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, int8_t p1, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((int8_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, int8_t p1, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((int8_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Byte_t3683104436_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef uint8_t (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, const MethodInfo* method);
	uint8_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Byte_t3683104436_Il2CppObject_Int32_t2071877448_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef uint8_t (*Func)(void* obj, Il2CppObject * p1, int32_t p2, Il2CppObject * p3, const MethodInfo* method);
	uint8_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), (Il2CppObject *)args[2], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Il2CppObject_ByteU26_t1147306860 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Il2CppObject * p1, uint8_t* p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (uint8_t*)args[1], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Int32_t2071877448_Il2CppObject_ByteU26_t1147306860 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Il2CppObject * p1, int32_t p2, Il2CppObject * p3, uint8_t* p4, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), (Il2CppObject *)args[2], (uint8_t*)args[3], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Il2CppObject_SByte_t454417549_SByteU26_t3920581883_ExceptionU26_t1467204777 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Il2CppObject * p1, int8_t p2, int8_t* p3, Exception_t1927440687 ** p4, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int8_t*)args[1]), (int8_t*)args[2], (Exception_t1927440687 **)args[3], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_SByte_t454417549_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef int8_t (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, const MethodInfo* method);
	int8_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_SByte_t454417549_Il2CppObject_Int32_t2071877448_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef int8_t (*Func)(void* obj, Il2CppObject * p1, int32_t p2, Il2CppObject * p3, const MethodInfo* method);
	int8_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), (Il2CppObject *)args[2], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Il2CppObject_SByteU26_t3920581883 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Il2CppObject * p1, int8_t* p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (int8_t*)args[1], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Int16_t4041245914 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, int16_t p1, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((int16_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Int16_t4041245914 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, int16_t p1, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((int16_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Il2CppObject_SByte_t454417549_Int16U26_t3189330998_ExceptionU26_t1467204777 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Il2CppObject * p1, int8_t p2, int16_t* p3, Exception_t1927440687 ** p4, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int8_t*)args[1]), (int16_t*)args[2], (Exception_t1927440687 **)args[3], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int16_t4041245914_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef int16_t (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, const MethodInfo* method);
	int16_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int16_t4041245914_Il2CppObject_Int32_t2071877448_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef int16_t (*Func)(void* obj, Il2CppObject * p1, int32_t p2, Il2CppObject * p3, const MethodInfo* method);
	int16_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), (Il2CppObject *)args[2], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Int16U26_t3189330998 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Il2CppObject * p1, int16_t* p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (int16_t*)args[1], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_UInt16_t986882611_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef uint16_t (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, const MethodInfo* method);
	uint16_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_UInt16_t986882611_Il2CppObject_Int32_t2071877448_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef uint16_t (*Func)(void* obj, Il2CppObject * p1, int32_t p2, Il2CppObject * p3, const MethodInfo* method);
	uint16_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), (Il2CppObject *)args[2], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Il2CppObject_UInt16U26_t3314555461 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Il2CppObject * p1, uint16_t* p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (uint16_t*)args[1], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Int32_t2071877448_Il2CppObject_UInt16U26_t3314555461 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Il2CppObject * p1, int32_t p2, Il2CppObject * p3, uint16_t* p4, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), (Il2CppObject *)args[2], (uint16_t*)args[3], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_ByteU2AU26_t3544685828_ByteU2AU26_t3544685828_DoubleU2AU26_t3349029_UInt16U2AU26_t1636670495_UInt16U2AU26_t1636670495_UInt16U2AU26_t1636670495_UInt16U2AU26_t1636670495 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, uint8_t** p1, uint8_t** p2, double** p3, uint16_t** p4, uint16_t** p5, uint16_t** p6, uint16_t** p7, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (uint8_t**)args[0], (uint8_t**)args[1], (double**)args[2], (uint16_t**)args[3], (uint16_t**)args[4], (uint16_t**)args[5], (uint16_t**)args[6], method);
	return NULL;
}

void* RuntimeInvoker_UnicodeCategory_t682236799_Int16_t4041245914 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, int16_t p1, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((int16_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Il2CppObject * p1, int32_t p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, int32_t p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Char_t3454481338_Int16_t4041245914 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppChar (*Func)(void* obj, int16_t p1, const MethodInfo* method);
	Il2CppChar ret = ((Func)method->methodPointer)(obj, *((int16_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Char_t3454481338_Int16_t4041245914_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppChar (*Func)(void* obj, int16_t p1, Il2CppObject * p2, const MethodInfo* method);
	Il2CppChar ret = ((Func)method->methodPointer)(obj, *((int16_t*)args[0]), (Il2CppObject *)args[1], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, int32_t p2, int32_t p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Int16_t4041245914_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int16_t p1, int32_t p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int16_t*)args[0]), *((int32_t*)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Char_t3454481338_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppChar (*Func)(void* obj, int32_t p1, const MethodInfo* method);
	Il2CppChar ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, Il2CppObject * p2, int32_t p3, int32_t p4, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), (Il2CppObject *)args[1], *((int32_t*)args[2]), *((int32_t*)args[3]), method);
	return NULL;
}

void* RuntimeInvoker_Il2CppObject_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, int32_t p1, int32_t p2, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((int32_t*)args[1]), method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Il2CppObject_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Il2CppObject * p1, int32_t p2, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Il2CppObject_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Il2CppObject * p1, int32_t p2, int32_t p3, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, int32_t p1, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), method);
	return ret;
}

void* RuntimeInvoker_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, int32_t p1, int32_t p2, int32_t p3, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((int32_t*)args[1]), *((int32_t*)args[2]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, int32_t p1, int32_t p2, int32_t p3, Il2CppObject * p4, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((int32_t*)args[1]), *((int32_t*)args[2]), (Il2CppObject *)args[3], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Il2CppObject_Il2CppObject_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, int8_t p3, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], *((int8_t*)args[2]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Il2CppObject_Il2CppObject_SByte_t454417549_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, int8_t p3, Il2CppObject * p4, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], *((int8_t*)args[2]), (Il2CppObject *)args[3], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448_SByte_t454417549_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, int32_t p2, Il2CppObject * p3, int32_t p4, int32_t p5, int8_t p6, Il2CppObject * p7, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), (Il2CppObject *)args[2], *((int32_t*)args[3]), *((int32_t*)args[4]), *((int8_t*)args[5]), (Il2CppObject *)args[6], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, int32_t p2, Il2CppObject * p3, int32_t p4, int32_t p5, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), (Il2CppObject *)args[2], *((int32_t*)args[3]), *((int32_t*)args[4]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, int32_t p2, int32_t p3, Il2CppObject * p4, int32_t p5, int32_t p6, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), (Il2CppObject *)args[3], *((int32_t*)args[4]), *((int32_t*)args[5]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, int32_t p2, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, int32_t p2, int32_t p3, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, int32_t p2, int32_t p3, int32_t p4, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), *((int32_t*)args[3]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Int16_t4041245914_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, int16_t p1, int32_t p2, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((int16_t*)args[0]), *((int32_t*)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Int16_t4041245914_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, int16_t p1, int32_t p2, int32_t p3, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((int16_t*)args[0]), *((int32_t*)args[1]), *((int32_t*)args[2]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Il2CppObject_Int32_t2071877448_Int16_t4041245914 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, int32_t p1, int16_t p2, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((int16_t*)args[1]), method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Int16_t4041245914_Int16_t4041245914 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, int16_t p1, int16_t p2, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((int16_t*)args[0]), *((int16_t*)args[1]), method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Il2CppObject_Il2CppObject_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, int32_t p3, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], *((int32_t*)args[2]), method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, Il2CppObject * p3, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], (Il2CppObject *)args[2], method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, Il2CppObject * p3, Il2CppObject * p4, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], (Il2CppObject *)args[2], (Il2CppObject *)args[3], method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Int32_t2071877448_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, int32_t p1, Il2CppObject * p2, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), (Il2CppObject *)args[1], method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Il2CppObject_Il2CppObject_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, int32_t p3, int32_t p4, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], *((int32_t*)args[2]), *((int32_t*)args[3]), method);
	return ret;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Int32U26_t455636984_Int32U26_t455636984_Int32U26_t455636984_BooleanU26_t3168250738_StringU26_t638738783 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, int32_t* p2, int32_t* p3, int32_t* p4, bool* p5, String_t** p6, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (int32_t*)args[1], (int32_t*)args[2], (int32_t*)args[3], (bool*)args[4], (String_t**)args[5], method);
	return NULL;
}

void* RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32U26_t455636984 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, int32_t* p2, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (int32_t*)args[1], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Int16_t4041245914 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, int16_t p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((int16_t*)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Il2CppObject_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Il2CppObject * p1, int32_t p2, int32_t p3, Il2CppObject * p4, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), (Il2CppObject *)args[3], method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Int16_t4041245914_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, int16_t p1, int32_t p2, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((int16_t*)args[0]), *((int32_t*)args[1]), method);
	return ret;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Il2CppObject_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, int32_t p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], *((int32_t*)args[2]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, int32_t p2, Il2CppObject * p3, int32_t p4, int32_t p5, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), (Il2CppObject *)args[2], *((int32_t*)args[3]), *((int32_t*)args[4]), method);
	return NULL;
}

void* RuntimeInvoker_Int32_t2071877448_Single_t2076509932 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, float p1, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((float*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Single_t2076509932 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, float p1, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((float*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Single_t2076509932_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef float (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, const MethodInfo* method);
	float ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Double_t4078015681 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, double p1, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((double*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Double_t4078015681 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, double p1, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((double*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Double_t4078015681_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef double (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, const MethodInfo* method);
	double ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Double_t4078015681_Il2CppObject_Int32_t2071877448_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef double (*Func)(void* obj, Il2CppObject * p1, int32_t p2, Il2CppObject * p3, const MethodInfo* method);
	double ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), (Il2CppObject *)args[2], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Int32_t2071877448_Il2CppObject_SByte_t454417549_DoubleU26_t1208767207_ExceptionU26_t1467204777 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Il2CppObject * p1, int32_t p2, Il2CppObject * p3, int8_t p4, double* p5, Exception_t1927440687 ** p6, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), (Il2CppObject *)args[2], *((int8_t*)args[3]), (double*)args[4], (Exception_t1927440687 **)args[5], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Il2CppObject_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, int32_t p3, int32_t p4, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], *((int32_t*)args[2]), *((int32_t*)args[3]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Il2CppObject_DoubleU26_t1208767207 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Il2CppObject * p1, double* p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (double*)args[1], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_SByte_t454417549_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, int32_t p2, int32_t p3, int8_t p4, int8_t p5, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((int32_t*)args[1]), *((int32_t*)args[2]), *((int8_t*)args[3]), *((int8_t*)args[4]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Int64_t909078037 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int64_t p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int64_t*)args[0]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Single_t2076509932 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, float p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((float*)args[0]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Double_t4078015681 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, double p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((double*)args[0]), method);
	return NULL;
}

void* RuntimeInvoker_Il2CppObject_Decimal_t724701077 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Decimal_t724701077  p1, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((Decimal_t724701077 *)args[0]), method);
	return ret;
}

void* RuntimeInvoker_Decimal_t724701077_Decimal_t724701077_Decimal_t724701077 (const MethodInfo* method, void* obj, void** args)
{
	typedef Decimal_t724701077  (*Func)(void* obj, Decimal_t724701077  p1, Decimal_t724701077  p2, const MethodInfo* method);
	Decimal_t724701077  ret = ((Func)method->methodPointer)(obj, *((Decimal_t724701077 *)args[0]), *((Decimal_t724701077 *)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_UInt64_t2909196914_Decimal_t724701077 (const MethodInfo* method, void* obj, void** args)
{
	typedef uint64_t (*Func)(void* obj, Decimal_t724701077  p1, const MethodInfo* method);
	uint64_t ret = ((Func)method->methodPointer)(obj, *((Decimal_t724701077 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int64_t909078037_Decimal_t724701077 (const MethodInfo* method, void* obj, void** args)
{
	typedef int64_t (*Func)(void* obj, Decimal_t724701077  p1, const MethodInfo* method);
	int64_t ret = ((Func)method->methodPointer)(obj, *((Decimal_t724701077 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Decimal_t724701077_Decimal_t724701077 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Decimal_t724701077  p1, Decimal_t724701077  p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((Decimal_t724701077 *)args[0]), *((Decimal_t724701077 *)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Decimal_t724701077_Decimal_t724701077 (const MethodInfo* method, void* obj, void** args)
{
	typedef Decimal_t724701077  (*Func)(void* obj, Decimal_t724701077  p1, const MethodInfo* method);
	Decimal_t724701077  ret = ((Func)method->methodPointer)(obj, *((Decimal_t724701077 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Decimal_t724701077_Decimal_t724701077 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Decimal_t724701077  p1, Decimal_t724701077  p2, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((Decimal_t724701077 *)args[0]), *((Decimal_t724701077 *)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Decimal_t724701077 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Decimal_t724701077  p1, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((Decimal_t724701077 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Decimal_t724701077 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Decimal_t724701077  p1, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((Decimal_t724701077 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Decimal_t724701077_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Decimal_t724701077  (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, const MethodInfo* method);
	Decimal_t724701077  ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Il2CppObject_Il2CppObject_Int32_t2071877448_Il2CppObject_Int32U26_t455636984_BooleanU26_t3168250738_BooleanU26_t3168250738_Int32U26_t455636984_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Il2CppObject * p1, int32_t p2, Il2CppObject * p3, int32_t* p4, bool* p5, bool* p6, int32_t* p7, int8_t p8, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), (Il2CppObject *)args[2], (int32_t*)args[3], (bool*)args[4], (bool*)args[5], (int32_t*)args[6], *((int8_t*)args[7]), method);
	return ret;
}

void* RuntimeInvoker_Decimal_t724701077_Il2CppObject_Int32_t2071877448_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Decimal_t724701077  (*Func)(void* obj, Il2CppObject * p1, int32_t p2, Il2CppObject * p3, const MethodInfo* method);
	Decimal_t724701077  ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), (Il2CppObject *)args[2], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Int32_t2071877448_Il2CppObject_DecimalU26_t1613489971_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Il2CppObject * p1, int32_t p2, Il2CppObject * p3, Decimal_t724701077 * p4, int8_t p5, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), (Il2CppObject *)args[2], (Decimal_t724701077 *)args[3], *((int8_t*)args[4]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_DecimalU26_t1613489971_UInt64U26_t1611942494 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Decimal_t724701077 * p1, uint64_t* p2, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Decimal_t724701077 *)args[0], (uint64_t*)args[1], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_DecimalU26_t1613489971_Int64U26_t763825331 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Decimal_t724701077 * p1, int64_t* p2, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Decimal_t724701077 *)args[0], (int64_t*)args[1], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_DecimalU26_t1613489971_DecimalU26_t1613489971 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Decimal_t724701077 * p1, Decimal_t724701077 * p2, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Decimal_t724701077 *)args[0], (Decimal_t724701077 *)args[1], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_DecimalU26_t1613489971_Il2CppObject_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Decimal_t724701077 * p1, Il2CppObject * p2, int32_t p3, int32_t p4, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Decimal_t724701077 *)args[0], (Il2CppObject *)args[1], *((int32_t*)args[2]), *((int32_t*)args[3]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_DecimalU26_t1613489971_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Decimal_t724701077 * p1, int32_t p2, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Decimal_t724701077 *)args[0], *((int32_t*)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Double_t4078015681_DecimalU26_t1613489971 (const MethodInfo* method, void* obj, void** args)
{
	typedef double (*Func)(void* obj, Decimal_t724701077 * p1, const MethodInfo* method);
	double ret = ((Func)method->methodPointer)(obj, (Decimal_t724701077 *)args[0], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_DecimalU26_t1613489971_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Decimal_t724701077 * p1, int32_t p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Decimal_t724701077 *)args[0], *((int32_t*)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Int32_t2071877448_DecimalU26_t1613489971_DecimalU26_t1613489971_DecimalU26_t1613489971 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Decimal_t724701077 * p1, Decimal_t724701077 * p2, Decimal_t724701077 * p3, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Decimal_t724701077 *)args[0], (Decimal_t724701077 *)args[1], (Decimal_t724701077 *)args[2], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Byte_t3683104436_Decimal_t724701077 (const MethodInfo* method, void* obj, void** args)
{
	typedef uint8_t (*Func)(void* obj, Decimal_t724701077  p1, const MethodInfo* method);
	uint8_t ret = ((Func)method->methodPointer)(obj, *((Decimal_t724701077 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_SByte_t454417549_Decimal_t724701077 (const MethodInfo* method, void* obj, void** args)
{
	typedef int8_t (*Func)(void* obj, Decimal_t724701077  p1, const MethodInfo* method);
	int8_t ret = ((Func)method->methodPointer)(obj, *((Decimal_t724701077 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int16_t4041245914_Decimal_t724701077 (const MethodInfo* method, void* obj, void** args)
{
	typedef int16_t (*Func)(void* obj, Decimal_t724701077  p1, const MethodInfo* method);
	int16_t ret = ((Func)method->methodPointer)(obj, *((Decimal_t724701077 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_UInt16_t986882611_Decimal_t724701077 (const MethodInfo* method, void* obj, void** args)
{
	typedef uint16_t (*Func)(void* obj, Decimal_t724701077  p1, const MethodInfo* method);
	uint16_t ret = ((Func)method->methodPointer)(obj, *((Decimal_t724701077 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_UInt32_t2149682021_Decimal_t724701077 (const MethodInfo* method, void* obj, void** args)
{
	typedef uint32_t (*Func)(void* obj, Decimal_t724701077  p1, const MethodInfo* method);
	uint32_t ret = ((Func)method->methodPointer)(obj, *((Decimal_t724701077 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Decimal_t724701077_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef Decimal_t724701077  (*Func)(void* obj, int8_t p1, const MethodInfo* method);
	Decimal_t724701077  ret = ((Func)method->methodPointer)(obj, *((int8_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Decimal_t724701077_Int16_t4041245914 (const MethodInfo* method, void* obj, void** args)
{
	typedef Decimal_t724701077  (*Func)(void* obj, int16_t p1, const MethodInfo* method);
	Decimal_t724701077  ret = ((Func)method->methodPointer)(obj, *((int16_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Decimal_t724701077_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef Decimal_t724701077  (*Func)(void* obj, int32_t p1, const MethodInfo* method);
	Decimal_t724701077  ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Decimal_t724701077_Int64_t909078037 (const MethodInfo* method, void* obj, void** args)
{
	typedef Decimal_t724701077  (*Func)(void* obj, int64_t p1, const MethodInfo* method);
	Decimal_t724701077  ret = ((Func)method->methodPointer)(obj, *((int64_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Decimal_t724701077_Single_t2076509932 (const MethodInfo* method, void* obj, void** args)
{
	typedef Decimal_t724701077  (*Func)(void* obj, float p1, const MethodInfo* method);
	Decimal_t724701077  ret = ((Func)method->methodPointer)(obj, *((float*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Decimal_t724701077_Double_t4078015681 (const MethodInfo* method, void* obj, void** args)
{
	typedef Decimal_t724701077  (*Func)(void* obj, double p1, const MethodInfo* method);
	Decimal_t724701077  ret = ((Func)method->methodPointer)(obj, *((double*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Single_t2076509932_Decimal_t724701077 (const MethodInfo* method, void* obj, void** args)
{
	typedef float (*Func)(void* obj, Decimal_t724701077  p1, const MethodInfo* method);
	float ret = ((Func)method->methodPointer)(obj, *((Decimal_t724701077 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Double_t4078015681_Decimal_t724701077 (const MethodInfo* method, void* obj, void** args)
{
	typedef double (*Func)(void* obj, Decimal_t724701077  p1, const MethodInfo* method);
	double ret = ((Func)method->methodPointer)(obj, *((Decimal_t724701077 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_StreamingContext_t1417235061 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, StreamingContext_t1417235061  p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((StreamingContext_t1417235061 *)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Int64_t909078037 (const MethodInfo* method, void* obj, void** args)
{
	typedef int64_t (*Func)(void* obj, const MethodInfo* method);
	int64_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_IntPtr_t_IntPtr_t (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, IntPtr_t p1, IntPtr_t p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((IntPtr_t*)args[0]), *((IntPtr_t*)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_IntPtr_t_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef IntPtr_t (*Func)(void* obj, int32_t p1, const MethodInfo* method);
	IntPtr_t ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_IntPtr_t_Int64_t909078037 (const MethodInfo* method, void* obj, void** args)
{
	typedef IntPtr_t (*Func)(void* obj, int64_t p1, const MethodInfo* method);
	IntPtr_t ret = ((Func)method->methodPointer)(obj, *((int64_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_IntPtr_t_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef IntPtr_t (*Func)(void* obj, Il2CppObject * p1, const MethodInfo* method);
	IntPtr_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_IntPtr_t (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, IntPtr_t p1, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((IntPtr_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Il2CppObject_IntPtr_t (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, IntPtr_t p1, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((IntPtr_t*)args[0]), method);
	return ret;
}

void* RuntimeInvoker_UInt32_t2149682021 (const MethodInfo* method, void* obj, void** args)
{
	typedef uint32_t (*Func)(void* obj, const MethodInfo* method);
	uint32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_UInt64_t2909196914 (const MethodInfo* method, void* obj, void** args)
{
	typedef uint64_t (*Func)(void* obj, const MethodInfo* method);
	uint64_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_UInt64_t2909196914_IntPtr_t (const MethodInfo* method, void* obj, void** args)
{
	typedef uint64_t (*Func)(void* obj, IntPtr_t p1, const MethodInfo* method);
	uint64_t ret = ((Func)method->methodPointer)(obj, *((IntPtr_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_UInt32_t2149682021_IntPtr_t (const MethodInfo* method, void* obj, void** args)
{
	typedef uint32_t (*Func)(void* obj, IntPtr_t p1, const MethodInfo* method);
	uint32_t ret = ((Func)method->methodPointer)(obj, *((IntPtr_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_UIntPtr_t_Int64_t909078037 (const MethodInfo* method, void* obj, void** args)
{
	typedef UIntPtr_t  (*Func)(void* obj, int64_t p1, const MethodInfo* method);
	UIntPtr_t  ret = ((Func)method->methodPointer)(obj, *((int64_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_UIntPtr_t_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef UIntPtr_t  (*Func)(void* obj, Il2CppObject * p1, const MethodInfo* method);
	UIntPtr_t  ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_UIntPtr_t_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef UIntPtr_t  (*Func)(void* obj, int32_t p1, const MethodInfo* method);
	UIntPtr_t  ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Il2CppObject_Il2CppObject_Il2CppObject_MulticastDelegateU26_t4036814277 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, MulticastDelegate_t3201952435 ** p3, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], (MulticastDelegate_t3201952435 **)args[2], method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, Il2CppObject * p3, int8_t p4, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], (Il2CppObject *)args[2], *((int8_t*)args[3]), method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject_Int32_t2071877448_SByte_t454417549_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, Il2CppObject * p3, int32_t p4, int8_t p5, int8_t p6, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], (Il2CppObject *)args[2], *((int32_t*)args[3]), *((int8_t*)args[4]), *((int8_t*)args[5]), method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject_SByte_t454417549_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, Il2CppObject * p3, int8_t p4, int8_t p5, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], (Il2CppObject *)args[2], *((int8_t*)args[3]), *((int8_t*)args[4]), method);
	return ret;
}

void* RuntimeInvoker_Int32_t2071877448_Il2CppObject_Il2CppObject_Il2CppObject_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, Il2CppObject * p3, int8_t p4, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], (Il2CppObject *)args[2], *((int8_t*)args[3]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_UInt64_t2909196914_Il2CppObject_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef uint64_t (*Func)(void* obj, Il2CppObject * p1, int32_t p2, const MethodInfo* method);
	uint64_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Il2CppObject_Il2CppObject_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Il2CppObject * p1, int8_t p2, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int8_t*)args[1]), method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Il2CppObject_Int16_t4041245914 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Il2CppObject * p1, int16_t p2, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int16_t*)args[1]), method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Il2CppObject_Int64_t909078037 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Il2CppObject * p1, int64_t p2, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int64_t*)args[1]), method);
	return ret;
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, Il2CppObject * p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), (Il2CppObject *)args[1], method);
	return NULL;
}

void* RuntimeInvoker_Int64_t909078037_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef int64_t (*Func)(void* obj, int32_t p1, const MethodInfo* method);
	int64_t ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Il2CppObject * p1, int32_t p2, Il2CppObject * p3, int32_t p4, int32_t p5, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), (Il2CppObject *)args[2], *((int32_t*)args[3]), *((int32_t*)args[4]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, int32_t p1, int32_t p2, int32_t p3, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((int32_t*)args[1]), *((int32_t*)args[2]), method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Int64_t909078037 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, int64_t p1, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((int64_t*)args[0]), method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Int64_t909078037_Int64_t909078037 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, int64_t p1, int64_t p2, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((int64_t*)args[0]), *((int64_t*)args[1]), method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Int64_t909078037_Int64_t909078037_Int64_t909078037 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, int64_t p1, int64_t p2, int64_t p3, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((int64_t*)args[0]), *((int64_t*)args[1]), *((int64_t*)args[2]), method);
	return ret;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Int64_t909078037 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, int64_t p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int64_t*)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Int64_t909078037_Int64_t909078037 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, int64_t p2, int64_t p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int64_t*)args[1]), *((int64_t*)args[2]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Int64_t909078037_Int64_t909078037_Int64_t909078037 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, int64_t p2, int64_t p3, int64_t p4, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int64_t*)args[1]), *((int64_t*)args[2]), *((int64_t*)args[3]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, int32_t p2, int32_t p3, int32_t p4, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), *((int32_t*)args[3]), method);
	return NULL;
}

void* RuntimeInvoker_Il2CppObject_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Il2CppObject * p1, int32_t p2, int32_t p3, int32_t p4, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), *((int32_t*)args[3]), method);
	return ret;
}

void* RuntimeInvoker_Int32_t2071877448_Il2CppObject_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, Il2CppObject * p3, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], (Il2CppObject *)args[2], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, int32_t p2, int32_t p3, Il2CppObject * p4, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), (Il2CppObject *)args[3], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, int32_t p2, int32_t p3, Il2CppObject * p4, Il2CppObject * p5, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), (Il2CppObject *)args[3], (Il2CppObject *)args[4], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Int64_t909078037_Il2CppObject_Int64_t909078037_Int64_t909078037 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, int64_t p2, Il2CppObject * p3, int64_t p4, int64_t p5, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int64_t*)args[1]), (Il2CppObject *)args[2], *((int64_t*)args[3]), *((int64_t*)args[4]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Il2CppObject_Int64_t909078037 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, int64_t p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], *((int64_t*)args[2]), method);
	return NULL;
}

void* RuntimeInvoker_Int32_t2071877448_Il2CppObject_Il2CppObject_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, int32_t p3, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], *((int32_t*)args[2]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Il2CppObject_Il2CppObject_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, int32_t p3, int32_t p4, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], *((int32_t*)args[2]), *((int32_t*)args[3]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, Il2CppObject * p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], (Il2CppObject *)args[2], method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Il2CppObject_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, int32_t p3, int32_t p4, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], *((int32_t*)args[2]), *((int32_t*)args[3]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, int32_t p2, int32_t p3, Il2CppObject * p4, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), (Il2CppObject *)args[3], method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, int32_t p3, int32_t p4, Il2CppObject * p5, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], *((int32_t*)args[2]), *((int32_t*)args[3]), (Il2CppObject *)args[4], method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, int32_t p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((int32_t*)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_IntPtr_t (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, IntPtr_t p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((IntPtr_t*)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, int32_t p1, int32_t p2, Il2CppObject * p3, Il2CppObject * p4, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((int32_t*)args[1]), (Il2CppObject *)args[2], (Il2CppObject *)args[3], method);
	return ret;
}

void* RuntimeInvoker_TypeAttributes_t2229518203 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_MemberTypes_t3343038963 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_RuntimeTypeHandle_t2330101084 (const MethodInfo* method, void* obj, void** args)
{
	typedef RuntimeTypeHandle_t2330101084  (*Func)(void* obj, const MethodInfo* method);
	RuntimeTypeHandle_t2330101084  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Il2CppObject_Il2CppObject_SByte_t454417549_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Il2CppObject * p1, int8_t p2, int8_t p3, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int8_t*)args[1]), *((int8_t*)args[2]), method);
	return ret;
}

void* RuntimeInvoker_TypeCode_t2536926201_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Il2CppObject_RuntimeTypeHandle_t2330101084 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, RuntimeTypeHandle_t2330101084  p1, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((RuntimeTypeHandle_t2330101084 *)args[0]), method);
	return ret;
}

void* RuntimeInvoker_RuntimeTypeHandle_t2330101084_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef RuntimeTypeHandle_t2330101084  (*Func)(void* obj, Il2CppObject * p1, const MethodInfo* method);
	RuntimeTypeHandle_t2330101084  ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Il2CppObject_Il2CppObject_Int32_t2071877448_Il2CppObject_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Il2CppObject * p1, int32_t p2, Il2CppObject * p3, Il2CppObject * p4, Il2CppObject * p5, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), (Il2CppObject *)args[2], (Il2CppObject *)args[3], (Il2CppObject *)args[4], method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Il2CppObject_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Il2CppObject * p1, int32_t p2, Il2CppObject * p3, int32_t p4, Il2CppObject * p5, Il2CppObject * p6, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), (Il2CppObject *)args[2], *((int32_t*)args[3]), (Il2CppObject *)args[4], (Il2CppObject *)args[5], method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Il2CppObject_Int32_t2071877448_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Il2CppObject * p1, int32_t p2, Il2CppObject * p3, Il2CppObject * p4, Il2CppObject * p5, Il2CppObject * p6, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), (Il2CppObject *)args[2], (Il2CppObject *)args[3], (Il2CppObject *)args[4], (Il2CppObject *)args[5], method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, int32_t p1, Il2CppObject * p2, int32_t p3, Il2CppObject * p4, Il2CppObject * p5, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), (Il2CppObject *)args[1], *((int32_t*)args[2]), (Il2CppObject *)args[3], (Il2CppObject *)args[4], method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Int32_t2071877448_Il2CppObject_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, int32_t p1, Il2CppObject * p2, Il2CppObject * p3, Il2CppObject * p4, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), (Il2CppObject *)args[1], (Il2CppObject *)args[2], (Il2CppObject *)args[3], method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Il2CppObject_Int32_t2071877448_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Il2CppObject * p1, int32_t p2, Il2CppObject * p3, Il2CppObject * p4, Il2CppObject * p5, Il2CppObject * p6, Il2CppObject * p7, Il2CppObject * p8, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), (Il2CppObject *)args[2], (Il2CppObject *)args[3], (Il2CppObject *)args[4], (Il2CppObject *)args[5], (Il2CppObject *)args[6], (Il2CppObject *)args[7], method);
	return ret;
}

void* RuntimeInvoker_Boolean_t3825574718_Il2CppObject_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Il2CppObject * p1, int8_t p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int8_t*)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Il2CppObject_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, int8_t p1, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((int8_t*)args[0]), method);
	return ret;
}

void* RuntimeInvoker_IntPtr_t (const MethodInfo* method, void* obj, void** args)
{
	typedef IntPtr_t (*Func)(void* obj, const MethodInfo* method);
	IntPtr_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, int8_t p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int8_t*)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_SByte_t454417549_SByte_t454417549_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int8_t p1, int8_t p2, int32_t p3, int32_t p4, int32_t p5, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int8_t*)args[0]), *((int8_t*)args[1]), *((int32_t*)args[2]), *((int32_t*)args[3]), *((int32_t*)args[4]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_RuntimeFieldHandle_t2331729674 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, RuntimeFieldHandle_t2331729674  p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((RuntimeFieldHandle_t2331729674 *)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_IntPtr_t_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, IntPtr_t p1, int8_t p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((IntPtr_t*)args[0]), *((int8_t*)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, int32_t p2, int32_t p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((int32_t*)args[1]), *((int32_t*)args[2]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, int32_t p2, int32_t p3, int8_t p4, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((int32_t*)args[1]), *((int32_t*)args[2]), *((int8_t*)args[3]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_SByte_t454417549_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int8_t p1, int8_t p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int8_t*)args[0]), *((int8_t*)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Il2CppObject_ContractionU5BU5DU26_t4026870663_Level2MapU5BU5DU26_t1752902637 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, ContractionU5BU5D_t4233480993** p3, Level2MapU5BU5D_t2838259787** p4, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], (ContractionU5BU5D_t4233480993**)args[2], (Level2MapU5BU5D_t2838259787**)args[3], method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_CodePointIndexerU26_t2645147126_ByteU2AU26_t3544685828_ByteU2AU26_t3544685828_CodePointIndexerU26_t2645147126_ByteU2AU26_t3544685828 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, CodePointIndexer_t1073906970 ** p2, uint8_t** p3, uint8_t** p4, CodePointIndexer_t1073906970 ** p5, uint8_t** p6, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (CodePointIndexer_t1073906970 **)args[1], (uint8_t**)args[2], (uint8_t**)args[3], (CodePointIndexer_t1073906970 **)args[4], (uint8_t**)args[5], method);
	return NULL;
}

void* RuntimeInvoker_Byte_t3683104436_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef uint8_t (*Func)(void* obj, int32_t p1, const MethodInfo* method);
	uint8_t ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Int32_t2071877448_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, int32_t p1, int8_t p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((int8_t*)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_UInt32_t2149682021_Il2CppObject_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef uint32_t (*Func)(void* obj, Il2CppObject * p1, int32_t p2, const MethodInfo* method);
	uint32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Byte_t3683104436_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef uint8_t (*Func)(void* obj, int32_t p1, int32_t p2, const MethodInfo* method);
	uint8_t ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((int32_t*)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, int32_t p1, int32_t p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((int32_t*)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, int32_t p1, int32_t p2, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((int32_t*)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_ExtenderType_t1556892101_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, int32_t p1, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Il2CppObject_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, int32_t p2, int32_t p3, Il2CppObject * p4, int32_t p5, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), (Il2CppObject *)args[3], *((int32_t*)args[4]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Int32_t2071877448_Il2CppObject_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, int32_t p2, Il2CppObject * p3, int32_t p4, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((int32_t*)args[1]), (Il2CppObject *)args[2], *((int32_t*)args[3]), method);
	return NULL;
}

void* RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448_BooleanU26_t3168250738_BooleanU26_t3168250738_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, int32_t p2, int32_t p3, Il2CppObject * p4, int32_t p5, int32_t p6, bool* p7, bool* p8, int8_t p9, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), (Il2CppObject *)args[3], *((int32_t*)args[4]), *((int32_t*)args[5]), (bool*)args[6], (bool*)args[7], *((int8_t*)args[8]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, int32_t p2, int32_t p3, Il2CppObject * p4, int32_t p5, int32_t p6, int32_t p7, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), (Il2CppObject *)args[3], *((int32_t*)args[4]), *((int32_t*)args[5]), *((int32_t*)args[6]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Il2CppObject * p1, int32_t p2, int32_t p3, Il2CppObject * p4, int32_t p5, int32_t p6, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), (Il2CppObject *)args[3], *((int32_t*)args[4]), *((int32_t*)args[5]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448_BooleanU26_t3168250738_BooleanU26_t3168250738_SByte_t454417549_SByte_t454417549_ContextU26_t3131521781 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, int32_t p2, int32_t p3, Il2CppObject * p4, int32_t p5, int32_t p6, bool* p7, bool* p8, int8_t p9, int8_t p10, Context_t2636657155 * p11, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), (Il2CppObject *)args[3], *((int32_t*)args[4]), *((int32_t*)args[5]), (bool*)args[6], (bool*)args[7], *((int8_t*)args[8]), *((int8_t*)args[9]), (Context_t2636657155 *)args[10], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_SByte_t454417549_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, int8_t p1, int8_t p2, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((int8_t*)args[0]), *((int8_t*)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Il2CppObject_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, int32_t p3, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], *((int32_t*)args[2]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, int32_t p3, int32_t p4, int32_t p5, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], *((int32_t*)args[2]), *((int32_t*)args[3]), *((int32_t*)args[4]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Il2CppObject_Int32_t2071877448_Int32_t2071877448_SByte_t454417549_ContextU26_t3131521781 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, int32_t p3, int32_t p4, int8_t p5, Context_t2636657155 * p6, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], *((int32_t*)args[2]), *((int32_t*)args[3]), *((int8_t*)args[4]), (Context_t2636657155 *)args[5], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Il2CppObject_Il2CppObject_Int32_t2071877448_Int32_t2071877448_BooleanU26_t3168250738 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, int32_t p3, int32_t p4, bool* p5, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], *((int32_t*)args[2]), *((int32_t*)args[3]), (bool*)args[4], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Il2CppObject_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, int32_t p3, int32_t p4, int32_t p5, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], *((int32_t*)args[2]), *((int32_t*)args[3]), *((int32_t*)args[4]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Il2CppObject_Int16_t4041245914_Int32_t2071877448_SByte_t454417549_ContextU26_t3131521781 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, int32_t p2, int32_t p3, Il2CppObject * p4, int16_t p5, int32_t p6, int8_t p7, Context_t2636657155 * p8, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), (Il2CppObject *)args[3], *((int16_t*)args[4]), *((int32_t*)args[5]), *((int8_t*)args[6]), (Context_t2636657155 *)args[7], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Il2CppObject_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Il2CppObject_ContextU26_t3131521781 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, int32_t p3, int32_t p4, Il2CppObject * p5, Context_t2636657155 * p6, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], *((int32_t*)args[2]), *((int32_t*)args[3]), (Il2CppObject *)args[4], (Context_t2636657155 *)args[5], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Il2CppObject_Int32_t2071877448_SByte_t454417549_ContextU26_t3131521781 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, int32_t p2, int32_t p3, int32_t p4, Il2CppObject * p5, int32_t p6, int8_t p7, Context_t2636657155 * p8, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), *((int32_t*)args[3]), (Il2CppObject *)args[4], *((int32_t*)args[5]), *((int8_t*)args[6]), (Context_t2636657155 *)args[7], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Int32U26_t455636984_Int32_t2071877448_Int32_t2071877448_Il2CppObject_SByte_t454417549_ContextU26_t3131521781 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Il2CppObject * p1, int32_t* p2, int32_t p3, int32_t p4, Il2CppObject * p5, int8_t p6, Context_t2636657155 * p7, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (int32_t*)args[1], *((int32_t*)args[2]), *((int32_t*)args[3]), (Il2CppObject *)args[4], *((int8_t*)args[5]), (Context_t2636657155 *)args[6], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Int32U26_t455636984_Int32_t2071877448_Int32_t2071877448_Il2CppObject_SByte_t454417549_Int32_t2071877448_ContractionU26_t2019974048_ContextU26_t3131521781 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Il2CppObject * p1, int32_t* p2, int32_t p3, int32_t p4, Il2CppObject * p5, int8_t p6, int32_t p7, Contraction_t1673853792 ** p8, Context_t2636657155 * p9, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (int32_t*)args[1], *((int32_t*)args[2]), *((int32_t*)args[3]), (Il2CppObject *)args[4], *((int8_t*)args[5]), *((int32_t*)args[6]), (Contraction_t1673853792 **)args[7], (Context_t2636657155 *)args[8], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Il2CppObject_Int32_t2071877448_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, int32_t p1, Il2CppObject * p2, int32_t p3, int32_t p4, Il2CppObject * p5, int32_t p6, int8_t p7, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), (Il2CppObject *)args[1], *((int32_t*)args[2]), *((int32_t*)args[3]), (Il2CppObject *)args[4], *((int32_t*)args[5]), *((int8_t*)args[6]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Int32U26_t455636984_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Il2CppObject_SByte_t454417549_ContextU26_t3131521781 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Il2CppObject * p1, int32_t* p2, int32_t p3, int32_t p4, int32_t p5, Il2CppObject * p6, int8_t p7, Context_t2636657155 * p8, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (int32_t*)args[1], *((int32_t*)args[2]), *((int32_t*)args[3]), *((int32_t*)args[4]), (Il2CppObject *)args[5], *((int8_t*)args[6]), (Context_t2636657155 *)args[7], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Int32U26_t455636984_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Il2CppObject_SByte_t454417549_Int32_t2071877448_ContractionU26_t2019974048_ContextU26_t3131521781 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Il2CppObject * p1, int32_t* p2, int32_t p3, int32_t p4, int32_t p5, Il2CppObject * p6, int8_t p7, int32_t p8, Contraction_t1673853792 ** p9, Context_t2636657155 * p10, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (int32_t*)args[1], *((int32_t*)args[2]), *((int32_t*)args[3]), *((int32_t*)args[4]), (Il2CppObject *)args[5], *((int8_t*)args[6]), *((int32_t*)args[7]), (Contraction_t1673853792 **)args[8], (Context_t2636657155 *)args[9], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, Il2CppObject * p2, Il2CppObject * p3, Il2CppObject * p4, Il2CppObject * p5, Il2CppObject * p6, int8_t p7, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), (Il2CppObject *)args[1], (Il2CppObject *)args[2], (Il2CppObject *)args[3], (Il2CppObject *)args[4], (Il2CppObject *)args[5], *((int8_t*)args[6]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Il2CppObject_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, Il2CppObject * p2, int32_t p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), (Il2CppObject *)args[1], *((int32_t*)args[2]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Il2CppObject_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, Il2CppObject * p2, Il2CppObject * p3, int32_t p4, int32_t p5, int32_t p6, int32_t p7, int32_t p8, int32_t p9, int32_t p10, int32_t p11, int32_t p12, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), (Il2CppObject *)args[1], (Il2CppObject *)args[2], *((int32_t*)args[3]), *((int32_t*)args[4]), *((int32_t*)args[5]), *((int32_t*)args[6]), *((int32_t*)args[7]), *((int32_t*)args[8]), *((int32_t*)args[9]), *((int32_t*)args[10]), *((int32_t*)args[11]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Int32_t2071877448_Il2CppObject_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, int32_t p2, Il2CppObject * p3, int8_t p4, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((int32_t*)args[1]), (Il2CppObject *)args[2], *((int8_t*)args[3]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_SByte_t454417549_SByte_t454417549_SByte_t454417549_SByte_t454417549_SByte_t454417549_SByte_t454417549_SByte_t454417549_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int8_t p1, int8_t p2, int8_t p3, int8_t p4, int8_t p5, int8_t p6, int8_t p7, int8_t p8, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int8_t*)args[0]), *((int8_t*)args[1]), *((int8_t*)args[2]), *((int8_t*)args[3]), *((int8_t*)args[4]), *((int8_t*)args[5]), *((int8_t*)args[6]), *((int8_t*)args[7]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_SByte_t454417549_SByte_t454417549_SByte_t454417549_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int8_t p1, int8_t p2, int8_t p3, int8_t p4, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int8_t*)args[0]), *((int8_t*)args[1]), *((int8_t*)args[2]), *((int8_t*)args[3]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_SByte_t454417549_ByteU5BU5DU26_t790777611_Int32U26_t455636984 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int8_t p1, ByteU5BU5D_t3397334013** p2, int32_t* p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int8_t*)args[0]), (ByteU5BU5D_t3397334013**)args[1], (int32_t*)args[2], method);
	return NULL;
}

void* RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32_t2071877448_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, int32_t p2, int8_t p3, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), *((int8_t*)args[2]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_ConfidenceFactor_t1997037801 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, int8_t p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((int8_t*)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Sign_t874893935_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Il2CppObject_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, int32_t p2, int32_t p3, Il2CppObject * p4, int32_t p5, int32_t p6, Il2CppObject * p7, int32_t p8, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), (Il2CppObject *)args[3], *((int32_t*)args[4]), *((int32_t*)args[5]), (Il2CppObject *)args[6], *((int32_t*)args[7]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, int32_t p2, int32_t p3, Il2CppObject * p4, int32_t p5, int32_t p6, Il2CppObject * p7, int32_t p8, int32_t p9, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), (Il2CppObject *)args[3], *((int32_t*)args[4]), *((int32_t*)args[5]), (Il2CppObject *)args[6], *((int32_t*)args[7]), *((int32_t*)args[8]), method);
	return NULL;
}

void* RuntimeInvoker_DSAParameters_t1872138834_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef DSAParameters_t1872138834  (*Func)(void* obj, int8_t p1, const MethodInfo* method);
	DSAParameters_t1872138834  ret = ((Func)method->methodPointer)(obj, *((int8_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_DSAParameters_t1872138834 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, DSAParameters_t1872138834  p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((DSAParameters_t1872138834 *)args[0]), method);
	return NULL;
}

void* RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, Il2CppObject * p3, Il2CppObject * p4, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], (Il2CppObject *)args[2], (Il2CppObject *)args[3], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, Il2CppObject * p3, Il2CppObject * p4, int8_t p5, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], (Il2CppObject *)args[2], (Il2CppObject *)args[3], *((int8_t*)args[4]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Il2CppObject_Il2CppObject_DSAParameters_t1872138834 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Il2CppObject * p1, DSAParameters_t1872138834  p2, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((DSAParameters_t1872138834 *)args[1]), method);
	return ret;
}

void* RuntimeInvoker_RSAParameters_t1462703416_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef RSAParameters_t1462703416  (*Func)(void* obj, int8_t p1, const MethodInfo* method);
	RSAParameters_t1462703416  ret = ((Func)method->methodPointer)(obj, *((int8_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_RSAParameters_t1462703416 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RSAParameters_t1462703416  p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((RSAParameters_t1462703416 *)args[0]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_SByte_t454417549_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, int8_t p2, Il2CppObject * p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int8_t*)args[1]), (Il2CppObject *)args[2], method);
	return NULL;
}

void* RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Il2CppObject_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, int32_t p2, int32_t p3, Il2CppObject * p4, int32_t p5, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), (Il2CppObject *)args[3], *((int32_t*)args[4]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Il2CppObject_Il2CppObject_Il2CppObject_Int32_t2071877448_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, int32_t p3, Il2CppObject * p4, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], *((int32_t*)args[2]), (Il2CppObject *)args[3], method);
	return ret;
}

void* RuntimeInvoker_DSAParameters_t1872138834_BooleanU26_t3168250738 (const MethodInfo* method, void* obj, void** args)
{
	typedef DSAParameters_t1872138834  (*Func)(void* obj, bool* p1, const MethodInfo* method);
	DSAParameters_t1872138834  ret = ((Func)method->methodPointer)(obj, (bool*)args[0], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Int32_t2071877448_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, int32_t p2, Il2CppObject * p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), (Il2CppObject *)args[2], method);
	return NULL;
}

void* RuntimeInvoker_Il2CppObject_Il2CppObject_SByte_t454417549_Il2CppObject_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Il2CppObject * p1, int8_t p2, Il2CppObject * p3, int8_t p4, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int8_t*)args[1]), (Il2CppObject *)args[2], *((int8_t*)args[3]), method);
	return ret;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Il2CppObject_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, int8_t p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], *((int8_t*)args[2]), method);
	return NULL;
}

void* RuntimeInvoker_DateTime_t693205669 (const MethodInfo* method, void* obj, void** args)
{
	typedef DateTime_t693205669  (*Func)(void* obj, const MethodInfo* method);
	DateTime_t693205669  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_SByte_t454417549_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int8_t p1, Il2CppObject * p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int8_t*)args[0]), (Il2CppObject *)args[1], method);
	return NULL;
}

void* RuntimeInvoker_Byte_t3683104436 (const MethodInfo* method, void* obj, void** args)
{
	typedef uint8_t (*Func)(void* obj, const MethodInfo* method);
	uint8_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Int32U26_t455636984_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, int32_t* p2, int32_t p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (int32_t*)args[1], *((int32_t*)args[2]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Int32U26_t455636984_ByteU26_t1147306860_Int32U26_t455636984_ByteU5BU5DU26_t790777611 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, int32_t* p2, uint8_t* p3, int32_t* p4, ByteU5BU5D_t3397334013** p5, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (int32_t*)args[1], (uint8_t*)args[2], (int32_t*)args[3], (ByteU5BU5D_t3397334013**)args[4], method);
	return NULL;
}

void* RuntimeInvoker_Il2CppObject_Int32_t2071877448_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, int32_t p1, int8_t p2, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((int8_t*)args[1]), method);
	return ret;
}

void* RuntimeInvoker_Int16_t4041245914_Il2CppObject_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef int16_t (*Func)(void* obj, Il2CppObject * p1, int32_t p2, const MethodInfo* method);
	int16_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Single_t2076509932_Il2CppObject_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef float (*Func)(void* obj, Il2CppObject * p1, int32_t p2, const MethodInfo* method);
	float ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Double_t4078015681_Il2CppObject_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef double (*Func)(void* obj, Il2CppObject * p1, int32_t p2, const MethodInfo* method);
	double ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Il2CppObject_Int16_t4041245914_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, int16_t p1, int8_t p2, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((int16_t*)args[0]), *((int8_t*)args[1]), method);
	return ret;
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, Il2CppObject * p2, Il2CppObject * p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), (Il2CppObject *)args[1], (Il2CppObject *)args[2], method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Single_t2076509932_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, float p2, Il2CppObject * p3, Il2CppObject * p4, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((float*)args[1]), (Il2CppObject *)args[2], (Il2CppObject *)args[3], method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Single_t2076509932 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, float p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((float*)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Single_t2076509932_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, float p2, Il2CppObject * p3, Il2CppObject * p4, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((float*)args[1]), (Il2CppObject *)args[2], (Il2CppObject *)args[3], method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Single_t2076509932_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, float p2, Il2CppObject * p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((float*)args[1]), (Il2CppObject *)args[2], method);
	return NULL;
}

void* RuntimeInvoker_DictionaryEntry_t3048875398 (const MethodInfo* method, void* obj, void** args)
{
	typedef DictionaryEntry_t3048875398  (*Func)(void* obj, const MethodInfo* method);
	DictionaryEntry_t3048875398  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Int32_t2071877448_SByte_t454417549_MethodBaseU26_t1609135766_Int32U26_t455636984_Int32U26_t455636984_StringU26_t638738783_Int32U26_t455636984_Int32U26_t455636984 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, int32_t p1, int8_t p2, MethodBase_t904190842 ** p3, int32_t* p4, int32_t* p5, String_t** p6, int32_t* p7, int32_t* p8, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((int8_t*)args[1]), (MethodBase_t904190842 **)args[2], (int32_t*)args[3], (int32_t*)args[4], (String_t**)args[5], (int32_t*)args[6], (int32_t*)args[7], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Int32_t2071877448_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, int32_t p2, int8_t p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), *((int8_t*)args[2]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Int32_t2071877448_SByte_t454417549_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, int32_t p2, int8_t p3, int8_t p4, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), *((int8_t*)args[2]), *((int8_t*)args[3]), method);
	return NULL;
}

void* RuntimeInvoker_Il2CppObject_Il2CppObject_Int32_t2071877448_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Il2CppObject * p1, int32_t p2, int8_t p3, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), *((int8_t*)args[2]), method);
	return ret;
}

void* RuntimeInvoker_Int32_t2071877448_DateTime_t693205669 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, DateTime_t693205669  p1, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((DateTime_t693205669 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_DayOfWeek_t721777893_DateTime_t693205669 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, DateTime_t693205669  p1, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((DateTime_t693205669 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Int32U26_t455636984_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, int32_t* p1, int32_t p2, int32_t p3, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (int32_t*)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_DayOfWeek_t721777893_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, int32_t p1, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Int32U26_t455636984_Int32U26_t455636984_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t* p1, int32_t* p2, int32_t p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (int32_t*)args[0], (int32_t*)args[1], *((int32_t*)args[2]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Int32U26_t455636984_Int32U26_t455636984_Int32U26_t455636984_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t* p1, int32_t* p2, int32_t* p3, int32_t p4, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (int32_t*)args[0], (int32_t*)args[1], (int32_t*)args[2], *((int32_t*)args[3]), method);
	return NULL;
}

void* RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Il2CppObject_Int32_t2071877448_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, int32_t p2, int32_t p3, Il2CppObject * p4, int32_t p5, int8_t p6, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), (Il2CppObject *)args[3], *((int32_t*)args[4]), *((int8_t*)args[5]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_SByte_t454417549_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, int8_t p2, int8_t p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((int8_t*)args[1]), *((int8_t*)args[2]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_SByte_t454417549_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, int8_t p2, int8_t p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int8_t*)args[1]), *((int8_t*)args[2]), method);
	return NULL;
}

void* RuntimeInvoker_Il2CppObject_Int16_t4041245914 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, int16_t p1, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((int16_t*)args[0]), method);
	return ret;
}

void* RuntimeInvoker_Void_t1841601450_DateTime_t693205669_DateTime_t693205669_TimeSpan_t3430258949 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, DateTime_t693205669  p1, DateTime_t693205669  p2, TimeSpan_t3430258949  p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((DateTime_t693205669 *)args[0]), *((DateTime_t693205669 *)args[1]), *((TimeSpan_t3430258949 *)args[2]), method);
	return NULL;
}

void* RuntimeInvoker_TimeSpan_t3430258949 (const MethodInfo* method, void* obj, void** args)
{
	typedef TimeSpan_t3430258949  (*Func)(void* obj, const MethodInfo* method);
	TimeSpan_t3430258949  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Int32_t2071877448_Il2CppObject_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, int32_t p2, Il2CppObject * p3, int8_t p4, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), (Il2CppObject *)args[2], *((int8_t*)args[3]), method);
	return NULL;
}

void* RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Int32U26_t455636984 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, int32_t p2, int32_t p3, int32_t* p4, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), (int32_t*)args[3], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Char_t3454481338 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppChar (*Func)(void* obj, const MethodInfo* method);
	Il2CppChar ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Decimal_t724701077 (const MethodInfo* method, void* obj, void** args)
{
	typedef Decimal_t724701077  (*Func)(void* obj, const MethodInfo* method);
	Decimal_t724701077  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Double_t4078015681 (const MethodInfo* method, void* obj, void** args)
{
	typedef double (*Func)(void* obj, const MethodInfo* method);
	double ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int16_t4041245914 (const MethodInfo* method, void* obj, void** args)
{
	typedef int16_t (*Func)(void* obj, const MethodInfo* method);
	int16_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef int8_t (*Func)(void* obj, const MethodInfo* method);
	int8_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Single_t2076509932 (const MethodInfo* method, void* obj, void** args)
{
	typedef float (*Func)(void* obj, const MethodInfo* method);
	float ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_UInt16_t986882611 (const MethodInfo* method, void* obj, void** args)
{
	typedef uint16_t (*Func)(void* obj, const MethodInfo* method);
	uint16_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_IntPtr_t_Int32_t2071877448_SByte_t454417549_Int32_t2071877448_SByte_t454417549_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, IntPtr_t p1, int32_t p2, int8_t p3, int32_t p4, int8_t p5, int8_t p6, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((IntPtr_t*)args[0]), *((int32_t*)args[1]), *((int8_t*)args[2]), *((int32_t*)args[3]), *((int8_t*)args[4]), *((int8_t*)args[5]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_SByte_t454417549_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, int32_t p2, int32_t p3, int32_t p4, int32_t p5, int8_t p6, int8_t p7, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), *((int32_t*)args[3]), *((int32_t*)args[4]), *((int8_t*)args[5]), *((int8_t*)args[6]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_SByte_t454417549_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, int32_t p2, int32_t p3, int32_t p4, int32_t p5, int8_t p6, int32_t p7, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), *((int32_t*)args[3]), *((int32_t*)args[4]), *((int8_t*)args[5]), *((int32_t*)args[6]), method);
	return NULL;
}

void* RuntimeInvoker_Il2CppObject_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Il2CppObject * p1, int32_t p2, int32_t p3, Il2CppObject * p4, Il2CppObject * p5, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), (Il2CppObject *)args[3], (Il2CppObject *)args[4], method);
	return ret;
}

void* RuntimeInvoker_Int64_t909078037_Int64_t909078037_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef int64_t (*Func)(void* obj, int64_t p1, int32_t p2, const MethodInfo* method);
	int64_t ret = ((Func)method->methodPointer)(obj, *((int64_t*)args[0]), *((int32_t*)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_IntPtr_t_Il2CppObject_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, IntPtr_t p1, Il2CppObject * p2, int32_t p3, int32_t p4, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((IntPtr_t*)args[0]), (Il2CppObject *)args[1], *((int32_t*)args[2]), *((int32_t*)args[3]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Int32_t2071877448_Int32_t2071877448_SByte_t454417549_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, int32_t p2, int32_t p3, int8_t p4, int8_t p5, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), *((int8_t*)args[3]), *((int8_t*)args[4]), method);
	return NULL;
}

void* RuntimeInvoker_Boolean_t3825574718_Il2CppObject_MonoIOErrorU26_t1029615899 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Il2CppObject * p1, int32_t* p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (int32_t*)args[1], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Il2CppObject_Il2CppObject_Il2CppObject_Int32_t2071877448_Int32_t2071877448_MonoIOErrorU26_t1029615899 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, int32_t p3, int32_t p4, int32_t* p5, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], *((int32_t*)args[2]), *((int32_t*)args[3]), (int32_t*)args[4], method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_MonoIOErrorU26_t1029615899 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, int32_t* p1, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (int32_t*)args[0], method);
	return ret;
}

void* RuntimeInvoker_FileAttributes_t3843045335_Il2CppObject_MonoIOErrorU26_t1029615899 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, int32_t* p2, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (int32_t*)args[1], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_MonoFileType_t3095218325_IntPtr_t_MonoIOErrorU26_t1029615899 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, IntPtr_t p1, int32_t* p2, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((IntPtr_t*)args[0]), (int32_t*)args[1], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Il2CppObject_MonoIOStatU26_t2252080831_MonoIOErrorU26_t1029615899 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Il2CppObject * p1, MonoIOStat_t1621921065 * p2, int32_t* p3, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (MonoIOStat_t1621921065 *)args[1], (int32_t*)args[2], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_IntPtr_t_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_MonoIOErrorU26_t1029615899 (const MethodInfo* method, void* obj, void** args)
{
	typedef IntPtr_t (*Func)(void* obj, Il2CppObject * p1, int32_t p2, int32_t p3, int32_t p4, int32_t p5, int32_t* p6, const MethodInfo* method);
	IntPtr_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), *((int32_t*)args[3]), *((int32_t*)args[4]), (int32_t*)args[5], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_IntPtr_t_MonoIOErrorU26_t1029615899 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, IntPtr_t p1, int32_t* p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((IntPtr_t*)args[0]), (int32_t*)args[1], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_IntPtr_t_Il2CppObject_Int32_t2071877448_Int32_t2071877448_MonoIOErrorU26_t1029615899 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, IntPtr_t p1, Il2CppObject * p2, int32_t p3, int32_t p4, int32_t* p5, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((IntPtr_t*)args[0]), (Il2CppObject *)args[1], *((int32_t*)args[2]), *((int32_t*)args[3]), (int32_t*)args[4], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int64_t909078037_IntPtr_t_Int64_t909078037_Int32_t2071877448_MonoIOErrorU26_t1029615899 (const MethodInfo* method, void* obj, void** args)
{
	typedef int64_t (*Func)(void* obj, IntPtr_t p1, int64_t p2, int32_t p3, int32_t* p4, const MethodInfo* method);
	int64_t ret = ((Func)method->methodPointer)(obj, *((IntPtr_t*)args[0]), *((int64_t*)args[1]), *((int32_t*)args[2]), (int32_t*)args[3], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int64_t909078037_IntPtr_t_MonoIOErrorU26_t1029615899 (const MethodInfo* method, void* obj, void** args)
{
	typedef int64_t (*Func)(void* obj, IntPtr_t p1, int32_t* p2, const MethodInfo* method);
	int64_t ret = ((Func)method->methodPointer)(obj, *((IntPtr_t*)args[0]), (int32_t*)args[1], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_IntPtr_t_Int64_t909078037_MonoIOErrorU26_t1029615899 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, IntPtr_t p1, int64_t p2, int32_t* p3, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((IntPtr_t*)args[0]), *((int64_t*)args[1]), (int32_t*)args[2], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Il2CppObject_SByte_t454417549_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, int8_t p3, int32_t p4, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], *((int8_t*)args[2]), *((int32_t*)args[3]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Int16_t4041245914 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int16_t p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int16_t*)args[0]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Il2CppObject_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, int32_t p2, int32_t p3, Il2CppObject * p4, Il2CppObject * p5, Il2CppObject * p6, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), (Il2CppObject *)args[3], (Il2CppObject *)args[4], (Il2CppObject *)args[5], method);
	return NULL;
}

void* RuntimeInvoker_CallingConventions_t1097349142 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_RuntimeMethodHandle_t894824333 (const MethodInfo* method, void* obj, void** args)
{
	typedef RuntimeMethodHandle_t894824333  (*Func)(void* obj, const MethodInfo* method);
	RuntimeMethodHandle_t894824333  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_MethodAttributes_t790385034 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_MethodToken_t3991686330 (const MethodInfo* method, void* obj, void** args)
{
	typedef MethodToken_t3991686330  (*Func)(void* obj, const MethodInfo* method);
	MethodToken_t3991686330  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_FieldAttributes_t1122705193 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_RuntimeFieldHandle_t2331729674 (const MethodInfo* method, void* obj, void** args)
{
	typedef RuntimeFieldHandle_t2331729674  (*Func)(void* obj, const MethodInfo* method);
	RuntimeFieldHandle_t2331729674  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Il2CppObject_Int32_t2071877448_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, int32_t p3, Il2CppObject * p4, Il2CppObject * p5, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], *((int32_t*)args[2]), (Il2CppObject *)args[3], (Il2CppObject *)args[4], method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_OpCode_t2247480392 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, OpCode_t2247480392  p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((OpCode_t2247480392 *)args[0]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_OpCode_t2247480392_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, OpCode_t2247480392  p1, Il2CppObject * p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((OpCode_t2247480392 *)args[0]), (Il2CppObject *)args[1], method);
	return NULL;
}

void* RuntimeInvoker_StackBehaviour_t1390406961 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, int32_t p1, int32_t p2, Il2CppObject * p3, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((int32_t*)args[1]), (Il2CppObject *)args[2], method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Il2CppObject_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, int32_t p1, int32_t p2, Il2CppObject * p3, Il2CppObject * p4, Il2CppObject * p5, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((int32_t*)args[1]), (Il2CppObject *)args[2], (Il2CppObject *)args[3], (Il2CppObject *)args[4], method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Il2CppObject_Int32_t2071877448_SByte_t454417549_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Il2CppObject * p1, int32_t p2, int8_t p3, Il2CppObject * p4, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), *((int8_t*)args[2]), (Il2CppObject *)args[3], method);
	return ret;
}

void* RuntimeInvoker_IntPtr_t_Il2CppObject_Int32U26_t455636984_ModuleU26_t4102634234 (const MethodInfo* method, void* obj, void** args)
{
	typedef IntPtr_t (*Func)(void* obj, Il2CppObject * p1, int32_t* p2, Module_t4282841206 ** p3, const MethodInfo* method);
	IntPtr_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (int32_t*)args[1], (Module_t4282841206 **)args[2], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Il2CppObject_Il2CppObject_Il2CppObject_SByte_t454417549_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, int8_t p3, int8_t p4, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], *((int8_t*)args[2]), *((int8_t*)args[3]), method);
	return ret;
}

void* RuntimeInvoker_AssemblyNameFlags_t1794031440 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Il2CppObject_Int32_t2071877448_Il2CppObject_ObjectU5BU5DU26_t3223402458_Il2CppObject_Il2CppObject_Il2CppObject_ObjectU26_t597476745 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, int32_t p1, Il2CppObject * p2, ObjectU5BU5D_t3614634134** p3, Il2CppObject * p4, Il2CppObject * p5, Il2CppObject * p6, Il2CppObject ** p7, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), (Il2CppObject *)args[1], (ObjectU5BU5D_t3614634134**)args[2], (Il2CppObject *)args[3], (Il2CppObject *)args[4], (Il2CppObject *)args[5], (Il2CppObject **)args[6], method);
	return ret;
}

void* RuntimeInvoker_Void_t1841601450_ObjectU5BU5DU26_t3223402458_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, ObjectU5BU5D_t3614634134** p1, Il2CppObject * p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (ObjectU5BU5D_t3614634134**)args[0], (Il2CppObject *)args[1], method);
	return NULL;
}

void* RuntimeInvoker_Il2CppObject_Int32_t2071877448_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, int32_t p1, Il2CppObject * p2, Il2CppObject * p3, Il2CppObject * p4, Il2CppObject * p5, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), (Il2CppObject *)args[1], (Il2CppObject *)args[2], (Il2CppObject *)args[3], (Il2CppObject *)args[4], method);
	return ret;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_ObjectU5BU5DU26_t3223402458_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, ObjectU5BU5D_t3614634134** p2, Il2CppObject * p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (ObjectU5BU5D_t3614634134**)args[1], (Il2CppObject *)args[2], method);
	return NULL;
}

void* RuntimeInvoker_Il2CppObject_Int32_t2071877448_Il2CppObject_Il2CppObject_Il2CppObject_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, int32_t p1, Il2CppObject * p2, Il2CppObject * p3, Il2CppObject * p4, int8_t p5, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), (Il2CppObject *)args[1], (Il2CppObject *)args[2], (Il2CppObject *)args[3], *((int8_t*)args[4]), method);
	return ret;
}

void* RuntimeInvoker_EventAttributes_t2989788983 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Il2CppObject_IntPtr_t_IntPtr_t (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, IntPtr_t p1, IntPtr_t p2, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((IntPtr_t*)args[0]), *((IntPtr_t*)args[1]), method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_RuntimeFieldHandle_t2331729674 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, RuntimeFieldHandle_t2331729674  p1, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((RuntimeFieldHandle_t2331729674 *)args[0]), method);
	return ret;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, Il2CppObject * p3, Il2CppObject * p4, int32_t p5, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], (Il2CppObject *)args[2], (Il2CppObject *)args[3], *((int32_t*)args[4]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject_Int32_t2071877448_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, Il2CppObject * p3, Il2CppObject * p4, int32_t p5, Il2CppObject * p6, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], (Il2CppObject *)args[2], (Il2CppObject *)args[3], *((int32_t*)args[4]), (Il2CppObject *)args[5], method);
	return NULL;
}

void* RuntimeInvoker_Il2CppObject_StreamingContext_t1417235061 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, StreamingContext_t1417235061  p1, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((StreamingContext_t1417235061 *)args[0]), method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_RuntimeMethodHandle_t894824333 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, RuntimeMethodHandle_t894824333  p1, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((RuntimeMethodHandle_t894824333 *)args[0]), method);
	return ret;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_MonoEventInfoU26_t2234966955 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, MonoEventInfo_t2190036573 * p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (MonoEventInfo_t2190036573 *)args[1], method);
	return NULL;
}

void* RuntimeInvoker_MonoEventInfo_t2190036573_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef MonoEventInfo_t2190036573  (*Func)(void* obj, Il2CppObject * p1, const MethodInfo* method);
	MonoEventInfo_t2190036573  ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_IntPtr_t_MonoMethodInfoU26_t16045984 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, IntPtr_t p1, MonoMethodInfo_t3646562144 * p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((IntPtr_t*)args[0]), (MonoMethodInfo_t3646562144 *)args[1], method);
	return NULL;
}

void* RuntimeInvoker_MonoMethodInfo_t3646562144_IntPtr_t (const MethodInfo* method, void* obj, void** args)
{
	typedef MonoMethodInfo_t3646562144  (*Func)(void* obj, IntPtr_t p1, const MethodInfo* method);
	MonoMethodInfo_t3646562144  ret = ((Func)method->methodPointer)(obj, *((IntPtr_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_MethodAttributes_t790385034_IntPtr_t (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, IntPtr_t p1, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((IntPtr_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_CallingConventions_t1097349142_IntPtr_t (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, IntPtr_t p1, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((IntPtr_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Il2CppObject_IntPtr_t_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, IntPtr_t p1, Il2CppObject * p2, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((IntPtr_t*)args[0]), (Il2CppObject *)args[1], method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Il2CppObject_Il2CppObject_ExceptionU26_t1467204777 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, Exception_t1927440687 ** p3, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], (Exception_t1927440687 **)args[2], method);
	return ret;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_MonoPropertyInfoU26_t828568312_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, MonoPropertyInfo_t486106184 * p2, int32_t p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (MonoPropertyInfo_t486106184 *)args[1], *((int32_t*)args[2]), method);
	return NULL;
}

void* RuntimeInvoker_PropertyAttributes_t883448530 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Il2CppObject_Int32_t2071877448_Il2CppObject_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, int32_t p3, Il2CppObject * p4, Il2CppObject * p5, Il2CppObject * p6, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], *((int32_t*)args[2]), (Il2CppObject *)args[3], (Il2CppObject *)args[4], (Il2CppObject *)args[5], method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Il2CppObject_Il2CppObject_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, Il2CppObject * p3, int32_t p4, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], (Il2CppObject *)args[2], *((int32_t*)args[3]), method);
	return NULL;
}

void* RuntimeInvoker_ParameterAttributes_t1266705348 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Int64_t909078037_ResourceInfoU26_t3126209420 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int64_t p1, ResourceInfo_t3933049236 * p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int64_t*)args[0]), (ResourceInfo_t3933049236 *)args[1], method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Int64_t909078037_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, int64_t p2, int32_t p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int64_t*)args[1]), *((int32_t*)args[2]), method);
	return NULL;
}

void* RuntimeInvoker_GCHandle_t3409268066_Il2CppObject_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef GCHandle_t3409268066  (*Func)(void* obj, Il2CppObject * p1, int32_t p2, const MethodInfo* method);
	GCHandle_t3409268066  ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_IntPtr_t_Int32_t2071877448_Il2CppObject_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, IntPtr_t p1, int32_t p2, Il2CppObject * p3, int32_t p4, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((IntPtr_t*)args[0]), *((int32_t*)args[1]), (Il2CppObject *)args[2], *((int32_t*)args[3]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_IntPtr_t_Il2CppObject_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, IntPtr_t p1, Il2CppObject * p2, int32_t p3, int32_t p4, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((IntPtr_t*)args[0]), (Il2CppObject *)args[1], *((int32_t*)args[2]), *((int32_t*)args[3]), method);
	return NULL;
}

void* RuntimeInvoker_Byte_t3683104436_IntPtr_t_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef uint8_t (*Func)(void* obj, IntPtr_t p1, int32_t p2, const MethodInfo* method);
	uint8_t ret = ((Func)method->methodPointer)(obj, *((IntPtr_t*)args[0]), *((int32_t*)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_IntPtr_t_Int32_t2071877448_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, IntPtr_t p1, int32_t p2, int8_t p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((IntPtr_t*)args[0]), *((int32_t*)args[1]), *((int8_t*)args[2]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_BooleanU26_t3168250738 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, bool* p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (bool*)args[0], method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_IntPtr_t (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, IntPtr_t p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((IntPtr_t*)args[0]), method);
	return NULL;
}

void* RuntimeInvoker_Il2CppObject_Il2CppObject_Il2CppObject_StringU26_t638738783 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, String_t** p3, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], (String_t**)args[2], method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject_StringU26_t638738783 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, Il2CppObject * p3, String_t** p4, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], (Il2CppObject *)args[2], (String_t**)args[3], method);
	return ret;
}

void* RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, Il2CppObject * p3, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], (Il2CppObject *)args[2], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_SByte_t454417549_Il2CppObject_SByte_t454417549_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int8_t p1, Il2CppObject * p2, int8_t p3, int8_t p4, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int8_t*)args[0]), (Il2CppObject *)args[1], *((int8_t*)args[2]), *((int8_t*)args[3]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_TimeSpan_t3430258949 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, TimeSpan_t3430258949  p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((TimeSpan_t3430258949 *)args[0]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Byte_t3683104436 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, uint8_t p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((uint8_t*)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Il2CppObject_SByte_t454417549_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, int8_t p3, Il2CppObject * p4, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], *((int8_t*)args[2]), (Il2CppObject *)args[3], method);
	return NULL;
}

void* RuntimeInvoker_Il2CppObject_Il2CppObject_Il2CppObject_StreamingContext_t1417235061_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, StreamingContext_t1417235061  p3, Il2CppObject * p4, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], *((StreamingContext_t1417235061 *)args[2]), (Il2CppObject *)args[3], method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Il2CppObject_StreamingContext_t1417235061_ISurrogateSelectorU26_t2635255864 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Il2CppObject * p1, StreamingContext_t1417235061  p2, Il2CppObject ** p3, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((StreamingContext_t1417235061 *)args[1]), (Il2CppObject **)args[2], method);
	return ret;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_IntPtr_t_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, IntPtr_t p2, Il2CppObject * p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((IntPtr_t*)args[1]), (Il2CppObject *)args[2], method);
	return NULL;
}

void* RuntimeInvoker_TimeSpan_t3430258949_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef TimeSpan_t3430258949  (*Func)(void* obj, Il2CppObject * p1, const MethodInfo* method);
	TimeSpan_t3430258949  ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Il2CppObject_StringU26_t638738783 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, String_t** p1, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (String_t**)args[0], method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Il2CppObject_Il2CppObject_ObjectU26_t597476745 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, Il2CppObject ** p3, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], (Il2CppObject **)args[2], method);
	return ret;
}

void* RuntimeInvoker_Boolean_t3825574718_Il2CppObject_StringU26_t638738783_StringU26_t638738783 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Il2CppObject * p1, String_t** p2, String_t** p3, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (String_t**)args[1], (String_t**)args[2], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_WellKnownObjectMode_t2630225581 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_StreamingContext_t1417235061 (const MethodInfo* method, void* obj, void** args)
{
	typedef StreamingContext_t1417235061  (*Func)(void* obj, const MethodInfo* method);
	StreamingContext_t1417235061  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_TypeFilterLevel_t1182459634 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_BooleanU26_t3168250738 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, bool* p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (bool*)args[1], method);
	return NULL;
}

void* RuntimeInvoker_Il2CppObject_Byte_t3683104436_Il2CppObject_SByte_t454417549_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, uint8_t p1, Il2CppObject * p2, int8_t p3, Il2CppObject * p4, Il2CppObject * p5, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((uint8_t*)args[0]), (Il2CppObject *)args[1], *((int8_t*)args[2]), (Il2CppObject *)args[3], (Il2CppObject *)args[4], method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Byte_t3683104436_Il2CppObject_SByte_t454417549_Il2CppObject_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, uint8_t p1, Il2CppObject * p2, int8_t p3, Il2CppObject * p4, Il2CppObject * p5, Il2CppObject * p6, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((uint8_t*)args[0]), (Il2CppObject *)args[1], *((int8_t*)args[2]), (Il2CppObject *)args[3], (Il2CppObject *)args[4], (Il2CppObject *)args[5], method);
	return ret;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_SByte_t454417549_ObjectU26_t597476745_HeaderU5BU5DU26_t2818328198 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, int8_t p2, Il2CppObject ** p3, HeaderU5BU5D_t2408360458** p4, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int8_t*)args[1]), (Il2CppObject **)args[2], (HeaderU5BU5D_t2408360458**)args[3], method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Byte_t3683104436_Il2CppObject_SByte_t454417549_ObjectU26_t597476745_HeaderU5BU5DU26_t2818328198 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, uint8_t p1, Il2CppObject * p2, int8_t p3, Il2CppObject ** p4, HeaderU5BU5D_t2408360458** p5, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((uint8_t*)args[0]), (Il2CppObject *)args[1], *((int8_t*)args[2]), (Il2CppObject **)args[3], (HeaderU5BU5D_t2408360458**)args[4], method);
	return NULL;
}

void* RuntimeInvoker_Boolean_t3825574718_Byte_t3683104436_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, uint8_t p1, Il2CppObject * p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((uint8_t*)args[0]), (Il2CppObject *)args[1], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Byte_t3683104436_Il2CppObject_Int64U26_t763825331_ObjectU26_t597476745_SerializationInfoU26_t4051840202 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, uint8_t p1, Il2CppObject * p2, int64_t* p3, Il2CppObject ** p4, SerializationInfo_t228987430 ** p5, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((uint8_t*)args[0]), (Il2CppObject *)args[1], (int64_t*)args[2], (Il2CppObject **)args[3], (SerializationInfo_t228987430 **)args[4], method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_SByte_t454417549_SByte_t454417549_Int64U26_t763825331_ObjectU26_t597476745_SerializationInfoU26_t4051840202 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, int8_t p2, int8_t p3, int64_t* p4, Il2CppObject ** p5, SerializationInfo_t228987430 ** p6, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int8_t*)args[1]), *((int8_t*)args[2]), (int64_t*)args[3], (Il2CppObject **)args[4], (SerializationInfo_t228987430 **)args[5], method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Int64U26_t763825331_ObjectU26_t597476745_SerializationInfoU26_t4051840202 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, int64_t* p2, Il2CppObject ** p3, SerializationInfo_t228987430 ** p4, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (int64_t*)args[1], (Il2CppObject **)args[2], (SerializationInfo_t228987430 **)args[3], method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Il2CppObject_Int64_t909078037_ObjectU26_t597476745_SerializationInfoU26_t4051840202 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, int64_t p3, Il2CppObject ** p4, SerializationInfo_t228987430 ** p5, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], *((int64_t*)args[2]), (Il2CppObject **)args[3], (SerializationInfo_t228987430 **)args[4], method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Int64_t909078037_Il2CppObject_Il2CppObject_Int64_t909078037_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int64_t p1, Il2CppObject * p2, Il2CppObject * p3, int64_t p4, Il2CppObject * p5, Il2CppObject * p6, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int64_t*)args[0]), (Il2CppObject *)args[1], (Il2CppObject *)args[2], *((int64_t*)args[3]), (Il2CppObject *)args[4], (Il2CppObject *)args[5], method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Int64U26_t763825331_ObjectU26_t597476745 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, int64_t* p2, Il2CppObject ** p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (int64_t*)args[1], (Il2CppObject **)args[2], method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Il2CppObject_Int64U26_t763825331_ObjectU26_t597476745 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, int64_t* p3, Il2CppObject ** p4, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], (int64_t*)args[2], (Il2CppObject **)args[3], method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Il2CppObject_Int64_t909078037_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, int64_t p3, Il2CppObject * p4, Il2CppObject * p5, Il2CppObject * p6, Il2CppObject * p7, Il2CppObject * p8, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], *((int64_t*)args[2]), (Il2CppObject *)args[3], (Il2CppObject *)args[4], (Il2CppObject *)args[5], (Il2CppObject *)args[6], (Il2CppObject *)args[7], method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, Il2CppObject * p3, Il2CppObject * p4, Il2CppObject * p5, Il2CppObject * p6, Il2CppObject * p7, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], (Il2CppObject *)args[2], (Il2CppObject *)args[3], (Il2CppObject *)args[4], (Il2CppObject *)args[5], (Il2CppObject *)args[6], method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Int64_t909078037_Int64_t909078037_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int64_t p1, int64_t p2, Il2CppObject * p3, Il2CppObject * p4, Il2CppObject * p5, Il2CppObject * p6, Il2CppObject * p7, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int64_t*)args[0]), *((int64_t*)args[1]), (Il2CppObject *)args[2], (Il2CppObject *)args[3], (Il2CppObject *)args[4], (Il2CppObject *)args[5], (Il2CppObject *)args[6], method);
	return NULL;
}

void* RuntimeInvoker_Il2CppObject_Int64_t909078037_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, int64_t p1, Il2CppObject * p2, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((int64_t*)args[0]), (Il2CppObject *)args[1], method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Il2CppObject_Byte_t3683104436 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Il2CppObject * p1, uint8_t p2, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((uint8_t*)args[1]), method);
	return ret;
}

void* RuntimeInvoker_Void_t1841601450_Int64_t909078037_Int32_t2071877448_Int64_t909078037 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int64_t p1, int32_t p2, int64_t p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int64_t*)args[0]), *((int32_t*)args[1]), *((int64_t*)args[2]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Int64_t909078037_Il2CppObject_Int64_t909078037 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int64_t p1, Il2CppObject * p2, int64_t p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int64_t*)args[0]), (Il2CppObject *)args[1], *((int64_t*)args[2]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Int64_t909078037_Il2CppObject_Int64_t909078037_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, int64_t p2, Il2CppObject * p3, int64_t p4, Il2CppObject * p5, Il2CppObject * p6, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int64_t*)args[1]), (Il2CppObject *)args[2], *((int64_t*)args[3]), (Il2CppObject *)args[4], (Il2CppObject *)args[5], method);
	return NULL;
}

void* RuntimeInvoker_Boolean_t3825574718_SByte_t454417549_Il2CppObject_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, int8_t p1, Il2CppObject * p2, int8_t p3, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((int8_t*)args[0]), (Il2CppObject *)args[1], *((int8_t*)args[2]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Il2CppObject_StreamingContext_t1417235061 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, StreamingContext_t1417235061  p3, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], *((StreamingContext_t1417235061 *)args[2]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Il2CppObject_StreamingContext_t1417235061 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, StreamingContext_t1417235061  p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], *((StreamingContext_t1417235061 *)args[2]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_StreamingContext_t1417235061 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, StreamingContext_t1417235061  p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((StreamingContext_t1417235061 *)args[0]), method);
	return NULL;
}

void* RuntimeInvoker_Il2CppObject_StreamingContext_t1417235061_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, StreamingContext_t1417235061  p1, Il2CppObject * p2, Il2CppObject * p3, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((StreamingContext_t1417235061 *)args[0]), (Il2CppObject *)args[1], (Il2CppObject *)args[2], method);
	return ret;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Int16_t4041245914 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, int16_t p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int16_t*)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_DateTime_t693205669 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, DateTime_t693205669  p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((DateTime_t693205669 *)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Single_t2076509932 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, float p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((float*)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_SerializationEntry_t3485203212 (const MethodInfo* method, void* obj, void** args)
{
	typedef SerializationEntry_t3485203212  (*Func)(void* obj, const MethodInfo* method);
	SerializationEntry_t3485203212  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_StreamingContextStates_t4264247603 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_CspProviderFlags_t105264000 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_SByte_t454417549_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, int8_t p2, Il2CppObject * p3, Il2CppObject * p4, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int8_t*)args[1]), (Il2CppObject *)args[2], (Il2CppObject *)args[3], method);
	return NULL;
}

void* RuntimeInvoker_UInt32_t2149682021_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef uint32_t (*Func)(void* obj, int32_t p1, int32_t p2, const MethodInfo* method);
	uint32_t ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((int32_t*)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Il2CppObject_Il2CppObject_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, Il2CppObject * p3, int8_t p4, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], (Il2CppObject *)args[2], *((int8_t*)args[3]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Int64_t909078037_Il2CppObject_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int64_t p1, Il2CppObject * p2, int32_t p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int64_t*)args[0]), (Il2CppObject *)args[1], *((int32_t*)args[2]), method);
	return NULL;
}

void* RuntimeInvoker_UInt32_t2149682021_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef uint32_t (*Func)(void* obj, int32_t p1, int32_t p2, int32_t p3, const MethodInfo* method);
	uint32_t ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((int32_t*)args[1]), *((int32_t*)args[2]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_UInt32U26_t2197289955_Int32_t2071877448_UInt32U26_t2197289955_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, uint32_t* p1, int32_t p2, uint32_t* p3, int32_t p4, int32_t p5, int32_t p6, int32_t p7, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (uint32_t*)args[0], *((int32_t*)args[1]), (uint32_t*)args[2], *((int32_t*)args[3]), *((int32_t*)args[4]), *((int32_t*)args[5]), *((int32_t*)args[6]), method);
	return NULL;
}

void* RuntimeInvoker_IntPtr_t_IntPtr_t_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef IntPtr_t (*Func)(void* obj, IntPtr_t p1, Il2CppObject * p2, const MethodInfo* method);
	IntPtr_t ret = ((Func)method->methodPointer)(obj, *((IntPtr_t*)args[0]), (Il2CppObject *)args[1], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_UInt32_t2149682021_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef uint32_t (*Func)(void* obj, int32_t p1, const MethodInfo* method);
	uint32_t ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Int64_t909078037_Int64_t909078037 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int64_t p1, int64_t p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int64_t*)args[0]), *((int64_t*)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_UInt64_t2909196914_Int64_t909078037_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef uint64_t (*Func)(void* obj, int64_t p1, int32_t p2, const MethodInfo* method);
	uint64_t ret = ((Func)method->methodPointer)(obj, *((int64_t*)args[0]), *((int32_t*)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_UInt64_t2909196914_Int64_t909078037_Int64_t909078037_Int64_t909078037 (const MethodInfo* method, void* obj, void** args)
{
	typedef uint64_t (*Func)(void* obj, int64_t p1, int64_t p2, int64_t p3, const MethodInfo* method);
	uint64_t ret = ((Func)method->methodPointer)(obj, *((int64_t*)args[0]), *((int64_t*)args[1]), *((int64_t*)args[2]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_UInt64_t2909196914_Int64_t909078037 (const MethodInfo* method, void* obj, void** args)
{
	typedef uint64_t (*Func)(void* obj, int64_t p1, const MethodInfo* method);
	uint64_t ret = ((Func)method->methodPointer)(obj, *((int64_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_CipherMode_t162592484 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_PaddingMode_t3032142640 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_StringBuilderU26_t731233658_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, StringBuilder_t1221177846 ** p1, int32_t p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (StringBuilder_t1221177846 **)args[0], *((int32_t*)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Il2CppObject_IntPtr_t_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, IntPtr_t p1, int32_t p2, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((IntPtr_t*)args[0]), *((int32_t*)args[1]), method);
	return ret;
}

void* RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Il2CppObject_Int32_t2071877448_EncoderFallbackBufferU26_t1009712630_CharU5BU5DU26_t3108165433 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, int32_t p2, int32_t p3, Il2CppObject * p4, int32_t p5, EncoderFallbackBuffer_t3883615514 ** p6, CharU5BU5D_t1328083999** p7, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), (Il2CppObject *)args[3], *((int32_t*)args[4]), (EncoderFallbackBuffer_t3883615514 **)args[5], (CharU5BU5D_t1328083999**)args[6], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Il2CppObject_Int32_t2071877448_DecoderFallbackBufferU26_t3597875002 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, int32_t p2, int32_t p3, Il2CppObject * p4, int32_t p5, DecoderFallbackBuffer_t4206371382 ** p6, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), (Il2CppObject *)args[3], *((int32_t*)args[4]), (DecoderFallbackBuffer_t4206371382 **)args[5], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Il2CppObject_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, int32_t p2, Il2CppObject * p3, int32_t p4, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), (Il2CppObject *)args[2], *((int32_t*)args[3]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Int16_t4041245914_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, int16_t p1, int32_t p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((int16_t*)args[0]), *((int32_t*)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Int16_t4041245914_Int16_t4041245914_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, int16_t p1, int16_t p2, int32_t p3, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((int16_t*)args[0]), *((int16_t*)args[1]), *((int32_t*)args[2]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Int16_t4041245914_Int16_t4041245914_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int16_t p1, int16_t p2, int32_t p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int16_t*)args[0]), *((int16_t*)args[1]), *((int32_t*)args[2]), method);
	return NULL;
}

void* RuntimeInvoker_Il2CppObject_Int32U26_t455636984 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, int32_t* p1, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (int32_t*)args[0], method);
	return ret;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, int32_t p2, int32_t p3, int32_t p4, int32_t p5, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), *((int32_t*)args[3]), *((int32_t*)args[4]), method);
	return NULL;
}

void* RuntimeInvoker_Il2CppObject_Int32_t2071877448_Il2CppObject_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, int32_t p1, Il2CppObject * p2, int32_t p3, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), (Il2CppObject *)args[1], *((int32_t*)args[2]), method);
	return ret;
}

void* RuntimeInvoker_Void_t1841601450_SByte_t454417549_SByte_t454417549_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int8_t p1, int8_t p2, int8_t p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int8_t*)args[0]), *((int8_t*)args[1]), *((int8_t*)args[2]), method);
	return NULL;
}

void* RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448_SByte_t454417549_Int32_t2071877448_SByte_t454417549_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, int32_t p2, int32_t p3, int8_t p4, int32_t p5, int8_t p6, int8_t p7, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), *((int8_t*)args[3]), *((int32_t*)args[4]), *((int8_t*)args[5]), *((int8_t*)args[6]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Il2CppObject_Int32_t2071877448_SByte_t454417549_Int32U26_t455636984_BooleanU26_t3168250738_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, int32_t p2, int32_t p3, Il2CppObject * p4, int32_t p5, int8_t p6, int32_t* p7, bool* p8, int8_t p9, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), (Il2CppObject *)args[3], *((int32_t*)args[4]), *((int8_t*)args[5]), (int32_t*)args[6], (bool*)args[7], *((int8_t*)args[8]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32U26_t455636984 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, int32_t p2, int32_t p3, Il2CppObject * p4, int32_t p5, int32_t* p6, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), (Il2CppObject *)args[3], *((int32_t*)args[4]), (int32_t*)args[5], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448_CharU26_t1894467670_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, int32_t p2, int32_t p3, Il2CppChar* p4, int8_t p5, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), (Il2CppChar*)args[3], *((int8_t*)args[4]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32_t2071877448_CharU26_t1894467670_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, int32_t p2, Il2CppChar* p3, int8_t p4, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), (Il2CppChar*)args[2], *((int8_t*)args[3]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Il2CppObject_Int32_t2071877448_CharU26_t1894467670_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, int32_t p2, int32_t p3, Il2CppObject * p4, int32_t p5, Il2CppChar* p6, int8_t p7, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), (Il2CppObject *)args[3], *((int32_t*)args[4]), (Il2CppChar*)args[5], *((int8_t*)args[6]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Il2CppObject_Int32_t2071877448_CharU26_t1894467670_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, int32_t p2, Il2CppObject * p3, int32_t p4, Il2CppChar* p5, int8_t p6, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), (Il2CppObject *)args[2], *((int32_t*)args[3]), (Il2CppChar*)args[4], *((int8_t*)args[5]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Il2CppObject_DecoderFallbackBufferU26_t3597875002_ByteU5BU5DU26_t790777611_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, int32_t p2, int32_t p3, int32_t p4, int32_t p5, Il2CppObject * p6, DecoderFallbackBuffer_t4206371382 ** p7, ByteU5BU5D_t3397334013** p8, int8_t p9, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), *((int32_t*)args[3]), *((int32_t*)args[4]), (Il2CppObject *)args[5], (DecoderFallbackBuffer_t4206371382 **)args[6], (ByteU5BU5D_t3397334013**)args[7], *((int8_t*)args[8]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Il2CppObject_DecoderFallbackBufferU26_t3597875002_ByteU5BU5DU26_t790777611_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, int32_t p2, int32_t p3, int32_t p4, Il2CppObject * p5, DecoderFallbackBuffer_t4206371382 ** p6, ByteU5BU5D_t3397334013** p7, int8_t p8, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), *((int32_t*)args[3]), (Il2CppObject *)args[4], (DecoderFallbackBuffer_t4206371382 **)args[5], (ByteU5BU5D_t3397334013**)args[6], *((int8_t*)args[7]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Il2CppObject_DecoderFallbackBufferU26_t3597875002_ByteU5BU5DU26_t790777611_Il2CppObject_Int64_t909078037_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, DecoderFallbackBuffer_t4206371382 ** p2, ByteU5BU5D_t3397334013** p3, Il2CppObject * p4, int64_t p5, int32_t p6, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (DecoderFallbackBuffer_t4206371382 **)args[1], (ByteU5BU5D_t3397334013**)args[2], (Il2CppObject *)args[3], *((int64_t*)args[4]), *((int32_t*)args[5]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_DecoderFallbackBufferU26_t3597875002_ByteU5BU5DU26_t790777611_Il2CppObject_Int64_t909078037_Int32_t2071877448_Il2CppObject_Int32U26_t455636984 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, DecoderFallbackBuffer_t4206371382 ** p2, ByteU5BU5D_t3397334013** p3, Il2CppObject * p4, int64_t p5, int32_t p6, Il2CppObject * p7, int32_t* p8, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (DecoderFallbackBuffer_t4206371382 **)args[1], (ByteU5BU5D_t3397334013**)args[2], (Il2CppObject *)args[3], *((int64_t*)args[4]), *((int32_t*)args[5]), (Il2CppObject *)args[6], (int32_t*)args[7], method);
	return NULL;
}

void* RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Il2CppObject_Int32_t2071877448_UInt32U26_t2197289955_UInt32U26_t2197289955_Il2CppObject_DecoderFallbackBufferU26_t3597875002_ByteU5BU5DU26_t790777611_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, int32_t p2, int32_t p3, Il2CppObject * p4, int32_t p5, uint32_t* p6, uint32_t* p7, Il2CppObject * p8, DecoderFallbackBuffer_t4206371382 ** p9, ByteU5BU5D_t3397334013** p10, int8_t p11, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), (Il2CppObject *)args[3], *((int32_t*)args[4]), (uint32_t*)args[5], (uint32_t*)args[6], (Il2CppObject *)args[7], (DecoderFallbackBuffer_t4206371382 **)args[8], (ByteU5BU5D_t3397334013**)args[9], *((int8_t*)args[10]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Il2CppObject_Int32_t2071877448_UInt32U26_t2197289955_UInt32U26_t2197289955_Il2CppObject_DecoderFallbackBufferU26_t3597875002_ByteU5BU5DU26_t790777611_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, int32_t p2, Il2CppObject * p3, int32_t p4, uint32_t* p5, uint32_t* p6, Il2CppObject * p7, DecoderFallbackBuffer_t4206371382 ** p8, ByteU5BU5D_t3397334013** p9, int8_t p10, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), (Il2CppObject *)args[2], *((int32_t*)args[3]), (uint32_t*)args[4], (uint32_t*)args[5], (Il2CppObject *)args[6], (DecoderFallbackBuffer_t4206371382 **)args[7], (ByteU5BU5D_t3397334013**)args[8], *((int8_t*)args[9]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Il2CppObject_Int32_t2071877448_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, int32_t p3, int8_t p4, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], *((int32_t*)args[2]), *((int8_t*)args[3]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_SByte_t454417549_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int8_t p1, int32_t p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int8_t*)args[0]), *((int32_t*)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Single_t2076509932_SingleU26_t4173844468_Single_t2076509932_Single_t2076509932 (const MethodInfo* method, void* obj, void** args)
{
	typedef float (*Func)(void* obj, float* p1, float p2, float p3, const MethodInfo* method);
	float ret = ((Func)method->methodPointer)(obj, (float*)args[0], *((float*)args[1]), *((float*)args[2]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_IntPtr_t_SByte_t454417549_Il2CppObject_BooleanU26_t3168250738 (const MethodInfo* method, void* obj, void** args)
{
	typedef IntPtr_t (*Func)(void* obj, int8_t p1, Il2CppObject * p2, bool* p3, const MethodInfo* method);
	IntPtr_t ret = ((Func)method->methodPointer)(obj, *((int8_t*)args[0]), (Il2CppObject *)args[1], (bool*)args[2], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_IntPtr_t (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, IntPtr_t p1, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((IntPtr_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_IntPtr_t_SByte_t454417549_SByte_t454417549_Il2CppObject_BooleanU26_t3168250738 (const MethodInfo* method, void* obj, void** args)
{
	typedef IntPtr_t (*Func)(void* obj, int8_t p1, int8_t p2, Il2CppObject * p3, bool* p4, const MethodInfo* method);
	IntPtr_t ret = ((Func)method->methodPointer)(obj, *((int8_t*)args[0]), *((int8_t*)args[1]), (Il2CppObject *)args[2], (bool*)args[3], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_TimeSpan_t3430258949_TimeSpan_t3430258949 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, TimeSpan_t3430258949  p1, TimeSpan_t3430258949  p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((TimeSpan_t3430258949 *)args[0]), *((TimeSpan_t3430258949 *)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Int64_t909078037_Int64_t909078037_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, int64_t p1, int64_t p2, int8_t p3, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((int64_t*)args[0]), *((int64_t*)args[1]), *((int8_t*)args[2]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_IntPtr_t_Int32_t2071877448_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, IntPtr_t p1, int32_t p2, int8_t p3, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((IntPtr_t*)args[0]), *((int32_t*)args[1]), *((int8_t*)args[2]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int64_t909078037_Double_t4078015681 (const MethodInfo* method, void* obj, void** args)
{
	typedef int64_t (*Func)(void* obj, double p1, const MethodInfo* method);
	int64_t ret = ((Func)method->methodPointer)(obj, *((double*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Il2CppObject_Double_t4078015681 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, double p1, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((double*)args[0]), method);
	return ret;
}

void* RuntimeInvoker_Int64_t909078037_Il2CppObject_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef int64_t (*Func)(void* obj, Il2CppObject * p1, int32_t p2, const MethodInfo* method);
	int64_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Il2CppObject_IntPtr_t_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, IntPtr_t p1, int32_t p2, int32_t p3, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((IntPtr_t*)args[0]), *((int32_t*)args[1]), *((int32_t*)args[2]), method);
	return ret;
}

void* RuntimeInvoker_Byte_t3683104436_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef uint8_t (*Func)(void* obj, int8_t p1, const MethodInfo* method);
	uint8_t ret = ((Func)method->methodPointer)(obj, *((int8_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Byte_t3683104436_Int16_t4041245914 (const MethodInfo* method, void* obj, void** args)
{
	typedef uint8_t (*Func)(void* obj, int16_t p1, const MethodInfo* method);
	uint8_t ret = ((Func)method->methodPointer)(obj, *((int16_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Byte_t3683104436_Double_t4078015681 (const MethodInfo* method, void* obj, void** args)
{
	typedef uint8_t (*Func)(void* obj, double p1, const MethodInfo* method);
	uint8_t ret = ((Func)method->methodPointer)(obj, *((double*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Byte_t3683104436_Single_t2076509932 (const MethodInfo* method, void* obj, void** args)
{
	typedef uint8_t (*Func)(void* obj, float p1, const MethodInfo* method);
	uint8_t ret = ((Func)method->methodPointer)(obj, *((float*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Byte_t3683104436_Int64_t909078037 (const MethodInfo* method, void* obj, void** args)
{
	typedef uint8_t (*Func)(void* obj, int64_t p1, const MethodInfo* method);
	uint8_t ret = ((Func)method->methodPointer)(obj, *((int64_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Char_t3454481338_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppChar (*Func)(void* obj, int8_t p1, const MethodInfo* method);
	Il2CppChar ret = ((Func)method->methodPointer)(obj, *((int8_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Char_t3454481338_Int64_t909078037 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppChar (*Func)(void* obj, int64_t p1, const MethodInfo* method);
	Il2CppChar ret = ((Func)method->methodPointer)(obj, *((int64_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Char_t3454481338_Single_t2076509932 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppChar (*Func)(void* obj, float p1, const MethodInfo* method);
	Il2CppChar ret = ((Func)method->methodPointer)(obj, *((float*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Char_t3454481338_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppChar (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, const MethodInfo* method);
	Il2CppChar ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_DateTime_t693205669_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef DateTime_t693205669  (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, const MethodInfo* method);
	DateTime_t693205669  ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_DateTime_t693205669_Int16_t4041245914 (const MethodInfo* method, void* obj, void** args)
{
	typedef DateTime_t693205669  (*Func)(void* obj, int16_t p1, const MethodInfo* method);
	DateTime_t693205669  ret = ((Func)method->methodPointer)(obj, *((int16_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_DateTime_t693205669_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef DateTime_t693205669  (*Func)(void* obj, int32_t p1, const MethodInfo* method);
	DateTime_t693205669  ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_DateTime_t693205669_Int64_t909078037 (const MethodInfo* method, void* obj, void** args)
{
	typedef DateTime_t693205669  (*Func)(void* obj, int64_t p1, const MethodInfo* method);
	DateTime_t693205669  ret = ((Func)method->methodPointer)(obj, *((int64_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_DateTime_t693205669_Single_t2076509932 (const MethodInfo* method, void* obj, void** args)
{
	typedef DateTime_t693205669  (*Func)(void* obj, float p1, const MethodInfo* method);
	DateTime_t693205669  ret = ((Func)method->methodPointer)(obj, *((float*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_DateTime_t693205669_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef DateTime_t693205669  (*Func)(void* obj, int8_t p1, const MethodInfo* method);
	DateTime_t693205669  ret = ((Func)method->methodPointer)(obj, *((int8_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Double_t4078015681_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef double (*Func)(void* obj, int8_t p1, const MethodInfo* method);
	double ret = ((Func)method->methodPointer)(obj, *((int8_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Double_t4078015681_Double_t4078015681 (const MethodInfo* method, void* obj, void** args)
{
	typedef double (*Func)(void* obj, double p1, const MethodInfo* method);
	double ret = ((Func)method->methodPointer)(obj, *((double*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Double_t4078015681_Single_t2076509932 (const MethodInfo* method, void* obj, void** args)
{
	typedef double (*Func)(void* obj, float p1, const MethodInfo* method);
	double ret = ((Func)method->methodPointer)(obj, *((float*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Double_t4078015681_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef double (*Func)(void* obj, int32_t p1, const MethodInfo* method);
	double ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Double_t4078015681_Int64_t909078037 (const MethodInfo* method, void* obj, void** args)
{
	typedef double (*Func)(void* obj, int64_t p1, const MethodInfo* method);
	double ret = ((Func)method->methodPointer)(obj, *((int64_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Double_t4078015681_Int16_t4041245914 (const MethodInfo* method, void* obj, void** args)
{
	typedef double (*Func)(void* obj, int16_t p1, const MethodInfo* method);
	double ret = ((Func)method->methodPointer)(obj, *((int16_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int16_t4041245914_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef int16_t (*Func)(void* obj, int8_t p1, const MethodInfo* method);
	int16_t ret = ((Func)method->methodPointer)(obj, *((int8_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int16_t4041245914_Int16_t4041245914 (const MethodInfo* method, void* obj, void** args)
{
	typedef int16_t (*Func)(void* obj, int16_t p1, const MethodInfo* method);
	int16_t ret = ((Func)method->methodPointer)(obj, *((int16_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int16_t4041245914_Double_t4078015681 (const MethodInfo* method, void* obj, void** args)
{
	typedef int16_t (*Func)(void* obj, double p1, const MethodInfo* method);
	int16_t ret = ((Func)method->methodPointer)(obj, *((double*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int16_t4041245914_Single_t2076509932 (const MethodInfo* method, void* obj, void** args)
{
	typedef int16_t (*Func)(void* obj, float p1, const MethodInfo* method);
	int16_t ret = ((Func)method->methodPointer)(obj, *((float*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int16_t4041245914_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef int16_t (*Func)(void* obj, int32_t p1, const MethodInfo* method);
	int16_t ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int16_t4041245914_Int64_t909078037 (const MethodInfo* method, void* obj, void** args)
{
	typedef int16_t (*Func)(void* obj, int64_t p1, const MethodInfo* method);
	int16_t ret = ((Func)method->methodPointer)(obj, *((int64_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int64_t909078037_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef int64_t (*Func)(void* obj, int8_t p1, const MethodInfo* method);
	int64_t ret = ((Func)method->methodPointer)(obj, *((int8_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int64_t909078037_Int16_t4041245914 (const MethodInfo* method, void* obj, void** args)
{
	typedef int64_t (*Func)(void* obj, int16_t p1, const MethodInfo* method);
	int64_t ret = ((Func)method->methodPointer)(obj, *((int16_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int64_t909078037_Single_t2076509932 (const MethodInfo* method, void* obj, void** args)
{
	typedef int64_t (*Func)(void* obj, float p1, const MethodInfo* method);
	int64_t ret = ((Func)method->methodPointer)(obj, *((float*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int64_t909078037_Int64_t909078037 (const MethodInfo* method, void* obj, void** args)
{
	typedef int64_t (*Func)(void* obj, int64_t p1, const MethodInfo* method);
	int64_t ret = ((Func)method->methodPointer)(obj, *((int64_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_SByte_t454417549_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef int8_t (*Func)(void* obj, int8_t p1, const MethodInfo* method);
	int8_t ret = ((Func)method->methodPointer)(obj, *((int8_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_SByte_t454417549_Int16_t4041245914 (const MethodInfo* method, void* obj, void** args)
{
	typedef int8_t (*Func)(void* obj, int16_t p1, const MethodInfo* method);
	int8_t ret = ((Func)method->methodPointer)(obj, *((int16_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_SByte_t454417549_Double_t4078015681 (const MethodInfo* method, void* obj, void** args)
{
	typedef int8_t (*Func)(void* obj, double p1, const MethodInfo* method);
	int8_t ret = ((Func)method->methodPointer)(obj, *((double*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_SByte_t454417549_Single_t2076509932 (const MethodInfo* method, void* obj, void** args)
{
	typedef int8_t (*Func)(void* obj, float p1, const MethodInfo* method);
	int8_t ret = ((Func)method->methodPointer)(obj, *((float*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_SByte_t454417549_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef int8_t (*Func)(void* obj, int32_t p1, const MethodInfo* method);
	int8_t ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_SByte_t454417549_Int64_t909078037 (const MethodInfo* method, void* obj, void** args)
{
	typedef int8_t (*Func)(void* obj, int64_t p1, const MethodInfo* method);
	int8_t ret = ((Func)method->methodPointer)(obj, *((int64_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Single_t2076509932_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef float (*Func)(void* obj, int8_t p1, const MethodInfo* method);
	float ret = ((Func)method->methodPointer)(obj, *((int8_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Single_t2076509932_Double_t4078015681 (const MethodInfo* method, void* obj, void** args)
{
	typedef float (*Func)(void* obj, double p1, const MethodInfo* method);
	float ret = ((Func)method->methodPointer)(obj, *((double*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Single_t2076509932_Single_t2076509932 (const MethodInfo* method, void* obj, void** args)
{
	typedef float (*Func)(void* obj, float p1, const MethodInfo* method);
	float ret = ((Func)method->methodPointer)(obj, *((float*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Single_t2076509932_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef float (*Func)(void* obj, int32_t p1, const MethodInfo* method);
	float ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Single_t2076509932_Int64_t909078037 (const MethodInfo* method, void* obj, void** args)
{
	typedef float (*Func)(void* obj, int64_t p1, const MethodInfo* method);
	float ret = ((Func)method->methodPointer)(obj, *((int64_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Single_t2076509932_Int16_t4041245914 (const MethodInfo* method, void* obj, void** args)
{
	typedef float (*Func)(void* obj, int16_t p1, const MethodInfo* method);
	float ret = ((Func)method->methodPointer)(obj, *((int16_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_UInt16_t986882611_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef uint16_t (*Func)(void* obj, int8_t p1, const MethodInfo* method);
	uint16_t ret = ((Func)method->methodPointer)(obj, *((int8_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_UInt16_t986882611_Int16_t4041245914 (const MethodInfo* method, void* obj, void** args)
{
	typedef uint16_t (*Func)(void* obj, int16_t p1, const MethodInfo* method);
	uint16_t ret = ((Func)method->methodPointer)(obj, *((int16_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_UInt16_t986882611_Double_t4078015681 (const MethodInfo* method, void* obj, void** args)
{
	typedef uint16_t (*Func)(void* obj, double p1, const MethodInfo* method);
	uint16_t ret = ((Func)method->methodPointer)(obj, *((double*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_UInt16_t986882611_Single_t2076509932 (const MethodInfo* method, void* obj, void** args)
{
	typedef uint16_t (*Func)(void* obj, float p1, const MethodInfo* method);
	uint16_t ret = ((Func)method->methodPointer)(obj, *((float*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_UInt16_t986882611_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef uint16_t (*Func)(void* obj, int32_t p1, const MethodInfo* method);
	uint16_t ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_UInt16_t986882611_Int64_t909078037 (const MethodInfo* method, void* obj, void** args)
{
	typedef uint16_t (*Func)(void* obj, int64_t p1, const MethodInfo* method);
	uint16_t ret = ((Func)method->methodPointer)(obj, *((int64_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_UInt32_t2149682021_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef uint32_t (*Func)(void* obj, int8_t p1, const MethodInfo* method);
	uint32_t ret = ((Func)method->methodPointer)(obj, *((int8_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_UInt32_t2149682021_Int16_t4041245914 (const MethodInfo* method, void* obj, void** args)
{
	typedef uint32_t (*Func)(void* obj, int16_t p1, const MethodInfo* method);
	uint32_t ret = ((Func)method->methodPointer)(obj, *((int16_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_UInt32_t2149682021_Double_t4078015681 (const MethodInfo* method, void* obj, void** args)
{
	typedef uint32_t (*Func)(void* obj, double p1, const MethodInfo* method);
	uint32_t ret = ((Func)method->methodPointer)(obj, *((double*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_UInt32_t2149682021_Single_t2076509932 (const MethodInfo* method, void* obj, void** args)
{
	typedef uint32_t (*Func)(void* obj, float p1, const MethodInfo* method);
	uint32_t ret = ((Func)method->methodPointer)(obj, *((float*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_UInt32_t2149682021_Int64_t909078037 (const MethodInfo* method, void* obj, void** args)
{
	typedef uint32_t (*Func)(void* obj, int64_t p1, const MethodInfo* method);
	uint32_t ret = ((Func)method->methodPointer)(obj, *((int64_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_UInt64_t2909196914_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef uint64_t (*Func)(void* obj, int8_t p1, const MethodInfo* method);
	uint64_t ret = ((Func)method->methodPointer)(obj, *((int8_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_UInt64_t2909196914_Int16_t4041245914 (const MethodInfo* method, void* obj, void** args)
{
	typedef uint64_t (*Func)(void* obj, int16_t p1, const MethodInfo* method);
	uint64_t ret = ((Func)method->methodPointer)(obj, *((int16_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_UInt64_t2909196914_Double_t4078015681 (const MethodInfo* method, void* obj, void** args)
{
	typedef uint64_t (*Func)(void* obj, double p1, const MethodInfo* method);
	uint64_t ret = ((Func)method->methodPointer)(obj, *((double*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_UInt64_t2909196914_Single_t2076509932 (const MethodInfo* method, void* obj, void** args)
{
	typedef uint64_t (*Func)(void* obj, float p1, const MethodInfo* method);
	uint64_t ret = ((Func)method->methodPointer)(obj, *((float*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_UInt64_t2909196914_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef uint64_t (*Func)(void* obj, int32_t p1, const MethodInfo* method);
	uint64_t ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, int32_t p2, int32_t p3, int32_t p4, int32_t p5, int32_t p6, int32_t p7, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((int32_t*)args[1]), *((int32_t*)args[2]), *((int32_t*)args[3]), *((int32_t*)args[4]), *((int32_t*)args[5]), *((int32_t*)args[6]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_SByte_t454417549_TimeSpan_t3430258949 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int8_t p1, TimeSpan_t3430258949  p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int8_t*)args[0]), *((TimeSpan_t3430258949 *)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Int64_t909078037_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int64_t p1, int32_t p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int64_t*)args[0]), *((int32_t*)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_DayOfWeek_t721777893 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_DateTimeKind_t2186819611 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_DateTime_t693205669_TimeSpan_t3430258949 (const MethodInfo* method, void* obj, void** args)
{
	typedef DateTime_t693205669  (*Func)(void* obj, TimeSpan_t3430258949  p1, const MethodInfo* method);
	DateTime_t693205669  ret = ((Func)method->methodPointer)(obj, *((TimeSpan_t3430258949 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_DateTime_t693205669_Double_t4078015681 (const MethodInfo* method, void* obj, void** args)
{
	typedef DateTime_t693205669  (*Func)(void* obj, double p1, const MethodInfo* method);
	DateTime_t693205669  ret = ((Func)method->methodPointer)(obj, *((double*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_DateTime_t693205669_DateTime_t693205669 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, DateTime_t693205669  p1, DateTime_t693205669  p2, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((DateTime_t693205669 *)args[0]), *((DateTime_t693205669 *)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_DateTime_t693205669 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, DateTime_t693205669  p1, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((DateTime_t693205669 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_DateTime_t693205669_DateTime_t693205669_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef DateTime_t693205669  (*Func)(void* obj, DateTime_t693205669  p1, int32_t p2, const MethodInfo* method);
	DateTime_t693205669  ret = ((Func)method->methodPointer)(obj, *((DateTime_t693205669 *)args[0]), *((int32_t*)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_DateTime_t693205669_Il2CppObject_Il2CppObject_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef DateTime_t693205669  (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, int32_t p3, const MethodInfo* method);
	DateTime_t693205669  ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], *((int32_t*)args[2]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Il2CppObject_Int32_t2071877448_DateTimeU26_t3448131235_DateTimeOffsetU26_t3212986406_SByte_t454417549_ExceptionU26_t1467204777 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, int32_t p3, DateTime_t693205669 * p4, DateTimeOffset_t1362988906 * p5, int8_t p6, Exception_t1927440687 ** p7, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], *((int32_t*)args[2]), (DateTime_t693205669 *)args[3], (DateTimeOffset_t1362988906 *)args[4], *((int8_t*)args[5]), (Exception_t1927440687 **)args[6], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Il2CppObject_Il2CppObject_SByte_t454417549_ExceptionU26_t1467204777 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Il2CppObject * p1, int8_t p2, Exception_t1927440687 ** p3, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int8_t*)args[1]), (Exception_t1927440687 **)args[2], method);
	return ret;
}

void* RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_SByte_t454417549_SByte_t454417549_Int32U26_t455636984 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, int32_t p2, int32_t p3, int32_t p4, int8_t p5, int8_t p6, int32_t* p7, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), *((int32_t*)args[3]), *((int8_t*)args[4]), *((int8_t*)args[5]), (int32_t*)args[6], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Il2CppObject_Il2CppObject_SByte_t454417549_Int32U26_t455636984 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, int32_t p2, Il2CppObject * p3, Il2CppObject * p4, int8_t p5, int32_t* p6, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), (Il2CppObject *)args[2], (Il2CppObject *)args[3], *((int8_t*)args[4]), (int32_t*)args[5], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Il2CppObject_Int32U26_t455636984 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Il2CppObject * p1, int32_t p2, int32_t p3, Il2CppObject * p4, int32_t* p5, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), (Il2CppObject *)args[3], (int32_t*)args[4], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Il2CppObject_SByte_t454417549_Int32U26_t455636984_Int32U26_t455636984 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Il2CppObject * p1, int32_t p2, int32_t p3, Il2CppObject * p4, int8_t p5, int32_t* p6, int32_t* p7, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), (Il2CppObject *)args[3], *((int8_t*)args[4]), (int32_t*)args[5], (int32_t*)args[6], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Int32_t2071877448_Il2CppObject_SByte_t454417549_Int32U26_t455636984 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Il2CppObject * p1, int32_t p2, Il2CppObject * p3, int8_t p4, int32_t* p5, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), (Il2CppObject *)args[2], *((int8_t*)args[3]), (int32_t*)args[4], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Il2CppObject_Il2CppObject_SByte_t454417549_DateTimeU26_t3448131235_DateTimeOffsetU26_t3212986406_Il2CppObject_Int32_t2071877448_SByte_t454417549_BooleanU26_t3168250738_BooleanU26_t3168250738 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, Il2CppObject * p3, int8_t p4, DateTime_t693205669 * p5, DateTimeOffset_t1362988906 * p6, Il2CppObject * p7, int32_t p8, int8_t p9, bool* p10, bool* p11, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], (Il2CppObject *)args[2], *((int8_t*)args[3]), (DateTime_t693205669 *)args[4], (DateTimeOffset_t1362988906 *)args[5], (Il2CppObject *)args[6], *((int32_t*)args[7]), *((int8_t*)args[8]), (bool*)args[9], (bool*)args[10], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_DateTime_t693205669_Il2CppObject_Il2CppObject_Il2CppObject_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef DateTime_t693205669  (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, Il2CppObject * p3, int32_t p4, const MethodInfo* method);
	DateTime_t693205669  ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], (Il2CppObject *)args[2], *((int32_t*)args[3]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Il2CppObject_Il2CppObject_Int32_t2071877448_DateTimeU26_t3448131235_SByte_t454417549_BooleanU26_t3168250738_SByte_t454417549_ExceptionU26_t1467204777 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, Il2CppObject * p3, int32_t p4, DateTime_t693205669 * p5, int8_t p6, bool* p7, int8_t p8, Exception_t1927440687 ** p9, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], (Il2CppObject *)args[2], *((int32_t*)args[3]), (DateTime_t693205669 *)args[4], *((int8_t*)args[5]), (bool*)args[6], *((int8_t*)args[7]), (Exception_t1927440687 **)args[8], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_DateTime_t693205669_DateTime_t693205669_TimeSpan_t3430258949 (const MethodInfo* method, void* obj, void** args)
{
	typedef DateTime_t693205669  (*Func)(void* obj, DateTime_t693205669  p1, TimeSpan_t3430258949  p2, const MethodInfo* method);
	DateTime_t693205669  ret = ((Func)method->methodPointer)(obj, *((DateTime_t693205669 *)args[0]), *((TimeSpan_t3430258949 *)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_DateTime_t693205669_DateTime_t693205669 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, DateTime_t693205669  p1, DateTime_t693205669  p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((DateTime_t693205669 *)args[0]), *((DateTime_t693205669 *)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_DateTime_t693205669 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, DateTime_t693205669  p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((DateTime_t693205669 *)args[0]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_DateTime_t693205669_TimeSpan_t3430258949 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, DateTime_t693205669  p1, TimeSpan_t3430258949  p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((DateTime_t693205669 *)args[0]), *((TimeSpan_t3430258949 *)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Int64_t909078037_TimeSpan_t3430258949 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int64_t p1, TimeSpan_t3430258949  p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int64_t*)args[0]), *((TimeSpan_t3430258949 *)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Int32_t2071877448_DateTimeOffset_t1362988906 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, DateTimeOffset_t1362988906  p1, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((DateTimeOffset_t1362988906 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_DateTimeOffset_t1362988906 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, DateTimeOffset_t1362988906  p1, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((DateTimeOffset_t1362988906 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int16_t4041245914 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, int32_t p2, int16_t p3, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), *((int16_t*)args[2]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Il2CppObject_Int16_t4041245914_Il2CppObject_BooleanU26_t3168250738_BooleanU26_t3168250738 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, int16_t p1, Il2CppObject * p2, bool* p3, bool* p4, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((int16_t*)args[0]), (Il2CppObject *)args[1], (bool*)args[2], (bool*)args[3], method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Int16_t4041245914_Il2CppObject_BooleanU26_t3168250738_BooleanU26_t3168250738_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, int16_t p1, Il2CppObject * p2, bool* p3, bool* p4, int8_t p5, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((int16_t*)args[0]), (Il2CppObject *)args[1], (bool*)args[2], (bool*)args[3], *((int8_t*)args[4]), method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_DateTime_t693205669_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, DateTime_t693205669  p1, Il2CppObject * p2, Il2CppObject * p3, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((DateTime_t693205669 *)args[0]), (Il2CppObject *)args[1], (Il2CppObject *)args[2], method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_DateTime_t693205669_Nullable_1_t1693325264_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, DateTime_t693205669  p1, Nullable_1_t1693325264  p2, Il2CppObject * p3, Il2CppObject * p4, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((DateTime_t693205669 *)args[0]), *((Nullable_1_t1693325264 *)args[1]), (Il2CppObject *)args[2], (Il2CppObject *)args[3], method);
	return ret;
}

void* RuntimeInvoker_Void_t1841601450_MonoEnumInfo_t2335995564 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, MonoEnumInfo_t2335995564  p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((MonoEnumInfo_t2335995564 *)args[0]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_MonoEnumInfoU26_t3695146548 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, MonoEnumInfo_t2335995564 * p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (MonoEnumInfo_t2335995564 *)args[1], method);
	return NULL;
}

void* RuntimeInvoker_Int32_t2071877448_Int16_t4041245914_Int16_t4041245914 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, int16_t p1, int16_t p2, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((int16_t*)args[0]), *((int16_t*)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Int64_t909078037_Int64_t909078037 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, int64_t p1, int64_t p2, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((int64_t*)args[0]), *((int64_t*)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_PlatformID_t1006634368 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Int16_t4041245914_Int16_t4041245914_SByte_t454417549_SByte_t454417549_SByte_t454417549_SByte_t454417549_SByte_t454417549_SByte_t454417549_SByte_t454417549_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, int16_t p2, int16_t p3, int8_t p4, int8_t p5, int8_t p6, int8_t p7, int8_t p8, int8_t p9, int8_t p10, int8_t p11, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((int16_t*)args[1]), *((int16_t*)args[2]), *((int8_t*)args[3]), *((int8_t*)args[4]), *((int8_t*)args[5]), *((int8_t*)args[6]), *((int8_t*)args[7]), *((int8_t*)args[8]), *((int8_t*)args[9]), *((int8_t*)args[10]), method);
	return NULL;
}

void* RuntimeInvoker_Int32_t2071877448_Guid_t2533601593 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Guid_t2533601593  p1, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((Guid_t2533601593 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Guid_t2533601593 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Guid_t2533601593  p1, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((Guid_t2533601593 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Guid_t2533601593 (const MethodInfo* method, void* obj, void** args)
{
	typedef Guid_t2533601593  (*Func)(void* obj, const MethodInfo* method);
	Guid_t2533601593  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Il2CppObject_SByte_t454417549_SByte_t454417549_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, int8_t p1, int8_t p2, int8_t p3, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((int8_t*)args[0]), *((int8_t*)args[1]), *((int8_t*)args[2]), method);
	return ret;
}

void* RuntimeInvoker_Double_t4078015681_Double_t4078015681_Double_t4078015681 (const MethodInfo* method, void* obj, void** args)
{
	typedef double (*Func)(void* obj, double p1, double p2, const MethodInfo* method);
	double ret = ((Func)method->methodPointer)(obj, *((double*)args[0]), *((double*)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_TypeAttributes_t2229518203_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Il2CppObject_SByte_t454417549_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, int8_t p1, int8_t p2, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((int8_t*)args[0]), *((int8_t*)args[1]), method);
	return ret;
}

void* RuntimeInvoker_Void_t1841601450_UInt64U2AU26_t2027109114_Int32U2AU26_t347619176_CharU2AU26_t4068306018_CharU2AU26_t4068306018_Int64U2AU26_t3929841737_Int32U2AU26_t347619176 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, uint64_t** p1, int32_t** p2, Il2CppChar** p3, Il2CppChar** p4, int64_t** p5, int32_t** p6, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (uint64_t**)args[0], (int32_t**)args[1], (Il2CppChar**)args[2], (Il2CppChar**)args[3], (int64_t**)args[4], (int32_t**)args[5], method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Int64_t909078037 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, int64_t p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((int64_t*)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Double_t4078015681_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, double p2, int32_t p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((double*)args[1]), *((int32_t*)args[2]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Decimal_t724701077 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, Decimal_t724701077  p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((Decimal_t724701077 *)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Il2CppObject_Il2CppObject_SByte_t454417549_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Il2CppObject * p1, int8_t p2, Il2CppObject * p3, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int8_t*)args[1]), (Il2CppObject *)args[2], method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Il2CppObject_Int16_t4041245914_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Il2CppObject * p1, int16_t p2, Il2CppObject * p3, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int16_t*)args[1]), (Il2CppObject *)args[2], method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Il2CppObject_Int32_t2071877448_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Il2CppObject * p1, int32_t p2, Il2CppObject * p3, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), (Il2CppObject *)args[2], method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Il2CppObject_Int64_t909078037_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Il2CppObject * p1, int64_t p2, Il2CppObject * p3, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int64_t*)args[1]), (Il2CppObject *)args[2], method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Il2CppObject_Single_t2076509932_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Il2CppObject * p1, float p2, Il2CppObject * p3, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((float*)args[1]), (Il2CppObject *)args[2], method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Il2CppObject_Double_t4078015681_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Il2CppObject * p1, double p2, Il2CppObject * p3, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((double*)args[1]), (Il2CppObject *)args[2], method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Il2CppObject_Decimal_t724701077_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Il2CppObject * p1, Decimal_t724701077  p2, Il2CppObject * p3, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((Decimal_t724701077 *)args[1]), (Il2CppObject *)args[2], method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Single_t2076509932_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, float p1, Il2CppObject * p2, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((float*)args[0]), (Il2CppObject *)args[1], method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Double_t4078015681_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, double p1, Il2CppObject * p2, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((double*)args[0]), (Il2CppObject *)args[1], method);
	return ret;
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Int32_t2071877448_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, int32_t p2, Il2CppObject * p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((int32_t*)args[1]), (Il2CppObject *)args[2], method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_BooleanU26_t3168250738_SByte_t454417549_Int32U26_t455636984_Int32U26_t455636984 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, bool* p2, int8_t p3, int32_t* p4, int32_t* p5, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (bool*)args[1], *((int8_t*)args[2]), (int32_t*)args[3], (int32_t*)args[4], method);
	return NULL;
}

void* RuntimeInvoker_Il2CppObject_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Il2CppObject_SByte_t454417549_Il2CppObject_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Il2CppObject * p1, int32_t p2, int32_t p3, Il2CppObject * p4, int8_t p5, Il2CppObject * p6, Il2CppObject * p7, Il2CppObject * p8, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), (Il2CppObject *)args[3], *((int8_t*)args[4]), (Il2CppObject *)args[5], (Il2CppObject *)args[6], (Il2CppObject *)args[7], method);
	return ret;
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, int32_t p2, int32_t p3, int32_t p4, int32_t p5, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((int32_t*)args[1]), *((int32_t*)args[2]), *((int32_t*)args[3]), *((int32_t*)args[4]), method);
	return NULL;
}

void* RuntimeInvoker_Int64_t909078037_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef int64_t (*Func)(void* obj, int32_t p1, int32_t p2, int32_t p3, int32_t p4, int32_t p5, const MethodInfo* method);
	int64_t ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((int32_t*)args[1]), *((int32_t*)args[2]), *((int32_t*)args[3]), *((int32_t*)args[4]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_TimeSpan_t3430258949_TimeSpan_t3430258949 (const MethodInfo* method, void* obj, void** args)
{
	typedef TimeSpan_t3430258949  (*Func)(void* obj, TimeSpan_t3430258949  p1, const MethodInfo* method);
	TimeSpan_t3430258949  ret = ((Func)method->methodPointer)(obj, *((TimeSpan_t3430258949 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_TimeSpan_t3430258949_TimeSpan_t3430258949 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, TimeSpan_t3430258949  p1, TimeSpan_t3430258949  p2, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((TimeSpan_t3430258949 *)args[0]), *((TimeSpan_t3430258949 *)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_TimeSpan_t3430258949 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, TimeSpan_t3430258949  p1, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((TimeSpan_t3430258949 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_TimeSpan_t3430258949 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, TimeSpan_t3430258949  p1, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((TimeSpan_t3430258949 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_TimeSpan_t3430258949_Double_t4078015681 (const MethodInfo* method, void* obj, void** args)
{
	typedef TimeSpan_t3430258949  (*Func)(void* obj, double p1, const MethodInfo* method);
	TimeSpan_t3430258949  ret = ((Func)method->methodPointer)(obj, *((double*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_TimeSpan_t3430258949_Double_t4078015681_Int64_t909078037 (const MethodInfo* method, void* obj, void** args)
{
	typedef TimeSpan_t3430258949  (*Func)(void* obj, double p1, int64_t p2, const MethodInfo* method);
	TimeSpan_t3430258949  ret = ((Func)method->methodPointer)(obj, *((double*)args[0]), *((int64_t*)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_TimeSpan_t3430258949_TimeSpan_t3430258949_TimeSpan_t3430258949 (const MethodInfo* method, void* obj, void** args)
{
	typedef TimeSpan_t3430258949  (*Func)(void* obj, TimeSpan_t3430258949  p1, TimeSpan_t3430258949  p2, const MethodInfo* method);
	TimeSpan_t3430258949  ret = ((Func)method->methodPointer)(obj, *((TimeSpan_t3430258949 *)args[0]), *((TimeSpan_t3430258949 *)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_TimeSpan_t3430258949_DateTime_t693205669 (const MethodInfo* method, void* obj, void** args)
{
	typedef TimeSpan_t3430258949  (*Func)(void* obj, DateTime_t693205669  p1, const MethodInfo* method);
	TimeSpan_t3430258949  ret = ((Func)method->methodPointer)(obj, *((DateTime_t693205669 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_DateTime_t693205669_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, DateTime_t693205669  p1, Il2CppObject * p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((DateTime_t693205669 *)args[0]), (Il2CppObject *)args[1], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_DateTime_t693205669_DateTime_t693205669 (const MethodInfo* method, void* obj, void** args)
{
	typedef DateTime_t693205669  (*Func)(void* obj, DateTime_t693205669  p1, const MethodInfo* method);
	DateTime_t693205669  ret = ((Func)method->methodPointer)(obj, *((DateTime_t693205669 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_TimeSpan_t3430258949_DateTime_t693205669_TimeSpan_t3430258949 (const MethodInfo* method, void* obj, void** args)
{
	typedef TimeSpan_t3430258949  (*Func)(void* obj, DateTime_t693205669  p1, TimeSpan_t3430258949  p2, const MethodInfo* method);
	TimeSpan_t3430258949  ret = ((Func)method->methodPointer)(obj, *((DateTime_t693205669 *)args[0]), *((TimeSpan_t3430258949 *)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Int32_t2071877448_Int64U5BU5DU26_t2476256456_StringU5BU5DU26_t3730240492 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, int32_t p1, Int64U5BU5D_t717125112** p2, StringU5BU5D_t1642385972** p3, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), (Int64U5BU5D_t717125112**)args[1], (StringU5BU5D_t1642385972**)args[2], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, int32_t p2, int32_t p3, int32_t p4, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((int32_t*)args[1]), *((int32_t*)args[2]), *((int32_t*)args[3]), method);
	return NULL;
}

void* RuntimeInvoker_Il2CppObject_Il2CppObject_Int32_t2071877448_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Il2CppObject * p1, int32_t p2, Il2CppObject * p3, Il2CppObject * p4, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), (Il2CppObject *)args[2], (Il2CppObject *)args[3], method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Il2CppObject_DictionaryNodeU26_t2101813158 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Il2CppObject * p1, DictionaryNode_t2725637098 ** p2, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (DictionaryNode_t2725637098 **)args[1], method);
	return ret;
}

void* RuntimeInvoker_EditorBrowsableState_t373498655 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_SocketType_t1143498533 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Il2CppObject_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Il2CppObject * p1, int32_t p2, int32_t p3, int32_t p4, Il2CppObject * p5, Il2CppObject * p6, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), *((int32_t*)args[3]), (Il2CppObject *)args[4], (Il2CppObject *)args[5], method);
	return ret;
}

void* RuntimeInvoker_Void_t1841601450_IntPtr_t_Il2CppObject_Int32U26_t455636984 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, IntPtr_t p1, Il2CppObject * p2, int32_t* p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((IntPtr_t*)args[0]), (Il2CppObject *)args[1], (int32_t*)args[2], method);
	return NULL;
}

void* RuntimeInvoker_Int32_t2071877448_Il2CppObject_SocketErrorU26_t2724123615 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, int32_t* p2, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (int32_t*)args[1], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_IntPtr_t_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_SocketAddressU26_t3239642505_Int32U26_t455636984 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, IntPtr_t p1, Il2CppObject * p2, int32_t p3, int32_t p4, int32_t p5, SocketAddress_t838303055 ** p6, int32_t* p7, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((IntPtr_t*)args[0]), (Il2CppObject *)args[1], *((int32_t*)args[2]), *((int32_t*)args[3]), *((int32_t*)args[4]), (SocketAddress_t838303055 **)args[5], (int32_t*)args[6], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_EndPointU26_t983111093 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, int32_t p2, int32_t p3, int32_t p4, EndPoint_t4156119363 ** p5, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), *((int32_t*)args[3]), (EndPoint_t4156119363 **)args[4], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_EndPointU26_t983111093_SByte_t454417549_Int32U26_t455636984 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, int32_t p2, int32_t p3, int32_t p4, EndPoint_t4156119363 ** p5, int8_t p6, int32_t* p7, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), *((int32_t*)args[3]), (EndPoint_t4156119363 **)args[4], *((int8_t*)args[5]), (int32_t*)args[6], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_IntPtr_t_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Il2CppObject_Int32U26_t455636984 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, IntPtr_t p1, Il2CppObject * p2, int32_t p3, int32_t p4, int32_t p5, Il2CppObject * p6, int32_t* p7, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((IntPtr_t*)args[0]), (Il2CppObject *)args[1], *((int32_t*)args[2]), *((int32_t*)args[3]), *((int32_t*)args[4]), (Il2CppObject *)args[5], (int32_t*)args[6], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, int32_t p2, int32_t p3, int32_t p4, Il2CppObject * p5, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), *((int32_t*)args[3]), (Il2CppObject *)args[4], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_IntPtr_t_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Int32U26_t455636984 (const MethodInfo* method, void* obj, void** args)
{
	typedef IntPtr_t (*Func)(void* obj, int32_t p1, int32_t p2, int32_t p3, int32_t* p4, const MethodInfo* method);
	IntPtr_t ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((int32_t*)args[1]), *((int32_t*)args[2]), (int32_t*)args[3], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Il2CppObject_IntPtr_t_Int32U26_t455636984 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, IntPtr_t p1, int32_t* p2, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((IntPtr_t*)args[0]), (int32_t*)args[1], method);
	return ret;
}

void* RuntimeInvoker_Void_t1841601450_IntPtr_t_Int32U26_t455636984 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, IntPtr_t p1, int32_t* p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((IntPtr_t*)args[0]), (int32_t*)args[1], method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_IntPtr_t_Il2CppObject_Int32U26_t455636984_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, IntPtr_t p1, Il2CppObject * p2, int32_t* p3, int8_t p4, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((IntPtr_t*)args[0]), (Il2CppObject *)args[1], (int32_t*)args[2], *((int8_t*)args[3]), method);
	return NULL;
}

void* RuntimeInvoker_Boolean_t3825574718_IntPtr_t_Int32_t2071877448_Int32_t2071877448_Int32U26_t455636984 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, IntPtr_t p1, int32_t p2, int32_t p3, int32_t* p4, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((IntPtr_t*)args[0]), *((int32_t*)args[1]), *((int32_t*)args[2]), (int32_t*)args[3], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Int32_t2071877448_Int32_t2071877448_Int32U26_t455636984 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, int32_t p1, int32_t p2, int32_t* p3, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((int32_t*)args[1]), (int32_t*)args[2], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_IntPtr_t_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Int32U26_t455636984 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, IntPtr_t p1, Il2CppObject * p2, int32_t p3, int32_t p4, int32_t p5, int32_t* p6, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((IntPtr_t*)args[0]), (Il2CppObject *)args[1], *((int32_t*)args[2]), *((int32_t*)args[3]), *((int32_t*)args[4]), (int32_t*)args[5], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_SocketErrorU26_t2724123615 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, int32_t p2, int32_t p3, int32_t p4, int32_t* p5, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), *((int32_t*)args[3]), (int32_t*)args[4], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_IntPtr_t_Int32_t2071877448_Int32_t2071877448_ObjectU26_t597476745_Int32U26_t455636984 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, IntPtr_t p1, int32_t p2, int32_t p3, Il2CppObject ** p4, int32_t* p5, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((IntPtr_t*)args[0]), *((int32_t*)args[1]), *((int32_t*)args[2]), (Il2CppObject **)args[3], (int32_t*)args[4], method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_IntPtr_t_Int32_t2071877448_Int32U26_t455636984 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, IntPtr_t p1, int32_t p2, int32_t* p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((IntPtr_t*)args[0]), *((int32_t*)args[1]), (int32_t*)args[2], method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_IntPtr_t_Int32_t2071877448_Int32_t2071877448_Il2CppObject_Il2CppObject_Int32_t2071877448_Int32U26_t455636984 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, IntPtr_t p1, int32_t p2, int32_t p3, Il2CppObject * p4, Il2CppObject * p5, int32_t p6, int32_t* p7, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((IntPtr_t*)args[0]), *((int32_t*)args[1]), *((int32_t*)args[2]), (Il2CppObject *)args[3], (Il2CppObject *)args[4], *((int32_t*)args[5]), (int32_t*)args[6], method);
	return NULL;
}

void* RuntimeInvoker_SocketError_t307542793 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Il2CppObject_Il2CppObject_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, Il2CppObject * p3, int32_t p4, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], (Il2CppObject *)args[2], *((int32_t*)args[3]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Il2CppObject_StringU26_t638738783_StringU5BU5DU26_t3730240492_StringU5BU5DU26_t3730240492 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Il2CppObject * p1, String_t** p2, StringU5BU5D_t1642385972** p3, StringU5BU5D_t1642385972** p4, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (String_t**)args[1], (StringU5BU5D_t1642385972**)args[2], (StringU5BU5D_t1642385972**)args[3], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_AddressFamily_t303362630 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Il2CppObject_IPAddressU26_t903689901 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Il2CppObject * p1, IPAddress_t1399971723 ** p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (IPAddress_t1399971723 **)args[1], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, int32_t p1, int32_t p2, int32_t p3, int32_t p4, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((int32_t*)args[1]), *((int32_t*)args[2]), *((int32_t*)args[3]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Il2CppObject_IPv6AddressU26_t2456310193 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Il2CppObject * p1, IPv6Address_t2596635879 ** p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (IPv6Address_t2596635879 **)args[1], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_SecurityProtocolType_t3099771628 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_SByte_t454417549_SByte_t454417549_Int32_t2071877448_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int8_t p1, int8_t p2, int32_t p3, int8_t p4, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int8_t*)args[0]), *((int8_t*)args[1]), *((int32_t*)args[2]), *((int8_t*)args[3]), method);
	return NULL;
}

void* RuntimeInvoker_AsnDecodeStatus_t1962003286_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Il2CppObject_Int32_t2071877448_Il2CppObject_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, int32_t p1, Il2CppObject * p2, int8_t p3, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), (Il2CppObject *)args[1], *((int8_t*)args[2]), method);
	return ret;
}

void* RuntimeInvoker_X509ChainStatusFlags_t480677120_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_X509ChainStatusFlags_t480677120_Il2CppObject_Int32_t2071877448_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, int32_t p2, int8_t p3, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), *((int8_t*)args[2]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_X509ChainStatusFlags_t480677120_Il2CppObject_Il2CppObject_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, int8_t p3, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], *((int8_t*)args[2]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_X509ChainStatusFlags_t480677120 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Int32U26_t455636984_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, int32_t* p2, int32_t p3, int32_t p4, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (int32_t*)args[1], *((int32_t*)args[2]), *((int32_t*)args[3]), method);
	return NULL;
}

void* RuntimeInvoker_X509RevocationFlag_t2166064554 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_X509RevocationMode_t2065307963 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_X509VerificationFlags_t2169036324 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_X509KeyUsageFlags_t2461349531 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_X509KeyUsageFlags_t2461349531_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, int32_t p1, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Byte_t3683104436_Int16_t4041245914_Int16_t4041245914 (const MethodInfo* method, void* obj, void** args)
{
	typedef uint8_t (*Func)(void* obj, int16_t p1, int16_t p2, const MethodInfo* method);
	uint8_t ret = ((Func)method->methodPointer)(obj, *((int16_t*)args[0]), *((int16_t*)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Il2CppObject_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, Il2CppObject * p3, int32_t p4, int32_t p5, int32_t p6, int32_t p7, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], (Il2CppObject *)args[2], *((int32_t*)args[3]), *((int32_t*)args[4]), *((int32_t*)args[5]), *((int32_t*)args[6]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Il2CppObject_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, Il2CppObject * p3, int32_t p4, int32_t p5, int32_t p6, int32_t p7, int32_t p8, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], (Il2CppObject *)args[2], *((int32_t*)args[3]), *((int32_t*)args[4]), *((int32_t*)args[5]), *((int32_t*)args[6]), *((int32_t*)args[7]), method);
	return NULL;
}

void* RuntimeInvoker_RegexOptions_t2418259727 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Category_t1984577050_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef uint16_t (*Func)(void* obj, Il2CppObject * p1, const MethodInfo* method);
	uint16_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_UInt16_t986882611_Int16_t4041245914 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, uint16_t p1, int16_t p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((uint16_t*)args[0]), *((int16_t*)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Int32_t2071877448_Int16_t4041245914 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, int32_t p1, int16_t p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((int16_t*)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Int16_t4041245914_SByte_t454417549_SByte_t454417549_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int16_t p1, int8_t p2, int8_t p3, int8_t p4, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int16_t*)args[0]), *((int8_t*)args[1]), *((int8_t*)args[2]), *((int8_t*)args[3]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_UInt16_t986882611_SByte_t454417549_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, uint16_t p1, int8_t p2, int8_t p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((uint16_t*)args[0]), *((int8_t*)args[1]), *((int8_t*)args[2]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Int16_t4041245914_Int16_t4041245914_SByte_t454417549_SByte_t454417549_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int16_t p1, int16_t p2, int8_t p3, int8_t p4, int8_t p5, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int16_t*)args[0]), *((int16_t*)args[1]), *((int8_t*)args[2]), *((int8_t*)args[3]), *((int8_t*)args[4]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Int16_t4041245914_Il2CppObject_SByte_t454417549_SByte_t454417549_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int16_t p1, Il2CppObject * p2, int8_t p3, int8_t p4, int8_t p5, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int16_t*)args[0]), (Il2CppObject *)args[1], *((int8_t*)args[2]), *((int8_t*)args[3]), *((int8_t*)args[4]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_UInt16_t986882611 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, uint16_t p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((uint16_t*)args[0]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Int32_t2071877448_SByte_t454417549_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, int32_t p2, int8_t p3, Il2CppObject * p4, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((int32_t*)args[1]), *((int8_t*)args[2]), (Il2CppObject *)args[3], method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_SByte_t454417549_Int32_t2071877448_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int8_t p1, int32_t p2, Il2CppObject * p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int8_t*)args[0]), *((int32_t*)args[1]), (Il2CppObject *)args[2], method);
	return NULL;
}

void* RuntimeInvoker_UInt16_t986882611_UInt16_t986882611_UInt16_t986882611 (const MethodInfo* method, void* obj, void** args)
{
	typedef uint16_t (*Func)(void* obj, uint16_t p1, uint16_t p2, const MethodInfo* method);
	uint16_t ret = ((Func)method->methodPointer)(obj, *((uint16_t*)args[0]), *((uint16_t*)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_OpFlags_t378191910_SByte_t454417549_SByte_t454417549_SByte_t454417549_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef uint16_t (*Func)(void* obj, int8_t p1, int8_t p2, int8_t p3, int8_t p4, const MethodInfo* method);
	uint16_t ret = ((Func)method->methodPointer)(obj, *((int8_t*)args[0]), *((int8_t*)args[1]), *((int8_t*)args[2]), *((int8_t*)args[3]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_UInt16_t986882611_UInt16_t986882611 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, uint16_t p1, uint16_t p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((uint16_t*)args[0]), *((uint16_t*)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Boolean_t3825574718_Int32_t2071877448_Int32U26_t455636984_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, int32_t p1, int32_t* p2, int32_t p3, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), (int32_t*)args[1], *((int32_t*)args[2]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Int32_t2071877448_Int32U26_t455636984_Int32U26_t455636984_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, int32_t p1, int32_t* p2, int32_t* p3, int8_t p4, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), (int32_t*)args[1], (int32_t*)args[2], *((int8_t*)args[3]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Int32U26_t455636984_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, int32_t* p1, int32_t p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (int32_t*)args[0], *((int32_t*)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_UInt16_t986882611_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, uint16_t p1, int32_t p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((uint16_t*)args[0]), *((int32_t*)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Int32_t2071877448_Int32_t2071877448_SByte_t454417549_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, int32_t p1, int32_t p2, int8_t p3, int32_t p4, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((int32_t*)args[1]), *((int8_t*)args[2]), *((int32_t*)args[3]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Int32U26_t455636984_Int32U26_t455636984 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, int32_t* p2, int32_t* p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), (int32_t*)args[1], (int32_t*)args[2], method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Int32_t2071877448_Int32_t2071877448_SByte_t454417549_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, int32_t p2, int32_t p3, int8_t p4, int32_t p5, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), *((int8_t*)args[3]), *((int32_t*)args[4]), method);
	return NULL;
}

void* RuntimeInvoker_Interval_t2354235237 (const MethodInfo* method, void* obj, void** args)
{
	typedef Interval_t2354235237  (*Func)(void* obj, const MethodInfo* method);
	Interval_t2354235237  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Interval_t2354235237 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Interval_t2354235237  p1, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((Interval_t2354235237 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Interval_t2354235237 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Interval_t2354235237  p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((Interval_t2354235237 *)args[0]), method);
	return NULL;
}

void* RuntimeInvoker_Interval_t2354235237_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef Interval_t2354235237  (*Func)(void* obj, int32_t p1, const MethodInfo* method);
	Interval_t2354235237  ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Int32_t2071877448_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, int32_t p2, Il2CppObject * p3, Il2CppObject * p4, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((int32_t*)args[1]), (Il2CppObject *)args[2], (Il2CppObject *)args[3], method);
	return NULL;
}

void* RuntimeInvoker_Double_t4078015681_Interval_t2354235237 (const MethodInfo* method, void* obj, void** args)
{
	typedef double (*Func)(void* obj, Interval_t2354235237  p1, const MethodInfo* method);
	double ret = ((Func)method->methodPointer)(obj, *((Interval_t2354235237 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Il2CppObject_Interval_t2354235237_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Interval_t2354235237  p1, Il2CppObject * p2, Il2CppObject * p3, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((Interval_t2354235237 *)args[0]), (Il2CppObject *)args[1], (Il2CppObject *)args[2], method);
	return ret;
}

void* RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32U26_t455636984_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, int32_t* p2, int32_t p3, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (int32_t*)args[1], *((int32_t*)args[2]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32U26_t455636984_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, int32_t* p2, int32_t p3, int32_t p4, int32_t p5, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (int32_t*)args[1], *((int32_t*)args[2]), *((int32_t*)args[3]), *((int32_t*)args[4]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Il2CppObject_Il2CppObject_Int32U26_t455636984 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Il2CppObject * p1, int32_t* p2, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (int32_t*)args[1], method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_RegexOptionsU26_t3063574985 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, int32_t* p1, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (int32_t*)args[0], method);
	return ret;
}

void* RuntimeInvoker_Void_t1841601450_RegexOptionsU26_t3063574985_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t* p1, int8_t p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (int32_t*)args[0], *((int8_t*)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Boolean_t3825574718_Int32U26_t455636984_Int32U26_t455636984_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, int32_t* p1, int32_t* p2, int32_t p3, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (int32_t*)args[0], (int32_t*)args[1], *((int32_t*)args[2]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Category_t1984577050 (const MethodInfo* method, void* obj, void** args)
{
	typedef uint16_t (*Func)(void* obj, const MethodInfo* method);
	uint16_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Int32U26_t455636984_Int32U26_t455636984 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t* p1, int32_t* p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (int32_t*)args[0], (int32_t*)args[1], method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Int32_t2071877448_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, int32_t p2, int8_t p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((int32_t*)args[1]), *((int8_t*)args[2]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Il2CppObject_SByte_t454417549_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, int8_t p3, int8_t p4, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], *((int8_t*)args[2]), *((int8_t*)args[3]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_UInt16_t986882611_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, uint16_t p1, int8_t p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((uint16_t*)args[0]), *((int8_t*)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Int16_t4041245914_Int16_t4041245914 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int16_t p1, int16_t p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int16_t*)args[0]), *((int16_t*)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Il2CppObject_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, int32_t p2, int32_t p3, Il2CppObject * p4, int8_t p5, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), (Il2CppObject *)args[3], *((int8_t*)args[4]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Int32_t2071877448_Int32_t2071877448_UInt16_t986882611 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, int32_t p2, int32_t p3, uint16_t p4, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), *((uint16_t*)args[3]), method);
	return NULL;
}

void* RuntimeInvoker_Position_t3781184359 (const MethodInfo* method, void* obj, void** args)
{
	typedef uint16_t (*Func)(void* obj, const MethodInfo* method);
	uint16_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_UriHostNameType_t2148127109_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_StringU26_t638738783 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, String_t** p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (String_t**)args[0], method);
	return NULL;
}

void* RuntimeInvoker_Il2CppObject_Il2CppObject_SByte_t454417549_SByte_t454417549_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Il2CppObject * p1, int8_t p2, int8_t p3, int8_t p4, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int8_t*)args[1]), *((int8_t*)args[2]), *((int8_t*)args[3]), method);
	return ret;
}

void* RuntimeInvoker_Char_t3454481338_Il2CppObject_Int32U26_t455636984_CharU26_t1894467670 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppChar (*Func)(void* obj, Il2CppObject * p1, int32_t* p2, Il2CppChar* p3, const MethodInfo* method);
	Il2CppChar ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (int32_t*)args[1], (Il2CppChar*)args[2], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_UriFormatExceptionU26_t1218551640 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, UriFormatException_t3682083048 ** p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (UriFormatException_t3682083048 **)args[1], method);
	return NULL;
}

void* RuntimeInvoker_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject_Int32_t2071877448_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, Il2CppObject * p3, int32_t p4, Il2CppObject * p5, Il2CppObject * p6, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], (Il2CppObject *)args[2], *((int32_t*)args[3]), (Il2CppObject *)args[4], (Il2CppObject *)args[5], method);
	return ret;
}

void* RuntimeInvoker_Sign_t874893936_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_ConfidenceFactor_t1997037802 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_UInt32_t2149682021_Int32_t2071877448_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef uint32_t (*Func)(void* obj, int32_t p1, int8_t p2, const MethodInfo* method);
	uint32_t ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((int8_t*)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_UInt32U26_t2197289955_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, uint32_t* p1, int32_t p2, int32_t p3, int32_t p4, int32_t p5, int8_t p6, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (uint32_t*)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), *((int32_t*)args[3]), *((int32_t*)args[4]), *((int8_t*)args[5]), method);
	return NULL;
}

void* RuntimeInvoker_X509ChainStatusFlags_t2843686920 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Byte_t3683104436 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, uint8_t p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((uint8_t*)args[0]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Byte_t3683104436_Byte_t3683104436 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, uint8_t p1, uint8_t p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((uint8_t*)args[0]), *((uint8_t*)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_AlertLevel_t1706602846 (const MethodInfo* method, void* obj, void** args)
{
	typedef uint8_t (*Func)(void* obj, const MethodInfo* method);
	uint8_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_AlertDescription_t844791462 (const MethodInfo* method, void* obj, void** args)
{
	typedef uint8_t (*Func)(void* obj, const MethodInfo* method);
	uint8_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Il2CppObject_Byte_t3683104436 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, uint8_t p1, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((uint8_t*)args[0]), method);
	return ret;
}

void* RuntimeInvoker_Void_t1841601450_Int16_t4041245914_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_SByte_t454417549_SByte_t454417549_SByte_t454417549_SByte_t454417549_Int16_t4041245914_SByte_t454417549_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int16_t p1, Il2CppObject * p2, int32_t p3, int32_t p4, int32_t p5, int8_t p6, int8_t p7, int8_t p8, int8_t p9, int16_t p10, int8_t p11, int8_t p12, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int16_t*)args[0]), (Il2CppObject *)args[1], *((int32_t*)args[2]), *((int32_t*)args[3]), *((int32_t*)args[4]), *((int8_t*)args[5]), *((int8_t*)args[6]), *((int8_t*)args[7]), *((int8_t*)args[8]), *((int16_t*)args[9]), *((int8_t*)args[10]), *((int8_t*)args[11]), method);
	return NULL;
}

void* RuntimeInvoker_CipherAlgorithmType_t4212518094 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_HashAlgorithmType_t1654661965 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_ExchangeAlgorithmType_t954949548 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Int32_t2071877448_Int16_t4041245914 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, int32_t p2, int16_t p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), *((int16_t*)args[2]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Int32_t2071877448_Int64_t909078037 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, int32_t p2, int64_t p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), *((int64_t*)args[2]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_ByteU5BU5DU26_t790777611_ByteU5BU5DU26_t790777611 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, ByteU5BU5D_t3397334013** p2, ByteU5BU5D_t3397334013** p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (ByteU5BU5D_t3397334013**)args[1], (ByteU5BU5D_t3397334013**)args[2], method);
	return NULL;
}

void* RuntimeInvoker_Il2CppObject_Byte_t3683104436_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, uint8_t p1, Il2CppObject * p2, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((uint8_t*)args[0]), (Il2CppObject *)args[1], method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, Il2CppObject * p3, int32_t p4, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], (Il2CppObject *)args[2], *((int32_t*)args[3]), method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Int16_t4041245914_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_SByte_t454417549_SByte_t454417549_SByte_t454417549_SByte_t454417549_Int16_t4041245914_SByte_t454417549_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, int16_t p1, Il2CppObject * p2, int32_t p3, int32_t p4, int32_t p5, int8_t p6, int8_t p7, int8_t p8, int8_t p9, int16_t p10, int8_t p11, int8_t p12, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((int16_t*)args[0]), (Il2CppObject *)args[1], *((int32_t*)args[2]), *((int32_t*)args[3]), *((int32_t*)args[4]), *((int8_t*)args[5]), *((int8_t*)args[6]), *((int8_t*)args[7]), *((int8_t*)args[8]), *((int16_t*)args[9]), *((int8_t*)args[10]), *((int8_t*)args[11]), method);
	return ret;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Int32_t2071877448_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, int32_t p2, Il2CppObject * p3, Il2CppObject * p4, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), (Il2CppObject *)args[2], (Il2CppObject *)args[3], method);
	return NULL;
}

void* RuntimeInvoker_SecurityProtocolType_t155967584 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_SecurityCompressionType_t3722381418 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_HandshakeType_t2540099417 (const MethodInfo* method, void* obj, void** args)
{
	typedef uint8_t (*Func)(void* obj, const MethodInfo* method);
	uint8_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_HandshakeState_t1820731088 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_SecurityProtocolType_t155967584_Int16_t4041245914 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, int16_t p1, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((int16_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, Il2CppObject * p3, Il2CppObject * p4, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], (Il2CppObject *)args[2], (Il2CppObject *)args[3], method);
	return NULL;
}

void* RuntimeInvoker_Il2CppObject_Byte_t3683104436_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, uint8_t p1, Il2CppObject * p2, Il2CppObject * p3, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((uint8_t*)args[0]), (Il2CppObject *)args[1], (Il2CppObject *)args[2], method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Byte_t3683104436_Il2CppObject_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, uint8_t p1, Il2CppObject * p2, Il2CppObject * p3, Il2CppObject * p4, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((uint8_t*)args[0]), (Il2CppObject *)args[1], (Il2CppObject *)args[2], (Il2CppObject *)args[3], method);
	return ret;
}

void* RuntimeInvoker_Void_t1841601450_Byte_t3683104436_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, uint8_t p1, Il2CppObject * p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((uint8_t*)args[0]), (Il2CppObject *)args[1], method);
	return NULL;
}

void* RuntimeInvoker_Il2CppObject_Byte_t3683104436_Il2CppObject_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, uint8_t p1, Il2CppObject * p2, int32_t p3, int32_t p4, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((uint8_t*)args[0]), (Il2CppObject *)args[1], *((int32_t*)args[2]), *((int32_t*)args[3]), method);
	return ret;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Il2CppObject_SByte_t454417549_Int32_t2071877448_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, int8_t p3, int32_t p4, Il2CppObject * p5, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], *((int8_t*)args[2]), *((int32_t*)args[3]), (Il2CppObject *)args[4], method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Il2CppObject_Il2CppObject_Int32_t2071877448_Int32_t2071877448_SByte_t454417549_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, Il2CppObject * p3, int32_t p4, int32_t p5, int8_t p6, int8_t p7, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], (Il2CppObject *)args[2], *((int32_t*)args[3]), *((int32_t*)args[4]), *((int8_t*)args[5]), *((int8_t*)args[6]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Byte_t3683104436_Byte_t3683104436_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, uint8_t p1, uint8_t p2, Il2CppObject * p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((uint8_t*)args[0]), *((uint8_t*)args[1]), (Il2CppObject *)args[2], method);
	return NULL;
}

void* RuntimeInvoker_RSAParameters_t1462703416 (const MethodInfo* method, void* obj, void** args)
{
	typedef RSAParameters_t1462703416  (*Func)(void* obj, const MethodInfo* method);
	RSAParameters_t1462703416  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Byte_t3683104436_Byte_t3683104436 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, uint8_t p2, uint8_t p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((uint8_t*)args[1]), *((uint8_t*)args[2]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Byte_t3683104436_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, uint8_t p2, Il2CppObject * p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((uint8_t*)args[1]), (Il2CppObject *)args[2], method);
	return NULL;
}

void* RuntimeInvoker_ContentType_t859870085 (const MethodInfo* method, void* obj, void** args)
{
	typedef uint8_t (*Func)(void* obj, const MethodInfo* method);
	uint8_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, Il2CppObject * p3, Il2CppObject * p4, Il2CppObject * p5, Il2CppObject * p6, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], (Il2CppObject *)args[2], (Il2CppObject *)args[3], (Il2CppObject *)args[4], (Il2CppObject *)args[5], method);
	return ret;
}

void* RuntimeInvoker_RuntimePlatform_t1869584967 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Il2CppObject_Il2CppObject_Il2CppObject_Int32_t2071877448_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, int32_t p3, Il2CppObject * p4, Il2CppObject * p5, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], *((int32_t*)args[2]), (Il2CppObject *)args[3], (Il2CppObject *)args[4], method);
	return ret;
}

void* RuntimeInvoker_OperatingSystemFamily_t1896948788 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Rect_t3681755626 (const MethodInfo* method, void* obj, void** args)
{
	typedef Rect_t3681755626  (*Func)(void* obj, const MethodInfo* method);
	Rect_t3681755626  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_RectU26_t844847526 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Rect_t3681755626 * p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Rect_t3681755626 *)args[0], method);
	return NULL;
}

void* RuntimeInvoker_CameraClearFlags_t452084705 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Vector3_t2243707580_Vector3_t2243707580 (const MethodInfo* method, void* obj, void** args)
{
	typedef Vector3_t2243707580  (*Func)(void* obj, Vector3_t2243707580  p1, const MethodInfo* method);
	Vector3_t2243707580  ret = ((Func)method->methodPointer)(obj, *((Vector3_t2243707580 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Vector3U26_t425862308_Vector3U26_t425862308 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, Vector3_t2243707580 * p2, Vector3_t2243707580 * p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Vector3_t2243707580 *)args[1], (Vector3_t2243707580 *)args[2], method);
	return NULL;
}

void* RuntimeInvoker_Ray_t2469606224_Vector3_t2243707580 (const MethodInfo* method, void* obj, void** args)
{
	typedef Ray_t2469606224  (*Func)(void* obj, Vector3_t2243707580  p1, const MethodInfo* method);
	Ray_t2469606224  ret = ((Func)method->methodPointer)(obj, *((Vector3_t2243707580 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Vector3U26_t425862308_RayU26_t3651946800 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, Vector3_t2243707580 * p2, Ray_t2469606224 * p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Vector3_t2243707580 *)args[1], (Ray_t2469606224 *)args[2], method);
	return NULL;
}

void* RuntimeInvoker_Il2CppObject_Ray_t2469606224_Single_t2076509932_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Ray_t2469606224  p1, float p2, int32_t p3, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((Ray_t2469606224 *)args[0]), *((float*)args[1]), *((int32_t*)args[2]), method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Il2CppObject_RayU26_t3651946800_Single_t2076509932_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Il2CppObject * p1, Ray_t2469606224 * p2, float p3, int32_t p4, int32_t p5, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Ray_t2469606224 *)args[1], *((float*)args[2]), *((int32_t*)args[3]), *((int32_t*)args[4]), method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Il2CppObject_RayU26_t3651946800_Single_t2076509932_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Il2CppObject * p1, Ray_t2469606224 * p2, float p3, int32_t p4, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Ray_t2469606224 *)args[1], *((float*)args[2]), *((int32_t*)args[3]), method);
	return ret;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_IntPtr_t_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, IntPtr_t p2, int32_t p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((IntPtr_t*)args[1]), *((int32_t*)args[2]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_CullingGroupEvent_t1057617917 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, CullingGroupEvent_t1057617917  p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((CullingGroupEvent_t1057617917 *)args[0]), method);
	return NULL;
}

void* RuntimeInvoker_Il2CppObject_CullingGroupEvent_t1057617917_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, CullingGroupEvent_t1057617917  p1, Il2CppObject * p2, Il2CppObject * p3, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((CullingGroupEvent_t1057617917 *)args[0]), (Il2CppObject *)args[1], (Il2CppObject *)args[2], method);
	return ret;
}

void* RuntimeInvoker_CursorLockMode_t3372615096 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Il2CppObject_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, Il2CppObject * p2, Il2CppObject * p3, Il2CppObject * p4, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), (Il2CppObject *)args[1], (Il2CppObject *)args[2], (Il2CppObject *)args[3], method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_IntPtr_t_Int32U26_t455636984_Int32U26_t455636984 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, IntPtr_t p1, int32_t* p2, int32_t* p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((IntPtr_t*)args[0]), (int32_t*)args[1], (int32_t*)args[2], method);
	return NULL;
}

void* RuntimeInvoker_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Int32U26_t455636984_Int32U26_t455636984 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, int32_t p1, int32_t p2, int32_t* p3, int32_t* p4, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((int32_t*)args[1]), (int32_t*)args[2], (int32_t*)args[3], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Il2CppObject_Il2CppObject_SByte_t454417549_SByte_t454417549_SByte_t454417549_SByte_t454417549_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Il2CppObject * p1, int8_t p2, int8_t p3, int8_t p4, int8_t p5, Il2CppObject * p6, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int8_t*)args[1]), *((int8_t*)args[2]), *((int8_t*)args[3]), *((int8_t*)args[4]), (Il2CppObject *)args[5], method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Vector3_t2243707580 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Vector3_t2243707580  p1, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((Vector3_t2243707580 *)args[0]), method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Il2CppObject_Vector3U26_t425862308 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Il2CppObject * p1, Vector3_t2243707580 * p2, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Vector3_t2243707580 *)args[1], method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Il2CppObject_Int32_t2071877448_SByte_t454417549_SByte_t454417549_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Il2CppObject * p1, int32_t p2, int8_t p3, int8_t p4, int8_t p5, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), *((int8_t*)args[2]), *((int8_t*)args[3]), *((int8_t*)args[4]), method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Il2CppObject_Int32_t2071877448_SByte_t454417549_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Il2CppObject * p1, int32_t p2, int8_t p3, int8_t p4, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), *((int8_t*)args[2]), *((int8_t*)args[3]), method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Il2CppObject_Int32_t2071877448_SByte_t454417549_SByte_t454417549_SByte_t454417549_SByte_t454417549_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Il2CppObject * p1, int32_t p2, int8_t p3, int8_t p4, int8_t p5, int8_t p6, Il2CppObject * p7, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), *((int8_t*)args[2]), *((int8_t*)args[3]), *((int8_t*)args[4]), *((int8_t*)args[5]), (Il2CppObject *)args[6], method);
	return ret;
}

void* RuntimeInvoker_Vector2_t2243707579 (const MethodInfo* method, void* obj, void** args)
{
	typedef Vector2_t2243707579  (*Func)(void* obj, const MethodInfo* method);
	Vector2_t2243707579  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_TouchPhase_t2458120420 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_TouchType_t2732027771 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Vector3_t2243707580 (const MethodInfo* method, void* obj, void** args)
{
	typedef Vector3_t2243707580  (*Func)(void* obj, const MethodInfo* method);
	Vector3_t2243707580  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Vector3U26_t425862308 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Vector3_t2243707580 * p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Vector3_t2243707580 *)args[0], method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Vector2U26_t3911752445 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Vector2_t2243707579 * p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Vector2_t2243707579 *)args[0], method);
	return NULL;
}

void* RuntimeInvoker_Touch_t407273883_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef Touch_t407273883  (*Func)(void* obj, int32_t p1, const MethodInfo* method);
	Touch_t407273883  ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_TouchU26_t2094890781 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, Touch_t407273883 * p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), (Touch_t407273883 *)args[1], method);
	return NULL;
}

void* RuntimeInvoker_IMECompositionMode_t1898275508 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Vector2_t2243707579 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Vector2_t2243707579  p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((Vector2_t2243707579 *)args[0]), method);
	return NULL;
}

void* RuntimeInvoker_Int32_t2071877448_LayerMask_t3188175821 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, LayerMask_t3188175821  p1, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((LayerMask_t3188175821 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_LayerMask_t3188175821_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef LayerMask_t3188175821  (*Func)(void* obj, int32_t p1, const MethodInfo* method);
	LayerMask_t3188175821  ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Single_t2076509932_Single_t2076509932_Single_t2076509932 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, float p1, float p2, float p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((float*)args[0]), *((float*)args[1]), *((float*)args[2]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Single_t2076509932_Single_t2076509932 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, float p1, float p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((float*)args[0]), *((float*)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Vector3_t2243707580_Vector3_t2243707580_Vector3_t2243707580_Single_t2076509932 (const MethodInfo* method, void* obj, void** args)
{
	typedef Vector3_t2243707580  (*Func)(void* obj, Vector3_t2243707580  p1, Vector3_t2243707580  p2, float p3, const MethodInfo* method);
	Vector3_t2243707580  ret = ((Func)method->methodPointer)(obj, *((Vector3_t2243707580 *)args[0]), *((Vector3_t2243707580 *)args[1]), *((float*)args[2]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Single_t2076509932_Vector3_t2243707580_Vector3_t2243707580 (const MethodInfo* method, void* obj, void** args)
{
	typedef float (*Func)(void* obj, Vector3_t2243707580  p1, Vector3_t2243707580  p2, const MethodInfo* method);
	float ret = ((Func)method->methodPointer)(obj, *((Vector3_t2243707580 *)args[0]), *((Vector3_t2243707580 *)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Single_t2076509932_Vector3_t2243707580 (const MethodInfo* method, void* obj, void** args)
{
	typedef float (*Func)(void* obj, Vector3_t2243707580  p1, const MethodInfo* method);
	float ret = ((Func)method->methodPointer)(obj, *((Vector3_t2243707580 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Vector3_t2243707580_Vector3_t2243707580_Vector3_t2243707580 (const MethodInfo* method, void* obj, void** args)
{
	typedef Vector3_t2243707580  (*Func)(void* obj, Vector3_t2243707580  p1, Vector3_t2243707580  p2, const MethodInfo* method);
	Vector3_t2243707580  ret = ((Func)method->methodPointer)(obj, *((Vector3_t2243707580 *)args[0]), *((Vector3_t2243707580 *)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Vector3_t2243707580_Vector3_t2243707580_Single_t2076509932 (const MethodInfo* method, void* obj, void** args)
{
	typedef Vector3_t2243707580  (*Func)(void* obj, Vector3_t2243707580  p1, float p2, const MethodInfo* method);
	Vector3_t2243707580  ret = ((Func)method->methodPointer)(obj, *((Vector3_t2243707580 *)args[0]), *((float*)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Vector3_t2243707580_Vector3_t2243707580 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Vector3_t2243707580  p1, Vector3_t2243707580  p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((Vector3_t2243707580 *)args[0]), *((Vector3_t2243707580 *)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Single_t2076509932_Single_t2076509932_Single_t2076509932_Single_t2076509932 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, float p1, float p2, float p3, float p4, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((float*)args[0]), *((float*)args[1]), *((float*)args[2]), *((float*)args[3]), method);
	return NULL;
}

void* RuntimeInvoker_Quaternion_t4030073918_Quaternion_t4030073918 (const MethodInfo* method, void* obj, void** args)
{
	typedef Quaternion_t4030073918  (*Func)(void* obj, Quaternion_t4030073918  p1, const MethodInfo* method);
	Quaternion_t4030073918  ret = ((Func)method->methodPointer)(obj, *((Quaternion_t4030073918 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_QuaternionU26_t4187826802_QuaternionU26_t4187826802 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Quaternion_t4030073918 * p1, Quaternion_t4030073918 * p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Quaternion_t4030073918 *)args[0], (Quaternion_t4030073918 *)args[1], method);
	return NULL;
}

void* RuntimeInvoker_Quaternion_t4030073918_Single_t2076509932_Single_t2076509932_Single_t2076509932 (const MethodInfo* method, void* obj, void** args)
{
	typedef Quaternion_t4030073918  (*Func)(void* obj, float p1, float p2, float p3, const MethodInfo* method);
	Quaternion_t4030073918  ret = ((Func)method->methodPointer)(obj, *((float*)args[0]), *((float*)args[1]), *((float*)args[2]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Quaternion_t4030073918_Vector3_t2243707580 (const MethodInfo* method, void* obj, void** args)
{
	typedef Quaternion_t4030073918  (*Func)(void* obj, Vector3_t2243707580  p1, const MethodInfo* method);
	Quaternion_t4030073918  ret = ((Func)method->methodPointer)(obj, *((Vector3_t2243707580 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Vector3U26_t425862308_QuaternionU26_t4187826802 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Vector3_t2243707580 * p1, Quaternion_t4030073918 * p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Vector3_t2243707580 *)args[0], (Quaternion_t4030073918 *)args[1], method);
	return NULL;
}

void* RuntimeInvoker_Quaternion_t4030073918_Quaternion_t4030073918_Quaternion_t4030073918 (const MethodInfo* method, void* obj, void** args)
{
	typedef Quaternion_t4030073918  (*Func)(void* obj, Quaternion_t4030073918  p1, Quaternion_t4030073918  p2, const MethodInfo* method);
	Quaternion_t4030073918  ret = ((Func)method->methodPointer)(obj, *((Quaternion_t4030073918 *)args[0]), *((Quaternion_t4030073918 *)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Vector3_t2243707580_Quaternion_t4030073918_Vector3_t2243707580 (const MethodInfo* method, void* obj, void** args)
{
	typedef Vector3_t2243707580  (*Func)(void* obj, Quaternion_t4030073918  p1, Vector3_t2243707580  p2, const MethodInfo* method);
	Vector3_t2243707580  ret = ((Func)method->methodPointer)(obj, *((Quaternion_t4030073918 *)args[0]), *((Vector3_t2243707580 *)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Quaternion_t4030073918_Quaternion_t4030073918 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Quaternion_t4030073918  p1, Quaternion_t4030073918  p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((Quaternion_t4030073918 *)args[0]), *((Quaternion_t4030073918 *)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Single_t2076509932_Quaternion_t4030073918_Quaternion_t4030073918 (const MethodInfo* method, void* obj, void** args)
{
	typedef float (*Func)(void* obj, Quaternion_t4030073918  p1, Quaternion_t4030073918  p2, const MethodInfo* method);
	float ret = ((Func)method->methodPointer)(obj, *((Quaternion_t4030073918 *)args[0]), *((Quaternion_t4030073918 *)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Single_t2076509932_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef float (*Func)(void* obj, int32_t p1, int32_t p2, const MethodInfo* method);
	float ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((int32_t*)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Vector4_t2243707581_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef Vector4_t2243707581  (*Func)(void* obj, int32_t p1, const MethodInfo* method);
	Vector4_t2243707581  ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Vector3_t2243707580_Vector3_t2243707580 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Vector3_t2243707580  p1, Vector3_t2243707580  p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((Vector3_t2243707580 *)args[0]), *((Vector3_t2243707580 *)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Vector3_t2243707580 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Vector3_t2243707580  p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((Vector3_t2243707580 *)args[0]), method);
	return NULL;
}

void* RuntimeInvoker_Boolean_t3825574718_Bounds_t3033363703_Bounds_t3033363703 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Bounds_t3033363703  p1, Bounds_t3033363703  p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((Bounds_t3033363703 *)args[0]), *((Bounds_t3033363703 *)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Single_t2076509932_Single_t2076509932_Single_t2076509932 (const MethodInfo* method, void* obj, void** args)
{
	typedef float (*Func)(void* obj, float p1, float p2, const MethodInfo* method);
	float ret = ((Func)method->methodPointer)(obj, *((float*)args[0]), *((float*)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Single_t2076509932_Single_t2076509932_Single_t2076509932_Single_t2076509932 (const MethodInfo* method, void* obj, void** args)
{
	typedef float (*Func)(void* obj, float p1, float p2, float p3, const MethodInfo* method);
	float ret = ((Func)method->methodPointer)(obj, *((float*)args[0]), *((float*)args[1]), *((float*)args[2]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Single_t2076509932_Single_t2076509932 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, float p1, float p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((float*)args[0]), *((float*)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Single_t2076509932_Single_t2076509932_Single_t2076509932_SingleU26_t4173844468_Single_t2076509932_Single_t2076509932_Single_t2076509932 (const MethodInfo* method, void* obj, void** args)
{
	typedef float (*Func)(void* obj, float p1, float p2, float* p3, float p4, float p5, float p6, const MethodInfo* method);
	float ret = ((Func)method->methodPointer)(obj, *((float*)args[0]), *((float*)args[1]), (float*)args[2], *((float*)args[3]), *((float*)args[4]), *((float*)args[5]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Il2CppObject_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, int32_t p2, int32_t p3, Il2CppObject * p4, int32_t p5, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((int32_t*)args[1]), *((int32_t*)args[2]), (Il2CppObject *)args[3], *((int32_t*)args[4]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Il2CppObject_Int32_t2071877448_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, Il2CppObject * p2, int32_t p3, int8_t p4, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), (Il2CppObject *)args[1], *((int32_t*)args[2]), *((int8_t*)args[3]), method);
	return NULL;
}

void* RuntimeInvoker_InternalShaderChannel_t3331827198_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, int32_t p1, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Single_t2076509932_Single_t2076509932 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, float p2, float p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((float*)args[1]), *((float*)args[2]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Single_t2076509932_Single_t2076509932 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, float p2, float p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((float*)args[1]), *((float*)args[2]), method);
	return NULL;
}

void* RuntimeInvoker_Vector4_t2243707581 (const MethodInfo* method, void* obj, void** args)
{
	typedef Vector4_t2243707581  (*Func)(void* obj, const MethodInfo* method);
	Vector4_t2243707581  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Vector4U26_t1234939467 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Vector4_t2243707581 * p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Vector4_t2243707581 *)args[0], method);
	return NULL;
}

void* RuntimeInvoker_Vector4_t2243707581_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Vector4_t2243707581  (*Func)(void* obj, Il2CppObject * p1, const MethodInfo* method);
	Vector4_t2243707581  ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Vector4U26_t1234939467 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, Vector4_t2243707581 * p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Vector4_t2243707581 *)args[1], method);
	return NULL;
}

void* RuntimeInvoker_Vector2_t2243707579_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Vector2_t2243707579  (*Func)(void* obj, Il2CppObject * p1, const MethodInfo* method);
	Vector2_t2243707579  ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Vector2U26_t3911752445 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, Vector2_t2243707579 * p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Vector2_t2243707579 *)args[1], method);
	return NULL;
}

void* RuntimeInvoker_TextureWrapMode_t3683976566 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_SByte_t454417549_SByte_t454417549_IntPtr_t (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, int32_t p2, int32_t p3, int32_t p4, int8_t p5, int8_t p6, IntPtr_t p7, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), *((int32_t*)args[3]), *((int8_t*)args[4]), *((int8_t*)args[5]), *((IntPtr_t*)args[6]), method);
	return NULL;
}

void* RuntimeInvoker_Color_t2020392075_Single_t2076509932_Single_t2076509932 (const MethodInfo* method, void* obj, void** args)
{
	typedef Color_t2020392075  (*Func)(void* obj, float p1, float p2, const MethodInfo* method);
	Color_t2020392075  ret = ((Func)method->methodPointer)(obj, *((float*)args[0]), *((float*)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Single_t2076509932_Single_t2076509932_ColorU26_t3402129837 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, float p2, float p3, Color_t2020392075 * p4, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((float*)args[1]), *((float*)args[2]), (Color_t2020392075 *)args[3], method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Rect_t3681755626_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Rect_t3681755626  p1, int32_t p2, int32_t p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((Rect_t3681755626 *)args[0]), *((int32_t*)args[1]), *((int32_t*)args[2]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_RectU26_t844847526_Int32_t2071877448_Int32_t2071877448_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, Rect_t3681755626 * p2, int32_t p3, int32_t p4, int8_t p5, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Rect_t3681755626 *)args[1], *((int32_t*)args[2]), *((int32_t*)args[3]), *((int8_t*)args[4]), method);
	return NULL;
}

void* RuntimeInvoker_Quaternion_t4030073918 (const MethodInfo* method, void* obj, void** args)
{
	typedef Quaternion_t4030073918  (*Func)(void* obj, const MethodInfo* method);
	Quaternion_t4030073918  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Quaternion_t4030073918 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Quaternion_t4030073918  p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((Quaternion_t4030073918 *)args[0]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_QuaternionU26_t4187826802 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Quaternion_t4030073918 * p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Quaternion_t4030073918 *)args[0], method);
	return NULL;
}

void* RuntimeInvoker_Matrix4x4_t2933234003 (const MethodInfo* method, void* obj, void** args)
{
	typedef Matrix4x4_t2933234003  (*Func)(void* obj, const MethodInfo* method);
	Matrix4x4_t2933234003  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Matrix4x4U26_t266301477 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Matrix4x4_t2933234003 * p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Matrix4x4_t2933234003 *)args[0], method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Vector3_t2243707580_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Vector3_t2243707580  p1, int32_t p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((Vector3_t2243707580 *)args[0]), *((int32_t*)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Il2CppObject_Il2CppObject_Vector3_t2243707580_Quaternion_t4030073918 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Il2CppObject * p1, Vector3_t2243707580  p2, Quaternion_t4030073918  p3, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((Vector3_t2243707580 *)args[1]), *((Quaternion_t4030073918 *)args[2]), method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Il2CppObject_Vector3U26_t425862308_QuaternionU26_t4187826802 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Il2CppObject * p1, Vector3_t2243707580 * p2, Quaternion_t4030073918 * p3, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Vector3_t2243707580 *)args[1], (Quaternion_t4030073918 *)args[2], method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Il2CppObject_Il2CppObject_Vector3_t2243707580_Quaternion_t4030073918 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, Vector3_t2243707580  p3, Quaternion_t4030073918  p4, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], *((Vector3_t2243707580 *)args[2]), *((Quaternion_t4030073918 *)args[3]), method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Il2CppObject_Il2CppObject_Vector3U26_t425862308_QuaternionU26_t4187826802 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, Vector3_t2243707580 * p3, Quaternion_t4030073918 * p4, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], (Vector3_t2243707580 *)args[2], (Quaternion_t4030073918 *)args[3], method);
	return ret;
}

void* RuntimeInvoker_HideFlags_t1434274199 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Il2CppObject_Il2CppObject_Vector3_t2243707580_Quaternion_t4030073918_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Il2CppObject * p1, Vector3_t2243707580  p2, Quaternion_t4030073918  p3, Il2CppObject * p4, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((Vector3_t2243707580 *)args[1]), *((Quaternion_t4030073918 *)args[2]), (Il2CppObject *)args[3], method);
	return ret;
}

void* RuntimeInvoker_Boolean_t3825574718_PlayableU26_t3233213460 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Playable_t3667545548 * p1, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (Playable_t3667545548 *)args[0], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Playable_t3667545548_Playable_t3667545548_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Playable_t3667545548  p1, Playable_t3667545548  p2, int32_t p3, int32_t p4, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((Playable_t3667545548 *)args[0]), *((Playable_t3667545548 *)args[1]), *((int32_t*)args[2]), *((int32_t*)args[3]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Playable_t3667545548_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Playable_t3667545548  p1, int32_t p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((Playable_t3667545548 *)args[0]), *((int32_t*)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_PlayState_t3250302433 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_PlayState_t3250302433_PlayableU26_t3233213460 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Playable_t3667545548 * p1, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Playable_t3667545548 *)args[0], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_PlayableU26_t3233213460_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Playable_t3667545548 * p1, int32_t p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Playable_t3667545548 *)args[0], *((int32_t*)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Double_t4078015681_PlayableU26_t3233213460 (const MethodInfo* method, void* obj, void** args)
{
	typedef double (*Func)(void* obj, Playable_t3667545548 * p1, const MethodInfo* method);
	double ret = ((Func)method->methodPointer)(obj, (Playable_t3667545548 *)args[0], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_PlayableU26_t3233213460_Double_t4078015681 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Playable_t3667545548 * p1, double p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Playable_t3667545548 *)args[0], *((double*)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Int32_t2071877448_PlayableU26_t3233213460 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Playable_t3667545548 * p1, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Playable_t3667545548 *)args[0], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Playable_t3667545548_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef Playable_t3667545548  (*Func)(void* obj, int32_t p1, const MethodInfo* method);
	Playable_t3667545548  ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Playable_t3667545548_PlayableU26_t3233213460_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef Playable_t3667545548  (*Func)(void* obj, Playable_t3667545548 * p1, int32_t p2, const MethodInfo* method);
	Playable_t3667545548  ret = ((Func)method->methodPointer)(obj, (Playable_t3667545548 *)args[0], *((int32_t*)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_PlayableU26_t3233213460_Int32_t2071877448_PlayableU26_t3233213460 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Playable_t3667545548 * p1, int32_t p2, Playable_t3667545548 * p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Playable_t3667545548 *)args[0], *((int32_t*)args[1]), (Playable_t3667545548 *)args[2], method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_PlayableU26_t3233213460_Int32_t2071877448_Single_t2076509932 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Playable_t3667545548 * p1, int32_t p2, float p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Playable_t3667545548 *)args[0], *((int32_t*)args[1]), *((float*)args[2]), method);
	return NULL;
}

void* RuntimeInvoker_Boolean_t3825574718_Int32_t2071877448_Single_t2076509932 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, int32_t p1, float p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((float*)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Single_t2076509932_PlayableU26_t3233213460_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef float (*Func)(void* obj, Playable_t3667545548 * p1, int32_t p2, const MethodInfo* method);
	float ret = ((Func)method->methodPointer)(obj, (Playable_t3667545548 *)args[0], *((int32_t*)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Playable_t3667545548 (const MethodInfo* method, void* obj, void** args)
{
	typedef Playable_t3667545548  (*Func)(void* obj, const MethodInfo* method);
	Playable_t3667545548  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_GenericMixerPlayable_t788733994 (const MethodInfo* method, void* obj, void** args)
{
	typedef GenericMixerPlayable_t788733994  (*Func)(void* obj, const MethodInfo* method);
	GenericMixerPlayable_t788733994  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_GenericMixerPlayableU26_t1620735334 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, GenericMixerPlayable_t788733994 * p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (GenericMixerPlayable_t788733994 *)args[0], method);
	return NULL;
}

void* RuntimeInvoker_Playable_t3667545548_GenericMixerPlayable_t788733994 (const MethodInfo* method, void* obj, void** args)
{
	typedef Playable_t3667545548  (*Func)(void* obj, GenericMixerPlayable_t788733994  p1, const MethodInfo* method);
	Playable_t3667545548  ret = ((Func)method->methodPointer)(obj, *((GenericMixerPlayable_t788733994 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Il2CppObject_Il2CppObject_IntPtr_t_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Il2CppObject * p1, IntPtr_t p2, int32_t p3, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((IntPtr_t*)args[1]), *((int32_t*)args[2]), method);
	return ret;
}

void* RuntimeInvoker_Void_t1841601450_PlayableU26_t3233213460 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Playable_t3667545548 * p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Playable_t3667545548 *)args[0], method);
	return NULL;
}

void* RuntimeInvoker_Boolean_t3825574718_PlayableU26_t3233213460_PlayableU26_t3233213460_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Playable_t3667545548 * p1, Playable_t3667545548 * p2, int32_t p3, int32_t p4, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (Playable_t3667545548 *)args[0], (Playable_t3667545548 *)args[1], *((int32_t*)args[2]), *((int32_t*)args[3]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Playable_t3667545548_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Playable_t3667545548  p1, int32_t p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((Playable_t3667545548 *)args[0]), *((int32_t*)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Playable_t3667545548 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Playable_t3667545548  p1, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((Playable_t3667545548 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Playable_t3667545548_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Playable_t3667545548  p1, Il2CppObject * p2, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((Playable_t3667545548 *)args[0]), (Il2CppObject *)args[1], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_PlayState_t3250302433_Playable_t3667545548_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Playable_t3667545548  p1, Il2CppObject * p2, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((Playable_t3667545548 *)args[0]), (Il2CppObject *)args[1], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Playable_t3667545548_Int32_t2071877448_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Playable_t3667545548  p1, int32_t p2, Il2CppObject * p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((Playable_t3667545548 *)args[0]), *((int32_t*)args[1]), (Il2CppObject *)args[2], method);
	return NULL;
}

void* RuntimeInvoker_Double_t4078015681_Playable_t3667545548_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef double (*Func)(void* obj, Playable_t3667545548  p1, Il2CppObject * p2, const MethodInfo* method);
	double ret = ((Func)method->methodPointer)(obj, *((Playable_t3667545548 *)args[0]), (Il2CppObject *)args[1], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Playable_t3667545548_Double_t4078015681_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Playable_t3667545548  p1, double p2, Il2CppObject * p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((Playable_t3667545548 *)args[0]), *((double*)args[1]), (Il2CppObject *)args[2], method);
	return NULL;
}

void* RuntimeInvoker_Playable_t3667545548_Playable_t3667545548_Int32_t2071877448_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Playable_t3667545548  (*Func)(void* obj, Playable_t3667545548  p1, int32_t p2, Il2CppObject * p3, const MethodInfo* method);
	Playable_t3667545548  ret = ((Func)method->methodPointer)(obj, *((Playable_t3667545548 *)args[0]), *((int32_t*)args[1]), (Il2CppObject *)args[2], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Playable_t3667545548_Int32_t2071877448_Single_t2076509932_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Playable_t3667545548  p1, int32_t p2, float p3, Il2CppObject * p4, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((Playable_t3667545548 *)args[0]), *((int32_t*)args[1]), *((float*)args[2]), (Il2CppObject *)args[3], method);
	return NULL;
}

void* RuntimeInvoker_Single_t2076509932_Playable_t3667545548_Int32_t2071877448_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef float (*Func)(void* obj, Playable_t3667545548  p1, int32_t p2, Il2CppObject * p3, const MethodInfo* method);
	float ret = ((Func)method->methodPointer)(obj, *((Playable_t3667545548 *)args[0]), *((int32_t*)args[1]), (Il2CppObject *)args[2], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Playable_t3667545548_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Playable_t3667545548  p1, Il2CppObject * p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((Playable_t3667545548 *)args[0]), (Il2CppObject *)args[1], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Scene_t1684909666_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Scene_t1684909666  p1, int32_t p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((Scene_t1684909666 *)args[0]), *((int32_t*)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Scene_t1684909666 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Scene_t1684909666  p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((Scene_t1684909666 *)args[0]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Scene_t1684909666_Scene_t1684909666 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Scene_t1684909666  p1, Scene_t1684909666  p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((Scene_t1684909666 *)args[0]), *((Scene_t1684909666 *)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Boolean_t3825574718_Vector3_t2243707580_Vector3_t2243707580_Single_t2076509932_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Vector3_t2243707580  p1, Vector3_t2243707580  p2, float p3, int32_t p4, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((Vector3_t2243707580 *)args[0]), *((Vector3_t2243707580 *)args[1]), *((float*)args[2]), *((int32_t*)args[3]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Vector3_t2243707580_Vector3_t2243707580_Single_t2076509932 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Vector3_t2243707580  p1, Vector3_t2243707580  p2, float p3, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((Vector3_t2243707580 *)args[0]), *((Vector3_t2243707580 *)args[1]), *((float*)args[2]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Vector3_t2243707580_Vector3_t2243707580_Single_t2076509932_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Vector3_t2243707580  p1, Vector3_t2243707580  p2, float p3, int32_t p4, int32_t p5, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((Vector3_t2243707580 *)args[0]), *((Vector3_t2243707580 *)args[1]), *((float*)args[2]), *((int32_t*)args[3]), *((int32_t*)args[4]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Vector3_t2243707580_Vector3_t2243707580_RaycastHitU26_t1969197280_Single_t2076509932_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Vector3_t2243707580  p1, Vector3_t2243707580  p2, RaycastHit_t87180320 * p3, float p4, int32_t p5, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((Vector3_t2243707580 *)args[0]), *((Vector3_t2243707580 *)args[1]), (RaycastHit_t87180320 *)args[2], *((float*)args[3]), *((int32_t*)args[4]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Vector3_t2243707580_Vector3_t2243707580_RaycastHitU26_t1969197280_Single_t2076509932 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Vector3_t2243707580  p1, Vector3_t2243707580  p2, RaycastHit_t87180320 * p3, float p4, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((Vector3_t2243707580 *)args[0]), *((Vector3_t2243707580 *)args[1]), (RaycastHit_t87180320 *)args[2], *((float*)args[3]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Vector3_t2243707580_Vector3_t2243707580_RaycastHitU26_t1969197280 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Vector3_t2243707580  p1, Vector3_t2243707580  p2, RaycastHit_t87180320 * p3, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((Vector3_t2243707580 *)args[0]), *((Vector3_t2243707580 *)args[1]), (RaycastHit_t87180320 *)args[2], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Vector3_t2243707580_Vector3_t2243707580_RaycastHitU26_t1969197280_Single_t2076509932_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Vector3_t2243707580  p1, Vector3_t2243707580  p2, RaycastHit_t87180320 * p3, float p4, int32_t p5, int32_t p6, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((Vector3_t2243707580 *)args[0]), *((Vector3_t2243707580 *)args[1]), (RaycastHit_t87180320 *)args[2], *((float*)args[3]), *((int32_t*)args[4]), *((int32_t*)args[5]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Ray_t2469606224_Single_t2076509932_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Ray_t2469606224  p1, float p2, int32_t p3, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((Ray_t2469606224 *)args[0]), *((float*)args[1]), *((int32_t*)args[2]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Ray_t2469606224_Single_t2076509932 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Ray_t2469606224  p1, float p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((Ray_t2469606224 *)args[0]), *((float*)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Ray_t2469606224 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Ray_t2469606224  p1, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((Ray_t2469606224 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Ray_t2469606224_Single_t2076509932_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Ray_t2469606224  p1, float p2, int32_t p3, int32_t p4, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((Ray_t2469606224 *)args[0]), *((float*)args[1]), *((int32_t*)args[2]), *((int32_t*)args[3]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Ray_t2469606224_RaycastHitU26_t1969197280_Single_t2076509932_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Ray_t2469606224  p1, RaycastHit_t87180320 * p2, float p3, int32_t p4, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((Ray_t2469606224 *)args[0]), (RaycastHit_t87180320 *)args[1], *((float*)args[2]), *((int32_t*)args[3]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Ray_t2469606224_RaycastHitU26_t1969197280_Single_t2076509932 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Ray_t2469606224  p1, RaycastHit_t87180320 * p2, float p3, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((Ray_t2469606224 *)args[0]), (RaycastHit_t87180320 *)args[1], *((float*)args[2]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Ray_t2469606224_RaycastHitU26_t1969197280 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Ray_t2469606224  p1, RaycastHit_t87180320 * p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((Ray_t2469606224 *)args[0]), (RaycastHit_t87180320 *)args[1], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Ray_t2469606224_RaycastHitU26_t1969197280_Single_t2076509932_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Ray_t2469606224  p1, RaycastHit_t87180320 * p2, float p3, int32_t p4, int32_t p5, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((Ray_t2469606224 *)args[0]), (RaycastHit_t87180320 *)args[1], *((float*)args[2]), *((int32_t*)args[3]), *((int32_t*)args[4]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Il2CppObject_Ray_t2469606224_Single_t2076509932 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Ray_t2469606224  p1, float p2, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((Ray_t2469606224 *)args[0]), *((float*)args[1]), method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Ray_t2469606224 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Ray_t2469606224  p1, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((Ray_t2469606224 *)args[0]), method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Ray_t2469606224_Single_t2076509932_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Ray_t2469606224  p1, float p2, int32_t p3, int32_t p4, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((Ray_t2469606224 *)args[0]), *((float*)args[1]), *((int32_t*)args[2]), *((int32_t*)args[3]), method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Vector3_t2243707580_Vector3_t2243707580_Single_t2076509932_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Vector3_t2243707580  p1, Vector3_t2243707580  p2, float p3, int32_t p4, int32_t p5, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((Vector3_t2243707580 *)args[0]), *((Vector3_t2243707580 *)args[1]), *((float*)args[2]), *((int32_t*)args[3]), *((int32_t*)args[4]), method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Vector3_t2243707580_Vector3_t2243707580_Single_t2076509932_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Vector3_t2243707580  p1, Vector3_t2243707580  p2, float p3, int32_t p4, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((Vector3_t2243707580 *)args[0]), *((Vector3_t2243707580 *)args[1]), *((float*)args[2]), *((int32_t*)args[3]), method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Vector3_t2243707580_Vector3_t2243707580_Single_t2076509932 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Vector3_t2243707580  p1, Vector3_t2243707580  p2, float p3, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((Vector3_t2243707580 *)args[0]), *((Vector3_t2243707580 *)args[1]), *((float*)args[2]), method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Vector3_t2243707580_Vector3_t2243707580 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Vector3_t2243707580  p1, Vector3_t2243707580  p2, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((Vector3_t2243707580 *)args[0]), *((Vector3_t2243707580 *)args[1]), method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Vector3U26_t425862308_Vector3U26_t425862308_Single_t2076509932_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Vector3_t2243707580 * p1, Vector3_t2243707580 * p2, float p3, int32_t p4, int32_t p5, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Vector3_t2243707580 *)args[0], (Vector3_t2243707580 *)args[1], *((float*)args[2]), *((int32_t*)args[3]), *((int32_t*)args[4]), method);
	return ret;
}

void* RuntimeInvoker_Boolean_t3825574718_Vector3U26_t425862308_Vector3U26_t425862308_RaycastHitU26_t1969197280_Single_t2076509932_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Vector3_t2243707580 * p1, Vector3_t2243707580 * p2, RaycastHit_t87180320 * p3, float p4, int32_t p5, int32_t p6, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (Vector3_t2243707580 *)args[0], (Vector3_t2243707580 *)args[1], (RaycastHit_t87180320 *)args[2], *((float*)args[3]), *((int32_t*)args[4]), *((int32_t*)args[5]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Vector3U26_t425862308_Vector3U26_t425862308_Single_t2076509932_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Vector3_t2243707580 * p1, Vector3_t2243707580 * p2, float p3, int32_t p4, int32_t p5, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (Vector3_t2243707580 *)args[0], (Vector3_t2243707580 *)args[1], *((float*)args[2]), *((int32_t*)args[3]), *((int32_t*)args[4]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Vector2_t2243707579_Vector2_t2243707579_Single_t2076509932_Int32_t2071877448_Single_t2076509932_Single_t2076509932_RaycastHit2DU26_t4207306570 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Vector2_t2243707579  p1, Vector2_t2243707579  p2, float p3, int32_t p4, float p5, float p6, RaycastHit2D_t4063908774 * p7, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((Vector2_t2243707579 *)args[0]), *((Vector2_t2243707579 *)args[1]), *((float*)args[2]), *((int32_t*)args[3]), *((float*)args[4]), *((float*)args[5]), (RaycastHit2D_t4063908774 *)args[6], method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Vector2U26_t3911752445_Vector2U26_t3911752445_Single_t2076509932_Int32_t2071877448_Single_t2076509932_Single_t2076509932_RaycastHit2DU26_t4207306570 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Vector2_t2243707579 * p1, Vector2_t2243707579 * p2, float p3, int32_t p4, float p5, float p6, RaycastHit2D_t4063908774 * p7, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Vector2_t2243707579 *)args[0], (Vector2_t2243707579 *)args[1], *((float*)args[2]), *((int32_t*)args[3]), *((float*)args[4]), *((float*)args[5]), (RaycastHit2D_t4063908774 *)args[6], method);
	return NULL;
}

void* RuntimeInvoker_RaycastHit2D_t4063908774_Vector2_t2243707579_Vector2_t2243707579_Single_t2076509932_Int32_t2071877448_Single_t2076509932 (const MethodInfo* method, void* obj, void** args)
{
	typedef RaycastHit2D_t4063908774  (*Func)(void* obj, Vector2_t2243707579  p1, Vector2_t2243707579  p2, float p3, int32_t p4, float p5, const MethodInfo* method);
	RaycastHit2D_t4063908774  ret = ((Func)method->methodPointer)(obj, *((Vector2_t2243707579 *)args[0]), *((Vector2_t2243707579 *)args[1]), *((float*)args[2]), *((int32_t*)args[3]), *((float*)args[4]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_RaycastHit2D_t4063908774_Vector2_t2243707579_Vector2_t2243707579_Single_t2076509932_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef RaycastHit2D_t4063908774  (*Func)(void* obj, Vector2_t2243707579  p1, Vector2_t2243707579  p2, float p3, int32_t p4, const MethodInfo* method);
	RaycastHit2D_t4063908774  ret = ((Func)method->methodPointer)(obj, *((Vector2_t2243707579 *)args[0]), *((Vector2_t2243707579 *)args[1]), *((float*)args[2]), *((int32_t*)args[3]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_RaycastHit2D_t4063908774_Vector2_t2243707579_Vector2_t2243707579_Single_t2076509932 (const MethodInfo* method, void* obj, void** args)
{
	typedef RaycastHit2D_t4063908774  (*Func)(void* obj, Vector2_t2243707579  p1, Vector2_t2243707579  p2, float p3, const MethodInfo* method);
	RaycastHit2D_t4063908774  ret = ((Func)method->methodPointer)(obj, *((Vector2_t2243707579 *)args[0]), *((Vector2_t2243707579 *)args[1]), *((float*)args[2]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_RaycastHit2D_t4063908774_Vector2_t2243707579_Vector2_t2243707579 (const MethodInfo* method, void* obj, void** args)
{
	typedef RaycastHit2D_t4063908774  (*Func)(void* obj, Vector2_t2243707579  p1, Vector2_t2243707579  p2, const MethodInfo* method);
	RaycastHit2D_t4063908774  ret = ((Func)method->methodPointer)(obj, *((Vector2_t2243707579 *)args[0]), *((Vector2_t2243707579 *)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_RaycastHit2D_t4063908774_Vector2_t2243707579_Vector2_t2243707579_Single_t2076509932_Int32_t2071877448_Single_t2076509932_Single_t2076509932 (const MethodInfo* method, void* obj, void** args)
{
	typedef RaycastHit2D_t4063908774  (*Func)(void* obj, Vector2_t2243707579  p1, Vector2_t2243707579  p2, float p3, int32_t p4, float p5, float p6, const MethodInfo* method);
	RaycastHit2D_t4063908774  ret = ((Func)method->methodPointer)(obj, *((Vector2_t2243707579 *)args[0]), *((Vector2_t2243707579 *)args[1]), *((float*)args[2]), *((int32_t*)args[3]), *((float*)args[4]), *((float*)args[5]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Il2CppObject_RayU26_t3651946800_Single_t2076509932_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Ray_t2469606224 * p1, float p2, int32_t p3, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Ray_t2469606224 *)args[0], *((float*)args[1]), *((int32_t*)args[2]), method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_SByte_t454417549_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, int8_t p1, Il2CppObject * p2, Il2CppObject * p3, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((int8_t*)args[0]), (Il2CppObject *)args[1], (Il2CppObject *)args[2], method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Int32_t2071877448_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, int32_t p1, Il2CppObject * p2, Il2CppObject * p3, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), (Il2CppObject *)args[1], (Il2CppObject *)args[2], method);
	return ret;
}

void* RuntimeInvoker_SendMessageOptions_t1414041951 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_AnimatorStateInfo_t2577870592 (const MethodInfo* method, void* obj, void** args)
{
	typedef AnimatorStateInfo_t2577870592  (*Func)(void* obj, const MethodInfo* method);
	AnimatorStateInfo_t2577870592  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_AnimatorClipInfo_t3905751349 (const MethodInfo* method, void* obj, void** args)
{
	typedef AnimatorClipInfo_t3905751349  (*Func)(void* obj, const MethodInfo* method);
	AnimatorClipInfo_t3905751349  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Playable_t3667545548_AnimatorControllerPlayable_t4078305555 (const MethodInfo* method, void* obj, void** args)
{
	typedef Playable_t3667545548  (*Func)(void* obj, AnimatorControllerPlayable_t4078305555  p1, const MethodInfo* method);
	Playable_t3667545548  ret = ((Func)method->methodPointer)(obj, *((AnimatorControllerPlayable_t4078305555 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Playable_t3667545548 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Playable_t3667545548  p1, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((Playable_t3667545548 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Playable_t3667545548_AnimationPlayable_t1693994278 (const MethodInfo* method, void* obj, void** args)
{
	typedef Playable_t3667545548  (*Func)(void* obj, AnimationPlayable_t1693994278  p1, const MethodInfo* method);
	Playable_t3667545548  ret = ((Func)method->methodPointer)(obj, *((AnimationPlayable_t1693994278 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_IntPtr_t (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, IntPtr_t p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((IntPtr_t*)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Playable_t3667545548_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Playable_t3667545548  (*Func)(void* obj, Il2CppObject * p1, const MethodInfo* method);
	Playable_t3667545548  ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_AnimationPlayable_t1693994278_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef AnimationPlayable_t1693994278  (*Func)(void* obj, Il2CppObject * p1, const MethodInfo* method);
	AnimationPlayable_t1693994278  ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_FrameData_t1120735295 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, FrameData_t1120735295  p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((FrameData_t1120735295 *)args[0]), method);
	return NULL;
}

void* RuntimeInvoker_Boolean_t3825574718_Color_t2020392075_Color_t2020392075 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Color_t2020392075  p1, Color_t2020392075  p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((Color_t2020392075 *)args[0]), *((Color_t2020392075 *)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Vector2_t2243707579_Vector2_t2243707579 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Vector2_t2243707579  p1, Vector2_t2243707579  p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((Vector2_t2243707579 *)args[0]), *((Vector2_t2243707579 *)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_TextGenerationSettings_t2543476768 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, TextGenerationSettings_t2543476768  p1, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((TextGenerationSettings_t2543476768 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_TextGenerationSettings_t2543476768_TextGenerationSettings_t2543476768 (const MethodInfo* method, void* obj, void** args)
{
	typedef TextGenerationSettings_t2543476768  (*Func)(void* obj, TextGenerationSettings_t2543476768  p1, const MethodInfo* method);
	TextGenerationSettings_t2543476768  ret = ((Func)method->methodPointer)(obj, *((TextGenerationSettings_t2543476768 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Single_t2076509932_Il2CppObject_TextGenerationSettings_t2543476768 (const MethodInfo* method, void* obj, void** args)
{
	typedef float (*Func)(void* obj, Il2CppObject * p1, TextGenerationSettings_t2543476768  p2, const MethodInfo* method);
	float ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((TextGenerationSettings_t2543476768 *)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Il2CppObject_TextGenerationSettings_t2543476768_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Il2CppObject * p1, TextGenerationSettings_t2543476768  p2, Il2CppObject * p3, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((TextGenerationSettings_t2543476768 *)args[1]), (Il2CppObject *)args[2], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Il2CppObject_TextGenerationSettings_t2543476768 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Il2CppObject * p1, TextGenerationSettings_t2543476768  p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((TextGenerationSettings_t2543476768 *)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_TextGenerationError_t780770201_Il2CppObject_TextGenerationSettings_t2543476768 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, TextGenerationSettings_t2543476768  p2, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((TextGenerationSettings_t2543476768 *)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Il2CppObject_Color_t2020392075_Int32_t2071877448_Single_t2076509932_Single_t2076509932_Int32_t2071877448_SByte_t454417549_SByte_t454417549_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_SByte_t454417549_Int32_t2071877448_Vector2_t2243707579_Vector2_t2243707579_SByte_t454417549_SByte_t454417549_TextGenerationErrorU26_t1427792335 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, Color_t2020392075  p3, int32_t p4, float p5, float p6, int32_t p7, int8_t p8, int8_t p9, int32_t p10, int32_t p11, int32_t p12, int32_t p13, int8_t p14, int32_t p15, Vector2_t2243707579  p16, Vector2_t2243707579  p17, int8_t p18, int8_t p19, int32_t* p20, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], *((Color_t2020392075 *)args[2]), *((int32_t*)args[3]), *((float*)args[4]), *((float*)args[5]), *((int32_t*)args[6]), *((int8_t*)args[7]), *((int8_t*)args[8]), *((int32_t*)args[9]), *((int32_t*)args[10]), *((int32_t*)args[11]), *((int32_t*)args[12]), *((int8_t*)args[13]), *((int32_t*)args[14]), *((Vector2_t2243707579 *)args[15]), *((Vector2_t2243707579 *)args[16]), *((int8_t*)args[17]), *((int8_t*)args[18]), (int32_t*)args[19], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Il2CppObject_Color_t2020392075_Int32_t2071877448_Single_t2076509932_Single_t2076509932_Int32_t2071877448_SByte_t454417549_SByte_t454417549_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_SByte_t454417549_Int32_t2071877448_Single_t2076509932_Single_t2076509932_Single_t2076509932_Single_t2076509932_SByte_t454417549_SByte_t454417549_UInt32U26_t2197289955 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, Color_t2020392075  p3, int32_t p4, float p5, float p6, int32_t p7, int8_t p8, int8_t p9, int32_t p10, int32_t p11, int32_t p12, int32_t p13, int8_t p14, int32_t p15, float p16, float p17, float p18, float p19, int8_t p20, int8_t p21, uint32_t* p22, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], *((Color_t2020392075 *)args[2]), *((int32_t*)args[3]), *((float*)args[4]), *((float*)args[5]), *((int32_t*)args[6]), *((int8_t*)args[7]), *((int8_t*)args[8]), *((int32_t*)args[9]), *((int32_t*)args[10]), *((int32_t*)args[11]), *((int32_t*)args[12]), *((int8_t*)args[13]), *((int32_t*)args[14]), *((float*)args[15]), *((float*)args[16]), *((float*)args[17]), *((float*)args[18]), *((int8_t*)args[19]), *((int8_t*)args[20]), (uint32_t*)args[21], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Il2CppObject_Il2CppObject_ColorU26_t3402129837_Int32_t2071877448_Single_t2076509932_Single_t2076509932_Int32_t2071877448_SByte_t454417549_SByte_t454417549_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_SByte_t454417549_Int32_t2071877448_Single_t2076509932_Single_t2076509932_Single_t2076509932_Single_t2076509932_SByte_t454417549_SByte_t454417549_UInt32U26_t2197289955 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, Il2CppObject * p3, Color_t2020392075 * p4, int32_t p5, float p6, float p7, int32_t p8, int8_t p9, int8_t p10, int32_t p11, int32_t p12, int32_t p13, int32_t p14, int8_t p15, int32_t p16, float p17, float p18, float p19, float p20, int8_t p21, int8_t p22, uint32_t* p23, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], (Il2CppObject *)args[2], (Color_t2020392075 *)args[3], *((int32_t*)args[4]), *((float*)args[5]), *((float*)args[6]), *((int32_t*)args[7]), *((int8_t*)args[8]), *((int8_t*)args[9]), *((int32_t*)args[10]), *((int32_t*)args[11]), *((int32_t*)args[12]), *((int32_t*)args[13]), *((int8_t*)args[14]), *((int32_t*)args[15]), *((float*)args[16]), *((float*)args[17]), *((float*)args[18]), *((float*)args[19]), *((int8_t*)args[20]), *((int8_t*)args[21]), (uint32_t*)args[22], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Vector2_t2243707579_Il2CppObject_Vector3U26_t425862308 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Il2CppObject * p1, Vector2_t2243707579  p2, Il2CppObject * p3, Vector3_t2243707580 * p4, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((Vector2_t2243707579 *)args[1]), (Il2CppObject *)args[2], (Vector3_t2243707580 *)args[3], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Vector2_t2243707579_Il2CppObject_Vector2U26_t3911752445 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Il2CppObject * p1, Vector2_t2243707579  p2, Il2CppObject * p3, Vector2_t2243707579 * p4, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((Vector2_t2243707579 *)args[1]), (Il2CppObject *)args[2], (Vector2_t2243707579 *)args[3], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Ray_t2469606224_Il2CppObject_Vector2_t2243707579 (const MethodInfo* method, void* obj, void** args)
{
	typedef Ray_t2469606224  (*Func)(void* obj, Il2CppObject * p1, Vector2_t2243707579  p2, const MethodInfo* method);
	Ray_t2469606224  ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((Vector2_t2243707579 *)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Vector2_t2243707579_Vector2_t2243707579 (const MethodInfo* method, void* obj, void** args)
{
	typedef Vector2_t2243707579  (*Func)(void* obj, Vector2_t2243707579  p1, const MethodInfo* method);
	Vector2_t2243707579  ret = ((Func)method->methodPointer)(obj, *((Vector2_t2243707579 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Vector2_t2243707579_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Il2CppObject * p1, Vector2_t2243707579  p2, Il2CppObject * p3, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((Vector2_t2243707579 *)args[1]), (Il2CppObject *)args[2], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Vector2U26_t3911752445_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Il2CppObject * p1, Vector2_t2243707579 * p2, Il2CppObject * p3, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Vector2_t2243707579 *)args[1], (Il2CppObject *)args[2], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Vector2_t2243707579_Vector2_t2243707579_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Vector2_t2243707579  (*Func)(void* obj, Vector2_t2243707579  p1, Il2CppObject * p2, Il2CppObject * p3, const MethodInfo* method);
	Vector2_t2243707579  ret = ((Func)method->methodPointer)(obj, *((Vector2_t2243707579 *)args[0]), (Il2CppObject *)args[1], (Il2CppObject *)args[2], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Vector2U26_t3911752445_Il2CppObject_Il2CppObject_Vector2U26_t3911752445 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Vector2_t2243707579 * p1, Il2CppObject * p2, Il2CppObject * p3, Vector2_t2243707579 * p4, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Vector2_t2243707579 *)args[0], (Il2CppObject *)args[1], (Il2CppObject *)args[2], (Vector2_t2243707579 *)args[3], method);
	return NULL;
}

void* RuntimeInvoker_Rect_t3681755626_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Rect_t3681755626  (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, const MethodInfo* method);
	Rect_t3681755626  ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Il2CppObject_RectU26_t844847526 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, Rect_t3681755626 * p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], (Rect_t3681755626 *)args[2], method);
	return NULL;
}

void* RuntimeInvoker_RenderMode_t4280533217 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Vector2_t2243707579_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Vector2_t2243707579  p1, Il2CppObject * p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((Vector2_t2243707579 *)args[0]), (Il2CppObject *)args[1], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Color_t2020392075 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Color_t2020392075  p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((Color_t2020392075 *)args[0]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_ColorU26_t3402129837 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, Color_t2020392075 * p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Color_t2020392075 *)args[1], method);
	return NULL;
}

void* RuntimeInvoker_Color_t2020392075 (const MethodInfo* method, void* obj, void** args)
{
	typedef Color_t2020392075  (*Func)(void* obj, const MethodInfo* method);
	Color_t2020392075  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Rect_t3681755626 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Rect_t3681755626  p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((Rect_t3681755626 *)args[0]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_RectU26_t844847526 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, Rect_t3681755626 * p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Rect_t3681755626 *)args[1], method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, Il2CppObject * p3, Il2CppObject * p4, Il2CppObject * p5, Il2CppObject * p6, Il2CppObject * p7, Il2CppObject * p8, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], (Il2CppObject *)args[2], (Il2CppObject *)args[3], (Il2CppObject *)args[4], (Il2CppObject *)args[5], (Il2CppObject *)args[6], (Il2CppObject *)args[7], method);
	return NULL;
}

void* RuntimeInvoker_EventType_t3919834026 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_EventModifiers_t2690251474 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_KeyCode_t2283395152 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Single_t2076509932_Single_t2076509932_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, int32_t p2, Il2CppObject * p3, int32_t p4, float p5, float p6, Il2CppObject * p7, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), (Il2CppObject *)args[2], *((int32_t*)args[3]), *((float*)args[4]), *((float*)args[5]), (Il2CppObject *)args[6], method);
	return NULL;
}

void* RuntimeInvoker_Il2CppObject_Single_t2076509932 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, float p1, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((float*)args[0]), method);
	return ret;
}

void* RuntimeInvoker_Void_t1841601450_Single_t2076509932_Single_t2076509932_Single_t2076509932_Single_t2076509932_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, float p1, float p2, float p3, float p4, Il2CppObject * p5, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((float*)args[0]), *((float*)args[1]), *((float*)args[2]), *((float*)args[3]), (Il2CppObject *)args[4], method);
	return NULL;
}

void* RuntimeInvoker_Rect_t3681755626_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef Rect_t3681755626  (*Func)(void* obj, int32_t p1, const MethodInfo* method);
	Rect_t3681755626  ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_RectU26_t844847526 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, Rect_t3681755626 * p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), (Rect_t3681755626 *)args[1], method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Rect_t3681755626 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, Rect_t3681755626  p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((Rect_t3681755626 *)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Il2CppObject_Il2CppObject_IntPtr_t (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Il2CppObject * p1, IntPtr_t p2, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((IntPtr_t*)args[1]), method);
	return ret;
}

void* RuntimeInvoker_Void_t1841601450_ColorU26_t3402129837 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Color_t2020392075 * p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Color_t2020392075 *)args[0], method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_IntPtr_t_Rect_t3681755626_Il2CppObject_SByte_t454417549_SByte_t454417549_SByte_t454417549_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, IntPtr_t p1, Rect_t3681755626  p2, Il2CppObject * p3, int8_t p4, int8_t p5, int8_t p6, int8_t p7, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((IntPtr_t*)args[0]), *((Rect_t3681755626 *)args[1]), (Il2CppObject *)args[2], *((int8_t*)args[3]), *((int8_t*)args[4]), *((int8_t*)args[5]), *((int8_t*)args[6]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Rect_t3681755626_SByte_t454417549_SByte_t454417549_SByte_t454417549_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Rect_t3681755626  p1, int8_t p2, int8_t p3, int8_t p4, int8_t p5, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((Rect_t3681755626 *)args[0]), *((int8_t*)args[1]), *((int8_t*)args[2]), *((int8_t*)args[3]), *((int8_t*)args[4]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Rect_t3681755626_Il2CppObject_SByte_t454417549_SByte_t454417549_SByte_t454417549_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Rect_t3681755626  p1, Il2CppObject * p2, int8_t p3, int8_t p4, int8_t p5, int8_t p6, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((Rect_t3681755626 *)args[0]), (Il2CppObject *)args[1], *((int8_t*)args[2]), *((int8_t*)args[3]), *((int8_t*)args[4]), *((int8_t*)args[5]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Rect_t3681755626_Il2CppObject_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Rect_t3681755626  p1, Il2CppObject * p2, int32_t p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((Rect_t3681755626 *)args[0]), (Il2CppObject *)args[1], *((int32_t*)args[2]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Rect_t3681755626_Il2CppObject_Int32_t2071877448_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Rect_t3681755626  p1, Il2CppObject * p2, int32_t p3, int8_t p4, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((Rect_t3681755626 *)args[0]), (Il2CppObject *)args[1], *((int32_t*)args[2]), *((int8_t*)args[3]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Rect_t3681755626_Il2CppObject_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Rect_t3681755626  p1, Il2CppObject * p2, int32_t p3, int32_t p4, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((Rect_t3681755626 *)args[0]), (Il2CppObject *)args[1], *((int32_t*)args[2]), *((int32_t*)args[3]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Rect_t3681755626_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Rect_t3681755626  p1, Il2CppObject * p2, int32_t p3, int32_t p4, int32_t p5, int8_t p6, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((Rect_t3681755626 *)args[0]), (Il2CppObject *)args[1], *((int32_t*)args[2]), *((int32_t*)args[3]), *((int32_t*)args[4]), *((int8_t*)args[5]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Rect_t3681755626_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Rect_t3681755626  p1, Il2CppObject * p2, int32_t p3, int32_t p4, int32_t p5, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((Rect_t3681755626 *)args[0]), (Il2CppObject *)args[1], *((int32_t*)args[2]), *((int32_t*)args[3]), *((int32_t*)args[4]), method);
	return NULL;
}

void* RuntimeInvoker_Vector2_t2243707579_Rect_t3681755626_Il2CppObject_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef Vector2_t2243707579  (*Func)(void* obj, Rect_t3681755626  p1, Il2CppObject * p2, int32_t p3, const MethodInfo* method);
	Vector2_t2243707579  ret = ((Func)method->methodPointer)(obj, *((Rect_t3681755626 *)args[0]), (Il2CppObject *)args[1], *((int32_t*)args[2]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Rect_t3681755626_Il2CppObject_Vector2_t2243707579 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Rect_t3681755626  p1, Il2CppObject * p2, Vector2_t2243707579  p3, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((Rect_t3681755626 *)args[0]), (Il2CppObject *)args[1], *((Vector2_t2243707579 *)args[2]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Il2CppObject_Single_t2076509932 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, float p2, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((float*)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Vector2_t2243707579_Il2CppObject_Vector2_t2243707579 (const MethodInfo* method, void* obj, void** args)
{
	typedef Vector2_t2243707579  (*Func)(void* obj, Il2CppObject * p1, Vector2_t2243707579  p2, const MethodInfo* method);
	Vector2_t2243707579  ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((Vector2_t2243707579 *)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Single_t2076509932_Il2CppObject_Single_t2076509932 (const MethodInfo* method, void* obj, void** args)
{
	typedef float (*Func)(void* obj, Il2CppObject * p1, float p2, const MethodInfo* method);
	float ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((float*)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_SingleU26_t4173844468_SingleU26_t4173844468 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, float* p2, float* p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (float*)args[1], (float*)args[2], method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Int32_t2071877448_IntPtrU26_t1981417703 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, int32_t p2, IntPtr_t* p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), (IntPtr_t*)args[2], method);
	return NULL;
}

void* RuntimeInvoker_ImagePosition_t3491916276 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_TextAnchor_t112990806 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_TextClipping_t2573530411 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Single_t2076509932_IntPtr_t (const MethodInfo* method, void* obj, void** args)
{
	typedef float (*Func)(void* obj, IntPtr_t p1, const MethodInfo* method);
	float ret = ((Func)method->methodPointer)(obj, *((IntPtr_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_FontStyle_t2764949590 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Internal_DrawArgumentsU26_t3595831378 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, Internal_DrawArguments_t2834709342 * p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Internal_DrawArguments_t2834709342 *)args[1], method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_IntPtr_t_Rect_t3681755626_Il2CppObject_Int32_t2071877448_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, IntPtr_t p1, Rect_t3681755626  p2, Il2CppObject * p3, int32_t p4, int8_t p5, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((IntPtr_t*)args[0]), *((Rect_t3681755626 *)args[1]), (Il2CppObject *)args[2], *((int32_t*)args[3]), *((int8_t*)args[4]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_IntPtr_t_RectU26_t844847526_Il2CppObject_Int32_t2071877448_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, IntPtr_t p1, Rect_t3681755626 * p2, Il2CppObject * p3, int32_t p4, int8_t p5, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((IntPtr_t*)args[0]), (Rect_t3681755626 *)args[1], (Il2CppObject *)args[2], *((int32_t*)args[3]), *((int8_t*)args[4]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Rect_t3681755626 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, Rect_t3681755626  p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((Rect_t3681755626 *)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_IntPtr_t_Rect_t3681755626_Il2CppObject_Int32_t2071877448_Color_t2020392075 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, IntPtr_t p1, Rect_t3681755626  p2, Il2CppObject * p3, int32_t p4, Color_t2020392075  p5, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((IntPtr_t*)args[0]), *((Rect_t3681755626 *)args[1]), (Il2CppObject *)args[2], *((int32_t*)args[3]), *((Color_t2020392075 *)args[4]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_IntPtr_t_RectU26_t844847526_Il2CppObject_Int32_t2071877448_ColorU26_t3402129837 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, IntPtr_t p1, Rect_t3681755626 * p2, Il2CppObject * p3, int32_t p4, Color_t2020392075 * p5, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((IntPtr_t*)args[0]), (Rect_t3681755626 *)args[1], (Il2CppObject *)args[2], *((int32_t*)args[3]), (Color_t2020392075 *)args[4], method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Internal_DrawWithTextSelectionArgumentsU26_t807284931 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, Internal_DrawWithTextSelectionArguments_t1327795077 * p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Internal_DrawWithTextSelectionArguments_t1327795077 *)args[1], method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_IntPtr_t_Rect_t3681755626_Il2CppObject_Int32_t2071877448_Vector2U26_t3911752445 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, IntPtr_t p1, Rect_t3681755626  p2, Il2CppObject * p3, int32_t p4, Vector2_t2243707579 * p5, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((IntPtr_t*)args[0]), *((Rect_t3681755626 *)args[1]), (Il2CppObject *)args[2], *((int32_t*)args[3]), (Vector2_t2243707579 *)args[4], method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_IntPtr_t_RectU26_t844847526_Il2CppObject_Int32_t2071877448_Vector2U26_t3911752445 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, IntPtr_t p1, Rect_t3681755626 * p2, Il2CppObject * p3, int32_t p4, Vector2_t2243707579 * p5, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((IntPtr_t*)args[0]), (Rect_t3681755626 *)args[1], (Il2CppObject *)args[2], *((int32_t*)args[3]), (Vector2_t2243707579 *)args[4], method);
	return NULL;
}

void* RuntimeInvoker_Int32_t2071877448_IntPtr_t_Rect_t3681755626_Il2CppObject_Vector2_t2243707579 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, IntPtr_t p1, Rect_t3681755626  p2, Il2CppObject * p3, Vector2_t2243707579  p4, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((IntPtr_t*)args[0]), *((Rect_t3681755626 *)args[1]), (Il2CppObject *)args[2], *((Vector2_t2243707579 *)args[3]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_IntPtr_t_RectU26_t844847526_Il2CppObject_Vector2U26_t3911752445 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, IntPtr_t p1, Rect_t3681755626 * p2, Il2CppObject * p3, Vector2_t2243707579 * p4, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((IntPtr_t*)args[0]), (Rect_t3681755626 *)args[1], (Il2CppObject *)args[2], (Vector2_t2243707579 *)args[3], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_IntPtr_t_Il2CppObject_Single_t2076509932 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, IntPtr_t p1, Il2CppObject * p2, float p3, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((IntPtr_t*)args[0]), (Il2CppObject *)args[1], *((float*)args[2]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_IntPtr_t_Il2CppObject_Vector2U26_t3911752445 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, IntPtr_t p1, Il2CppObject * p2, Vector2_t2243707579 * p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((IntPtr_t*)args[0]), (Il2CppObject *)args[1], (Vector2_t2243707579 *)args[2], method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_IntPtr_t_Il2CppObject_Vector2_t2243707579_Vector2U26_t3911752445 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, IntPtr_t p1, Il2CppObject * p2, Vector2_t2243707579  p3, Vector2_t2243707579 * p4, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((IntPtr_t*)args[0]), (Il2CppObject *)args[1], *((Vector2_t2243707579 *)args[2]), (Vector2_t2243707579 *)args[3], method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_IntPtr_t_Il2CppObject_Vector2U26_t3911752445_Vector2U26_t3911752445 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, IntPtr_t p1, Il2CppObject * p2, Vector2_t2243707579 * p3, Vector2_t2243707579 * p4, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((IntPtr_t*)args[0]), (Il2CppObject *)args[1], (Vector2_t2243707579 *)args[2], (Vector2_t2243707579 *)args[3], method);
	return NULL;
}

void* RuntimeInvoker_Single_t2076509932_IntPtr_t_Il2CppObject_Single_t2076509932 (const MethodInfo* method, void* obj, void** args)
{
	typedef float (*Func)(void* obj, IntPtr_t p1, Il2CppObject * p2, float p3, const MethodInfo* method);
	float ret = ((Func)method->methodPointer)(obj, *((IntPtr_t*)args[0]), (Il2CppObject *)args[1], *((float*)args[2]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_IntPtr_t_Il2CppObject_SingleU26_t4173844468_SingleU26_t4173844468 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, IntPtr_t p1, Il2CppObject * p2, float* p3, float* p4, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((IntPtr_t*)args[0]), (Il2CppObject *)args[1], (float*)args[2], (float*)args[3], method);
	return NULL;
}

void* RuntimeInvoker_Color_t2020392075_Color_t2020392075_Single_t2076509932 (const MethodInfo* method, void* obj, void** args)
{
	typedef Color_t2020392075  (*Func)(void* obj, Color_t2020392075  p1, float p2, const MethodInfo* method);
	Color_t2020392075  ret = ((Func)method->methodPointer)(obj, *((Color_t2020392075 *)args[0]), *((float*)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Color_t2020392075_Color_t2020392075_Color_t2020392075_Single_t2076509932 (const MethodInfo* method, void* obj, void** args)
{
	typedef Color_t2020392075  (*Func)(void* obj, Color_t2020392075  p1, Color_t2020392075  p2, float p3, const MethodInfo* method);
	Color_t2020392075  ret = ((Func)method->methodPointer)(obj, *((Color_t2020392075 *)args[0]), *((Color_t2020392075 *)args[1]), *((float*)args[2]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Vector4_t2243707581_Color_t2020392075 (const MethodInfo* method, void* obj, void** args)
{
	typedef Vector4_t2243707581  (*Func)(void* obj, Color_t2020392075  p1, const MethodInfo* method);
	Vector4_t2243707581  ret = ((Func)method->methodPointer)(obj, *((Color_t2020392075 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Color32_t874517518_Color_t2020392075 (const MethodInfo* method, void* obj, void** args)
{
	typedef Color32_t874517518  (*Func)(void* obj, Color_t2020392075  p1, const MethodInfo* method);
	Color32_t874517518  ret = ((Func)method->methodPointer)(obj, *((Color_t2020392075 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Color_t2020392075_Color32_t874517518 (const MethodInfo* method, void* obj, void** args)
{
	typedef Color_t2020392075  (*Func)(void* obj, Color32_t874517518  p1, const MethodInfo* method);
	Color_t2020392075  ret = ((Func)method->methodPointer)(obj, *((Color32_t874517518 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_HitInfo_t1761367055 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, HitInfo_t1761367055  p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((HitInfo_t1761367055 *)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Boolean_t3825574718_HitInfo_t1761367055 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, HitInfo_t1761367055  p1, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((HitInfo_t1761367055 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_HitInfo_t1761367055_HitInfo_t1761367055 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, HitInfo_t1761367055  p1, HitInfo_t1761367055  p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((HitInfo_t1761367055 *)args[0]), *((HitInfo_t1761367055 *)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Ray_t2469606224_SingleU26_t4173844468 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Ray_t2469606224  p1, float* p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((Ray_t2469606224 *)args[0]), (float*)args[1], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Vector3_t2243707580_Single_t2076509932 (const MethodInfo* method, void* obj, void** args)
{
	typedef Vector3_t2243707580  (*Func)(void* obj, float p1, const MethodInfo* method);
	Vector3_t2243707580  ret = ((Func)method->methodPointer)(obj, *((float*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Vector2_t2243707579 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Vector2_t2243707579  p1, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((Vector2_t2243707579 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Vector3_t2243707580 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Vector3_t2243707580  p1, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((Vector3_t2243707580 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Rect_t3681755626_Rect_t3681755626 (const MethodInfo* method, void* obj, void** args)
{
	typedef Rect_t3681755626  (*Func)(void* obj, Rect_t3681755626  p1, const MethodInfo* method);
	Rect_t3681755626  ret = ((Func)method->methodPointer)(obj, *((Rect_t3681755626 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Rect_t3681755626 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Rect_t3681755626  p1, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((Rect_t3681755626 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Rect_t3681755626_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Rect_t3681755626  p1, int8_t p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((Rect_t3681755626 *)args[0]), *((int8_t*)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Rect_t3681755626_Rect_t3681755626 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Rect_t3681755626  p1, Rect_t3681755626  p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((Rect_t3681755626 *)args[0]), *((Rect_t3681755626 *)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_StringU26_t638738783_StringU26_t638738783 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, String_t** p2, String_t** p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (String_t**)args[1], (String_t**)args[2], method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_AnimatorStateInfo_t2577870592_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, AnimatorStateInfo_t2577870592  p2, int32_t p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((AnimatorStateInfo_t2577870592 *)args[1]), *((int32_t*)args[2]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_AnimatorStateInfo_t2577870592_Int32_t2071877448_AnimatorControllerPlayable_t4078305555 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, AnimatorStateInfo_t2577870592  p2, int32_t p3, AnimatorControllerPlayable_t4078305555  p4, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((AnimatorStateInfo_t2577870592 *)args[1]), *((int32_t*)args[2]), *((AnimatorControllerPlayable_t4078305555 *)args[3]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Int32_t2071877448_AnimatorControllerPlayable_t4078305555 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, int32_t p2, AnimatorControllerPlayable_t4078305555  p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), *((AnimatorControllerPlayable_t4078305555 *)args[2]), method);
	return NULL;
}

void* RuntimeInvoker_PersistentListenerMode_t857969000 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Vector2_t2243707579_Vector2_t2243707579_Vector2_t2243707579 (const MethodInfo* method, void* obj, void** args)
{
	typedef Vector2_t2243707579  (*Func)(void* obj, Vector2_t2243707579  p1, Vector2_t2243707579  p2, const MethodInfo* method);
	Vector2_t2243707579  ret = ((Func)method->methodPointer)(obj, *((Vector2_t2243707579 *)args[0]), *((Vector2_t2243707579 *)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Single_t2076509932_Vector2_t2243707579_Vector2_t2243707579 (const MethodInfo* method, void* obj, void** args)
{
	typedef float (*Func)(void* obj, Vector2_t2243707579  p1, Vector2_t2243707579  p2, const MethodInfo* method);
	float ret = ((Func)method->methodPointer)(obj, *((Vector2_t2243707579 *)args[0]), *((Vector2_t2243707579 *)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Vector2_t2243707579_Vector2_t2243707579_Single_t2076509932 (const MethodInfo* method, void* obj, void** args)
{
	typedef Vector2_t2243707579  (*Func)(void* obj, Vector2_t2243707579  p1, float p2, const MethodInfo* method);
	Vector2_t2243707579  ret = ((Func)method->methodPointer)(obj, *((Vector2_t2243707579 *)args[0]), *((float*)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Vector2_t2243707579_Vector3_t2243707580 (const MethodInfo* method, void* obj, void** args)
{
	typedef Vector2_t2243707579  (*Func)(void* obj, Vector3_t2243707580  p1, const MethodInfo* method);
	Vector2_t2243707579  ret = ((Func)method->methodPointer)(obj, *((Vector3_t2243707580 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Vector3_t2243707580_Vector2_t2243707579 (const MethodInfo* method, void* obj, void** args)
{
	typedef Vector3_t2243707580  (*Func)(void* obj, Vector2_t2243707579  p1, const MethodInfo* method);
	Vector3_t2243707580  ret = ((Func)method->methodPointer)(obj, *((Vector2_t2243707579 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Single_t2076509932_Vector4_t2243707581_Vector4_t2243707581 (const MethodInfo* method, void* obj, void** args)
{
	typedef float (*Func)(void* obj, Vector4_t2243707581  p1, Vector4_t2243707581  p2, const MethodInfo* method);
	float ret = ((Func)method->methodPointer)(obj, *((Vector4_t2243707581 *)args[0]), *((Vector4_t2243707581 *)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Vector4_t2243707581_Vector4_t2243707581_Vector4_t2243707581 (const MethodInfo* method, void* obj, void** args)
{
	typedef Vector4_t2243707581  (*Func)(void* obj, Vector4_t2243707581  p1, Vector4_t2243707581  p2, const MethodInfo* method);
	Vector4_t2243707581  ret = ((Func)method->methodPointer)(obj, *((Vector4_t2243707581 *)args[0]), *((Vector4_t2243707581 *)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Vector4_t2243707581_Vector4_t2243707581_Single_t2076509932 (const MethodInfo* method, void* obj, void** args)
{
	typedef Vector4_t2243707581  (*Func)(void* obj, Vector4_t2243707581  p1, float p2, const MethodInfo* method);
	Vector4_t2243707581  ret = ((Func)method->methodPointer)(obj, *((Vector4_t2243707581 *)args[0]), *((float*)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Vector4_t2243707581_Vector4_t2243707581 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Vector4_t2243707581  p1, Vector4_t2243707581  p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((Vector4_t2243707581 *)args[0]), *((Vector4_t2243707581 *)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Single_t2076509932_Vector4_t2243707581 (const MethodInfo* method, void* obj, void** args)
{
	typedef float (*Func)(void* obj, Vector4_t2243707581  p1, const MethodInfo* method);
	float ret = ((Func)method->methodPointer)(obj, *((Vector4_t2243707581 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_AnimationPlayable_t1693994278_Playable_t3667545548_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, AnimationPlayable_t1693994278  p1, Playable_t3667545548  p2, Il2CppObject * p3, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((AnimationPlayable_t1693994278 *)args[0]), *((Playable_t3667545548 *)args[1]), (Il2CppObject *)args[2], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_AnimationPlayable_t1693994278_Playable_t3667545548_Int32_t2071877448_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, AnimationPlayable_t1693994278  p1, Playable_t3667545548  p2, int32_t p3, Il2CppObject * p4, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((AnimationPlayable_t1693994278 *)args[0]), *((Playable_t3667545548 *)args[1]), *((int32_t*)args[2]), (Il2CppObject *)args[3], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_AnimationPlayable_t1693994278_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, AnimationPlayable_t1693994278  p1, Il2CppObject * p2, Il2CppObject * p3, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((AnimationPlayable_t1693994278 *)args[0]), (Il2CppObject *)args[1], (Il2CppObject *)args[2], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_AnimationPlayable_t1693994278_Int32_t2071877448_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, AnimationPlayable_t1693994278  p1, int32_t p2, Il2CppObject * p3, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((AnimationPlayable_t1693994278 *)args[0]), *((int32_t*)args[1]), (Il2CppObject *)args[2], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_AnimationPlayable_t1693994278_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, AnimationPlayable_t1693994278  p1, Il2CppObject * p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((AnimationPlayable_t1693994278 *)args[0]), (Il2CppObject *)args[1], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_LogType_t1559732862 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_RaycastResult_t21186376_RaycastResult_t21186376 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, RaycastResult_t21186376  p1, RaycastResult_t21186376  p2, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((RaycastResult_t21186376 *)args[0]), *((RaycastResult_t21186376 *)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_MoveDirection_t1406276862 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_RaycastResult_t21186376 (const MethodInfo* method, void* obj, void** args)
{
	typedef RaycastResult_t21186376  (*Func)(void* obj, const MethodInfo* method);
	RaycastResult_t21186376  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_RaycastResult_t21186376 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RaycastResult_t21186376  p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((RaycastResult_t21186376 *)args[0]), method);
	return NULL;
}

void* RuntimeInvoker_InputButton_t2981963041 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_RaycastResult_t21186376_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef RaycastResult_t21186376  (*Func)(void* obj, Il2CppObject * p1, const MethodInfo* method);
	RaycastResult_t21186376  ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_MoveDirection_t1406276862_Single_t2076509932_Single_t2076509932 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, float p1, float p2, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((float*)args[0]), *((float*)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_MoveDirection_t1406276862_Single_t2076509932_Single_t2076509932_Single_t2076509932 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, float p1, float p2, float p3, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((float*)args[0]), *((float*)args[1]), *((float*)args[2]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Il2CppObject_Single_t2076509932_Single_t2076509932_Single_t2076509932 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, float p1, float p2, float p3, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((float*)args[0]), *((float*)args[1]), *((float*)args[2]), method);
	return ret;
}

void* RuntimeInvoker_Boolean_t3825574718_Int32_t2071877448_PointerEventDataU26_t2885421157_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, int32_t p1, PointerEventData_t1599784723 ** p2, int8_t p3, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), (PointerEventData_t1599784723 **)args[1], *((int8_t*)args[2]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Il2CppObject_Touch_t407273883_BooleanU26_t3168250738_BooleanU26_t3168250738 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Touch_t407273883  p1, bool* p2, bool* p3, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((Touch_t407273883 *)args[0]), (bool*)args[1], (bool*)args[2], method);
	return ret;
}

void* RuntimeInvoker_FramePressState_t1414739712_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, int32_t p1, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Vector2_t2243707579_Vector2_t2243707579_Single_t2076509932_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Vector2_t2243707579  p1, Vector2_t2243707579  p2, float p3, int8_t p4, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((Vector2_t2243707579 *)args[0]), *((Vector2_t2243707579 *)args[1]), *((float*)args[2]), *((int8_t*)args[3]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_InputMode_t2680906638 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_LayerMask_t3188175821 (const MethodInfo* method, void* obj, void** args)
{
	typedef LayerMask_t3188175821  (*Func)(void* obj, const MethodInfo* method);
	LayerMask_t3188175821  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_LayerMask_t3188175821 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, LayerMask_t3188175821  p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((LayerMask_t3188175821 *)args[0]), method);
	return NULL;
}

void* RuntimeInvoker_Int32_t2071877448_RaycastHit_t87180320_RaycastHit_t87180320 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, RaycastHit_t87180320  p1, RaycastHit_t87180320  p2, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((RaycastHit_t87180320 *)args[0]), *((RaycastHit_t87180320 *)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_ColorTweenMode_t1328781136 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_ColorBlock_t2652774230 (const MethodInfo* method, void* obj, void** args)
{
	typedef ColorBlock_t2652774230  (*Func)(void* obj, const MethodInfo* method);
	ColorBlock_t2652774230  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_ColorBlock_t2652774230 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, ColorBlock_t2652774230  p1, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((ColorBlock_t2652774230 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_ColorBlock_t2652774230_ColorBlock_t2652774230 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, ColorBlock_t2652774230  p1, ColorBlock_t2652774230  p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((ColorBlock_t2652774230 *)args[0]), *((ColorBlock_t2652774230 *)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Il2CppObject_Il2CppObject_Vector2_t2243707579 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Il2CppObject * p1, Vector2_t2243707579  p2, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((Vector2_t2243707579 *)args[1]), method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Resources_t2975512894 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Resources_t2975512894  p1, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((Resources_t2975512894 *)args[0]), method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Il2CppObject_SByte_t454417549_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Il2CppObject * p1, int8_t p2, Il2CppObject * p3, Il2CppObject * p4, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int8_t*)args[1]), (Il2CppObject *)args[2], (Il2CppObject *)args[3], method);
	return ret;
}

void* RuntimeInvoker_HorizontalWrapMode_t2027154177 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_VerticalWrapMode_t3668245347 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Color_t2020392075_Single_t2076509932_SByte_t454417549_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Color_t2020392075  p1, float p2, int8_t p3, int8_t p4, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((Color_t2020392075 *)args[0]), *((float*)args[1]), *((int8_t*)args[2]), *((int8_t*)args[3]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Color_t2020392075_Single_t2076509932_SByte_t454417549_SByte_t454417549_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Color_t2020392075  p1, float p2, int8_t p3, int8_t p4, int8_t p5, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((Color_t2020392075 *)args[0]), *((float*)args[1]), *((int8_t*)args[2]), *((int8_t*)args[3]), *((int8_t*)args[4]), method);
	return NULL;
}

void* RuntimeInvoker_Color_t2020392075_Single_t2076509932 (const MethodInfo* method, void* obj, void** args)
{
	typedef Color_t2020392075  (*Func)(void* obj, float p1, const MethodInfo* method);
	Color_t2020392075  ret = ((Func)method->methodPointer)(obj, *((float*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Single_t2076509932_Single_t2076509932_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, float p1, float p2, int8_t p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((float*)args[0]), *((float*)args[1]), *((int8_t*)args[2]), method);
	return NULL;
}

void* RuntimeInvoker_BlockingObjects_t2548930813 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Il2CppObject_Vector2_t2243707579_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, Vector2_t2243707579  p3, Il2CppObject * p4, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], *((Vector2_t2243707579 *)args[2]), (Il2CppObject *)args[3], method);
	return NULL;
}

void* RuntimeInvoker_Type_t3352948571 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_FillMethod_t1640962579 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Vector4_t2243707581_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef Vector4_t2243707581  (*Func)(void* obj, int8_t p1, const MethodInfo* method);
	Vector4_t2243707581  ret = ((Func)method->methodPointer)(obj, *((int8_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Il2CppObject_Color32_t874517518_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, Color32_t874517518  p3, Il2CppObject * p4, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], *((Color32_t874517518 *)args[2]), (Il2CppObject *)args[3], method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Vector2_t2243707579_Vector2_t2243707579_Color32_t874517518_Vector2_t2243707579_Vector2_t2243707579 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, Vector2_t2243707579  p2, Vector2_t2243707579  p3, Color32_t874517518  p4, Vector2_t2243707579  p5, Vector2_t2243707579  p6, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((Vector2_t2243707579 *)args[1]), *((Vector2_t2243707579 *)args[2]), *((Color32_t874517518 *)args[3]), *((Vector2_t2243707579 *)args[4]), *((Vector2_t2243707579 *)args[5]), method);
	return NULL;
}

void* RuntimeInvoker_Vector4_t2243707581_Vector4_t2243707581_Rect_t3681755626 (const MethodInfo* method, void* obj, void** args)
{
	typedef Vector4_t2243707581  (*Func)(void* obj, Vector4_t2243707581  p1, Rect_t3681755626  p2, const MethodInfo* method);
	Vector4_t2243707581  ret = ((Func)method->methodPointer)(obj, *((Vector4_t2243707581 *)args[0]), *((Rect_t3681755626 *)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Il2CppObject_Single_t2076509932_SByte_t454417549_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, float p3, int8_t p4, int32_t p5, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], *((float*)args[2]), *((int8_t*)args[3]), *((int32_t*)args[4]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Single_t2076509932_Single_t2076509932_SByte_t454417549_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, float p2, float p3, int8_t p4, int32_t p5, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((float*)args[1]), *((float*)args[2]), *((int8_t*)args[3]), *((int32_t*)args[4]), method);
	return NULL;
}

void* RuntimeInvoker_Vector2_t2243707579_Vector2_t2243707579_Rect_t3681755626 (const MethodInfo* method, void* obj, void** args)
{
	typedef Vector2_t2243707579  (*Func)(void* obj, Vector2_t2243707579  p1, Rect_t3681755626  p2, const MethodInfo* method);
	Vector2_t2243707579  ret = ((Func)method->methodPointer)(obj, *((Vector2_t2243707579 *)args[0]), *((Rect_t3681755626 *)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_ContentType_t1028629049 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_LineType_t2931319356 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_InputType_t1274231802 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_TouchScreenKeyboardType_t875112366 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_CharacterValidation_t3437478890 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Int32U26_t455636984 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t* p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (int32_t*)args[0], method);
	return NULL;
}

void* RuntimeInvoker_Int32_t2071877448_Vector2_t2243707579_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Vector2_t2243707579  p1, Il2CppObject * p2, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((Vector2_t2243707579 *)args[0]), (Il2CppObject *)args[1], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Vector2_t2243707579 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Vector2_t2243707579  p1, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((Vector2_t2243707579 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_EditState_t1111987863_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Int32_t2071877448_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, int32_t p1, Il2CppObject * p2, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), (Il2CppObject *)args[1], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Int32_t2071877448_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, int32_t p1, int8_t p2, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((int8_t*)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Vector2_t2243707579 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, Vector2_t2243707579  p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((Vector2_t2243707579 *)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Char_t3454481338_Il2CppObject_Int32_t2071877448_Int16_t4041245914 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppChar (*Func)(void* obj, Il2CppObject * p1, int32_t p2, int16_t p3, const MethodInfo* method);
	Il2CppChar ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), *((int16_t*)args[2]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Il2CppObject_Il2CppObject_Int32_t2071877448_Int16_t4041245914_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Il2CppObject * p1, int32_t p2, int16_t p3, Il2CppObject * p4, Il2CppObject * p5, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), *((int16_t*)args[2]), (Il2CppObject *)args[3], (Il2CppObject *)args[4], method);
	return ret;
}

void* RuntimeInvoker_Void_t1841601450_Rect_t3681755626_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Rect_t3681755626  p1, int8_t p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((Rect_t3681755626 *)args[0]), *((int8_t*)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Mode_t1081683921 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Navigation_t1571958496 (const MethodInfo* method, void* obj, void** args)
{
	typedef Navigation_t1571958496  (*Func)(void* obj, const MethodInfo* method);
	Navigation_t1571958496  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Navigation_t1571958496 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Navigation_t1571958496  p1, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((Navigation_t1571958496 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Direction_t3696775921 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Single_t2076509932_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, float p1, int8_t p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((float*)args[0]), *((int8_t*)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Axis_t2427050347 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_MovementType_t905360158 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_ScrollbarVisibility_t3834843475 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Single_t2076509932_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, float p1, int32_t p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((float*)args[0]), *((int32_t*)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_SByte_t454417549_SByte_t454417549_Int32_t2071877448_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int8_t p1, int8_t p2, int32_t p3, Il2CppObject * p4, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int8_t*)args[0]), *((int8_t*)args[1]), *((int32_t*)args[2]), (Il2CppObject *)args[3], method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_BoundsU26_t1084128289_Vector2U26_t3911752445_Vector3U26_t425862308_Vector3U26_t425862308 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Bounds_t3033363703 * p1, Vector2_t2243707579 * p2, Vector3_t2243707580 * p3, Vector3_t2243707580 * p4, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Bounds_t3033363703 *)args[0], (Vector2_t2243707579 *)args[1], (Vector3_t2243707580 *)args[2], (Vector3_t2243707580 *)args[3], method);
	return NULL;
}

void* RuntimeInvoker_Bounds_t3033363703 (const MethodInfo* method, void* obj, void** args)
{
	typedef Bounds_t3033363703  (*Func)(void* obj, const MethodInfo* method);
	Bounds_t3033363703  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Bounds_t3033363703_Il2CppObject_Matrix4x4U26_t266301477 (const MethodInfo* method, void* obj, void** args)
{
	typedef Bounds_t3033363703  (*Func)(void* obj, Il2CppObject * p1, Matrix4x4_t2933234003 * p2, const MethodInfo* method);
	Bounds_t3033363703  ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Matrix4x4_t2933234003 *)args[1], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Vector2_t2243707579_BoundsU26_t1084128289_BoundsU26_t1084128289_SByte_t454417549_SByte_t454417549_Int32_t2071877448_Vector2U26_t3911752445 (const MethodInfo* method, void* obj, void** args)
{
	typedef Vector2_t2243707579  (*Func)(void* obj, Bounds_t3033363703 * p1, Bounds_t3033363703 * p2, int8_t p3, int8_t p4, int32_t p5, Vector2_t2243707579 * p6, const MethodInfo* method);
	Vector2_t2243707579  ret = ((Func)method->methodPointer)(obj, (Bounds_t3033363703 *)args[0], (Bounds_t3033363703 *)args[1], *((int8_t*)args[2]), *((int8_t*)args[3]), *((int32_t*)args[4]), (Vector2_t2243707579 *)args[5], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Navigation_t1571958496 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Navigation_t1571958496  p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((Navigation_t1571958496 *)args[0]), method);
	return NULL;
}

void* RuntimeInvoker_Transition_t605142169 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_ColorBlock_t2652774230 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, ColorBlock_t2652774230  p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((ColorBlock_t2652774230 *)args[0]), method);
	return NULL;
}

void* RuntimeInvoker_SpriteState_t1353336012 (const MethodInfo* method, void* obj, void** args)
{
	typedef SpriteState_t1353336012  (*Func)(void* obj, const MethodInfo* method);
	SpriteState_t1353336012  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_SpriteState_t1353336012 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, SpriteState_t1353336012  p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((SpriteState_t1353336012 *)args[0]), method);
	return NULL;
}

void* RuntimeInvoker_SelectionState_t3187567897 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Vector3_t2243707580_Il2CppObject_Vector2_t2243707579 (const MethodInfo* method, void* obj, void** args)
{
	typedef Vector3_t2243707580  (*Func)(void* obj, Il2CppObject * p1, Vector2_t2243707579  p2, const MethodInfo* method);
	Vector3_t2243707580  ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((Vector2_t2243707579 *)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Color_t2020392075_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Color_t2020392075  p1, int8_t p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((Color_t2020392075 *)args[0]), *((int8_t*)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Boolean_t3825574718_ColorU26_t3402129837_Color_t2020392075 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Color_t2020392075 * p1, Color_t2020392075  p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (Color_t2020392075 *)args[0], *((Color_t2020392075 *)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Direction_t1525323322 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Axis_t375128448 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_SpriteState_t1353336012 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, SpriteState_t1353336012  p1, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((SpriteState_t1353336012 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Il2CppObject_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Il2CppObject * p1, int32_t p2, int32_t p3, int32_t p4, int32_t p5, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), *((int32_t*)args[3]), *((int32_t*)args[4]), method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Il2CppObject * p1, int32_t p2, int32_t p3, int32_t p4, int32_t p5, int32_t p6, int32_t p7, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), *((int32_t*)args[3]), *((int32_t*)args[4]), *((int32_t*)args[5]), *((int32_t*)args[6]), method);
	return ret;
}

void* RuntimeInvoker_TextGenerationSettings_t2543476768_Vector2_t2243707579 (const MethodInfo* method, void* obj, void** args)
{
	typedef TextGenerationSettings_t2543476768  (*Func)(void* obj, Vector2_t2243707579  p1, const MethodInfo* method);
	TextGenerationSettings_t2543476768  ret = ((Func)method->methodPointer)(obj, *((Vector2_t2243707579 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Vector2_t2243707579_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef Vector2_t2243707579  (*Func)(void* obj, int32_t p1, const MethodInfo* method);
	Vector2_t2243707579  ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Rect_t3681755626_Il2CppObject_BooleanU26_t3168250738 (const MethodInfo* method, void* obj, void** args)
{
	typedef Rect_t3681755626  (*Func)(void* obj, Il2CppObject * p1, bool* p2, const MethodInfo* method);
	Rect_t3681755626  ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (bool*)args[1], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Rect_t3681755626_Rect_t3681755626_Rect_t3681755626 (const MethodInfo* method, void* obj, void** args)
{
	typedef Rect_t3681755626  (*Func)(void* obj, Rect_t3681755626  p1, Rect_t3681755626  p2, const MethodInfo* method);
	Rect_t3681755626  ret = ((Func)method->methodPointer)(obj, *((Rect_t3681755626 *)args[0]), *((Rect_t3681755626 *)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_AspectMode_t1166448724 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Single_t2076509932_Single_t2076509932_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef float (*Func)(void* obj, float p1, int32_t p2, const MethodInfo* method);
	float ret = ((Func)method->methodPointer)(obj, *((float*)args[0]), *((int32_t*)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_ScaleMode_t987318053 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_ScreenMatchMode_t1916789528 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Unit_t3220761768 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_FitMode_t4030874534 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Corner_t1077473318 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Axis_t1431825778 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Constraint_t3558160636 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Int32_t2071877448_SByte_t454417549_SByte_t454417549_SingleU26_t4173844468_SingleU26_t4173844468_SingleU26_t4173844468 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, int32_t p2, int8_t p3, int8_t p4, float* p5, float* p6, float* p7, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), *((int8_t*)args[2]), *((int8_t*)args[3]), (float*)args[4], (float*)args[5], (float*)args[6], method);
	return NULL;
}

void* RuntimeInvoker_Single_t2076509932_Int32_t2071877448_Single_t2076509932 (const MethodInfo* method, void* obj, void** args)
{
	typedef float (*Func)(void* obj, int32_t p1, float p2, const MethodInfo* method);
	float ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((float*)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Single_t2076509932_Single_t2076509932_Single_t2076509932_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, float p1, float p2, float p3, int32_t p4, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((float*)args[0]), *((float*)args[1]), *((float*)args[2]), *((int32_t*)args[3]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Int32_t2071877448_Single_t2076509932 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, int32_t p2, float p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), *((float*)args[2]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Int32_t2071877448_Single_t2076509932_Single_t2076509932 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, int32_t p2, float p3, float p4, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), *((float*)args[2]), *((float*)args[3]), method);
	return NULL;
}

void* RuntimeInvoker_Single_t2076509932_Il2CppObject_Il2CppObject_Single_t2076509932 (const MethodInfo* method, void* obj, void** args)
{
	typedef float (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, float p3, const MethodInfo* method);
	float ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], *((float*)args[2]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Single_t2076509932_Il2CppObject_Il2CppObject_Single_t2076509932_ILayoutElementU26_t440254879 (const MethodInfo* method, void* obj, void** args)
{
	typedef float (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, float p3, Il2CppObject ** p4, const MethodInfo* method);
	float ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], *((float*)args[2]), (Il2CppObject **)args[3], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Il2CppObject_Ray_t2469606224_RaycastHitU26_t1969197280_Single_t2076509932_Int32_t2071877448_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Ray_t2469606224  p1, RaycastHit_t87180320 * p2, float p3, int32_t p4, Il2CppObject * p5, Il2CppObject * p6, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((Ray_t2469606224 *)args[0]), (RaycastHit_t87180320 *)args[1], *((float*)args[2]), *((int32_t*)args[3]), (Il2CppObject *)args[4], (Il2CppObject *)args[5], method);
	return ret;
}

void* RuntimeInvoker_Boolean_t3825574718_RaycastHitU26_t1969197280_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, RaycastHit_t87180320 * p1, Il2CppObject * p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (RaycastHit_t87180320 *)args[0], (Il2CppObject *)args[1], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Il2CppObject_Vector2_t2243707579_Vector2_t2243707579_Single_t2076509932_Int32_t2071877448_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Vector2_t2243707579  p1, Vector2_t2243707579  p2, float p3, int32_t p4, Il2CppObject * p5, Il2CppObject * p6, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((Vector2_t2243707579 *)args[0]), *((Vector2_t2243707579 *)args[1]), *((float*)args[2]), *((int32_t*)args[3]), (Il2CppObject *)args[4], (Il2CppObject *)args[5], method);
	return ret;
}

void* RuntimeInvoker_RaycastHit2D_t4063908774_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef RaycastHit2D_t4063908774  (*Func)(void* obj, Il2CppObject * p1, const MethodInfo* method);
	RaycastHit2D_t4063908774  ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Il2CppObject_Ray_t2469606224_Single_t2076509932_Int32_t2071877448_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Ray_t2469606224  p1, float p2, int32_t p3, Il2CppObject * p4, Il2CppObject * p5, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((Ray_t2469606224 *)args[0]), *((float*)args[1]), *((int32_t*)args[2]), (Il2CppObject *)args[3], (Il2CppObject *)args[4], method);
	return ret;
}

void* RuntimeInvoker_Void_t1841601450_UIVertexU26_t1130679118_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, UIVertex_t1204258818 * p1, int32_t p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (UIVertex_t1204258818 *)args[0], *((int32_t*)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_UIVertex_t1204258818_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, UIVertex_t1204258818  p1, int32_t p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((UIVertex_t1204258818 *)args[0]), *((int32_t*)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Vector3_t2243707580_Color32_t874517518_Vector2_t2243707579_Vector2_t2243707579_Vector3_t2243707580_Vector4_t2243707581 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Vector3_t2243707580  p1, Color32_t874517518  p2, Vector2_t2243707579  p3, Vector2_t2243707579  p4, Vector3_t2243707580  p5, Vector4_t2243707581  p6, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((Vector3_t2243707580 *)args[0]), *((Color32_t874517518 *)args[1]), *((Vector2_t2243707579 *)args[2]), *((Vector2_t2243707579 *)args[3]), *((Vector3_t2243707580 *)args[4]), *((Vector4_t2243707581 *)args[5]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Vector3_t2243707580_Color32_t874517518_Vector2_t2243707579 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Vector3_t2243707580  p1, Color32_t874517518  p2, Vector2_t2243707579  p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((Vector3_t2243707580 *)args[0]), *((Color32_t874517518 *)args[1]), *((Vector2_t2243707579 *)args[2]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_UIVertex_t1204258818 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, UIVertex_t1204258818  p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((UIVertex_t1204258818 *)args[0]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Color32_t874517518_Int32_t2071877448_Int32_t2071877448_Single_t2076509932_Single_t2076509932 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, Color32_t874517518  p2, int32_t p3, int32_t p4, float p5, float p6, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((Color32_t874517518 *)args[1]), *((int32_t*)args[2]), *((int32_t*)args[3]), *((float*)args[4]), *((float*)args[5]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_ObjectU26_t597476745 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, Il2CppObject ** p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), (Il2CppObject **)args[1], method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_ObjectU5BU5DU26_t3223402458_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, ObjectU5BU5D_t3614634134** p1, int32_t p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (ObjectU5BU5D_t3614634134**)args[0], *((int32_t*)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_ObjectU5BU5DU26_t3223402458_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, ObjectU5BU5D_t3614634134** p1, int32_t p2, int32_t p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (ObjectU5BU5D_t3614634134**)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_KeyValuePair_2_t38854645 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, KeyValuePair_2_t38854645  p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((KeyValuePair_2_t38854645 *)args[0]), method);
	return NULL;
}

void* RuntimeInvoker_Boolean_t3825574718_KeyValuePair_2_t38854645 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, KeyValuePair_2_t38854645  p1, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((KeyValuePair_2_t38854645 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_KeyValuePair_2_t38854645_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef KeyValuePair_2_t38854645  (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, const MethodInfo* method);
	KeyValuePair_2_t38854645  ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Il2CppObject_ObjectU26_t597476745 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Il2CppObject * p1, Il2CppObject ** p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject **)args[1], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Enumerator_t3601534125 (const MethodInfo* method, void* obj, void** args)
{
	typedef Enumerator_t3601534125  (*Func)(void* obj, const MethodInfo* method);
	Enumerator_t3601534125  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_DictionaryEntry_t3048875398_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef DictionaryEntry_t3048875398  (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, const MethodInfo* method);
	DictionaryEntry_t3048875398  ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_KeyValuePair_2_t38854645 (const MethodInfo* method, void* obj, void** args)
{
	typedef KeyValuePair_2_t38854645  (*Func)(void* obj, const MethodInfo* method);
	KeyValuePair_2_t38854645  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Enumerator_t3968042187 (const MethodInfo* method, void* obj, void** args)
{
	typedef Enumerator_t3968042187  (*Func)(void* obj, const MethodInfo* method);
	Enumerator_t3968042187  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, int32_t p1, int32_t p2, Il2CppObject * p3, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((int32_t*)args[1]), (Il2CppObject *)args[2], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Enumerator_t1593300101 (const MethodInfo* method, void* obj, void** args)
{
	typedef Enumerator_t1593300101  (*Func)(void* obj, const MethodInfo* method);
	Enumerator_t1593300101  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Il2CppObject_ObjectU26_t597476745_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Il2CppObject ** p1, Il2CppObject * p2, Il2CppObject * p3, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Il2CppObject **)args[0], (Il2CppObject *)args[1], (Il2CppObject *)args[2], method);
	return ret;
}

void* RuntimeInvoker_Boolean_t3825574718_ArraySegment_1_t1600562341 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, ArraySegment_1_t1600562341  p1, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((ArraySegment_1_t1600562341 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Enumerator_t132208513 (const MethodInfo* method, void* obj, void** args)
{
	typedef Enumerator_t132208513  (*Func)(void* obj, const MethodInfo* method);
	Enumerator_t132208513  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Int32_t2071877448_Int32_t2071877448_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, int32_t p1, int32_t p2, Il2CppObject * p3, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((int32_t*)args[1]), (Il2CppObject *)args[2], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Enumerator_t3806193287 (const MethodInfo* method, void* obj, void** args)
{
	typedef Enumerator_t3806193287  (*Func)(void* obj, const MethodInfo* method);
	Enumerator_t3806193287  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, int32_t p2, int32_t p3, Il2CppObject * p4, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((int32_t*)args[1]), *((int32_t*)args[2]), (Il2CppObject *)args[3], method);
	return NULL;
}

void* RuntimeInvoker_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, Il2CppObject * p3, Il2CppObject * p4, Il2CppObject * p5, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], (Il2CppObject *)args[2], (Il2CppObject *)args[3], (Il2CppObject *)args[4], method);
	return ret;
}

void* RuntimeInvoker_Boolean_t3825574718_ObjectU26_t597476745_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Il2CppObject ** p1, Il2CppObject * p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (Il2CppObject **)args[0], (Il2CppObject *)args[1], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_ObjectU26_t597476745_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject ** p1, Il2CppObject * p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject **)args[0], (Il2CppObject *)args[1], method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Il2CppObject_Il2CppObject_Single_t2076509932 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Il2CppObject * p1, Il2CppObject * p2, float p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (Il2CppObject *)args[1], *((float*)args[2]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Playable_t3667545548 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Playable_t3667545548  p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((Playable_t3667545548 *)args[0]), method);
	return NULL;
}

void* RuntimeInvoker_Boolean_t3825574718_Int32_t2071877448_ObjectU26_t597476745 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, int32_t p1, Il2CppObject ** p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), (Il2CppObject **)args[1], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_RaycastResult_t21186376_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef RaycastResult_t21186376  (*Func)(void* obj, int32_t p1, const MethodInfo* method);
	RaycastResult_t21186376  ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Enumerator_t3383807694 (const MethodInfo* method, void* obj, void** args)
{
	typedef Enumerator_t3383807694  (*Func)(void* obj, const MethodInfo* method);
	Enumerator_t3383807694  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Enumerator_t3017299632 (const MethodInfo* method, void* obj, void** args)
{
	typedef Enumerator_t3017299632  (*Func)(void* obj, const MethodInfo* method);
	Enumerator_t3017299632  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_KeyValuePair_2_t3749587448 (const MethodInfo* method, void* obj, void** args)
{
	typedef KeyValuePair_2_t3749587448  (*Func)(void* obj, const MethodInfo* method);
	KeyValuePair_2_t3749587448  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_AspectModeU26_t218518220_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, int32_t* p1, int32_t p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (int32_t*)args[0], *((int32_t*)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_SingleU26_t4173844468_Single_t2076509932 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, float* p1, float p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (float*)args[0], *((float*)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_FitModeU26_t1633941322_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, int32_t* p1, int32_t p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (int32_t*)args[0], *((int32_t*)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_FloatTween_t2986189219 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, FloatTween_t2986189219  p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((FloatTween_t2986189219 *)args[0]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_ColorTween_t3438117476 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, ColorTween_t3438117476  p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((ColorTween_t3438117476 *)args[0]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_CornerU26_t4129226442_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t* p1, int32_t p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (int32_t*)args[0], *((int32_t*)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_AxisU26_t4174374750_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t* p1, int32_t p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (int32_t*)args[0], *((int32_t*)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Vector2U26_t3911752445_Vector2_t2243707579 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Vector2_t2243707579 * p1, Vector2_t2243707579  p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Vector2_t2243707579 *)args[0], *((Vector2_t2243707579 *)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_ConstraintU26_t2775779428_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t* p1, int32_t p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (int32_t*)args[0], *((int32_t*)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Int32U26_t455636984_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t* p1, int32_t p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (int32_t*)args[0], *((int32_t*)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_SingleU26_t4173844468_Single_t2076509932 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, float* p1, float p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (float*)args[0], *((float*)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_BooleanU26_t3168250738_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, bool* p1, int8_t p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (bool*)args[0], *((int8_t*)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Boolean_t3825574718_TypeU26_t1535498077_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, int32_t* p1, int32_t p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (int32_t*)args[0], *((int32_t*)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_BooleanU26_t3168250738_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, bool* p1, int8_t p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (bool*)args[0], *((int8_t*)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_FillMethodU26_t21572965_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, int32_t* p1, int32_t p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (int32_t*)args[0], *((int32_t*)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_ContentTypeU26_t1802785839_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, int32_t* p1, int32_t p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (int32_t*)args[0], *((int32_t*)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_LineTypeU26_t3325440292_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, int32_t* p1, int32_t p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (int32_t*)args[0], *((int32_t*)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_InputTypeU26_t4050577942_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, int32_t* p1, int32_t p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (int32_t*)args[0], *((int32_t*)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_TouchScreenKeyboardTypeU26_t2194866306_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, int32_t* p1, int32_t p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (int32_t*)args[0], *((int32_t*)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_CharacterValidationU26_t193398694_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, int32_t* p1, int32_t p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (int32_t*)args[0], *((int32_t*)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_CharU26_t1894467670_Int16_t4041245914 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Il2CppChar* p1, int16_t p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (Il2CppChar*)args[0], *((int16_t*)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_TextAnchorU26_t200487962_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t* p1, int32_t p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (int32_t*)args[0], *((int32_t*)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Boolean_t3825574718_DirectionU26_t2846495799_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, int32_t* p1, int32_t p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (int32_t*)args[0], *((int32_t*)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_NavigationU26_t3929175072_Navigation_t1571958496 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Navigation_t1571958496 * p1, Navigation_t1571958496  p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (Navigation_t1571958496 *)args[0], *((Navigation_t1571958496 *)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_TransitionU26_t3012618447_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, int32_t* p1, int32_t p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (int32_t*)args[0], *((int32_t*)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_ColorBlockU26_t1586591514_ColorBlock_t2652774230 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, ColorBlock_t2652774230 * p1, ColorBlock_t2652774230  p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (ColorBlock_t2652774230 *)args[0], *((ColorBlock_t2652774230 *)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_SpriteStateU26_t1330646292_SpriteState_t1353336012 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, SpriteState_t1353336012 * p1, SpriteState_t1353336012  p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (SpriteState_t1353336012 *)args[0], *((SpriteState_t1353336012 *)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_UIVertex_t1204258818_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef UIVertex_t1204258818  (*Func)(void* obj, int32_t p1, const MethodInfo* method);
	UIVertex_t1204258818  ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_UIVertex_t1204258818 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, UIVertex_t1204258818  p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((UIVertex_t1204258818 *)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Boolean_t3825574718_DirectionU26_t743901654_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, int32_t* p1, int32_t p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (int32_t*)args[0], *((int32_t*)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Vector3_t2243707580_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef Vector3_t2243707580  (*Func)(void* obj, int32_t p1, const MethodInfo* method);
	Vector3_t2243707580  ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Color32_t874517518_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef Color32_t874517518  (*Func)(void* obj, int32_t p1, const MethodInfo* method);
	Color32_t874517518  ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Vector3_t2243707580 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, Vector3_t2243707580  p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((Vector3_t2243707580 *)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Color32_t874517518 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, Color32_t874517518  p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((Color32_t874517518 *)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Vector2_t2243707579 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, Vector2_t2243707579  p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((Vector2_t2243707579 *)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Vector4_t2243707581 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, Vector4_t2243707581  p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((Vector4_t2243707581 *)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Color32_t874517518 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Color32_t874517518  p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((Color32_t874517518 *)args[0]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Vector4_t2243707581 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Vector4_t2243707581  p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((Vector4_t2243707581 *)args[0]), method);
	return NULL;
}

void* RuntimeInvoker_Boolean_t3825574718_TableRange_t2011406615 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, TableRange_t2011406615  p1, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((TableRange_t2011406615 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_ArraySegment_1_t2594217482 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, ArraySegment_1_t2594217482  p1, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((ArraySegment_1_t2594217482 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_DictionaryEntry_t3048875398 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, DictionaryEntry_t3048875398  p1, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((DictionaryEntry_t3048875398 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Link_t865133271 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Link_t865133271  p1, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((Link_t865133271 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_KeyValuePair_2_t3749587448 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, KeyValuePair_2_t3749587448  p1, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((KeyValuePair_2_t3749587448 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_KeyValuePair_2_t1174980068 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, KeyValuePair_2_t1174980068  p1, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((KeyValuePair_2_t1174980068 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_KeyValuePair_2_t3716250094 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, KeyValuePair_2_t3716250094  p1, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((KeyValuePair_2_t3716250094 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Link_t2723257478 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Link_t2723257478  p1, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((Link_t2723257478 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Slot_t2022531261 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Slot_t2022531261  p1, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((Slot_t2022531261 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Slot_t2267560602 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Slot_t2267560602  p1, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((Slot_t2267560602 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_CustomAttributeNamedArgument_t94157543 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, CustomAttributeNamedArgument_t94157543  p1, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((CustomAttributeNamedArgument_t94157543 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_CustomAttributeTypedArgument_t1498197914 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, CustomAttributeTypedArgument_t1498197914  p1, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((CustomAttributeTypedArgument_t1498197914 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_LabelData_t3712112744 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, LabelData_t3712112744  p1, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((LabelData_t3712112744 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_LabelFixup_t4090909514 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, LabelFixup_t4090909514  p1, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((LabelFixup_t4090909514 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_ILTokenInfo_t149559338 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, ILTokenInfo_t149559338  p1, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((ILTokenInfo_t149559338 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_ParameterModifier_t1820634920 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, ParameterModifier_t1820634920  p1, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((ParameterModifier_t1820634920 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_ResourceCacheItem_t333236149 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, ResourceCacheItem_t333236149  p1, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((ResourceCacheItem_t333236149 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_ResourceInfo_t3933049236 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, ResourceInfo_t3933049236  p1, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((ResourceInfo_t3933049236 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Byte_t3683104436 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, uint8_t p1, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((uint8_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_X509ChainStatus_t4278378721 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, X509ChainStatus_t4278378721  p1, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((X509ChainStatus_t4278378721 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Mark_t2724874473 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Mark_t2724874473  p1, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((Mark_t2724874473 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_UriScheme_t1876590943 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, UriScheme_t1876590943  p1, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((UriScheme_t1876590943 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Color32_t874517518 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Color32_t874517518  p1, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((Color32_t874517518 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_ContactPoint_t1376425630 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, ContactPoint_t1376425630  p1, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((ContactPoint_t1376425630 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_ContactPoint2D_t3659330976 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, ContactPoint2D_t3659330976  p1, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((ContactPoint2D_t3659330976 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_RaycastResult_t21186376 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, RaycastResult_t21186376  p1, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((RaycastResult_t21186376 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Keyframe_t1449471340 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Keyframe_t1449471340  p1, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((Keyframe_t1449471340 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_RaycastHit_t87180320 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, RaycastHit_t87180320  p1, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((RaycastHit_t87180320 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_RaycastHit2D_t4063908774 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, RaycastHit2D_t4063908774  p1, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((RaycastHit2D_t4063908774 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_UICharInfo_t3056636800 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, UICharInfo_t3056636800  p1, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((UICharInfo_t3056636800 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_UILineInfo_t3621277874 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, UILineInfo_t3621277874  p1, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((UILineInfo_t3621277874 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_UIVertex_t1204258818 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, UIVertex_t1204258818  p1, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((UIVertex_t1204258818 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Vector4_t2243707581 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Vector4_t2243707581  p1, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((Vector4_t2243707581 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_CustomAttributeNamedArgument_t94157543_CustomAttributeNamedArgument_t94157543_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, CustomAttributeNamedArgument_t94157543  p1, CustomAttributeNamedArgument_t94157543  p2, Il2CppObject * p3, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((CustomAttributeNamedArgument_t94157543 *)args[0]), *((CustomAttributeNamedArgument_t94157543 *)args[1]), (Il2CppObject *)args[2], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_CustomAttributeTypedArgument_t1498197914_CustomAttributeTypedArgument_t1498197914_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, CustomAttributeTypedArgument_t1498197914  p1, CustomAttributeTypedArgument_t1498197914  p2, Il2CppObject * p3, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((CustomAttributeTypedArgument_t1498197914 *)args[0]), *((CustomAttributeTypedArgument_t1498197914 *)args[1]), (Il2CppObject *)args[2], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Color32_t874517518_Color32_t874517518_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Color32_t874517518  p1, Color32_t874517518  p2, Il2CppObject * p3, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((Color32_t874517518 *)args[0]), *((Color32_t874517518 *)args[1]), (Il2CppObject *)args[2], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_RaycastResult_t21186376_RaycastResult_t21186376_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, RaycastResult_t21186376  p1, RaycastResult_t21186376  p2, Il2CppObject * p3, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((RaycastResult_t21186376 *)args[0]), *((RaycastResult_t21186376 *)args[1]), (Il2CppObject *)args[2], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Playable_t3667545548_Playable_t3667545548_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Playable_t3667545548  p1, Playable_t3667545548  p2, Il2CppObject * p3, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((Playable_t3667545548 *)args[0]), *((Playable_t3667545548 *)args[1]), (Il2CppObject *)args[2], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_UICharInfo_t3056636800_UICharInfo_t3056636800_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, UICharInfo_t3056636800  p1, UICharInfo_t3056636800  p2, Il2CppObject * p3, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((UICharInfo_t3056636800 *)args[0]), *((UICharInfo_t3056636800 *)args[1]), (Il2CppObject *)args[2], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_UILineInfo_t3621277874_UILineInfo_t3621277874_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, UILineInfo_t3621277874  p1, UILineInfo_t3621277874  p2, Il2CppObject * p3, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((UILineInfo_t3621277874 *)args[0]), *((UILineInfo_t3621277874 *)args[1]), (Il2CppObject *)args[2], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_UIVertex_t1204258818_UIVertex_t1204258818_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, UIVertex_t1204258818  p1, UIVertex_t1204258818  p2, Il2CppObject * p3, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((UIVertex_t1204258818 *)args[0]), *((UIVertex_t1204258818 *)args[1]), (Il2CppObject *)args[2], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Vector2_t2243707579_Vector2_t2243707579_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Vector2_t2243707579  p1, Vector2_t2243707579  p2, Il2CppObject * p3, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((Vector2_t2243707579 *)args[0]), *((Vector2_t2243707579 *)args[1]), (Il2CppObject *)args[2], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Vector3_t2243707580_Vector3_t2243707580_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Vector3_t2243707580  p1, Vector3_t2243707580  p2, Il2CppObject * p3, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((Vector3_t2243707580 *)args[0]), *((Vector3_t2243707580 *)args[1]), (Il2CppObject *)args[2], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Vector4_t2243707581_Vector4_t2243707581_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Vector4_t2243707581  p1, Vector4_t2243707581  p2, Il2CppObject * p3, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((Vector4_t2243707581 *)args[0]), *((Vector4_t2243707581 *)args[1]), (Il2CppObject *)args[2], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Il2CppObject_CustomAttributeNamedArgument_t94157543 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, CustomAttributeNamedArgument_t94157543  p2, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((CustomAttributeNamedArgument_t94157543 *)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Il2CppObject_CustomAttributeNamedArgument_t94157543_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, CustomAttributeNamedArgument_t94157543  p2, int32_t p3, int32_t p4, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((CustomAttributeNamedArgument_t94157543 *)args[1]), *((int32_t*)args[2]), *((int32_t*)args[3]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Il2CppObject_CustomAttributeTypedArgument_t1498197914 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, CustomAttributeTypedArgument_t1498197914  p2, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((CustomAttributeTypedArgument_t1498197914 *)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Il2CppObject_CustomAttributeTypedArgument_t1498197914_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, CustomAttributeTypedArgument_t1498197914  p2, int32_t p3, int32_t p4, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((CustomAttributeTypedArgument_t1498197914 *)args[1]), *((int32_t*)args[2]), *((int32_t*)args[3]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Il2CppObject_Color32_t874517518_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, Color32_t874517518  p2, int32_t p3, int32_t p4, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((Color32_t874517518 *)args[1]), *((int32_t*)args[2]), *((int32_t*)args[3]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Il2CppObject_RaycastResult_t21186376_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, RaycastResult_t21186376  p2, int32_t p3, int32_t p4, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((RaycastResult_t21186376 *)args[1]), *((int32_t*)args[2]), *((int32_t*)args[3]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Il2CppObject_Playable_t3667545548_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, Playable_t3667545548  p2, int32_t p3, int32_t p4, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((Playable_t3667545548 *)args[1]), *((int32_t*)args[2]), *((int32_t*)args[3]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Il2CppObject_UICharInfo_t3056636800_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, UICharInfo_t3056636800  p2, int32_t p3, int32_t p4, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((UICharInfo_t3056636800 *)args[1]), *((int32_t*)args[2]), *((int32_t*)args[3]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Il2CppObject_UILineInfo_t3621277874_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, UILineInfo_t3621277874  p2, int32_t p3, int32_t p4, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((UILineInfo_t3621277874 *)args[1]), *((int32_t*)args[2]), *((int32_t*)args[3]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Il2CppObject_UIVertex_t1204258818_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, UIVertex_t1204258818  p2, int32_t p3, int32_t p4, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((UIVertex_t1204258818 *)args[1]), *((int32_t*)args[2]), *((int32_t*)args[3]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Il2CppObject_Vector2_t2243707579_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, Vector2_t2243707579  p2, int32_t p3, int32_t p4, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((Vector2_t2243707579 *)args[1]), *((int32_t*)args[2]), *((int32_t*)args[3]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Il2CppObject_Vector3_t2243707580_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, Vector3_t2243707580  p2, int32_t p3, int32_t p4, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((Vector3_t2243707580 *)args[1]), *((int32_t*)args[2]), *((int32_t*)args[3]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Il2CppObject_Vector4_t2243707581_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Il2CppObject * p1, Vector4_t2243707581  p2, int32_t p3, int32_t p4, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((Vector4_t2243707581 *)args[1]), *((int32_t*)args[2]), *((int32_t*)args[3]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_TableRange_t2011406615 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, TableRange_t2011406615  p1, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((TableRange_t2011406615 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_ArraySegment_1_t2594217482 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, ArraySegment_1_t2594217482  p1, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((ArraySegment_1_t2594217482 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_DictionaryEntry_t3048875398 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, DictionaryEntry_t3048875398  p1, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((DictionaryEntry_t3048875398 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Link_t865133271 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Link_t865133271  p1, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((Link_t865133271 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_KeyValuePair_2_t3749587448 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, KeyValuePair_2_t3749587448  p1, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((KeyValuePair_2_t3749587448 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_KeyValuePair_2_t1174980068 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, KeyValuePair_2_t1174980068  p1, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((KeyValuePair_2_t1174980068 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_KeyValuePair_2_t3716250094 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, KeyValuePair_2_t3716250094  p1, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((KeyValuePair_2_t3716250094 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_KeyValuePair_2_t38854645 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, KeyValuePair_2_t38854645  p1, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((KeyValuePair_2_t38854645 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Link_t2723257478 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Link_t2723257478  p1, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((Link_t2723257478 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Slot_t2022531261 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Slot_t2022531261  p1, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((Slot_t2022531261 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Slot_t2267560602 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Slot_t2267560602  p1, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((Slot_t2267560602 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_CustomAttributeNamedArgument_t94157543 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, CustomAttributeNamedArgument_t94157543  p1, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((CustomAttributeNamedArgument_t94157543 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_CustomAttributeTypedArgument_t1498197914 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, CustomAttributeTypedArgument_t1498197914  p1, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((CustomAttributeTypedArgument_t1498197914 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_LabelData_t3712112744 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, LabelData_t3712112744  p1, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((LabelData_t3712112744 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_LabelFixup_t4090909514 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, LabelFixup_t4090909514  p1, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((LabelFixup_t4090909514 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_ILTokenInfo_t149559338 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, ILTokenInfo_t149559338  p1, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((ILTokenInfo_t149559338 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_ParameterModifier_t1820634920 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, ParameterModifier_t1820634920  p1, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((ParameterModifier_t1820634920 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_ResourceCacheItem_t333236149 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, ResourceCacheItem_t333236149  p1, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((ResourceCacheItem_t333236149 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_ResourceInfo_t3933049236 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, ResourceInfo_t3933049236  p1, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((ResourceInfo_t3933049236 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Byte_t3683104436 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, uint8_t p1, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((uint8_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_X509ChainStatus_t4278378721 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, X509ChainStatus_t4278378721  p1, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((X509ChainStatus_t4278378721 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Mark_t2724874473 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Mark_t2724874473  p1, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((Mark_t2724874473 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_UriScheme_t1876590943 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, UriScheme_t1876590943  p1, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((UriScheme_t1876590943 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Color32_t874517518 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Color32_t874517518  p1, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((Color32_t874517518 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_ContactPoint_t1376425630 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, ContactPoint_t1376425630  p1, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((ContactPoint_t1376425630 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_ContactPoint2D_t3659330976 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, ContactPoint2D_t3659330976  p1, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((ContactPoint2D_t3659330976 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_RaycastResult_t21186376 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, RaycastResult_t21186376  p1, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((RaycastResult_t21186376 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Keyframe_t1449471340 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Keyframe_t1449471340  p1, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((Keyframe_t1449471340 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_RaycastHit_t87180320 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, RaycastHit_t87180320  p1, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((RaycastHit_t87180320 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_RaycastHit2D_t4063908774 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, RaycastHit2D_t4063908774  p1, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((RaycastHit2D_t4063908774 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_HitInfo_t1761367055 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, HitInfo_t1761367055  p1, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((HitInfo_t1761367055 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_UICharInfo_t3056636800 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, UICharInfo_t3056636800  p1, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((UICharInfo_t3056636800 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_UILineInfo_t3621277874 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, UILineInfo_t3621277874  p1, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((UILineInfo_t3621277874 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_UIVertex_t1204258818 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, UIVertex_t1204258818  p1, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((UIVertex_t1204258818 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Vector3_t2243707580 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Vector3_t2243707580  p1, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((Vector3_t2243707580 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Vector4_t2243707581 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Vector4_t2243707581  p1, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((Vector4_t2243707581 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Void_t1841601450_TableRange_t2011406615 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, TableRange_t2011406615  p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((TableRange_t2011406615 *)args[0]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_ArraySegment_1_t2594217482 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, ArraySegment_1_t2594217482  p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((ArraySegment_1_t2594217482 *)args[0]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_DictionaryEntry_t3048875398 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, DictionaryEntry_t3048875398  p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((DictionaryEntry_t3048875398 *)args[0]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Link_t865133271 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Link_t865133271  p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((Link_t865133271 *)args[0]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_KeyValuePair_2_t3749587448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, KeyValuePair_2_t3749587448  p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((KeyValuePair_2_t3749587448 *)args[0]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_KeyValuePair_2_t1174980068 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, KeyValuePair_2_t1174980068  p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((KeyValuePair_2_t1174980068 *)args[0]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_KeyValuePair_2_t3716250094 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, KeyValuePair_2_t3716250094  p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((KeyValuePair_2_t3716250094 *)args[0]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Link_t2723257478 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Link_t2723257478  p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((Link_t2723257478 *)args[0]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Slot_t2022531261 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Slot_t2022531261  p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((Slot_t2022531261 *)args[0]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Slot_t2267560602 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Slot_t2267560602  p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((Slot_t2267560602 *)args[0]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Decimal_t724701077 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Decimal_t724701077  p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((Decimal_t724701077 *)args[0]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_CustomAttributeNamedArgument_t94157543 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, CustomAttributeNamedArgument_t94157543  p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((CustomAttributeNamedArgument_t94157543 *)args[0]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_CustomAttributeTypedArgument_t1498197914 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, CustomAttributeTypedArgument_t1498197914  p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((CustomAttributeTypedArgument_t1498197914 *)args[0]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_LabelData_t3712112744 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, LabelData_t3712112744  p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((LabelData_t3712112744 *)args[0]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_LabelFixup_t4090909514 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, LabelFixup_t4090909514  p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((LabelFixup_t4090909514 *)args[0]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_ILTokenInfo_t149559338 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, ILTokenInfo_t149559338  p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((ILTokenInfo_t149559338 *)args[0]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_ParameterModifier_t1820634920 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, ParameterModifier_t1820634920  p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((ParameterModifier_t1820634920 *)args[0]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_ResourceCacheItem_t333236149 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, ResourceCacheItem_t333236149  p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((ResourceCacheItem_t333236149 *)args[0]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_ResourceInfo_t3933049236 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, ResourceInfo_t3933049236  p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((ResourceInfo_t3933049236 *)args[0]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_X509ChainStatus_t4278378721 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, X509ChainStatus_t4278378721  p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((X509ChainStatus_t4278378721 *)args[0]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Mark_t2724874473 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Mark_t2724874473  p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((Mark_t2724874473 *)args[0]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_UriScheme_t1876590943 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, UriScheme_t1876590943  p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((UriScheme_t1876590943 *)args[0]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_ContactPoint_t1376425630 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, ContactPoint_t1376425630  p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((ContactPoint_t1376425630 *)args[0]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_ContactPoint2D_t3659330976 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, ContactPoint2D_t3659330976  p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((ContactPoint2D_t3659330976 *)args[0]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Keyframe_t1449471340 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Keyframe_t1449471340  p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((Keyframe_t1449471340 *)args[0]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_RaycastHit_t87180320 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RaycastHit_t87180320  p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((RaycastHit_t87180320 *)args[0]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_RaycastHit2D_t4063908774 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RaycastHit2D_t4063908774  p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((RaycastHit2D_t4063908774 *)args[0]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_HitInfo_t1761367055 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, HitInfo_t1761367055  p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((HitInfo_t1761367055 *)args[0]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_UICharInfo_t3056636800 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, UICharInfo_t3056636800  p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((UICharInfo_t3056636800 *)args[0]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_UILineInfo_t3621277874 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, UILineInfo_t3621277874  p1, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((UILineInfo_t3621277874 *)args[0]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_TableRange_t2011406615 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, TableRange_t2011406615  p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((TableRange_t2011406615 *)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_ArraySegment_1_t2594217482 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, ArraySegment_1_t2594217482  p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((ArraySegment_1_t2594217482 *)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_DictionaryEntry_t3048875398 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, DictionaryEntry_t3048875398  p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((DictionaryEntry_t3048875398 *)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Link_t865133271 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, Link_t865133271  p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((Link_t865133271 *)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_KeyValuePair_2_t3749587448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, KeyValuePair_2_t3749587448  p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((KeyValuePair_2_t3749587448 *)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_KeyValuePair_2_t1174980068 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, KeyValuePair_2_t1174980068  p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((KeyValuePair_2_t1174980068 *)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_KeyValuePair_2_t3716250094 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, KeyValuePair_2_t3716250094  p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((KeyValuePair_2_t3716250094 *)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_KeyValuePair_2_t38854645 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, KeyValuePair_2_t38854645  p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((KeyValuePair_2_t38854645 *)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Link_t2723257478 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, Link_t2723257478  p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((Link_t2723257478 *)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Slot_t2022531261 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, Slot_t2022531261  p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((Slot_t2022531261 *)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Slot_t2267560602 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, Slot_t2267560602  p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((Slot_t2267560602 *)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_DateTime_t693205669 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, DateTime_t693205669  p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((DateTime_t693205669 *)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Decimal_t724701077 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, Decimal_t724701077  p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((Decimal_t724701077 *)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Double_t4078015681 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, double p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((double*)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_CustomAttributeNamedArgument_t94157543 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, CustomAttributeNamedArgument_t94157543  p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((CustomAttributeNamedArgument_t94157543 *)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_CustomAttributeTypedArgument_t1498197914 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, CustomAttributeTypedArgument_t1498197914  p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((CustomAttributeTypedArgument_t1498197914 *)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_LabelData_t3712112744 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, LabelData_t3712112744  p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((LabelData_t3712112744 *)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_LabelFixup_t4090909514 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, LabelFixup_t4090909514  p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((LabelFixup_t4090909514 *)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_ILTokenInfo_t149559338 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, ILTokenInfo_t149559338  p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((ILTokenInfo_t149559338 *)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_ParameterModifier_t1820634920 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, ParameterModifier_t1820634920  p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((ParameterModifier_t1820634920 *)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_ResourceCacheItem_t333236149 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, ResourceCacheItem_t333236149  p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((ResourceCacheItem_t333236149 *)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_ResourceInfo_t3933049236 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, ResourceInfo_t3933049236  p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((ResourceInfo_t3933049236 *)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Byte_t3683104436 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, uint8_t p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((uint8_t*)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_X509ChainStatus_t4278378721 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, X509ChainStatus_t4278378721  p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((X509ChainStatus_t4278378721 *)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Mark_t2724874473 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, Mark_t2724874473  p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((Mark_t2724874473 *)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_TimeSpan_t3430258949 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, TimeSpan_t3430258949  p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((TimeSpan_t3430258949 *)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_UriScheme_t1876590943 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, UriScheme_t1876590943  p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((UriScheme_t1876590943 *)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_ContactPoint_t1376425630 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, ContactPoint_t1376425630  p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((ContactPoint_t1376425630 *)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_ContactPoint2D_t3659330976 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, ContactPoint2D_t3659330976  p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((ContactPoint2D_t3659330976 *)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_RaycastResult_t21186376 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, RaycastResult_t21186376  p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((RaycastResult_t21186376 *)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Playable_t3667545548 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, Playable_t3667545548  p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((Playable_t3667545548 *)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Keyframe_t1449471340 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, Keyframe_t1449471340  p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((Keyframe_t1449471340 *)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_RaycastHit_t87180320 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, RaycastHit_t87180320  p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((RaycastHit_t87180320 *)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_RaycastHit2D_t4063908774 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, RaycastHit2D_t4063908774  p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((RaycastHit2D_t4063908774 *)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_UICharInfo_t3056636800 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, UICharInfo_t3056636800  p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((UICharInfo_t3056636800 *)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Int32_t2071877448_UILineInfo_t3621277874 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, int32_t p1, UILineInfo_t3621277874  p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, *((int32_t*)args[0]), *((UILineInfo_t3621277874 *)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Int32U5BU5DU26_t1341332175_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Int32U5BU5D_t3030399641** p1, int32_t p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Int32U5BU5D_t3030399641**)args[0], *((int32_t*)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Int32U5BU5DU26_t1341332175_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Int32U5BU5D_t3030399641** p1, int32_t p2, int32_t p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Int32U5BU5D_t3030399641**)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_CustomAttributeNamedArgumentU5BU5DU26_t2117536786_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, CustomAttributeNamedArgumentU5BU5D_t3304067486** p1, int32_t p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (CustomAttributeNamedArgumentU5BU5D_t3304067486**)args[0], *((int32_t*)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_CustomAttributeNamedArgumentU5BU5DU26_t2117536786_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, CustomAttributeNamedArgumentU5BU5D_t3304067486** p1, int32_t p2, int32_t p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (CustomAttributeNamedArgumentU5BU5D_t3304067486**)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_CustomAttributeTypedArgumentU5BU5DU26_t4216645529_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, CustomAttributeTypedArgumentU5BU5D_t1075686591** p1, int32_t p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (CustomAttributeTypedArgumentU5BU5D_t1075686591**)args[0], *((int32_t*)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_CustomAttributeTypedArgumentU5BU5DU26_t4216645529_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, CustomAttributeTypedArgumentU5BU5D_t1075686591** p1, int32_t p2, int32_t p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (CustomAttributeTypedArgumentU5BU5D_t1075686591**)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Color32U5BU5DU26_t1617488829_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Color32U5BU5D_t30278651** p1, int32_t p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Color32U5BU5D_t30278651**)args[0], *((int32_t*)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Color32U5BU5DU26_t1617488829_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Color32U5BU5D_t30278651** p1, int32_t p2, int32_t p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Color32U5BU5D_t30278651**)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_RaycastResultU5BU5DU26_t2399554255_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RaycastResultU5BU5D_t603556505** p1, int32_t p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (RaycastResultU5BU5D_t603556505**)args[0], *((int32_t*)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_RaycastResultU5BU5DU26_t2399554255_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, RaycastResultU5BU5D_t603556505** p1, int32_t p2, int32_t p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (RaycastResultU5BU5D_t603556505**)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_PlayableU5BU5DU26_t2309105347_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, PlayableU5BU5D_t4034110853** p1, int32_t p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (PlayableU5BU5D_t4034110853**)args[0], *((int32_t*)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_PlayableU5BU5DU26_t2309105347_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, PlayableU5BU5D_t4034110853** p1, int32_t p2, int32_t p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (PlayableU5BU5D_t4034110853**)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_UICharInfoU5BU5DU26_t454909735_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, UICharInfoU5BU5D_t2749705857** p1, int32_t p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (UICharInfoU5BU5D_t2749705857**)args[0], *((int32_t*)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_UICharInfoU5BU5DU26_t454909735_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, UICharInfoU5BU5D_t2749705857** p1, int32_t p2, int32_t p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (UICharInfoU5BU5D_t2749705857**)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_UILineInfoU5BU5DU26_t11034961_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, UILineInfoU5BU5D_t3471944775** p1, int32_t p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (UILineInfoU5BU5D_t3471944775**)args[0], *((int32_t*)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_UILineInfoU5BU5DU26_t11034961_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, UILineInfoU5BU5D_t3471944775** p1, int32_t p2, int32_t p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (UILineInfoU5BU5D_t3471944775**)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_UIVertexU5BU5DU26_t2990985569_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, UIVertexU5BU5D_t3048644023** p1, int32_t p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (UIVertexU5BU5D_t3048644023**)args[0], *((int32_t*)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_UIVertexU5BU5DU26_t2990985569_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, UIVertexU5BU5D_t3048644023** p1, int32_t p2, int32_t p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (UIVertexU5BU5D_t3048644023**)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Vector2U5BU5DU26_t1595685398_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Vector2U5BU5D_t686124026** p1, int32_t p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Vector2U5BU5D_t686124026**)args[0], *((int32_t*)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Vector2U5BU5DU26_t1595685398_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Vector2U5BU5D_t686124026** p1, int32_t p2, int32_t p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Vector2U5BU5D_t686124026**)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Vector3U5BU5DU26_t3129387507_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Vector3U5BU5D_t1172311765** p1, int32_t p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Vector3U5BU5D_t1172311765**)args[0], *((int32_t*)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Vector3U5BU5DU26_t3129387507_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Vector3U5BU5D_t1172311765** p1, int32_t p2, int32_t p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Vector3U5BU5D_t1172311765**)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Vector4U5BU5DU26_t368122320_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Vector4U5BU5D_t1658499504** p1, int32_t p2, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Vector4U5BU5D_t1658499504**)args[0], *((int32_t*)args[1]), method);
	return NULL;
}

void* RuntimeInvoker_Void_t1841601450_Vector4U5BU5DU26_t368122320_Int32_t2071877448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef void (*Func)(void* obj, Vector4U5BU5D_t1658499504** p1, int32_t p2, int32_t p3, const MethodInfo* method);
	((Func)method->methodPointer)(obj, (Vector4U5BU5D_t1658499504**)args[0], *((int32_t*)args[1]), *((int32_t*)args[2]), method);
	return NULL;
}

void* RuntimeInvoker_TableRange_t2011406615_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef TableRange_t2011406615  (*Func)(void* obj, int32_t p1, const MethodInfo* method);
	TableRange_t2011406615  ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_ClientCertificateType_t4001384466_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, int32_t p1, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_ArraySegment_1_t2594217482_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef ArraySegment_1_t2594217482  (*Func)(void* obj, int32_t p1, const MethodInfo* method);
	ArraySegment_1_t2594217482  ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_DictionaryEntry_t3048875398_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef DictionaryEntry_t3048875398  (*Func)(void* obj, int32_t p1, const MethodInfo* method);
	DictionaryEntry_t3048875398  ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Link_t865133271_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef Link_t865133271  (*Func)(void* obj, int32_t p1, const MethodInfo* method);
	Link_t865133271  ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_KeyValuePair_2_t3749587448_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef KeyValuePair_2_t3749587448  (*Func)(void* obj, int32_t p1, const MethodInfo* method);
	KeyValuePair_2_t3749587448  ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_KeyValuePair_2_t1174980068_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef KeyValuePair_2_t1174980068  (*Func)(void* obj, int32_t p1, const MethodInfo* method);
	KeyValuePair_2_t1174980068  ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_KeyValuePair_2_t3716250094_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef KeyValuePair_2_t3716250094  (*Func)(void* obj, int32_t p1, const MethodInfo* method);
	KeyValuePair_2_t3716250094  ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_KeyValuePair_2_t38854645_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef KeyValuePair_2_t38854645  (*Func)(void* obj, int32_t p1, const MethodInfo* method);
	KeyValuePair_2_t38854645  ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Link_t2723257478_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef Link_t2723257478  (*Func)(void* obj, int32_t p1, const MethodInfo* method);
	Link_t2723257478  ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Slot_t2022531261_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef Slot_t2022531261  (*Func)(void* obj, int32_t p1, const MethodInfo* method);
	Slot_t2022531261  ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Slot_t2267560602_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef Slot_t2267560602  (*Func)(void* obj, int32_t p1, const MethodInfo* method);
	Slot_t2267560602  ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_CustomAttributeNamedArgument_t94157543_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef CustomAttributeNamedArgument_t94157543  (*Func)(void* obj, int32_t p1, const MethodInfo* method);
	CustomAttributeNamedArgument_t94157543  ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_CustomAttributeTypedArgument_t1498197914_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef CustomAttributeTypedArgument_t1498197914  (*Func)(void* obj, int32_t p1, const MethodInfo* method);
	CustomAttributeTypedArgument_t1498197914  ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_LabelData_t3712112744_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef LabelData_t3712112744  (*Func)(void* obj, int32_t p1, const MethodInfo* method);
	LabelData_t3712112744  ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_LabelFixup_t4090909514_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef LabelFixup_t4090909514  (*Func)(void* obj, int32_t p1, const MethodInfo* method);
	LabelFixup_t4090909514  ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_ILTokenInfo_t149559338_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef ILTokenInfo_t149559338  (*Func)(void* obj, int32_t p1, const MethodInfo* method);
	ILTokenInfo_t149559338  ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_ParameterModifier_t1820634920_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef ParameterModifier_t1820634920  (*Func)(void* obj, int32_t p1, const MethodInfo* method);
	ParameterModifier_t1820634920  ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_ResourceCacheItem_t333236149_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef ResourceCacheItem_t333236149  (*Func)(void* obj, int32_t p1, const MethodInfo* method);
	ResourceCacheItem_t333236149  ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_ResourceInfo_t3933049236_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef ResourceInfo_t3933049236  (*Func)(void* obj, int32_t p1, const MethodInfo* method);
	ResourceInfo_t3933049236  ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_TypeTag_t141209596_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef uint8_t (*Func)(void* obj, int32_t p1, const MethodInfo* method);
	uint8_t ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_X509ChainStatus_t4278378721_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef X509ChainStatus_t4278378721  (*Func)(void* obj, int32_t p1, const MethodInfo* method);
	X509ChainStatus_t4278378721  ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Mark_t2724874473_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef Mark_t2724874473  (*Func)(void* obj, int32_t p1, const MethodInfo* method);
	Mark_t2724874473  ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_TimeSpan_t3430258949_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef TimeSpan_t3430258949  (*Func)(void* obj, int32_t p1, const MethodInfo* method);
	TimeSpan_t3430258949  ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_UriScheme_t1876590943_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef UriScheme_t1876590943  (*Func)(void* obj, int32_t p1, const MethodInfo* method);
	UriScheme_t1876590943  ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_ContactPoint_t1376425630_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef ContactPoint_t1376425630  (*Func)(void* obj, int32_t p1, const MethodInfo* method);
	ContactPoint_t1376425630  ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_ContactPoint2D_t3659330976_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef ContactPoint2D_t3659330976  (*Func)(void* obj, int32_t p1, const MethodInfo* method);
	ContactPoint2D_t3659330976  ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Keyframe_t1449471340_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef Keyframe_t1449471340  (*Func)(void* obj, int32_t p1, const MethodInfo* method);
	Keyframe_t1449471340  ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_RaycastHit_t87180320_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef RaycastHit_t87180320  (*Func)(void* obj, int32_t p1, const MethodInfo* method);
	RaycastHit_t87180320  ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_RaycastHit2D_t4063908774_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef RaycastHit2D_t4063908774  (*Func)(void* obj, int32_t p1, const MethodInfo* method);
	RaycastHit2D_t4063908774  ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_HitInfo_t1761367055_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef HitInfo_t1761367055  (*Func)(void* obj, int32_t p1, const MethodInfo* method);
	HitInfo_t1761367055  ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_ContentType_t1028629049_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, int32_t p1, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_UICharInfo_t3056636800_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef UICharInfo_t3056636800  (*Func)(void* obj, int32_t p1, const MethodInfo* method);
	UICharInfo_t3056636800  ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_UILineInfo_t3621277874_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef UILineInfo_t3621277874  (*Func)(void* obj, int32_t p1, const MethodInfo* method);
	UILineInfo_t3621277874  ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_CustomAttributeNamedArgument_t94157543 (const MethodInfo* method, void* obj, void** args)
{
	typedef CustomAttributeNamedArgument_t94157543  (*Func)(void* obj, const MethodInfo* method);
	CustomAttributeNamedArgument_t94157543  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_CustomAttributeTypedArgument_t1498197914 (const MethodInfo* method, void* obj, void** args)
{
	typedef CustomAttributeTypedArgument_t1498197914  (*Func)(void* obj, const MethodInfo* method);
	CustomAttributeTypedArgument_t1498197914  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_TableRange_t2011406615 (const MethodInfo* method, void* obj, void** args)
{
	typedef TableRange_t2011406615  (*Func)(void* obj, const MethodInfo* method);
	TableRange_t2011406615  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_ClientCertificateType_t4001384466 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_ArraySegment_1_t2594217482 (const MethodInfo* method, void* obj, void** args)
{
	typedef ArraySegment_1_t2594217482  (*Func)(void* obj, const MethodInfo* method);
	ArraySegment_1_t2594217482  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Link_t865133271 (const MethodInfo* method, void* obj, void** args)
{
	typedef Link_t865133271  (*Func)(void* obj, const MethodInfo* method);
	Link_t865133271  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_KeyValuePair_2_t1174980068 (const MethodInfo* method, void* obj, void** args)
{
	typedef KeyValuePair_2_t1174980068  (*Func)(void* obj, const MethodInfo* method);
	KeyValuePair_2_t1174980068  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_KeyValuePair_2_t3716250094 (const MethodInfo* method, void* obj, void** args)
{
	typedef KeyValuePair_2_t3716250094  (*Func)(void* obj, const MethodInfo* method);
	KeyValuePair_2_t3716250094  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Link_t2723257478 (const MethodInfo* method, void* obj, void** args)
{
	typedef Link_t2723257478  (*Func)(void* obj, const MethodInfo* method);
	Link_t2723257478  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Slot_t2022531261 (const MethodInfo* method, void* obj, void** args)
{
	typedef Slot_t2022531261  (*Func)(void* obj, const MethodInfo* method);
	Slot_t2022531261  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Slot_t2267560602 (const MethodInfo* method, void* obj, void** args)
{
	typedef Slot_t2267560602  (*Func)(void* obj, const MethodInfo* method);
	Slot_t2267560602  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_LabelData_t3712112744 (const MethodInfo* method, void* obj, void** args)
{
	typedef LabelData_t3712112744  (*Func)(void* obj, const MethodInfo* method);
	LabelData_t3712112744  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_LabelFixup_t4090909514 (const MethodInfo* method, void* obj, void** args)
{
	typedef LabelFixup_t4090909514  (*Func)(void* obj, const MethodInfo* method);
	LabelFixup_t4090909514  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_ILTokenInfo_t149559338 (const MethodInfo* method, void* obj, void** args)
{
	typedef ILTokenInfo_t149559338  (*Func)(void* obj, const MethodInfo* method);
	ILTokenInfo_t149559338  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_ParameterModifier_t1820634920 (const MethodInfo* method, void* obj, void** args)
{
	typedef ParameterModifier_t1820634920  (*Func)(void* obj, const MethodInfo* method);
	ParameterModifier_t1820634920  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_ResourceCacheItem_t333236149 (const MethodInfo* method, void* obj, void** args)
{
	typedef ResourceCacheItem_t333236149  (*Func)(void* obj, const MethodInfo* method);
	ResourceCacheItem_t333236149  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_ResourceInfo_t3933049236 (const MethodInfo* method, void* obj, void** args)
{
	typedef ResourceInfo_t3933049236  (*Func)(void* obj, const MethodInfo* method);
	ResourceInfo_t3933049236  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_TypeTag_t141209596 (const MethodInfo* method, void* obj, void** args)
{
	typedef uint8_t (*Func)(void* obj, const MethodInfo* method);
	uint8_t ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_X509ChainStatus_t4278378721 (const MethodInfo* method, void* obj, void** args)
{
	typedef X509ChainStatus_t4278378721  (*Func)(void* obj, const MethodInfo* method);
	X509ChainStatus_t4278378721  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Mark_t2724874473 (const MethodInfo* method, void* obj, void** args)
{
	typedef Mark_t2724874473  (*Func)(void* obj, const MethodInfo* method);
	Mark_t2724874473  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_UriScheme_t1876590943 (const MethodInfo* method, void* obj, void** args)
{
	typedef UriScheme_t1876590943  (*Func)(void* obj, const MethodInfo* method);
	UriScheme_t1876590943  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Color32_t874517518 (const MethodInfo* method, void* obj, void** args)
{
	typedef Color32_t874517518  (*Func)(void* obj, const MethodInfo* method);
	Color32_t874517518  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_ContactPoint_t1376425630 (const MethodInfo* method, void* obj, void** args)
{
	typedef ContactPoint_t1376425630  (*Func)(void* obj, const MethodInfo* method);
	ContactPoint_t1376425630  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_ContactPoint2D_t3659330976 (const MethodInfo* method, void* obj, void** args)
{
	typedef ContactPoint2D_t3659330976  (*Func)(void* obj, const MethodInfo* method);
	ContactPoint2D_t3659330976  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Keyframe_t1449471340 (const MethodInfo* method, void* obj, void** args)
{
	typedef Keyframe_t1449471340  (*Func)(void* obj, const MethodInfo* method);
	Keyframe_t1449471340  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_RaycastHit_t87180320 (const MethodInfo* method, void* obj, void** args)
{
	typedef RaycastHit_t87180320  (*Func)(void* obj, const MethodInfo* method);
	RaycastHit_t87180320  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_RaycastHit2D_t4063908774 (const MethodInfo* method, void* obj, void** args)
{
	typedef RaycastHit2D_t4063908774  (*Func)(void* obj, const MethodInfo* method);
	RaycastHit2D_t4063908774  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_HitInfo_t1761367055 (const MethodInfo* method, void* obj, void** args)
{
	typedef HitInfo_t1761367055  (*Func)(void* obj, const MethodInfo* method);
	HitInfo_t1761367055  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_UICharInfo_t3056636800 (const MethodInfo* method, void* obj, void** args)
{
	typedef UICharInfo_t3056636800  (*Func)(void* obj, const MethodInfo* method);
	UICharInfo_t3056636800  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_UILineInfo_t3621277874 (const MethodInfo* method, void* obj, void** args)
{
	typedef UILineInfo_t3621277874  (*Func)(void* obj, const MethodInfo* method);
	UILineInfo_t3621277874  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_UIVertex_t1204258818 (const MethodInfo* method, void* obj, void** args)
{
	typedef UIVertex_t1204258818  (*Func)(void* obj, const MethodInfo* method);
	UIVertex_t1204258818  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_DateTimeOffset_t1362988906_DateTimeOffset_t1362988906 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, DateTimeOffset_t1362988906  p1, DateTimeOffset_t1362988906  p2, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((DateTimeOffset_t1362988906 *)args[0]), *((DateTimeOffset_t1362988906 *)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Guid_t2533601593_Guid_t2533601593 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Guid_t2533601593  p1, Guid_t2533601593  p2, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((Guid_t2533601593 *)args[0]), *((Guid_t2533601593 *)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_CustomAttributeNamedArgument_t94157543_CustomAttributeNamedArgument_t94157543 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, CustomAttributeNamedArgument_t94157543  p1, CustomAttributeNamedArgument_t94157543  p2, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((CustomAttributeNamedArgument_t94157543 *)args[0]), *((CustomAttributeNamedArgument_t94157543 *)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_CustomAttributeTypedArgument_t1498197914_CustomAttributeTypedArgument_t1498197914 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, CustomAttributeTypedArgument_t1498197914  p1, CustomAttributeTypedArgument_t1498197914  p2, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((CustomAttributeTypedArgument_t1498197914 *)args[0]), *((CustomAttributeTypedArgument_t1498197914 *)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Color32_t874517518_Color32_t874517518 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Color32_t874517518  p1, Color32_t874517518  p2, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((Color32_t874517518 *)args[0]), *((Color32_t874517518 *)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Playable_t3667545548_Playable_t3667545548 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Playable_t3667545548  p1, Playable_t3667545548  p2, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((Playable_t3667545548 *)args[0]), *((Playable_t3667545548 *)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_UICharInfo_t3056636800_UICharInfo_t3056636800 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, UICharInfo_t3056636800  p1, UICharInfo_t3056636800  p2, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((UICharInfo_t3056636800 *)args[0]), *((UICharInfo_t3056636800 *)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_UILineInfo_t3621277874_UILineInfo_t3621277874 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, UILineInfo_t3621277874  p1, UILineInfo_t3621277874  p2, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((UILineInfo_t3621277874 *)args[0]), *((UILineInfo_t3621277874 *)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_UIVertex_t1204258818_UIVertex_t1204258818 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, UIVertex_t1204258818  p1, UIVertex_t1204258818  p2, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((UIVertex_t1204258818 *)args[0]), *((UIVertex_t1204258818 *)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Vector2_t2243707579_Vector2_t2243707579 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Vector2_t2243707579  p1, Vector2_t2243707579  p2, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((Vector2_t2243707579 *)args[0]), *((Vector2_t2243707579 *)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Vector3_t2243707580_Vector3_t2243707580 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Vector3_t2243707580  p1, Vector3_t2243707580  p2, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((Vector3_t2243707580 *)args[0]), *((Vector3_t2243707580 *)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Vector4_t2243707581_Vector4_t2243707581 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Vector4_t2243707581  p1, Vector4_t2243707581  p2, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((Vector4_t2243707581 *)args[0]), *((Vector4_t2243707581 *)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_DictionaryEntry_t3048875398_Int32_t2071877448_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef DictionaryEntry_t3048875398  (*Func)(void* obj, int32_t p1, Il2CppObject * p2, const MethodInfo* method);
	DictionaryEntry_t3048875398  ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), (Il2CppObject *)args[1], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_DictionaryEntry_t3048875398_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef DictionaryEntry_t3048875398  (*Func)(void* obj, Il2CppObject * p1, const MethodInfo* method);
	DictionaryEntry_t3048875398  ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_KeyValuePair_2_t3749587448_Int32_t2071877448_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef KeyValuePair_2_t3749587448  (*Func)(void* obj, int32_t p1, Il2CppObject * p2, const MethodInfo* method);
	KeyValuePair_2_t3749587448  ret = ((Func)method->methodPointer)(obj, *((int32_t*)args[0]), (Il2CppObject *)args[1], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_KeyValuePair_2_t3749587448_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef KeyValuePair_2_t3749587448  (*Func)(void* obj, Il2CppObject * p1, const MethodInfo* method);
	KeyValuePair_2_t3749587448  ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_DictionaryEntry_t3048875398_Il2CppObject_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef DictionaryEntry_t3048875398  (*Func)(void* obj, Il2CppObject * p1, int8_t p2, const MethodInfo* method);
	DictionaryEntry_t3048875398  ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int8_t*)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_KeyValuePair_2_t1174980068_Il2CppObject_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef KeyValuePair_2_t1174980068  (*Func)(void* obj, Il2CppObject * p1, int8_t p2, const MethodInfo* method);
	KeyValuePair_2_t1174980068  ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int8_t*)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_KeyValuePair_2_t1174980068_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef KeyValuePair_2_t1174980068  (*Func)(void* obj, Il2CppObject * p1, const MethodInfo* method);
	KeyValuePair_2_t1174980068  ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_DictionaryEntry_t3048875398_Il2CppObject_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef DictionaryEntry_t3048875398  (*Func)(void* obj, Il2CppObject * p1, int32_t p2, const MethodInfo* method);
	DictionaryEntry_t3048875398  ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_KeyValuePair_2_t3716250094_Il2CppObject_Int32_t2071877448 (const MethodInfo* method, void* obj, void** args)
{
	typedef KeyValuePair_2_t3716250094  (*Func)(void* obj, Il2CppObject * p1, int32_t p2, const MethodInfo* method);
	KeyValuePair_2_t3716250094  ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], *((int32_t*)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_KeyValuePair_2_t3716250094_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef KeyValuePair_2_t3716250094  (*Func)(void* obj, Il2CppObject * p1, const MethodInfo* method);
	KeyValuePair_2_t3716250094  ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_KeyValuePair_2_t38854645_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef KeyValuePair_2_t38854645  (*Func)(void* obj, Il2CppObject * p1, const MethodInfo* method);
	KeyValuePair_2_t38854645  ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Enumerator_t809200314 (const MethodInfo* method, void* obj, void** args)
{
	typedef Enumerator_t809200314  (*Func)(void* obj, const MethodInfo* method);
	Enumerator_t809200314  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Enumerator_t3350470340 (const MethodInfo* method, void* obj, void** args)
{
	typedef Enumerator_t3350470340  (*Func)(void* obj, const MethodInfo* method);
	Enumerator_t3350470340  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Il2CppObject_BooleanU26_t3168250738 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Il2CppObject * p1, bool* p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], (bool*)args[1], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Enumerator_t442692252 (const MethodInfo* method, void* obj, void** args)
{
	typedef Enumerator_t442692252  (*Func)(void* obj, const MethodInfo* method);
	Enumerator_t442692252  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Enumerator_t2983962278 (const MethodInfo* method, void* obj, void** args)
{
	typedef Enumerator_t2983962278  (*Func)(void* obj, const MethodInfo* method);
	Enumerator_t2983962278  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_SByte_t454417549_SByte_t454417549 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, int8_t p1, int8_t p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((int8_t*)args[0]), *((int8_t*)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Int16_t4041245914_Int16_t4041245914 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, int16_t p1, int16_t p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((int16_t*)args[0]), *((int16_t*)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_DateTimeOffset_t1362988906_DateTimeOffset_t1362988906 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, DateTimeOffset_t1362988906  p1, DateTimeOffset_t1362988906  p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((DateTimeOffset_t1362988906 *)args[0]), *((DateTimeOffset_t1362988906 *)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Guid_t2533601593_Guid_t2533601593 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Guid_t2533601593  p1, Guid_t2533601593  p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((Guid_t2533601593 *)args[0]), *((Guid_t2533601593 *)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_CustomAttributeNamedArgument_t94157543_CustomAttributeNamedArgument_t94157543 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, CustomAttributeNamedArgument_t94157543  p1, CustomAttributeNamedArgument_t94157543  p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((CustomAttributeNamedArgument_t94157543 *)args[0]), *((CustomAttributeNamedArgument_t94157543 *)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_CustomAttributeTypedArgument_t1498197914_CustomAttributeTypedArgument_t1498197914 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, CustomAttributeTypedArgument_t1498197914  p1, CustomAttributeTypedArgument_t1498197914  p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((CustomAttributeTypedArgument_t1498197914 *)args[0]), *((CustomAttributeTypedArgument_t1498197914 *)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Color32_t874517518_Color32_t874517518 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Color32_t874517518  p1, Color32_t874517518  p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((Color32_t874517518 *)args[0]), *((Color32_t874517518 *)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_RaycastResult_t21186376_RaycastResult_t21186376 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, RaycastResult_t21186376  p1, RaycastResult_t21186376  p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((RaycastResult_t21186376 *)args[0]), *((RaycastResult_t21186376 *)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Playable_t3667545548_Playable_t3667545548 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Playable_t3667545548  p1, Playable_t3667545548  p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((Playable_t3667545548 *)args[0]), *((Playable_t3667545548 *)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_ColorBlock_t2652774230 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, ColorBlock_t2652774230  p1, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((ColorBlock_t2652774230 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_Navigation_t1571958496 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, Navigation_t1571958496  p1, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((Navigation_t1571958496 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_Navigation_t1571958496_Navigation_t1571958496 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Navigation_t1571958496  p1, Navigation_t1571958496  p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((Navigation_t1571958496 *)args[0]), *((Navigation_t1571958496 *)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Int32_t2071877448_SpriteState_t1353336012 (const MethodInfo* method, void* obj, void** args)
{
	typedef int32_t (*Func)(void* obj, SpriteState_t1353336012  p1, const MethodInfo* method);
	int32_t ret = ((Func)method->methodPointer)(obj, *((SpriteState_t1353336012 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_SpriteState_t1353336012_SpriteState_t1353336012 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, SpriteState_t1353336012  p1, SpriteState_t1353336012  p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((SpriteState_t1353336012 *)args[0]), *((SpriteState_t1353336012 *)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_UICharInfo_t3056636800_UICharInfo_t3056636800 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, UICharInfo_t3056636800  p1, UICharInfo_t3056636800  p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((UICharInfo_t3056636800 *)args[0]), *((UICharInfo_t3056636800 *)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_UILineInfo_t3621277874_UILineInfo_t3621277874 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, UILineInfo_t3621277874  p1, UILineInfo_t3621277874  p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((UILineInfo_t3621277874 *)args[0]), *((UILineInfo_t3621277874 *)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Boolean_t3825574718_UIVertex_t1204258818_UIVertex_t1204258818 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, UIVertex_t1204258818  p1, UIVertex_t1204258818  p2, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((UIVertex_t1204258818 *)args[0]), *((UIVertex_t1204258818 *)args[1]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Enumerator_t975728254 (const MethodInfo* method, void* obj, void** args)
{
	typedef Enumerator_t975728254  (*Func)(void* obj, const MethodInfo* method);
	Enumerator_t975728254  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_CustomAttributeNamedArgument_t94157543_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef CustomAttributeNamedArgument_t94157543  (*Func)(void* obj, Il2CppObject * p1, const MethodInfo* method);
	CustomAttributeNamedArgument_t94157543  ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Enumerator_t3292975645 (const MethodInfo* method, void* obj, void** args)
{
	typedef Enumerator_t3292975645  (*Func)(void* obj, const MethodInfo* method);
	Enumerator_t3292975645  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_CustomAttributeTypedArgument_t1498197914_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef CustomAttributeTypedArgument_t1498197914  (*Func)(void* obj, Il2CppObject * p1, const MethodInfo* method);
	CustomAttributeTypedArgument_t1498197914  ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Enumerator_t402048720 (const MethodInfo* method, void* obj, void** args)
{
	typedef Enumerator_t402048720  (*Func)(void* obj, const MethodInfo* method);
	Enumerator_t402048720  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Color32_t874517518_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Color32_t874517518  (*Func)(void* obj, Il2CppObject * p1, const MethodInfo* method);
	Color32_t874517518  ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Enumerator_t4073335620 (const MethodInfo* method, void* obj, void** args)
{
	typedef Enumerator_t4073335620  (*Func)(void* obj, const MethodInfo* method);
	Enumerator_t4073335620  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Enumerator_t3220004478 (const MethodInfo* method, void* obj, void** args)
{
	typedef Enumerator_t3220004478  (*Func)(void* obj, const MethodInfo* method);
	Enumerator_t3220004478  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Enumerator_t2571396354 (const MethodInfo* method, void* obj, void** args)
{
	typedef Enumerator_t2571396354  (*Func)(void* obj, const MethodInfo* method);
	Enumerator_t2571396354  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_UICharInfo_t3056636800_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef UICharInfo_t3056636800  (*Func)(void* obj, Il2CppObject * p1, const MethodInfo* method);
	UICharInfo_t3056636800  ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Enumerator_t1960487606 (const MethodInfo* method, void* obj, void** args)
{
	typedef Enumerator_t1960487606  (*Func)(void* obj, const MethodInfo* method);
	Enumerator_t1960487606  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_UILineInfo_t3621277874_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef UILineInfo_t3621277874  (*Func)(void* obj, Il2CppObject * p1, const MethodInfo* method);
	UILineInfo_t3621277874  ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Enumerator_t2525128680 (const MethodInfo* method, void* obj, void** args)
{
	typedef Enumerator_t2525128680  (*Func)(void* obj, const MethodInfo* method);
	Enumerator_t2525128680  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_UIVertex_t1204258818_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef UIVertex_t1204258818  (*Func)(void* obj, Il2CppObject * p1, const MethodInfo* method);
	UIVertex_t1204258818  ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Enumerator_t108109624 (const MethodInfo* method, void* obj, void** args)
{
	typedef Enumerator_t108109624  (*Func)(void* obj, const MethodInfo* method);
	Enumerator_t108109624  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Enumerator_t1147558385 (const MethodInfo* method, void* obj, void** args)
{
	typedef Enumerator_t1147558385  (*Func)(void* obj, const MethodInfo* method);
	Enumerator_t1147558385  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Vector3_t2243707580_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Vector3_t2243707580  (*Func)(void* obj, Il2CppObject * p1, const MethodInfo* method);
	Vector3_t2243707580  ret = ((Func)method->methodPointer)(obj, (Il2CppObject *)args[0], method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Enumerator_t1147558386 (const MethodInfo* method, void* obj, void** args)
{
	typedef Enumerator_t1147558386  (*Func)(void* obj, const MethodInfo* method);
	Enumerator_t1147558386  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Enumerator_t1147558387 (const MethodInfo* method, void* obj, void** args)
{
	typedef Enumerator_t1147558387  (*Func)(void* obj, const MethodInfo* method);
	Enumerator_t1147558387  ret = ((Func)method->methodPointer)(obj, method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Il2CppObject_CustomAttributeNamedArgument_t94157543_CustomAttributeNamedArgument_t94157543_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, CustomAttributeNamedArgument_t94157543  p1, CustomAttributeNamedArgument_t94157543  p2, Il2CppObject * p3, Il2CppObject * p4, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((CustomAttributeNamedArgument_t94157543 *)args[0]), *((CustomAttributeNamedArgument_t94157543 *)args[1]), (Il2CppObject *)args[2], (Il2CppObject *)args[3], method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_CustomAttributeTypedArgument_t1498197914_CustomAttributeTypedArgument_t1498197914_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, CustomAttributeTypedArgument_t1498197914  p1, CustomAttributeTypedArgument_t1498197914  p2, Il2CppObject * p3, Il2CppObject * p4, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((CustomAttributeTypedArgument_t1498197914 *)args[0]), *((CustomAttributeTypedArgument_t1498197914 *)args[1]), (Il2CppObject *)args[2], (Il2CppObject *)args[3], method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Color32_t874517518_Color32_t874517518_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Color32_t874517518  p1, Color32_t874517518  p2, Il2CppObject * p3, Il2CppObject * p4, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((Color32_t874517518 *)args[0]), *((Color32_t874517518 *)args[1]), (Il2CppObject *)args[2], (Il2CppObject *)args[3], method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_RaycastResult_t21186376_RaycastResult_t21186376_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, RaycastResult_t21186376  p1, RaycastResult_t21186376  p2, Il2CppObject * p3, Il2CppObject * p4, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((RaycastResult_t21186376 *)args[0]), *((RaycastResult_t21186376 *)args[1]), (Il2CppObject *)args[2], (Il2CppObject *)args[3], method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Playable_t3667545548_Playable_t3667545548_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Playable_t3667545548  p1, Playable_t3667545548  p2, Il2CppObject * p3, Il2CppObject * p4, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((Playable_t3667545548 *)args[0]), *((Playable_t3667545548 *)args[1]), (Il2CppObject *)args[2], (Il2CppObject *)args[3], method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_RaycastHit_t87180320_RaycastHit_t87180320_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, RaycastHit_t87180320  p1, RaycastHit_t87180320  p2, Il2CppObject * p3, Il2CppObject * p4, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((RaycastHit_t87180320 *)args[0]), *((RaycastHit_t87180320 *)args[1]), (Il2CppObject *)args[2], (Il2CppObject *)args[3], method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_UICharInfo_t3056636800_UICharInfo_t3056636800_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, UICharInfo_t3056636800  p1, UICharInfo_t3056636800  p2, Il2CppObject * p3, Il2CppObject * p4, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((UICharInfo_t3056636800 *)args[0]), *((UICharInfo_t3056636800 *)args[1]), (Il2CppObject *)args[2], (Il2CppObject *)args[3], method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_UILineInfo_t3621277874_UILineInfo_t3621277874_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, UILineInfo_t3621277874  p1, UILineInfo_t3621277874  p2, Il2CppObject * p3, Il2CppObject * p4, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((UILineInfo_t3621277874 *)args[0]), *((UILineInfo_t3621277874 *)args[1]), (Il2CppObject *)args[2], (Il2CppObject *)args[3], method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_UIVertex_t1204258818_UIVertex_t1204258818_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, UIVertex_t1204258818  p1, UIVertex_t1204258818  p2, Il2CppObject * p3, Il2CppObject * p4, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((UIVertex_t1204258818 *)args[0]), *((UIVertex_t1204258818 *)args[1]), (Il2CppObject *)args[2], (Il2CppObject *)args[3], method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Vector2_t2243707579_Vector2_t2243707579_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Vector2_t2243707579  p1, Vector2_t2243707579  p2, Il2CppObject * p3, Il2CppObject * p4, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((Vector2_t2243707579 *)args[0]), *((Vector2_t2243707579 *)args[1]), (Il2CppObject *)args[2], (Il2CppObject *)args[3], method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Vector3_t2243707580_Vector3_t2243707580_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Vector3_t2243707580  p1, Vector3_t2243707580  p2, Il2CppObject * p3, Il2CppObject * p4, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((Vector3_t2243707580 *)args[0]), *((Vector3_t2243707580 *)args[1]), (Il2CppObject *)args[2], (Il2CppObject *)args[3], method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Vector4_t2243707581_Vector4_t2243707581_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Vector4_t2243707581  p1, Vector4_t2243707581  p2, Il2CppObject * p3, Il2CppObject * p4, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((Vector4_t2243707581 *)args[0]), *((Vector4_t2243707581 *)args[1]), (Il2CppObject *)args[2], (Il2CppObject *)args[3], method);
	return ret;
}

void* RuntimeInvoker_Boolean_t3825574718_Nullable_1_t1693325264 (const MethodInfo* method, void* obj, void** args)
{
	typedef bool (*Func)(void* obj, Nullable_1_t1693325264  p1, const MethodInfo* method);
	bool ret = ((Func)method->methodPointer)(obj, *((Nullable_1_t1693325264 *)args[0]), method);
	return Box(il2cpp_codegen_class_from_type (method->return_type), &ret);
}

void* RuntimeInvoker_Il2CppObject_CustomAttributeNamedArgument_t94157543_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, CustomAttributeNamedArgument_t94157543  p1, Il2CppObject * p2, Il2CppObject * p3, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((CustomAttributeNamedArgument_t94157543 *)args[0]), (Il2CppObject *)args[1], (Il2CppObject *)args[2], method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_CustomAttributeTypedArgument_t1498197914_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, CustomAttributeTypedArgument_t1498197914  p1, Il2CppObject * p2, Il2CppObject * p3, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((CustomAttributeTypedArgument_t1498197914 *)args[0]), (Il2CppObject *)args[1], (Il2CppObject *)args[2], method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Color32_t874517518_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Color32_t874517518  p1, Il2CppObject * p2, Il2CppObject * p3, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((Color32_t874517518 *)args[0]), (Il2CppObject *)args[1], (Il2CppObject *)args[2], method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_RaycastResult_t21186376_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, RaycastResult_t21186376  p1, Il2CppObject * p2, Il2CppObject * p3, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((RaycastResult_t21186376 *)args[0]), (Il2CppObject *)args[1], (Il2CppObject *)args[2], method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Playable_t3667545548_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Playable_t3667545548  p1, Il2CppObject * p2, Il2CppObject * p3, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((Playable_t3667545548 *)args[0]), (Il2CppObject *)args[1], (Il2CppObject *)args[2], method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_UICharInfo_t3056636800_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, UICharInfo_t3056636800  p1, Il2CppObject * p2, Il2CppObject * p3, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((UICharInfo_t3056636800 *)args[0]), (Il2CppObject *)args[1], (Il2CppObject *)args[2], method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_UILineInfo_t3621277874_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, UILineInfo_t3621277874  p1, Il2CppObject * p2, Il2CppObject * p3, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((UILineInfo_t3621277874 *)args[0]), (Il2CppObject *)args[1], (Il2CppObject *)args[2], method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_UIVertex_t1204258818_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, UIVertex_t1204258818  p1, Il2CppObject * p2, Il2CppObject * p3, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((UIVertex_t1204258818 *)args[0]), (Il2CppObject *)args[1], (Il2CppObject *)args[2], method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Vector2_t2243707579_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Vector2_t2243707579  p1, Il2CppObject * p2, Il2CppObject * p3, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((Vector2_t2243707579 *)args[0]), (Il2CppObject *)args[1], (Il2CppObject *)args[2], method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Vector3_t2243707580_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Vector3_t2243707580  p1, Il2CppObject * p2, Il2CppObject * p3, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((Vector3_t2243707580 *)args[0]), (Il2CppObject *)args[1], (Il2CppObject *)args[2], method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Vector4_t2243707581_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Vector4_t2243707581  p1, Il2CppObject * p2, Il2CppObject * p3, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((Vector4_t2243707581 *)args[0]), (Il2CppObject *)args[1], (Il2CppObject *)args[2], method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Single_t2076509932_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, float p1, Il2CppObject * p2, Il2CppObject * p3, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((float*)args[0]), (Il2CppObject *)args[1], (Il2CppObject *)args[2], method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Color_t2020392075_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Color_t2020392075  p1, Il2CppObject * p2, Il2CppObject * p3, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((Color_t2020392075 *)args[0]), (Il2CppObject *)args[1], (Il2CppObject *)args[2], method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Scene_t1684909666_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Scene_t1684909666  p1, Il2CppObject * p2, Il2CppObject * p3, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((Scene_t1684909666 *)args[0]), (Il2CppObject *)args[1], (Il2CppObject *)args[2], method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Scene_t1684909666_Int32_t2071877448_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Scene_t1684909666  p1, int32_t p2, Il2CppObject * p3, Il2CppObject * p4, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((Scene_t1684909666 *)args[0]), *((int32_t*)args[1]), (Il2CppObject *)args[2], (Il2CppObject *)args[3], method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_Scene_t1684909666_Scene_t1684909666_Il2CppObject_Il2CppObject (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, Scene_t1684909666  p1, Scene_t1684909666  p2, Il2CppObject * p3, Il2CppObject * p4, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((Scene_t1684909666 *)args[0]), *((Scene_t1684909666 *)args[1]), (Il2CppObject *)args[2], (Il2CppObject *)args[3], method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_ColorTween_t3438117476 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, ColorTween_t3438117476  p1, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((ColorTween_t3438117476 *)args[0]), method);
	return ret;
}

void* RuntimeInvoker_Il2CppObject_FloatTween_t2986189219 (const MethodInfo* method, void* obj, void** args)
{
	typedef Il2CppObject * (*Func)(void* obj, FloatTween_t2986189219  p1, const MethodInfo* method);
	Il2CppObject * ret = ((Func)method->methodPointer)(obj, *((FloatTween_t2986189219 *)args[0]), method);
	return ret;
}

extern const InvokerMethod g_Il2CppInvokerPointers[1600] = 
{
	RuntimeInvoker_Void_t1841601450,
	RuntimeInvoker_Boolean_t3825574718_Il2CppObject,
	RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Int32_t2071877448,
	RuntimeInvoker_Il2CppObject,
	RuntimeInvoker_Int32_t2071877448_Il2CppObject,
	RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Il2CppObject_ObjectU5BU5DU26_t3223402458,
	RuntimeInvoker_Int32_t2071877448_Il2CppObject_ObjectU5BU5DU26_t3223402458,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Il2CppObject_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Il2CppObject_Il2CppObject_Il2CppObject_SByte_t454417549,
	RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Il2CppObject_SByte_t454417549,
	RuntimeInvoker_Byte_t3683104436_Il2CppObject,
	RuntimeInvoker_Char_t3454481338_Il2CppObject,
	RuntimeInvoker_DateTime_t693205669_Il2CppObject,
	RuntimeInvoker_Decimal_t724701077_Il2CppObject,
	RuntimeInvoker_Double_t4078015681_Il2CppObject,
	RuntimeInvoker_Int16_t4041245914_Il2CppObject,
	RuntimeInvoker_Int64_t909078037_Il2CppObject,
	RuntimeInvoker_SByte_t454417549_Il2CppObject,
	RuntimeInvoker_Single_t2076509932_Il2CppObject,
	RuntimeInvoker_UInt16_t986882611_Il2CppObject,
	RuntimeInvoker_UInt32_t2149682021_Il2CppObject,
	RuntimeInvoker_UInt64_t2909196914_Il2CppObject,
	RuntimeInvoker_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Boolean_t3825574718_Int32_t2071877448,
	RuntimeInvoker_Boolean_t3825574718_SByte_t454417549_Il2CppObject_Int32_t2071877448_ExceptionU26_t1467204777,
	RuntimeInvoker_Boolean_t3825574718_Il2CppObject_SByte_t454417549_Int32U26_t455636984_ExceptionU26_t1467204777,
	RuntimeInvoker_Int32_t2071877448_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Boolean_t3825574718_Int32_t2071877448_SByte_t454417549_ExceptionU26_t1467204777,
	RuntimeInvoker_Boolean_t3825574718_Int32U26_t455636984_Il2CppObject_SByte_t454417549_SByte_t454417549_ExceptionU26_t1467204777,
	RuntimeInvoker_Void_t1841601450_Int32U26_t455636984_Il2CppObject_Il2CppObject_BooleanU26_t3168250738_BooleanU26_t3168250738,
	RuntimeInvoker_Void_t1841601450_Int32U26_t455636984_Il2CppObject_Il2CppObject_BooleanU26_t3168250738,
	RuntimeInvoker_Boolean_t3825574718_Int32U26_t455636984_Il2CppObject_Int32U26_t455636984_SByte_t454417549_ExceptionU26_t1467204777,
	RuntimeInvoker_Boolean_t3825574718_Int32U26_t455636984_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Boolean_t3825574718_Int16_t4041245914_SByte_t454417549,
	RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Int32_t2071877448_Il2CppObject_SByte_t454417549_Int32U26_t455636984_ExceptionU26_t1467204777,
	RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Il2CppObject,
	RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Int32U26_t455636984,
	RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Int32_t2071877448_Il2CppObject_Int32U26_t455636984,
	RuntimeInvoker_Il2CppObject_Il2CppObject,
	RuntimeInvoker_TypeCode_t2536926201,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448,
	RuntimeInvoker_Boolean_t3825574718,
	RuntimeInvoker_Void_t1841601450_SByte_t454417549,
	RuntimeInvoker_Int32_t2071877448_Int64_t909078037,
	RuntimeInvoker_Boolean_t3825574718_Int64_t909078037,
	RuntimeInvoker_Boolean_t3825574718_Il2CppObject_SByte_t454417549_Int64U26_t763825331_ExceptionU26_t1467204777,
	RuntimeInvoker_Int64_t909078037_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Int32_t2071877448_Il2CppObject_SByte_t454417549_Int64U26_t763825331_ExceptionU26_t1467204777,
	RuntimeInvoker_Int64_t909078037_Il2CppObject_Int32_t2071877448_Il2CppObject,
	RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Int64U26_t763825331,
	RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Int32_t2071877448_Il2CppObject_Int64U26_t763825331,
	RuntimeInvoker_Boolean_t3825574718_Il2CppObject_SByte_t454417549_UInt32U26_t2197289955_ExceptionU26_t1467204777,
	RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Int32_t2071877448_Il2CppObject_SByte_t454417549_UInt32U26_t2197289955_ExceptionU26_t1467204777,
	RuntimeInvoker_UInt32_t2149682021_Il2CppObject_Int32_t2071877448_Il2CppObject,
	RuntimeInvoker_UInt32_t2149682021_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Boolean_t3825574718_Il2CppObject_UInt32U26_t2197289955,
	RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Int32_t2071877448_Il2CppObject_UInt32U26_t2197289955,
	RuntimeInvoker_UInt64_t2909196914_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Int32_t2071877448_Il2CppObject_SByte_t454417549_UInt64U26_t1611942494_ExceptionU26_t1467204777,
	RuntimeInvoker_UInt64_t2909196914_Il2CppObject_Int32_t2071877448_Il2CppObject,
	RuntimeInvoker_Boolean_t3825574718_Il2CppObject_UInt64U26_t1611942494,
	RuntimeInvoker_Int32_t2071877448_SByte_t454417549,
	RuntimeInvoker_Boolean_t3825574718_SByte_t454417549,
	RuntimeInvoker_Byte_t3683104436_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Byte_t3683104436_Il2CppObject_Int32_t2071877448_Il2CppObject,
	RuntimeInvoker_Boolean_t3825574718_Il2CppObject_ByteU26_t1147306860,
	RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Int32_t2071877448_Il2CppObject_ByteU26_t1147306860,
	RuntimeInvoker_Boolean_t3825574718_Il2CppObject_SByte_t454417549_SByteU26_t3920581883_ExceptionU26_t1467204777,
	RuntimeInvoker_SByte_t454417549_Il2CppObject_Il2CppObject,
	RuntimeInvoker_SByte_t454417549_Il2CppObject_Int32_t2071877448_Il2CppObject,
	RuntimeInvoker_Boolean_t3825574718_Il2CppObject_SByteU26_t3920581883,
	RuntimeInvoker_Int32_t2071877448_Int16_t4041245914,
	RuntimeInvoker_Boolean_t3825574718_Int16_t4041245914,
	RuntimeInvoker_Boolean_t3825574718_Il2CppObject_SByte_t454417549_Int16U26_t3189330998_ExceptionU26_t1467204777,
	RuntimeInvoker_Int16_t4041245914_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Int16_t4041245914_Il2CppObject_Int32_t2071877448_Il2CppObject,
	RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Int16U26_t3189330998,
	RuntimeInvoker_UInt16_t986882611_Il2CppObject_Il2CppObject,
	RuntimeInvoker_UInt16_t986882611_Il2CppObject_Int32_t2071877448_Il2CppObject,
	RuntimeInvoker_Boolean_t3825574718_Il2CppObject_UInt16U26_t3314555461,
	RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Int32_t2071877448_Il2CppObject_UInt16U26_t3314555461,
	RuntimeInvoker_Void_t1841601450_ByteU2AU26_t3544685828_ByteU2AU26_t3544685828_DoubleU2AU26_t3349029_UInt16U2AU26_t1636670495_UInt16U2AU26_t1636670495_UInt16U2AU26_t1636670495_UInt16U2AU26_t1636670495,
	RuntimeInvoker_UnicodeCategory_t682236799_Int16_t4041245914,
	RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Int32_t2071877448,
	RuntimeInvoker_Char_t3454481338_Int16_t4041245914,
	RuntimeInvoker_Char_t3454481338_Int16_t4041245914_Il2CppObject,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_Il2CppObject,
	RuntimeInvoker_Void_t1841601450_Int16_t4041245914_Int32_t2071877448,
	RuntimeInvoker_Char_t3454481338_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Il2CppObject_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Il2CppObject_Il2CppObject_Int32_t2071877448,
	RuntimeInvoker_Il2CppObject_Il2CppObject_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Il2CppObject_Int32_t2071877448,
	RuntimeInvoker_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Il2CppObject,
	RuntimeInvoker_Int32_t2071877448_Il2CppObject_Il2CppObject_SByte_t454417549,
	RuntimeInvoker_Int32_t2071877448_Il2CppObject_Il2CppObject_SByte_t454417549_Il2CppObject,
	RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448_SByte_t454417549_Il2CppObject,
	RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32_t2071877448,
	RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Int32_t2071877448_Int16_t4041245914_Int32_t2071877448,
	RuntimeInvoker_Int32_t2071877448_Int16_t4041245914_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Il2CppObject_Int32_t2071877448_Int16_t4041245914,
	RuntimeInvoker_Il2CppObject_Int16_t4041245914_Int16_t4041245914,
	RuntimeInvoker_Il2CppObject_Il2CppObject_Il2CppObject_Int32_t2071877448,
	RuntimeInvoker_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Il2CppObject_Int32_t2071877448_Il2CppObject,
	RuntimeInvoker_Il2CppObject_Il2CppObject_Il2CppObject_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Int32U26_t455636984_Int32U26_t455636984_Int32U26_t455636984_BooleanU26_t3168250738_StringU26_t638738783,
	RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32U26_t455636984,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Int16_t4041245914,
	RuntimeInvoker_Il2CppObject_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Il2CppObject,
	RuntimeInvoker_Il2CppObject_Int16_t4041245914_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Il2CppObject_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Int32_t2071877448_Single_t2076509932,
	RuntimeInvoker_Boolean_t3825574718_Single_t2076509932,
	RuntimeInvoker_Single_t2076509932_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Int32_t2071877448_Double_t4078015681,
	RuntimeInvoker_Boolean_t3825574718_Double_t4078015681,
	RuntimeInvoker_Double_t4078015681_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Double_t4078015681_Il2CppObject_Int32_t2071877448_Il2CppObject,
	RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Int32_t2071877448_Il2CppObject_SByte_t454417549_DoubleU26_t1208767207_ExceptionU26_t1467204777,
	RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Il2CppObject_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Boolean_t3825574718_Il2CppObject_DoubleU26_t1208767207,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_SByte_t454417549_SByte_t454417549,
	RuntimeInvoker_Void_t1841601450_Int64_t909078037,
	RuntimeInvoker_Void_t1841601450_Single_t2076509932,
	RuntimeInvoker_Void_t1841601450_Double_t4078015681,
	RuntimeInvoker_Il2CppObject_Decimal_t724701077,
	RuntimeInvoker_Decimal_t724701077_Decimal_t724701077_Decimal_t724701077,
	RuntimeInvoker_UInt64_t2909196914_Decimal_t724701077,
	RuntimeInvoker_Int64_t909078037_Decimal_t724701077,
	RuntimeInvoker_Boolean_t3825574718_Decimal_t724701077_Decimal_t724701077,
	RuntimeInvoker_Decimal_t724701077_Decimal_t724701077,
	RuntimeInvoker_Int32_t2071877448_Decimal_t724701077_Decimal_t724701077,
	RuntimeInvoker_Int32_t2071877448_Decimal_t724701077,
	RuntimeInvoker_Boolean_t3825574718_Decimal_t724701077,
	RuntimeInvoker_Decimal_t724701077_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Il2CppObject_Il2CppObject_Int32_t2071877448_Il2CppObject_Int32U26_t455636984_BooleanU26_t3168250738_BooleanU26_t3168250738_Int32U26_t455636984_SByte_t454417549,
	RuntimeInvoker_Decimal_t724701077_Il2CppObject_Int32_t2071877448_Il2CppObject,
	RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Int32_t2071877448_Il2CppObject_DecimalU26_t1613489971_SByte_t454417549,
	RuntimeInvoker_Int32_t2071877448_DecimalU26_t1613489971_UInt64U26_t1611942494,
	RuntimeInvoker_Int32_t2071877448_DecimalU26_t1613489971_Int64U26_t763825331,
	RuntimeInvoker_Int32_t2071877448_DecimalU26_t1613489971_DecimalU26_t1613489971,
	RuntimeInvoker_Int32_t2071877448_DecimalU26_t1613489971_Il2CppObject_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Int32_t2071877448_DecimalU26_t1613489971_Int32_t2071877448,
	RuntimeInvoker_Double_t4078015681_DecimalU26_t1613489971,
	RuntimeInvoker_Void_t1841601450_DecimalU26_t1613489971_Int32_t2071877448,
	RuntimeInvoker_Int32_t2071877448_DecimalU26_t1613489971_DecimalU26_t1613489971_DecimalU26_t1613489971,
	RuntimeInvoker_Byte_t3683104436_Decimal_t724701077,
	RuntimeInvoker_SByte_t454417549_Decimal_t724701077,
	RuntimeInvoker_Int16_t4041245914_Decimal_t724701077,
	RuntimeInvoker_UInt16_t986882611_Decimal_t724701077,
	RuntimeInvoker_UInt32_t2149682021_Decimal_t724701077,
	RuntimeInvoker_Decimal_t724701077_SByte_t454417549,
	RuntimeInvoker_Decimal_t724701077_Int16_t4041245914,
	RuntimeInvoker_Decimal_t724701077_Int32_t2071877448,
	RuntimeInvoker_Decimal_t724701077_Int64_t909078037,
	RuntimeInvoker_Decimal_t724701077_Single_t2076509932,
	RuntimeInvoker_Decimal_t724701077_Double_t4078015681,
	RuntimeInvoker_Single_t2076509932_Decimal_t724701077,
	RuntimeInvoker_Double_t4078015681_Decimal_t724701077,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_StreamingContext_t1417235061,
	RuntimeInvoker_Int64_t909078037,
	RuntimeInvoker_Boolean_t3825574718_IntPtr_t_IntPtr_t,
	RuntimeInvoker_IntPtr_t_Int32_t2071877448,
	RuntimeInvoker_IntPtr_t_Int64_t909078037,
	RuntimeInvoker_IntPtr_t_Il2CppObject,
	RuntimeInvoker_Int32_t2071877448_IntPtr_t,
	RuntimeInvoker_Il2CppObject_IntPtr_t,
	RuntimeInvoker_UInt32_t2149682021,
	RuntimeInvoker_UInt64_t2909196914,
	RuntimeInvoker_UInt64_t2909196914_IntPtr_t,
	RuntimeInvoker_UInt32_t2149682021_IntPtr_t,
	RuntimeInvoker_UIntPtr_t_Int64_t909078037,
	RuntimeInvoker_UIntPtr_t_Il2CppObject,
	RuntimeInvoker_UIntPtr_t_Int32_t2071877448,
	RuntimeInvoker_Il2CppObject_Il2CppObject_Il2CppObject_MulticastDelegateU26_t4036814277,
	RuntimeInvoker_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject_SByte_t454417549,
	RuntimeInvoker_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject_Int32_t2071877448_SByte_t454417549_SByte_t454417549,
	RuntimeInvoker_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject_SByte_t454417549_SByte_t454417549,
	RuntimeInvoker_Int32_t2071877448_Il2CppObject_Il2CppObject_Il2CppObject_SByte_t454417549,
	RuntimeInvoker_UInt64_t2909196914_Il2CppObject_Int32_t2071877448,
	RuntimeInvoker_Il2CppObject_Il2CppObject_SByte_t454417549,
	RuntimeInvoker_Il2CppObject_Il2CppObject_Int16_t4041245914,
	RuntimeInvoker_Il2CppObject_Il2CppObject_Int64_t909078037,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Il2CppObject,
	RuntimeInvoker_Int64_t909078037_Int32_t2071877448,
	RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Il2CppObject_Int64_t909078037,
	RuntimeInvoker_Il2CppObject_Int64_t909078037_Int64_t909078037,
	RuntimeInvoker_Il2CppObject_Int64_t909078037_Int64_t909078037_Int64_t909078037,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Int64_t909078037,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Int64_t909078037_Int64_t909078037,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Int64_t909078037_Int64_t909078037_Int64_t909078037,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Il2CppObject_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Int32_t2071877448_Il2CppObject_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Il2CppObject,
	RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Int64_t909078037_Il2CppObject_Int64_t909078037_Int64_t909078037,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Il2CppObject_Int64_t909078037,
	RuntimeInvoker_Int32_t2071877448_Il2CppObject_Il2CppObject_Int32_t2071877448,
	RuntimeInvoker_Int32_t2071877448_Il2CppObject_Il2CppObject_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Il2CppObject_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Il2CppObject,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Il2CppObject,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_IntPtr_t,
	RuntimeInvoker_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Il2CppObject_Il2CppObject,
	RuntimeInvoker_TypeAttributes_t2229518203,
	RuntimeInvoker_MemberTypes_t3343038963,
	RuntimeInvoker_RuntimeTypeHandle_t2330101084,
	RuntimeInvoker_Il2CppObject_Il2CppObject_SByte_t454417549_SByte_t454417549,
	RuntimeInvoker_TypeCode_t2536926201_Il2CppObject,
	RuntimeInvoker_Il2CppObject_RuntimeTypeHandle_t2330101084,
	RuntimeInvoker_RuntimeTypeHandle_t2330101084_Il2CppObject,
	RuntimeInvoker_Il2CppObject_Il2CppObject_Int32_t2071877448_Il2CppObject_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Il2CppObject_Il2CppObject_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Il2CppObject_Il2CppObject_Int32_t2071877448_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Il2CppObject_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Il2CppObject_Int32_t2071877448_Il2CppObject_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Il2CppObject_Il2CppObject_Int32_t2071877448_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Boolean_t3825574718_Il2CppObject_SByte_t454417549,
	RuntimeInvoker_Il2CppObject_SByte_t454417549,
	RuntimeInvoker_IntPtr_t,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_SByte_t454417549,
	RuntimeInvoker_Void_t1841601450_SByte_t454417549_SByte_t454417549_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_RuntimeFieldHandle_t2331729674,
	RuntimeInvoker_Void_t1841601450_IntPtr_t_SByte_t454417549,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_SByte_t454417549,
	RuntimeInvoker_Void_t1841601450_SByte_t454417549_SByte_t454417549,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Il2CppObject_ContractionU5BU5DU26_t4026870663_Level2MapU5BU5DU26_t1752902637,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_CodePointIndexerU26_t2645147126_ByteU2AU26_t3544685828_ByteU2AU26_t3544685828_CodePointIndexerU26_t2645147126_ByteU2AU26_t3544685828,
	RuntimeInvoker_Byte_t3683104436_Int32_t2071877448,
	RuntimeInvoker_Boolean_t3825574718_Int32_t2071877448_SByte_t454417549,
	RuntimeInvoker_UInt32_t2149682021_Il2CppObject_Int32_t2071877448,
	RuntimeInvoker_Byte_t3683104436_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Boolean_t3825574718_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_ExtenderType_t1556892101_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Il2CppObject_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Int32_t2071877448_Il2CppObject_Int32_t2071877448,
	RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448_BooleanU26_t3168250738_BooleanU26_t3168250738_SByte_t454417549,
	RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448_BooleanU26_t3168250738_BooleanU26_t3168250738_SByte_t454417549_SByte_t454417549_ContextU26_t3131521781,
	RuntimeInvoker_Int32_t2071877448_SByte_t454417549_SByte_t454417549,
	RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Il2CppObject_Int32_t2071877448,
	RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Il2CppObject_Int32_t2071877448_Int32_t2071877448_SByte_t454417549_ContextU26_t3131521781,
	RuntimeInvoker_Int32_t2071877448_Il2CppObject_Il2CppObject_Int32_t2071877448_Int32_t2071877448_BooleanU26_t3168250738,
	RuntimeInvoker_Int32_t2071877448_Il2CppObject_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Il2CppObject_Int16_t4041245914_Int32_t2071877448_SByte_t454417549_ContextU26_t3131521781,
	RuntimeInvoker_Int32_t2071877448_Il2CppObject_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Il2CppObject_ContextU26_t3131521781,
	RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Il2CppObject_Int32_t2071877448_SByte_t454417549_ContextU26_t3131521781,
	RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Int32U26_t455636984_Int32_t2071877448_Int32_t2071877448_Il2CppObject_SByte_t454417549_ContextU26_t3131521781,
	RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Int32U26_t455636984_Int32_t2071877448_Int32_t2071877448_Il2CppObject_SByte_t454417549_Int32_t2071877448_ContractionU26_t2019974048_ContextU26_t3131521781,
	RuntimeInvoker_Boolean_t3825574718_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Il2CppObject_Int32_t2071877448_SByte_t454417549,
	RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Int32U26_t455636984_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Il2CppObject_SByte_t454417549_ContextU26_t3131521781,
	RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Int32U26_t455636984_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Il2CppObject_SByte_t454417549_Int32_t2071877448_ContractionU26_t2019974048_ContextU26_t3131521781,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject_SByte_t454417549,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Il2CppObject_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Il2CppObject_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Int32_t2071877448_Il2CppObject_SByte_t454417549,
	RuntimeInvoker_Void_t1841601450_SByte_t454417549_SByte_t454417549_SByte_t454417549_SByte_t454417549_SByte_t454417549_SByte_t454417549_SByte_t454417549_SByte_t454417549,
	RuntimeInvoker_Void_t1841601450_SByte_t454417549_SByte_t454417549_SByte_t454417549_SByte_t454417549,
	RuntimeInvoker_Void_t1841601450_SByte_t454417549_ByteU5BU5DU26_t790777611_Int32U26_t455636984,
	RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32_t2071877448_SByte_t454417549,
	RuntimeInvoker_ConfidenceFactor_t1997037801,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_SByte_t454417549,
	RuntimeInvoker_Sign_t874893935_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Il2CppObject_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_DSAParameters_t1872138834_SByte_t454417549,
	RuntimeInvoker_Void_t1841601450_DSAParameters_t1872138834,
	RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject_SByte_t454417549,
	RuntimeInvoker_Il2CppObject_Il2CppObject_DSAParameters_t1872138834,
	RuntimeInvoker_RSAParameters_t1462703416_SByte_t454417549,
	RuntimeInvoker_Void_t1841601450_RSAParameters_t1462703416,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_SByte_t454417549_Il2CppObject,
	RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Il2CppObject_Int32_t2071877448,
	RuntimeInvoker_Il2CppObject_Il2CppObject_Il2CppObject_Int32_t2071877448_Il2CppObject,
	RuntimeInvoker_DSAParameters_t1872138834_BooleanU26_t3168250738,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Int32_t2071877448_Il2CppObject,
	RuntimeInvoker_Il2CppObject_Il2CppObject_SByte_t454417549_Il2CppObject_SByte_t454417549,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Il2CppObject_SByte_t454417549,
	RuntimeInvoker_DateTime_t693205669,
	RuntimeInvoker_Void_t1841601450_SByte_t454417549_Il2CppObject,
	RuntimeInvoker_Byte_t3683104436,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Int32U26_t455636984_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Int32U26_t455636984_ByteU26_t1147306860_Int32U26_t455636984_ByteU5BU5DU26_t790777611,
	RuntimeInvoker_Il2CppObject_Int32_t2071877448_SByte_t454417549,
	RuntimeInvoker_Int16_t4041245914_Il2CppObject_Int32_t2071877448,
	RuntimeInvoker_Single_t2076509932_Il2CppObject_Int32_t2071877448,
	RuntimeInvoker_Double_t4078015681_Il2CppObject_Int32_t2071877448,
	RuntimeInvoker_Il2CppObject_Int16_t4041245914_SByte_t454417549,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Single_t2076509932_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Single_t2076509932,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Single_t2076509932_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Single_t2076509932_Il2CppObject,
	RuntimeInvoker_DictionaryEntry_t3048875398,
	RuntimeInvoker_Boolean_t3825574718_Int32_t2071877448_SByte_t454417549_MethodBaseU26_t1609135766_Int32U26_t455636984_Int32U26_t455636984_StringU26_t638738783_Int32U26_t455636984_Int32U26_t455636984,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Int32_t2071877448_SByte_t454417549,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Int32_t2071877448_SByte_t454417549_SByte_t454417549,
	RuntimeInvoker_Il2CppObject_Il2CppObject_Int32_t2071877448_SByte_t454417549,
	RuntimeInvoker_Int32_t2071877448_DateTime_t693205669,
	RuntimeInvoker_DayOfWeek_t721777893_DateTime_t693205669,
	RuntimeInvoker_Int32_t2071877448_Int32U26_t455636984_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_DayOfWeek_t721777893_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_Int32U26_t455636984_Int32U26_t455636984_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_Int32U26_t455636984_Int32U26_t455636984_Int32U26_t455636984_Int32_t2071877448,
	RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Il2CppObject_Int32_t2071877448_SByte_t454417549,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_SByte_t454417549_SByte_t454417549,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_SByte_t454417549_SByte_t454417549,
	RuntimeInvoker_Il2CppObject_Int16_t4041245914,
	RuntimeInvoker_Void_t1841601450_DateTime_t693205669_DateTime_t693205669_TimeSpan_t3430258949,
	RuntimeInvoker_TimeSpan_t3430258949,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Int32_t2071877448_Il2CppObject_SByte_t454417549,
	RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Int32U26_t455636984,
	RuntimeInvoker_Char_t3454481338,
	RuntimeInvoker_Decimal_t724701077,
	RuntimeInvoker_Double_t4078015681,
	RuntimeInvoker_Int16_t4041245914,
	RuntimeInvoker_SByte_t454417549,
	RuntimeInvoker_Single_t2076509932,
	RuntimeInvoker_UInt16_t986882611,
	RuntimeInvoker_Void_t1841601450_IntPtr_t_Int32_t2071877448_SByte_t454417549_Int32_t2071877448_SByte_t454417549_SByte_t454417549,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_SByte_t454417549_SByte_t454417549,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_SByte_t454417549_Int32_t2071877448,
	RuntimeInvoker_Il2CppObject_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Int64_t909078037_Int64_t909078037_Int32_t2071877448,
	RuntimeInvoker_Int32_t2071877448_IntPtr_t_Il2CppObject_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Int32_t2071877448_Int32_t2071877448_SByte_t454417549_SByte_t454417549,
	RuntimeInvoker_Boolean_t3825574718_Il2CppObject_MonoIOErrorU26_t1029615899,
	RuntimeInvoker_Il2CppObject_Il2CppObject_Il2CppObject_Int32_t2071877448_Int32_t2071877448_MonoIOErrorU26_t1029615899,
	RuntimeInvoker_Il2CppObject_MonoIOErrorU26_t1029615899,
	RuntimeInvoker_FileAttributes_t3843045335_Il2CppObject_MonoIOErrorU26_t1029615899,
	RuntimeInvoker_MonoFileType_t3095218325_IntPtr_t_MonoIOErrorU26_t1029615899,
	RuntimeInvoker_Boolean_t3825574718_Il2CppObject_MonoIOStatU26_t2252080831_MonoIOErrorU26_t1029615899,
	RuntimeInvoker_IntPtr_t_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_MonoIOErrorU26_t1029615899,
	RuntimeInvoker_Boolean_t3825574718_IntPtr_t_MonoIOErrorU26_t1029615899,
	RuntimeInvoker_Int32_t2071877448_IntPtr_t_Il2CppObject_Int32_t2071877448_Int32_t2071877448_MonoIOErrorU26_t1029615899,
	RuntimeInvoker_Int64_t909078037_IntPtr_t_Int64_t909078037_Int32_t2071877448_MonoIOErrorU26_t1029615899,
	RuntimeInvoker_Int64_t909078037_IntPtr_t_MonoIOErrorU26_t1029615899,
	RuntimeInvoker_Boolean_t3825574718_IntPtr_t_Int64_t909078037_MonoIOErrorU26_t1029615899,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Il2CppObject_SByte_t454417549_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_Int16_t4041245914,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Il2CppObject_Il2CppObject_Il2CppObject,
	RuntimeInvoker_CallingConventions_t1097349142,
	RuntimeInvoker_RuntimeMethodHandle_t894824333,
	RuntimeInvoker_MethodAttributes_t790385034,
	RuntimeInvoker_MethodToken_t3991686330,
	RuntimeInvoker_FieldAttributes_t1122705193,
	RuntimeInvoker_RuntimeFieldHandle_t2331729674,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Il2CppObject_Int32_t2071877448_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Void_t1841601450_OpCode_t2247480392,
	RuntimeInvoker_Void_t1841601450_OpCode_t2247480392_Il2CppObject,
	RuntimeInvoker_StackBehaviour_t1390406961,
	RuntimeInvoker_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Il2CppObject,
	RuntimeInvoker_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Il2CppObject_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Il2CppObject_Il2CppObject_Int32_t2071877448_SByte_t454417549_Il2CppObject,
	RuntimeInvoker_IntPtr_t_Il2CppObject_Int32U26_t455636984_ModuleU26_t4102634234,
	RuntimeInvoker_Il2CppObject_Il2CppObject_Il2CppObject_SByte_t454417549_SByte_t454417549,
	RuntimeInvoker_AssemblyNameFlags_t1794031440,
	RuntimeInvoker_Il2CppObject_Int32_t2071877448_Il2CppObject_ObjectU5BU5DU26_t3223402458_Il2CppObject_Il2CppObject_Il2CppObject_ObjectU26_t597476745,
	RuntimeInvoker_Void_t1841601450_ObjectU5BU5DU26_t3223402458_Il2CppObject,
	RuntimeInvoker_Il2CppObject_Int32_t2071877448_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_ObjectU5BU5DU26_t3223402458_Il2CppObject,
	RuntimeInvoker_Il2CppObject_Int32_t2071877448_Il2CppObject_Il2CppObject_Il2CppObject_SByte_t454417549,
	RuntimeInvoker_EventAttributes_t2989788983,
	RuntimeInvoker_Il2CppObject_IntPtr_t_IntPtr_t,
	RuntimeInvoker_Il2CppObject_RuntimeFieldHandle_t2331729674,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject_Int32_t2071877448_Il2CppObject,
	RuntimeInvoker_Il2CppObject_StreamingContext_t1417235061,
	RuntimeInvoker_Il2CppObject_RuntimeMethodHandle_t894824333,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_MonoEventInfoU26_t2234966955,
	RuntimeInvoker_MonoEventInfo_t2190036573_Il2CppObject,
	RuntimeInvoker_Void_t1841601450_IntPtr_t_MonoMethodInfoU26_t16045984,
	RuntimeInvoker_MonoMethodInfo_t3646562144_IntPtr_t,
	RuntimeInvoker_MethodAttributes_t790385034_IntPtr_t,
	RuntimeInvoker_CallingConventions_t1097349142_IntPtr_t,
	RuntimeInvoker_Il2CppObject_IntPtr_t_Il2CppObject,
	RuntimeInvoker_Il2CppObject_Il2CppObject_Il2CppObject_ExceptionU26_t1467204777,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_MonoPropertyInfoU26_t828568312_Int32_t2071877448,
	RuntimeInvoker_PropertyAttributes_t883448530,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Il2CppObject_Int32_t2071877448_Il2CppObject_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Il2CppObject_Il2CppObject_Int32_t2071877448,
	RuntimeInvoker_ParameterAttributes_t1266705348,
	RuntimeInvoker_Void_t1841601450_Int64_t909078037_ResourceInfoU26_t3126209420,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Int64_t909078037_Int32_t2071877448,
	RuntimeInvoker_GCHandle_t3409268066_Il2CppObject_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_IntPtr_t_Int32_t2071877448_Il2CppObject_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_IntPtr_t_Il2CppObject_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Byte_t3683104436_IntPtr_t_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_IntPtr_t_Int32_t2071877448_SByte_t454417549,
	RuntimeInvoker_Void_t1841601450_BooleanU26_t3168250738,
	RuntimeInvoker_Void_t1841601450_IntPtr_t,
	RuntimeInvoker_Il2CppObject_Il2CppObject_Il2CppObject_StringU26_t638738783,
	RuntimeInvoker_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject_StringU26_t638738783,
	RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Void_t1841601450_SByte_t454417549_Il2CppObject_SByte_t454417549_SByte_t454417549,
	RuntimeInvoker_Void_t1841601450_TimeSpan_t3430258949,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Byte_t3683104436,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Il2CppObject_SByte_t454417549_Il2CppObject,
	RuntimeInvoker_Il2CppObject_Il2CppObject_Il2CppObject_StreamingContext_t1417235061_Il2CppObject,
	RuntimeInvoker_Il2CppObject_Il2CppObject_StreamingContext_t1417235061_ISurrogateSelectorU26_t2635255864,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_IntPtr_t_Il2CppObject,
	RuntimeInvoker_TimeSpan_t3430258949_Il2CppObject,
	RuntimeInvoker_Il2CppObject_StringU26_t638738783,
	RuntimeInvoker_Il2CppObject_Il2CppObject_Il2CppObject_ObjectU26_t597476745,
	RuntimeInvoker_Boolean_t3825574718_Il2CppObject_StringU26_t638738783_StringU26_t638738783,
	RuntimeInvoker_WellKnownObjectMode_t2630225581,
	RuntimeInvoker_StreamingContext_t1417235061,
	RuntimeInvoker_TypeFilterLevel_t1182459634,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_BooleanU26_t3168250738,
	RuntimeInvoker_Il2CppObject_Byte_t3683104436_Il2CppObject_SByte_t454417549_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Il2CppObject_Byte_t3683104436_Il2CppObject_SByte_t454417549_Il2CppObject_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_SByte_t454417549_ObjectU26_t597476745_HeaderU5BU5DU26_t2818328198,
	RuntimeInvoker_Void_t1841601450_Byte_t3683104436_Il2CppObject_SByte_t454417549_ObjectU26_t597476745_HeaderU5BU5DU26_t2818328198,
	RuntimeInvoker_Boolean_t3825574718_Byte_t3683104436_Il2CppObject,
	RuntimeInvoker_Void_t1841601450_Byte_t3683104436_Il2CppObject_Int64U26_t763825331_ObjectU26_t597476745_SerializationInfoU26_t4051840202,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_SByte_t454417549_SByte_t454417549_Int64U26_t763825331_ObjectU26_t597476745_SerializationInfoU26_t4051840202,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Int64U26_t763825331_ObjectU26_t597476745_SerializationInfoU26_t4051840202,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Il2CppObject_Int64_t909078037_ObjectU26_t597476745_SerializationInfoU26_t4051840202,
	RuntimeInvoker_Void_t1841601450_Int64_t909078037_Il2CppObject_Il2CppObject_Int64_t909078037_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Int64U26_t763825331_ObjectU26_t597476745,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Il2CppObject_Int64U26_t763825331_ObjectU26_t597476745,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Il2CppObject_Int64_t909078037_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Void_t1841601450_Int64_t909078037_Int64_t909078037_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Il2CppObject_Int64_t909078037_Il2CppObject,
	RuntimeInvoker_Il2CppObject_Il2CppObject_Byte_t3683104436,
	RuntimeInvoker_Void_t1841601450_Int64_t909078037_Int32_t2071877448_Int64_t909078037,
	RuntimeInvoker_Void_t1841601450_Int64_t909078037_Il2CppObject_Int64_t909078037,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Int64_t909078037_Il2CppObject_Int64_t909078037_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Boolean_t3825574718_SByte_t454417549_Il2CppObject_SByte_t454417549,
	RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Il2CppObject_StreamingContext_t1417235061,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Il2CppObject_StreamingContext_t1417235061,
	RuntimeInvoker_Void_t1841601450_StreamingContext_t1417235061,
	RuntimeInvoker_Il2CppObject_StreamingContext_t1417235061_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Int16_t4041245914,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_DateTime_t693205669,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Single_t2076509932,
	RuntimeInvoker_SerializationEntry_t3485203212,
	RuntimeInvoker_StreamingContextStates_t4264247603,
	RuntimeInvoker_CspProviderFlags_t105264000,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_SByte_t454417549_Il2CppObject_Il2CppObject,
	RuntimeInvoker_UInt32_t2149682021_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Il2CppObject_Il2CppObject_SByte_t454417549,
	RuntimeInvoker_Void_t1841601450_Int64_t909078037_Il2CppObject_Int32_t2071877448,
	RuntimeInvoker_UInt32_t2149682021_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_UInt32U26_t2197289955_Int32_t2071877448_UInt32U26_t2197289955_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_IntPtr_t_IntPtr_t_Il2CppObject,
	RuntimeInvoker_UInt32_t2149682021_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_Int64_t909078037_Int64_t909078037,
	RuntimeInvoker_UInt64_t2909196914_Int64_t909078037_Int32_t2071877448,
	RuntimeInvoker_UInt64_t2909196914_Int64_t909078037_Int64_t909078037_Int64_t909078037,
	RuntimeInvoker_UInt64_t2909196914_Int64_t909078037,
	RuntimeInvoker_CipherMode_t162592484,
	RuntimeInvoker_PaddingMode_t3032142640,
	RuntimeInvoker_Void_t1841601450_StringBuilderU26_t731233658_Int32_t2071877448,
	RuntimeInvoker_Il2CppObject_IntPtr_t_Int32_t2071877448,
	RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Il2CppObject_Int32_t2071877448_EncoderFallbackBufferU26_t1009712630_CharU5BU5DU26_t3108165433,
	RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Il2CppObject_Int32_t2071877448_DecoderFallbackBufferU26_t3597875002,
	RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Il2CppObject_Int32_t2071877448,
	RuntimeInvoker_Boolean_t3825574718_Int16_t4041245914_Int32_t2071877448,
	RuntimeInvoker_Boolean_t3825574718_Int16_t4041245914_Int16_t4041245914_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_Int16_t4041245914_Int16_t4041245914_Int32_t2071877448,
	RuntimeInvoker_Il2CppObject_Int32U26_t455636984,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Il2CppObject_Int32_t2071877448_Il2CppObject_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_SByte_t454417549_SByte_t454417549_SByte_t454417549,
	RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448_SByte_t454417549_Int32_t2071877448_SByte_t454417549_SByte_t454417549,
	RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Il2CppObject_Int32_t2071877448_SByte_t454417549_Int32U26_t455636984_BooleanU26_t3168250738_SByte_t454417549,
	RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32U26_t455636984,
	RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448_CharU26_t1894467670_SByte_t454417549,
	RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32_t2071877448_CharU26_t1894467670_SByte_t454417549,
	RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Il2CppObject_Int32_t2071877448_CharU26_t1894467670_SByte_t454417549,
	RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Il2CppObject_Int32_t2071877448_CharU26_t1894467670_SByte_t454417549,
	RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Il2CppObject_DecoderFallbackBufferU26_t3597875002_ByteU5BU5DU26_t790777611_SByte_t454417549,
	RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Il2CppObject_DecoderFallbackBufferU26_t3597875002_ByteU5BU5DU26_t790777611_SByte_t454417549,
	RuntimeInvoker_Int32_t2071877448_Il2CppObject_DecoderFallbackBufferU26_t3597875002_ByteU5BU5DU26_t790777611_Il2CppObject_Int64_t909078037_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_DecoderFallbackBufferU26_t3597875002_ByteU5BU5DU26_t790777611_Il2CppObject_Int64_t909078037_Int32_t2071877448_Il2CppObject_Int32U26_t455636984,
	RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Il2CppObject_Int32_t2071877448_UInt32U26_t2197289955_UInt32U26_t2197289955_Il2CppObject_DecoderFallbackBufferU26_t3597875002_ByteU5BU5DU26_t790777611_SByte_t454417549,
	RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Il2CppObject_Int32_t2071877448_UInt32U26_t2197289955_UInt32U26_t2197289955_Il2CppObject_DecoderFallbackBufferU26_t3597875002_ByteU5BU5DU26_t790777611_SByte_t454417549,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Il2CppObject_Int32_t2071877448_SByte_t454417549,
	RuntimeInvoker_Void_t1841601450_SByte_t454417549_Int32_t2071877448,
	RuntimeInvoker_Single_t2076509932_SingleU26_t4173844468_Single_t2076509932_Single_t2076509932,
	RuntimeInvoker_IntPtr_t_SByte_t454417549_Il2CppObject_BooleanU26_t3168250738,
	RuntimeInvoker_Boolean_t3825574718_IntPtr_t,
	RuntimeInvoker_IntPtr_t_SByte_t454417549_SByte_t454417549_Il2CppObject_BooleanU26_t3168250738,
	RuntimeInvoker_Boolean_t3825574718_TimeSpan_t3430258949_TimeSpan_t3430258949,
	RuntimeInvoker_Boolean_t3825574718_Int64_t909078037_Int64_t909078037_SByte_t454417549,
	RuntimeInvoker_Boolean_t3825574718_IntPtr_t_Int32_t2071877448_SByte_t454417549,
	RuntimeInvoker_Int64_t909078037_Double_t4078015681,
	RuntimeInvoker_Il2CppObject_Double_t4078015681,
	RuntimeInvoker_Int64_t909078037_Il2CppObject_Int32_t2071877448,
	RuntimeInvoker_Il2CppObject_IntPtr_t_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Byte_t3683104436_SByte_t454417549,
	RuntimeInvoker_Byte_t3683104436_Int16_t4041245914,
	RuntimeInvoker_Byte_t3683104436_Double_t4078015681,
	RuntimeInvoker_Byte_t3683104436_Single_t2076509932,
	RuntimeInvoker_Byte_t3683104436_Int64_t909078037,
	RuntimeInvoker_Char_t3454481338_SByte_t454417549,
	RuntimeInvoker_Char_t3454481338_Int64_t909078037,
	RuntimeInvoker_Char_t3454481338_Single_t2076509932,
	RuntimeInvoker_Char_t3454481338_Il2CppObject_Il2CppObject,
	RuntimeInvoker_DateTime_t693205669_Il2CppObject_Il2CppObject,
	RuntimeInvoker_DateTime_t693205669_Int16_t4041245914,
	RuntimeInvoker_DateTime_t693205669_Int32_t2071877448,
	RuntimeInvoker_DateTime_t693205669_Int64_t909078037,
	RuntimeInvoker_DateTime_t693205669_Single_t2076509932,
	RuntimeInvoker_DateTime_t693205669_SByte_t454417549,
	RuntimeInvoker_Double_t4078015681_SByte_t454417549,
	RuntimeInvoker_Double_t4078015681_Double_t4078015681,
	RuntimeInvoker_Double_t4078015681_Single_t2076509932,
	RuntimeInvoker_Double_t4078015681_Int32_t2071877448,
	RuntimeInvoker_Double_t4078015681_Int64_t909078037,
	RuntimeInvoker_Double_t4078015681_Int16_t4041245914,
	RuntimeInvoker_Int16_t4041245914_SByte_t454417549,
	RuntimeInvoker_Int16_t4041245914_Int16_t4041245914,
	RuntimeInvoker_Int16_t4041245914_Double_t4078015681,
	RuntimeInvoker_Int16_t4041245914_Single_t2076509932,
	RuntimeInvoker_Int16_t4041245914_Int32_t2071877448,
	RuntimeInvoker_Int16_t4041245914_Int64_t909078037,
	RuntimeInvoker_Int64_t909078037_SByte_t454417549,
	RuntimeInvoker_Int64_t909078037_Int16_t4041245914,
	RuntimeInvoker_Int64_t909078037_Single_t2076509932,
	RuntimeInvoker_Int64_t909078037_Int64_t909078037,
	RuntimeInvoker_SByte_t454417549_SByte_t454417549,
	RuntimeInvoker_SByte_t454417549_Int16_t4041245914,
	RuntimeInvoker_SByte_t454417549_Double_t4078015681,
	RuntimeInvoker_SByte_t454417549_Single_t2076509932,
	RuntimeInvoker_SByte_t454417549_Int32_t2071877448,
	RuntimeInvoker_SByte_t454417549_Int64_t909078037,
	RuntimeInvoker_Single_t2076509932_SByte_t454417549,
	RuntimeInvoker_Single_t2076509932_Double_t4078015681,
	RuntimeInvoker_Single_t2076509932_Single_t2076509932,
	RuntimeInvoker_Single_t2076509932_Int32_t2071877448,
	RuntimeInvoker_Single_t2076509932_Int64_t909078037,
	RuntimeInvoker_Single_t2076509932_Int16_t4041245914,
	RuntimeInvoker_UInt16_t986882611_SByte_t454417549,
	RuntimeInvoker_UInt16_t986882611_Int16_t4041245914,
	RuntimeInvoker_UInt16_t986882611_Double_t4078015681,
	RuntimeInvoker_UInt16_t986882611_Single_t2076509932,
	RuntimeInvoker_UInt16_t986882611_Int32_t2071877448,
	RuntimeInvoker_UInt16_t986882611_Int64_t909078037,
	RuntimeInvoker_UInt32_t2149682021_SByte_t454417549,
	RuntimeInvoker_UInt32_t2149682021_Int16_t4041245914,
	RuntimeInvoker_UInt32_t2149682021_Double_t4078015681,
	RuntimeInvoker_UInt32_t2149682021_Single_t2076509932,
	RuntimeInvoker_UInt32_t2149682021_Int64_t909078037,
	RuntimeInvoker_UInt64_t2909196914_SByte_t454417549,
	RuntimeInvoker_UInt64_t2909196914_Int16_t4041245914,
	RuntimeInvoker_UInt64_t2909196914_Double_t4078015681,
	RuntimeInvoker_UInt64_t2909196914_Single_t2076509932,
	RuntimeInvoker_UInt64_t2909196914_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_SByte_t454417549_TimeSpan_t3430258949,
	RuntimeInvoker_Void_t1841601450_Int64_t909078037_Int32_t2071877448,
	RuntimeInvoker_DayOfWeek_t721777893,
	RuntimeInvoker_DateTimeKind_t2186819611,
	RuntimeInvoker_DateTime_t693205669_TimeSpan_t3430258949,
	RuntimeInvoker_DateTime_t693205669_Double_t4078015681,
	RuntimeInvoker_Int32_t2071877448_DateTime_t693205669_DateTime_t693205669,
	RuntimeInvoker_Boolean_t3825574718_DateTime_t693205669,
	RuntimeInvoker_DateTime_t693205669_DateTime_t693205669_Int32_t2071877448,
	RuntimeInvoker_DateTime_t693205669_Il2CppObject_Il2CppObject_Int32_t2071877448,
	RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Il2CppObject_Int32_t2071877448_DateTimeU26_t3448131235_DateTimeOffsetU26_t3212986406_SByte_t454417549_ExceptionU26_t1467204777,
	RuntimeInvoker_Il2CppObject_Il2CppObject_SByte_t454417549_ExceptionU26_t1467204777,
	RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_SByte_t454417549_SByte_t454417549_Int32U26_t455636984,
	RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Il2CppObject_Il2CppObject_SByte_t454417549_Int32U26_t455636984,
	RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Il2CppObject_Int32U26_t455636984,
	RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Il2CppObject_SByte_t454417549_Int32U26_t455636984_Int32U26_t455636984,
	RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Int32_t2071877448_Il2CppObject_SByte_t454417549_Int32U26_t455636984,
	RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Il2CppObject_Il2CppObject_SByte_t454417549_DateTimeU26_t3448131235_DateTimeOffsetU26_t3212986406_Il2CppObject_Int32_t2071877448_SByte_t454417549_BooleanU26_t3168250738_BooleanU26_t3168250738,
	RuntimeInvoker_DateTime_t693205669_Il2CppObject_Il2CppObject_Il2CppObject_Int32_t2071877448,
	RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Il2CppObject_Il2CppObject_Int32_t2071877448_DateTimeU26_t3448131235_SByte_t454417549_BooleanU26_t3168250738_SByte_t454417549_ExceptionU26_t1467204777,
	RuntimeInvoker_DateTime_t693205669_DateTime_t693205669_TimeSpan_t3430258949,
	RuntimeInvoker_Boolean_t3825574718_DateTime_t693205669_DateTime_t693205669,
	RuntimeInvoker_Void_t1841601450_DateTime_t693205669,
	RuntimeInvoker_Void_t1841601450_DateTime_t693205669_TimeSpan_t3430258949,
	RuntimeInvoker_Void_t1841601450_Int64_t909078037_TimeSpan_t3430258949,
	RuntimeInvoker_Int32_t2071877448_DateTimeOffset_t1362988906,
	RuntimeInvoker_Boolean_t3825574718_DateTimeOffset_t1362988906,
	RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int16_t4041245914,
	RuntimeInvoker_Il2CppObject_Int16_t4041245914_Il2CppObject_BooleanU26_t3168250738_BooleanU26_t3168250738,
	RuntimeInvoker_Il2CppObject_Int16_t4041245914_Il2CppObject_BooleanU26_t3168250738_BooleanU26_t3168250738_SByte_t454417549,
	RuntimeInvoker_Il2CppObject_DateTime_t693205669_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Il2CppObject_DateTime_t693205669_Nullable_1_t1693325264_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Void_t1841601450_MonoEnumInfo_t2335995564,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_MonoEnumInfoU26_t3695146548,
	RuntimeInvoker_Int32_t2071877448_Int16_t4041245914_Int16_t4041245914,
	RuntimeInvoker_Int32_t2071877448_Int64_t909078037_Int64_t909078037,
	RuntimeInvoker_PlatformID_t1006634368,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Int16_t4041245914_Int16_t4041245914_SByte_t454417549_SByte_t454417549_SByte_t454417549_SByte_t454417549_SByte_t454417549_SByte_t454417549_SByte_t454417549_SByte_t454417549,
	RuntimeInvoker_Int32_t2071877448_Guid_t2533601593,
	RuntimeInvoker_Boolean_t3825574718_Guid_t2533601593,
	RuntimeInvoker_Guid_t2533601593,
	RuntimeInvoker_Il2CppObject_SByte_t454417549_SByte_t454417549_SByte_t454417549,
	RuntimeInvoker_Double_t4078015681_Double_t4078015681_Double_t4078015681,
	RuntimeInvoker_TypeAttributes_t2229518203_Il2CppObject,
	RuntimeInvoker_Il2CppObject_SByte_t454417549_SByte_t454417549,
	RuntimeInvoker_Void_t1841601450_UInt64U2AU26_t2027109114_Int32U2AU26_t347619176_CharU2AU26_t4068306018_CharU2AU26_t4068306018_Int64U2AU26_t3929841737_Int32U2AU26_t347619176,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Int64_t909078037,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Double_t4078015681_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Decimal_t724701077,
	RuntimeInvoker_Il2CppObject_Il2CppObject_SByte_t454417549_Il2CppObject,
	RuntimeInvoker_Il2CppObject_Il2CppObject_Int16_t4041245914_Il2CppObject,
	RuntimeInvoker_Il2CppObject_Il2CppObject_Int32_t2071877448_Il2CppObject,
	RuntimeInvoker_Il2CppObject_Il2CppObject_Int64_t909078037_Il2CppObject,
	RuntimeInvoker_Il2CppObject_Il2CppObject_Single_t2076509932_Il2CppObject,
	RuntimeInvoker_Il2CppObject_Il2CppObject_Double_t4078015681_Il2CppObject,
	RuntimeInvoker_Il2CppObject_Il2CppObject_Decimal_t724701077_Il2CppObject,
	RuntimeInvoker_Il2CppObject_Single_t2076509932_Il2CppObject,
	RuntimeInvoker_Il2CppObject_Double_t4078015681_Il2CppObject,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Int32_t2071877448_Il2CppObject,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_BooleanU26_t3168250738_SByte_t454417549_Int32U26_t455636984_Int32U26_t455636984,
	RuntimeInvoker_Il2CppObject_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Il2CppObject_SByte_t454417549_Il2CppObject_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Int64_t909078037_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_TimeSpan_t3430258949_TimeSpan_t3430258949,
	RuntimeInvoker_Int32_t2071877448_TimeSpan_t3430258949_TimeSpan_t3430258949,
	RuntimeInvoker_Int32_t2071877448_TimeSpan_t3430258949,
	RuntimeInvoker_Boolean_t3825574718_TimeSpan_t3430258949,
	RuntimeInvoker_TimeSpan_t3430258949_Double_t4078015681,
	RuntimeInvoker_TimeSpan_t3430258949_Double_t4078015681_Int64_t909078037,
	RuntimeInvoker_TimeSpan_t3430258949_TimeSpan_t3430258949_TimeSpan_t3430258949,
	RuntimeInvoker_TimeSpan_t3430258949_DateTime_t693205669,
	RuntimeInvoker_Boolean_t3825574718_DateTime_t693205669_Il2CppObject,
	RuntimeInvoker_DateTime_t693205669_DateTime_t693205669,
	RuntimeInvoker_TimeSpan_t3430258949_DateTime_t693205669_TimeSpan_t3430258949,
	RuntimeInvoker_Boolean_t3825574718_Int32_t2071877448_Int64U5BU5DU26_t2476256456_StringU5BU5DU26_t3730240492,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Il2CppObject_Il2CppObject_Int32_t2071877448_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Il2CppObject_Il2CppObject_DictionaryNodeU26_t2101813158,
	RuntimeInvoker_EditorBrowsableState_t373498655,
	RuntimeInvoker_SocketType_t1143498533,
	RuntimeInvoker_Il2CppObject_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Void_t1841601450_IntPtr_t_Il2CppObject_Int32U26_t455636984,
	RuntimeInvoker_Int32_t2071877448_Il2CppObject_SocketErrorU26_t2724123615,
	RuntimeInvoker_Int32_t2071877448_IntPtr_t_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_SocketAddressU26_t3239642505_Int32U26_t455636984,
	RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_EndPointU26_t983111093,
	RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_EndPointU26_t983111093_SByte_t454417549_Int32U26_t455636984,
	RuntimeInvoker_Int32_t2071877448_IntPtr_t_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Il2CppObject_Int32U26_t455636984,
	RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Il2CppObject,
	RuntimeInvoker_IntPtr_t_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Int32U26_t455636984,
	RuntimeInvoker_Il2CppObject_IntPtr_t_Int32U26_t455636984,
	RuntimeInvoker_Void_t1841601450_IntPtr_t_Int32U26_t455636984,
	RuntimeInvoker_Void_t1841601450_IntPtr_t_Il2CppObject_Int32U26_t455636984_SByte_t454417549,
	RuntimeInvoker_Boolean_t3825574718_IntPtr_t_Int32_t2071877448_Int32_t2071877448_Int32U26_t455636984,
	RuntimeInvoker_Boolean_t3825574718_Int32_t2071877448_Int32_t2071877448_Int32U26_t455636984,
	RuntimeInvoker_Int32_t2071877448_IntPtr_t_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Int32U26_t455636984,
	RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_SocketErrorU26_t2724123615,
	RuntimeInvoker_Void_t1841601450_IntPtr_t_Int32_t2071877448_Int32_t2071877448_ObjectU26_t597476745_Int32U26_t455636984,
	RuntimeInvoker_Void_t1841601450_IntPtr_t_Int32_t2071877448_Int32U26_t455636984,
	RuntimeInvoker_Void_t1841601450_IntPtr_t_Int32_t2071877448_Int32_t2071877448_Il2CppObject_Il2CppObject_Int32_t2071877448_Int32U26_t455636984,
	RuntimeInvoker_SocketError_t307542793,
	RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Il2CppObject_Il2CppObject_Int32_t2071877448,
	RuntimeInvoker_Boolean_t3825574718_Il2CppObject_StringU26_t638738783_StringU5BU5DU26_t3730240492_StringU5BU5DU26_t3730240492,
	RuntimeInvoker_AddressFamily_t303362630,
	RuntimeInvoker_Boolean_t3825574718_Il2CppObject_IPAddressU26_t903689901,
	RuntimeInvoker_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Boolean_t3825574718_Il2CppObject_IPv6AddressU26_t2456310193,
	RuntimeInvoker_SecurityProtocolType_t3099771628,
	RuntimeInvoker_Void_t1841601450_SByte_t454417549_SByte_t454417549_Int32_t2071877448_SByte_t454417549,
	RuntimeInvoker_AsnDecodeStatus_t1962003286_Il2CppObject,
	RuntimeInvoker_Il2CppObject_Int32_t2071877448_Il2CppObject_SByte_t454417549,
	RuntimeInvoker_X509ChainStatusFlags_t480677120_Il2CppObject,
	RuntimeInvoker_X509ChainStatusFlags_t480677120_Il2CppObject_Int32_t2071877448_SByte_t454417549,
	RuntimeInvoker_X509ChainStatusFlags_t480677120_Il2CppObject_Il2CppObject_SByte_t454417549,
	RuntimeInvoker_X509ChainStatusFlags_t480677120,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Int32U26_t455636984_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_X509RevocationFlag_t2166064554,
	RuntimeInvoker_X509RevocationMode_t2065307963,
	RuntimeInvoker_X509VerificationFlags_t2169036324,
	RuntimeInvoker_X509KeyUsageFlags_t2461349531,
	RuntimeInvoker_X509KeyUsageFlags_t2461349531_Int32_t2071877448,
	RuntimeInvoker_Byte_t3683104436_Int16_t4041245914_Int16_t4041245914,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Il2CppObject_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Il2CppObject_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_RegexOptions_t2418259727,
	RuntimeInvoker_Category_t1984577050_Il2CppObject,
	RuntimeInvoker_Boolean_t3825574718_UInt16_t986882611_Int16_t4041245914,
	RuntimeInvoker_Boolean_t3825574718_Int32_t2071877448_Int16_t4041245914,
	RuntimeInvoker_Void_t1841601450_Int16_t4041245914_SByte_t454417549_SByte_t454417549_SByte_t454417549,
	RuntimeInvoker_Void_t1841601450_UInt16_t986882611_SByte_t454417549_SByte_t454417549,
	RuntimeInvoker_Void_t1841601450_Int16_t4041245914_Int16_t4041245914_SByte_t454417549_SByte_t454417549_SByte_t454417549,
	RuntimeInvoker_Void_t1841601450_Int16_t4041245914_Il2CppObject_SByte_t454417549_SByte_t454417549_SByte_t454417549,
	RuntimeInvoker_Void_t1841601450_UInt16_t986882611,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Int32_t2071877448_SByte_t454417549_Il2CppObject,
	RuntimeInvoker_Void_t1841601450_SByte_t454417549_Int32_t2071877448_Il2CppObject,
	RuntimeInvoker_UInt16_t986882611_UInt16_t986882611_UInt16_t986882611,
	RuntimeInvoker_OpFlags_t378191910_SByte_t454417549_SByte_t454417549_SByte_t454417549_SByte_t454417549,
	RuntimeInvoker_Void_t1841601450_UInt16_t986882611_UInt16_t986882611,
	RuntimeInvoker_Boolean_t3825574718_Int32_t2071877448_Int32U26_t455636984_Int32_t2071877448,
	RuntimeInvoker_Boolean_t3825574718_Int32_t2071877448_Int32U26_t455636984_Int32U26_t455636984_SByte_t454417549,
	RuntimeInvoker_Boolean_t3825574718_Int32U26_t455636984_Int32_t2071877448,
	RuntimeInvoker_Boolean_t3825574718_UInt16_t986882611_Int32_t2071877448,
	RuntimeInvoker_Boolean_t3825574718_Int32_t2071877448_Int32_t2071877448_SByte_t454417549_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Int32U26_t455636984_Int32U26_t455636984,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Int32_t2071877448_Int32_t2071877448_SByte_t454417549_Int32_t2071877448,
	RuntimeInvoker_Interval_t2354235237,
	RuntimeInvoker_Boolean_t3825574718_Interval_t2354235237,
	RuntimeInvoker_Void_t1841601450_Interval_t2354235237,
	RuntimeInvoker_Interval_t2354235237_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Int32_t2071877448_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Double_t4078015681_Interval_t2354235237,
	RuntimeInvoker_Il2CppObject_Interval_t2354235237_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32U26_t455636984_Int32_t2071877448,
	RuntimeInvoker_Int32_t2071877448_Il2CppObject_Int32U26_t455636984_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Il2CppObject_Il2CppObject_Int32U26_t455636984,
	RuntimeInvoker_Il2CppObject_RegexOptionsU26_t3063574985,
	RuntimeInvoker_Void_t1841601450_RegexOptionsU26_t3063574985_SByte_t454417549,
	RuntimeInvoker_Boolean_t3825574718_Int32U26_t455636984_Int32U26_t455636984_Int32_t2071877448,
	RuntimeInvoker_Category_t1984577050,
	RuntimeInvoker_Void_t1841601450_Int32U26_t455636984_Int32U26_t455636984,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Int32_t2071877448_SByte_t454417549,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Il2CppObject_SByte_t454417549_SByte_t454417549,
	RuntimeInvoker_Void_t1841601450_UInt16_t986882611_SByte_t454417549,
	RuntimeInvoker_Void_t1841601450_Int16_t4041245914_Int16_t4041245914,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Il2CppObject_SByte_t454417549,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Int32_t2071877448_Int32_t2071877448_UInt16_t986882611,
	RuntimeInvoker_Position_t3781184359,
	RuntimeInvoker_UriHostNameType_t2148127109_Il2CppObject,
	RuntimeInvoker_Void_t1841601450_StringU26_t638738783,
	RuntimeInvoker_Il2CppObject_Il2CppObject_SByte_t454417549_SByte_t454417549_SByte_t454417549,
	RuntimeInvoker_Char_t3454481338_Il2CppObject_Int32U26_t455636984_CharU26_t1894467670,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_UriFormatExceptionU26_t1218551640,
	RuntimeInvoker_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject_Int32_t2071877448_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Sign_t874893936_Il2CppObject_Il2CppObject,
	RuntimeInvoker_ConfidenceFactor_t1997037802,
	RuntimeInvoker_UInt32_t2149682021_Int32_t2071877448_SByte_t454417549,
	RuntimeInvoker_Void_t1841601450_UInt32U26_t2197289955_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_SByte_t454417549,
	RuntimeInvoker_X509ChainStatusFlags_t2843686920,
	RuntimeInvoker_Void_t1841601450_Byte_t3683104436,
	RuntimeInvoker_Void_t1841601450_Byte_t3683104436_Byte_t3683104436,
	RuntimeInvoker_AlertLevel_t1706602846,
	RuntimeInvoker_AlertDescription_t844791462,
	RuntimeInvoker_Il2CppObject_Byte_t3683104436,
	RuntimeInvoker_Void_t1841601450_Int16_t4041245914_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_SByte_t454417549_SByte_t454417549_SByte_t454417549_SByte_t454417549_Int16_t4041245914_SByte_t454417549_SByte_t454417549,
	RuntimeInvoker_CipherAlgorithmType_t4212518094,
	RuntimeInvoker_HashAlgorithmType_t1654661965,
	RuntimeInvoker_ExchangeAlgorithmType_t954949548,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Int32_t2071877448_Int16_t4041245914,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Int32_t2071877448_Int64_t909078037,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_ByteU5BU5DU26_t790777611_ByteU5BU5DU26_t790777611,
	RuntimeInvoker_Il2CppObject_Byte_t3683104436_Il2CppObject,
	RuntimeInvoker_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject_Int32_t2071877448,
	RuntimeInvoker_Il2CppObject_Int16_t4041245914_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_SByte_t454417549_SByte_t454417549_SByte_t454417549_SByte_t454417549_Int16_t4041245914_SByte_t454417549_SByte_t454417549,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Int32_t2071877448_Il2CppObject_Il2CppObject,
	RuntimeInvoker_SecurityProtocolType_t155967584,
	RuntimeInvoker_SecurityCompressionType_t3722381418,
	RuntimeInvoker_HandshakeType_t2540099417,
	RuntimeInvoker_HandshakeState_t1820731088,
	RuntimeInvoker_SecurityProtocolType_t155967584_Int16_t4041245914,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Il2CppObject_Byte_t3683104436_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Il2CppObject_Byte_t3683104436_Il2CppObject_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Void_t1841601450_Byte_t3683104436_Il2CppObject,
	RuntimeInvoker_Il2CppObject_Byte_t3683104436_Il2CppObject_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Il2CppObject_SByte_t454417549_Int32_t2071877448_Il2CppObject,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Il2CppObject_Il2CppObject_Int32_t2071877448_Int32_t2071877448_SByte_t454417549_SByte_t454417549,
	RuntimeInvoker_Void_t1841601450_Byte_t3683104436_Byte_t3683104436_Il2CppObject,
	RuntimeInvoker_RSAParameters_t1462703416,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Byte_t3683104436_Byte_t3683104436,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Byte_t3683104436_Il2CppObject,
	RuntimeInvoker_ContentType_t859870085,
	RuntimeInvoker_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject,
	RuntimeInvoker_RuntimePlatform_t1869584967,
	RuntimeInvoker_Il2CppObject_Il2CppObject_Il2CppObject_Int32_t2071877448_Il2CppObject_Il2CppObject,
	RuntimeInvoker_OperatingSystemFamily_t1896948788,
	RuntimeInvoker_Rect_t3681755626,
	RuntimeInvoker_Void_t1841601450_RectU26_t844847526,
	RuntimeInvoker_CameraClearFlags_t452084705,
	RuntimeInvoker_Vector3_t2243707580_Vector3_t2243707580,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Vector3U26_t425862308_Vector3U26_t425862308,
	RuntimeInvoker_Ray_t2469606224_Vector3_t2243707580,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Vector3U26_t425862308_RayU26_t3651946800,
	RuntimeInvoker_Il2CppObject_Ray_t2469606224_Single_t2076509932_Int32_t2071877448,
	RuntimeInvoker_Il2CppObject_Il2CppObject_RayU26_t3651946800_Single_t2076509932_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Il2CppObject_Il2CppObject_RayU26_t3651946800_Single_t2076509932_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_IntPtr_t_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_CullingGroupEvent_t1057617917,
	RuntimeInvoker_Il2CppObject_CullingGroupEvent_t1057617917_Il2CppObject_Il2CppObject,
	RuntimeInvoker_CursorLockMode_t3372615096,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Il2CppObject_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Void_t1841601450_IntPtr_t_Int32U26_t455636984_Int32U26_t455636984,
	RuntimeInvoker_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Int32U26_t455636984_Int32U26_t455636984,
	RuntimeInvoker_Il2CppObject_Il2CppObject_SByte_t454417549_SByte_t454417549_SByte_t454417549_SByte_t454417549_Il2CppObject,
	RuntimeInvoker_Il2CppObject_Vector3_t2243707580,
	RuntimeInvoker_Il2CppObject_Il2CppObject_Vector3U26_t425862308,
	RuntimeInvoker_Il2CppObject_Il2CppObject_Int32_t2071877448_SByte_t454417549_SByte_t454417549_SByte_t454417549,
	RuntimeInvoker_Il2CppObject_Il2CppObject_Int32_t2071877448_SByte_t454417549_SByte_t454417549,
	RuntimeInvoker_Il2CppObject_Il2CppObject_Int32_t2071877448_SByte_t454417549_SByte_t454417549_SByte_t454417549_SByte_t454417549_Il2CppObject,
	RuntimeInvoker_Vector2_t2243707579,
	RuntimeInvoker_TouchPhase_t2458120420,
	RuntimeInvoker_TouchType_t2732027771,
	RuntimeInvoker_Vector3_t2243707580,
	RuntimeInvoker_Void_t1841601450_Vector3U26_t425862308,
	RuntimeInvoker_Void_t1841601450_Vector2U26_t3911752445,
	RuntimeInvoker_Touch_t407273883_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_TouchU26_t2094890781,
	RuntimeInvoker_IMECompositionMode_t1898275508,
	RuntimeInvoker_Void_t1841601450_Vector2_t2243707579,
	RuntimeInvoker_Int32_t2071877448_LayerMask_t3188175821,
	RuntimeInvoker_LayerMask_t3188175821_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_Single_t2076509932_Single_t2076509932_Single_t2076509932,
	RuntimeInvoker_Void_t1841601450_Single_t2076509932_Single_t2076509932,
	RuntimeInvoker_Vector3_t2243707580_Vector3_t2243707580_Vector3_t2243707580_Single_t2076509932,
	RuntimeInvoker_Single_t2076509932_Vector3_t2243707580_Vector3_t2243707580,
	RuntimeInvoker_Single_t2076509932_Vector3_t2243707580,
	RuntimeInvoker_Vector3_t2243707580_Vector3_t2243707580_Vector3_t2243707580,
	RuntimeInvoker_Vector3_t2243707580_Vector3_t2243707580_Single_t2076509932,
	RuntimeInvoker_Boolean_t3825574718_Vector3_t2243707580_Vector3_t2243707580,
	RuntimeInvoker_Void_t1841601450_Single_t2076509932_Single_t2076509932_Single_t2076509932_Single_t2076509932,
	RuntimeInvoker_Quaternion_t4030073918_Quaternion_t4030073918,
	RuntimeInvoker_Void_t1841601450_QuaternionU26_t4187826802_QuaternionU26_t4187826802,
	RuntimeInvoker_Quaternion_t4030073918_Single_t2076509932_Single_t2076509932_Single_t2076509932,
	RuntimeInvoker_Quaternion_t4030073918_Vector3_t2243707580,
	RuntimeInvoker_Void_t1841601450_Vector3U26_t425862308_QuaternionU26_t4187826802,
	RuntimeInvoker_Quaternion_t4030073918_Quaternion_t4030073918_Quaternion_t4030073918,
	RuntimeInvoker_Vector3_t2243707580_Quaternion_t4030073918_Vector3_t2243707580,
	RuntimeInvoker_Boolean_t3825574718_Quaternion_t4030073918_Quaternion_t4030073918,
	RuntimeInvoker_Single_t2076509932_Quaternion_t4030073918_Quaternion_t4030073918,
	RuntimeInvoker_Single_t2076509932_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Vector4_t2243707581_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_Vector3_t2243707580_Vector3_t2243707580,
	RuntimeInvoker_Void_t1841601450_Vector3_t2243707580,
	RuntimeInvoker_Boolean_t3825574718_Bounds_t3033363703_Bounds_t3033363703,
	RuntimeInvoker_Single_t2076509932_Single_t2076509932_Single_t2076509932,
	RuntimeInvoker_Single_t2076509932_Single_t2076509932_Single_t2076509932_Single_t2076509932,
	RuntimeInvoker_Boolean_t3825574718_Single_t2076509932_Single_t2076509932,
	RuntimeInvoker_Single_t2076509932_Single_t2076509932_Single_t2076509932_SingleU26_t4173844468_Single_t2076509932_Single_t2076509932_Single_t2076509932,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Il2CppObject_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Il2CppObject_Int32_t2071877448_SByte_t454417549,
	RuntimeInvoker_InternalShaderChannel_t3331827198_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Single_t2076509932_Single_t2076509932,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Single_t2076509932_Single_t2076509932,
	RuntimeInvoker_Vector4_t2243707581,
	RuntimeInvoker_Void_t1841601450_Vector4U26_t1234939467,
	RuntimeInvoker_Vector4_t2243707581_Il2CppObject,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Vector4U26_t1234939467,
	RuntimeInvoker_Vector2_t2243707579_Il2CppObject,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Vector2U26_t3911752445,
	RuntimeInvoker_TextureWrapMode_t3683976566,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_SByte_t454417549_SByte_t454417549_IntPtr_t,
	RuntimeInvoker_Color_t2020392075_Single_t2076509932_Single_t2076509932,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Single_t2076509932_Single_t2076509932_ColorU26_t3402129837,
	RuntimeInvoker_Void_t1841601450_Rect_t3681755626_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_RectU26_t844847526_Int32_t2071877448_Int32_t2071877448_SByte_t454417549,
	RuntimeInvoker_Quaternion_t4030073918,
	RuntimeInvoker_Void_t1841601450_Quaternion_t4030073918,
	RuntimeInvoker_Void_t1841601450_QuaternionU26_t4187826802,
	RuntimeInvoker_Matrix4x4_t2933234003,
	RuntimeInvoker_Void_t1841601450_Matrix4x4U26_t266301477,
	RuntimeInvoker_Void_t1841601450_Vector3_t2243707580_Int32_t2071877448,
	RuntimeInvoker_Il2CppObject_Il2CppObject_Vector3_t2243707580_Quaternion_t4030073918,
	RuntimeInvoker_Il2CppObject_Il2CppObject_Vector3U26_t425862308_QuaternionU26_t4187826802,
	RuntimeInvoker_Il2CppObject_Il2CppObject_Il2CppObject_Vector3_t2243707580_Quaternion_t4030073918,
	RuntimeInvoker_Il2CppObject_Il2CppObject_Il2CppObject_Vector3U26_t425862308_QuaternionU26_t4187826802,
	RuntimeInvoker_HideFlags_t1434274199,
	RuntimeInvoker_Il2CppObject_Il2CppObject_Vector3_t2243707580_Quaternion_t4030073918_Il2CppObject,
	RuntimeInvoker_Boolean_t3825574718_PlayableU26_t3233213460,
	RuntimeInvoker_Boolean_t3825574718_Playable_t3667545548_Playable_t3667545548_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_Playable_t3667545548_Int32_t2071877448,
	RuntimeInvoker_PlayState_t3250302433,
	RuntimeInvoker_PlayState_t3250302433_PlayableU26_t3233213460,
	RuntimeInvoker_Void_t1841601450_PlayableU26_t3233213460_Int32_t2071877448,
	RuntimeInvoker_Double_t4078015681_PlayableU26_t3233213460,
	RuntimeInvoker_Void_t1841601450_PlayableU26_t3233213460_Double_t4078015681,
	RuntimeInvoker_Int32_t2071877448_PlayableU26_t3233213460,
	RuntimeInvoker_Playable_t3667545548_Int32_t2071877448,
	RuntimeInvoker_Playable_t3667545548_PlayableU26_t3233213460_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_PlayableU26_t3233213460_Int32_t2071877448_PlayableU26_t3233213460,
	RuntimeInvoker_Void_t1841601450_PlayableU26_t3233213460_Int32_t2071877448_Single_t2076509932,
	RuntimeInvoker_Boolean_t3825574718_Int32_t2071877448_Single_t2076509932,
	RuntimeInvoker_Single_t2076509932_PlayableU26_t3233213460_Int32_t2071877448,
	RuntimeInvoker_Playable_t3667545548,
	RuntimeInvoker_GenericMixerPlayable_t788733994,
	RuntimeInvoker_Void_t1841601450_GenericMixerPlayableU26_t1620735334,
	RuntimeInvoker_Playable_t3667545548_GenericMixerPlayable_t788733994,
	RuntimeInvoker_Il2CppObject_Il2CppObject_IntPtr_t_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_PlayableU26_t3233213460,
	RuntimeInvoker_Boolean_t3825574718_PlayableU26_t3233213460_PlayableU26_t3233213460_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Boolean_t3825574718_Playable_t3667545548_Int32_t2071877448,
	RuntimeInvoker_Boolean_t3825574718_Playable_t3667545548,
	RuntimeInvoker_Int32_t2071877448_Playable_t3667545548_Il2CppObject,
	RuntimeInvoker_PlayState_t3250302433_Playable_t3667545548_Il2CppObject,
	RuntimeInvoker_Void_t1841601450_Playable_t3667545548_Int32_t2071877448_Il2CppObject,
	RuntimeInvoker_Double_t4078015681_Playable_t3667545548_Il2CppObject,
	RuntimeInvoker_Void_t1841601450_Playable_t3667545548_Double_t4078015681_Il2CppObject,
	RuntimeInvoker_Playable_t3667545548_Playable_t3667545548_Int32_t2071877448_Il2CppObject,
	RuntimeInvoker_Void_t1841601450_Playable_t3667545548_Int32_t2071877448_Single_t2076509932_Il2CppObject,
	RuntimeInvoker_Single_t2076509932_Playable_t3667545548_Int32_t2071877448_Il2CppObject,
	RuntimeInvoker_Boolean_t3825574718_Playable_t3667545548_Il2CppObject,
	RuntimeInvoker_Void_t1841601450_Scene_t1684909666_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_Scene_t1684909666,
	RuntimeInvoker_Void_t1841601450_Scene_t1684909666_Scene_t1684909666,
	RuntimeInvoker_Boolean_t3825574718_Vector3_t2243707580_Vector3_t2243707580_Single_t2076509932_Int32_t2071877448,
	RuntimeInvoker_Boolean_t3825574718_Vector3_t2243707580_Vector3_t2243707580_Single_t2076509932,
	RuntimeInvoker_Boolean_t3825574718_Vector3_t2243707580_Vector3_t2243707580_Single_t2076509932_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Boolean_t3825574718_Vector3_t2243707580_Vector3_t2243707580_RaycastHitU26_t1969197280_Single_t2076509932_Int32_t2071877448,
	RuntimeInvoker_Boolean_t3825574718_Vector3_t2243707580_Vector3_t2243707580_RaycastHitU26_t1969197280_Single_t2076509932,
	RuntimeInvoker_Boolean_t3825574718_Vector3_t2243707580_Vector3_t2243707580_RaycastHitU26_t1969197280,
	RuntimeInvoker_Boolean_t3825574718_Vector3_t2243707580_Vector3_t2243707580_RaycastHitU26_t1969197280_Single_t2076509932_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Boolean_t3825574718_Ray_t2469606224_Single_t2076509932_Int32_t2071877448,
	RuntimeInvoker_Boolean_t3825574718_Ray_t2469606224_Single_t2076509932,
	RuntimeInvoker_Boolean_t3825574718_Ray_t2469606224,
	RuntimeInvoker_Boolean_t3825574718_Ray_t2469606224_Single_t2076509932_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Boolean_t3825574718_Ray_t2469606224_RaycastHitU26_t1969197280_Single_t2076509932_Int32_t2071877448,
	RuntimeInvoker_Boolean_t3825574718_Ray_t2469606224_RaycastHitU26_t1969197280_Single_t2076509932,
	RuntimeInvoker_Boolean_t3825574718_Ray_t2469606224_RaycastHitU26_t1969197280,
	RuntimeInvoker_Boolean_t3825574718_Ray_t2469606224_RaycastHitU26_t1969197280_Single_t2076509932_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Il2CppObject_Ray_t2469606224_Single_t2076509932,
	RuntimeInvoker_Il2CppObject_Ray_t2469606224,
	RuntimeInvoker_Il2CppObject_Ray_t2469606224_Single_t2076509932_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Il2CppObject_Vector3_t2243707580_Vector3_t2243707580_Single_t2076509932_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Il2CppObject_Vector3_t2243707580_Vector3_t2243707580_Single_t2076509932_Int32_t2071877448,
	RuntimeInvoker_Il2CppObject_Vector3_t2243707580_Vector3_t2243707580_Single_t2076509932,
	RuntimeInvoker_Il2CppObject_Vector3_t2243707580_Vector3_t2243707580,
	RuntimeInvoker_Il2CppObject_Vector3U26_t425862308_Vector3U26_t425862308_Single_t2076509932_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Boolean_t3825574718_Vector3U26_t425862308_Vector3U26_t425862308_RaycastHitU26_t1969197280_Single_t2076509932_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Boolean_t3825574718_Vector3U26_t425862308_Vector3U26_t425862308_Single_t2076509932_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_Vector2_t2243707579_Vector2_t2243707579_Single_t2076509932_Int32_t2071877448_Single_t2076509932_Single_t2076509932_RaycastHit2DU26_t4207306570,
	RuntimeInvoker_Void_t1841601450_Vector2U26_t3911752445_Vector2U26_t3911752445_Single_t2076509932_Int32_t2071877448_Single_t2076509932_Single_t2076509932_RaycastHit2DU26_t4207306570,
	RuntimeInvoker_RaycastHit2D_t4063908774_Vector2_t2243707579_Vector2_t2243707579_Single_t2076509932_Int32_t2071877448_Single_t2076509932,
	RuntimeInvoker_RaycastHit2D_t4063908774_Vector2_t2243707579_Vector2_t2243707579_Single_t2076509932_Int32_t2071877448,
	RuntimeInvoker_RaycastHit2D_t4063908774_Vector2_t2243707579_Vector2_t2243707579_Single_t2076509932,
	RuntimeInvoker_RaycastHit2D_t4063908774_Vector2_t2243707579_Vector2_t2243707579,
	RuntimeInvoker_RaycastHit2D_t4063908774_Vector2_t2243707579_Vector2_t2243707579_Single_t2076509932_Int32_t2071877448_Single_t2076509932_Single_t2076509932,
	RuntimeInvoker_Il2CppObject_RayU26_t3651946800_Single_t2076509932_Int32_t2071877448,
	RuntimeInvoker_Il2CppObject_SByte_t454417549_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Il2CppObject_Int32_t2071877448_Il2CppObject_Il2CppObject,
	RuntimeInvoker_SendMessageOptions_t1414041951,
	RuntimeInvoker_AnimatorStateInfo_t2577870592,
	RuntimeInvoker_AnimatorClipInfo_t3905751349,
	RuntimeInvoker_Playable_t3667545548_AnimatorControllerPlayable_t4078305555,
	RuntimeInvoker_Int32_t2071877448_Playable_t3667545548,
	RuntimeInvoker_Playable_t3667545548_AnimationPlayable_t1693994278,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_IntPtr_t,
	RuntimeInvoker_Playable_t3667545548_Il2CppObject,
	RuntimeInvoker_AnimationPlayable_t1693994278_Il2CppObject,
	RuntimeInvoker_Void_t1841601450_FrameData_t1120735295,
	RuntimeInvoker_Boolean_t3825574718_Color_t2020392075_Color_t2020392075,
	RuntimeInvoker_Boolean_t3825574718_Vector2_t2243707579_Vector2_t2243707579,
	RuntimeInvoker_Boolean_t3825574718_TextGenerationSettings_t2543476768,
	RuntimeInvoker_TextGenerationSettings_t2543476768_TextGenerationSettings_t2543476768,
	RuntimeInvoker_Single_t2076509932_Il2CppObject_TextGenerationSettings_t2543476768,
	RuntimeInvoker_Boolean_t3825574718_Il2CppObject_TextGenerationSettings_t2543476768_Il2CppObject,
	RuntimeInvoker_Boolean_t3825574718_Il2CppObject_TextGenerationSettings_t2543476768,
	RuntimeInvoker_TextGenerationError_t780770201_Il2CppObject_TextGenerationSettings_t2543476768,
	RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Il2CppObject_Color_t2020392075_Int32_t2071877448_Single_t2076509932_Single_t2076509932_Int32_t2071877448_SByte_t454417549_SByte_t454417549_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_SByte_t454417549_Int32_t2071877448_Vector2_t2243707579_Vector2_t2243707579_SByte_t454417549_SByte_t454417549_TextGenerationErrorU26_t1427792335,
	RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Il2CppObject_Color_t2020392075_Int32_t2071877448_Single_t2076509932_Single_t2076509932_Int32_t2071877448_SByte_t454417549_SByte_t454417549_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_SByte_t454417549_Int32_t2071877448_Single_t2076509932_Single_t2076509932_Single_t2076509932_Single_t2076509932_SByte_t454417549_SByte_t454417549_UInt32U26_t2197289955,
	RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Il2CppObject_Il2CppObject_ColorU26_t3402129837_Int32_t2071877448_Single_t2076509932_Single_t2076509932_Int32_t2071877448_SByte_t454417549_SByte_t454417549_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_SByte_t454417549_Int32_t2071877448_Single_t2076509932_Single_t2076509932_Single_t2076509932_Single_t2076509932_SByte_t454417549_SByte_t454417549_UInt32U26_t2197289955,
	RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Vector2_t2243707579_Il2CppObject_Vector3U26_t425862308,
	RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Vector2_t2243707579_Il2CppObject_Vector2U26_t3911752445,
	RuntimeInvoker_Ray_t2469606224_Il2CppObject_Vector2_t2243707579,
	RuntimeInvoker_Vector2_t2243707579_Vector2_t2243707579,
	RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Vector2_t2243707579_Il2CppObject,
	RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Vector2U26_t3911752445_Il2CppObject,
	RuntimeInvoker_Vector2_t2243707579_Vector2_t2243707579_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Void_t1841601450_Vector2U26_t3911752445_Il2CppObject_Il2CppObject_Vector2U26_t3911752445,
	RuntimeInvoker_Rect_t3681755626_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Il2CppObject_RectU26_t844847526,
	RuntimeInvoker_RenderMode_t4280533217,
	RuntimeInvoker_Boolean_t3825574718_Vector2_t2243707579_Il2CppObject,
	RuntimeInvoker_Void_t1841601450_Color_t2020392075,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_ColorU26_t3402129837,
	RuntimeInvoker_Color_t2020392075,
	RuntimeInvoker_Void_t1841601450_Rect_t3681755626,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_RectU26_t844847526,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject,
	RuntimeInvoker_EventType_t3919834026,
	RuntimeInvoker_EventModifiers_t2690251474,
	RuntimeInvoker_KeyCode_t2283395152,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Int32_t2071877448_Il2CppObject_Int32_t2071877448_Single_t2076509932_Single_t2076509932_Il2CppObject,
	RuntimeInvoker_Il2CppObject_Single_t2076509932,
	RuntimeInvoker_Void_t1841601450_Single_t2076509932_Single_t2076509932_Single_t2076509932_Single_t2076509932_Il2CppObject,
	RuntimeInvoker_Rect_t3681755626_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_RectU26_t844847526,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Rect_t3681755626,
	RuntimeInvoker_Il2CppObject_Il2CppObject_IntPtr_t,
	RuntimeInvoker_Void_t1841601450_ColorU26_t3402129837,
	RuntimeInvoker_Void_t1841601450_IntPtr_t_Rect_t3681755626_Il2CppObject_SByte_t454417549_SByte_t454417549_SByte_t454417549_SByte_t454417549,
	RuntimeInvoker_Void_t1841601450_Rect_t3681755626_SByte_t454417549_SByte_t454417549_SByte_t454417549_SByte_t454417549,
	RuntimeInvoker_Void_t1841601450_Rect_t3681755626_Il2CppObject_SByte_t454417549_SByte_t454417549_SByte_t454417549_SByte_t454417549,
	RuntimeInvoker_Void_t1841601450_Rect_t3681755626_Il2CppObject_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_Rect_t3681755626_Il2CppObject_Int32_t2071877448_SByte_t454417549,
	RuntimeInvoker_Void_t1841601450_Rect_t3681755626_Il2CppObject_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_Rect_t3681755626_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_SByte_t454417549,
	RuntimeInvoker_Void_t1841601450_Rect_t3681755626_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Vector2_t2243707579_Rect_t3681755626_Il2CppObject_Int32_t2071877448,
	RuntimeInvoker_Int32_t2071877448_Rect_t3681755626_Il2CppObject_Vector2_t2243707579,
	RuntimeInvoker_Int32_t2071877448_Il2CppObject_Single_t2076509932,
	RuntimeInvoker_Vector2_t2243707579_Il2CppObject_Vector2_t2243707579,
	RuntimeInvoker_Single_t2076509932_Il2CppObject_Single_t2076509932,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_SingleU26_t4173844468_SingleU26_t4173844468,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Int32_t2071877448_IntPtrU26_t1981417703,
	RuntimeInvoker_ImagePosition_t3491916276,
	RuntimeInvoker_TextAnchor_t112990806,
	RuntimeInvoker_TextClipping_t2573530411,
	RuntimeInvoker_Single_t2076509932_IntPtr_t,
	RuntimeInvoker_FontStyle_t2764949590,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Internal_DrawArgumentsU26_t3595831378,
	RuntimeInvoker_Void_t1841601450_IntPtr_t_Rect_t3681755626_Il2CppObject_Int32_t2071877448_SByte_t454417549,
	RuntimeInvoker_Void_t1841601450_IntPtr_t_RectU26_t844847526_Il2CppObject_Int32_t2071877448_SByte_t454417549,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Rect_t3681755626,
	RuntimeInvoker_Void_t1841601450_IntPtr_t_Rect_t3681755626_Il2CppObject_Int32_t2071877448_Color_t2020392075,
	RuntimeInvoker_Void_t1841601450_IntPtr_t_RectU26_t844847526_Il2CppObject_Int32_t2071877448_ColorU26_t3402129837,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Internal_DrawWithTextSelectionArgumentsU26_t807284931,
	RuntimeInvoker_Void_t1841601450_IntPtr_t_Rect_t3681755626_Il2CppObject_Int32_t2071877448_Vector2U26_t3911752445,
	RuntimeInvoker_Void_t1841601450_IntPtr_t_RectU26_t844847526_Il2CppObject_Int32_t2071877448_Vector2U26_t3911752445,
	RuntimeInvoker_Int32_t2071877448_IntPtr_t_Rect_t3681755626_Il2CppObject_Vector2_t2243707579,
	RuntimeInvoker_Int32_t2071877448_IntPtr_t_RectU26_t844847526_Il2CppObject_Vector2U26_t3911752445,
	RuntimeInvoker_Int32_t2071877448_IntPtr_t_Il2CppObject_Single_t2076509932,
	RuntimeInvoker_Void_t1841601450_IntPtr_t_Il2CppObject_Vector2U26_t3911752445,
	RuntimeInvoker_Void_t1841601450_IntPtr_t_Il2CppObject_Vector2_t2243707579_Vector2U26_t3911752445,
	RuntimeInvoker_Void_t1841601450_IntPtr_t_Il2CppObject_Vector2U26_t3911752445_Vector2U26_t3911752445,
	RuntimeInvoker_Single_t2076509932_IntPtr_t_Il2CppObject_Single_t2076509932,
	RuntimeInvoker_Void_t1841601450_IntPtr_t_Il2CppObject_SingleU26_t4173844468_SingleU26_t4173844468,
	RuntimeInvoker_Color_t2020392075_Color_t2020392075_Single_t2076509932,
	RuntimeInvoker_Color_t2020392075_Color_t2020392075_Color_t2020392075_Single_t2076509932,
	RuntimeInvoker_Vector4_t2243707581_Color_t2020392075,
	RuntimeInvoker_Color32_t874517518_Color_t2020392075,
	RuntimeInvoker_Color_t2020392075_Color32_t874517518,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_HitInfo_t1761367055,
	RuntimeInvoker_Boolean_t3825574718_HitInfo_t1761367055,
	RuntimeInvoker_Boolean_t3825574718_HitInfo_t1761367055_HitInfo_t1761367055,
	RuntimeInvoker_Boolean_t3825574718_Ray_t2469606224_SingleU26_t4173844468,
	RuntimeInvoker_Vector3_t2243707580_Single_t2076509932,
	RuntimeInvoker_Boolean_t3825574718_Vector2_t2243707579,
	RuntimeInvoker_Boolean_t3825574718_Vector3_t2243707580,
	RuntimeInvoker_Rect_t3681755626_Rect_t3681755626,
	RuntimeInvoker_Boolean_t3825574718_Rect_t3681755626,
	RuntimeInvoker_Boolean_t3825574718_Rect_t3681755626_SByte_t454417549,
	RuntimeInvoker_Boolean_t3825574718_Rect_t3681755626_Rect_t3681755626,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_StringU26_t638738783_StringU26_t638738783,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_AnimatorStateInfo_t2577870592_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_AnimatorStateInfo_t2577870592_Int32_t2071877448_AnimatorControllerPlayable_t4078305555,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Int32_t2071877448_AnimatorControllerPlayable_t4078305555,
	RuntimeInvoker_PersistentListenerMode_t857969000,
	RuntimeInvoker_Vector2_t2243707579_Vector2_t2243707579_Vector2_t2243707579,
	RuntimeInvoker_Single_t2076509932_Vector2_t2243707579_Vector2_t2243707579,
	RuntimeInvoker_Vector2_t2243707579_Vector2_t2243707579_Single_t2076509932,
	RuntimeInvoker_Vector2_t2243707579_Vector3_t2243707580,
	RuntimeInvoker_Vector3_t2243707580_Vector2_t2243707579,
	RuntimeInvoker_Single_t2076509932_Vector4_t2243707581_Vector4_t2243707581,
	RuntimeInvoker_Vector4_t2243707581_Vector4_t2243707581_Vector4_t2243707581,
	RuntimeInvoker_Vector4_t2243707581_Vector4_t2243707581_Single_t2076509932,
	RuntimeInvoker_Boolean_t3825574718_Vector4_t2243707581_Vector4_t2243707581,
	RuntimeInvoker_Single_t2076509932_Vector4_t2243707581,
	RuntimeInvoker_Int32_t2071877448_AnimationPlayable_t1693994278_Playable_t3667545548_Il2CppObject,
	RuntimeInvoker_Boolean_t3825574718_AnimationPlayable_t1693994278_Playable_t3667545548_Int32_t2071877448_Il2CppObject,
	RuntimeInvoker_Boolean_t3825574718_AnimationPlayable_t1693994278_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Boolean_t3825574718_AnimationPlayable_t1693994278_Int32_t2071877448_Il2CppObject,
	RuntimeInvoker_Boolean_t3825574718_AnimationPlayable_t1693994278_Il2CppObject,
	RuntimeInvoker_LogType_t1559732862,
	RuntimeInvoker_Int32_t2071877448_RaycastResult_t21186376_RaycastResult_t21186376,
	RuntimeInvoker_MoveDirection_t1406276862,
	RuntimeInvoker_RaycastResult_t21186376,
	RuntimeInvoker_Void_t1841601450_RaycastResult_t21186376,
	RuntimeInvoker_InputButton_t2981963041,
	RuntimeInvoker_RaycastResult_t21186376_Il2CppObject,
	RuntimeInvoker_MoveDirection_t1406276862_Single_t2076509932_Single_t2076509932,
	RuntimeInvoker_MoveDirection_t1406276862_Single_t2076509932_Single_t2076509932_Single_t2076509932,
	RuntimeInvoker_Il2CppObject_Single_t2076509932_Single_t2076509932_Single_t2076509932,
	RuntimeInvoker_Boolean_t3825574718_Int32_t2071877448_PointerEventDataU26_t2885421157_SByte_t454417549,
	RuntimeInvoker_Il2CppObject_Touch_t407273883_BooleanU26_t3168250738_BooleanU26_t3168250738,
	RuntimeInvoker_FramePressState_t1414739712_Int32_t2071877448,
	RuntimeInvoker_Boolean_t3825574718_Vector2_t2243707579_Vector2_t2243707579_Single_t2076509932_SByte_t454417549,
	RuntimeInvoker_InputMode_t2680906638,
	RuntimeInvoker_LayerMask_t3188175821,
	RuntimeInvoker_Void_t1841601450_LayerMask_t3188175821,
	RuntimeInvoker_Int32_t2071877448_RaycastHit_t87180320_RaycastHit_t87180320,
	RuntimeInvoker_ColorTweenMode_t1328781136,
	RuntimeInvoker_ColorBlock_t2652774230,
	RuntimeInvoker_Boolean_t3825574718_ColorBlock_t2652774230,
	RuntimeInvoker_Boolean_t3825574718_ColorBlock_t2652774230_ColorBlock_t2652774230,
	RuntimeInvoker_Il2CppObject_Il2CppObject_Vector2_t2243707579,
	RuntimeInvoker_Il2CppObject_Resources_t2975512894,
	RuntimeInvoker_Il2CppObject_Il2CppObject_SByte_t454417549_Il2CppObject_Il2CppObject,
	RuntimeInvoker_HorizontalWrapMode_t2027154177,
	RuntimeInvoker_VerticalWrapMode_t3668245347,
	RuntimeInvoker_Void_t1841601450_Color_t2020392075_Single_t2076509932_SByte_t454417549_SByte_t454417549,
	RuntimeInvoker_Void_t1841601450_Color_t2020392075_Single_t2076509932_SByte_t454417549_SByte_t454417549_SByte_t454417549,
	RuntimeInvoker_Color_t2020392075_Single_t2076509932,
	RuntimeInvoker_Void_t1841601450_Single_t2076509932_Single_t2076509932_SByte_t454417549,
	RuntimeInvoker_BlockingObjects_t2548930813,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Il2CppObject_Vector2_t2243707579_Il2CppObject,
	RuntimeInvoker_Type_t3352948571,
	RuntimeInvoker_FillMethod_t1640962579,
	RuntimeInvoker_Vector4_t2243707581_SByte_t454417549,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Il2CppObject_Color32_t874517518_Il2CppObject,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Vector2_t2243707579_Vector2_t2243707579_Color32_t874517518_Vector2_t2243707579_Vector2_t2243707579,
	RuntimeInvoker_Vector4_t2243707581_Vector4_t2243707581_Rect_t3681755626,
	RuntimeInvoker_Boolean_t3825574718_Il2CppObject_Il2CppObject_Single_t2076509932_SByte_t454417549_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Single_t2076509932_Single_t2076509932_SByte_t454417549_Int32_t2071877448,
	RuntimeInvoker_Vector2_t2243707579_Vector2_t2243707579_Rect_t3681755626,
	RuntimeInvoker_ContentType_t1028629049,
	RuntimeInvoker_LineType_t2931319356,
	RuntimeInvoker_InputType_t1274231802,
	RuntimeInvoker_TouchScreenKeyboardType_t875112366,
	RuntimeInvoker_CharacterValidation_t3437478890,
	RuntimeInvoker_Void_t1841601450_Int32U26_t455636984,
	RuntimeInvoker_Int32_t2071877448_Vector2_t2243707579_Il2CppObject,
	RuntimeInvoker_Int32_t2071877448_Vector2_t2243707579,
	RuntimeInvoker_EditState_t1111987863_Il2CppObject,
	RuntimeInvoker_Int32_t2071877448_Int32_t2071877448_Il2CppObject,
	RuntimeInvoker_Int32_t2071877448_Int32_t2071877448_SByte_t454417549,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Vector2_t2243707579,
	RuntimeInvoker_Char_t3454481338_Il2CppObject_Int32_t2071877448_Int16_t4041245914,
	RuntimeInvoker_Il2CppObject_Il2CppObject_Int32_t2071877448_Int16_t4041245914_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Void_t1841601450_Rect_t3681755626_SByte_t454417549,
	RuntimeInvoker_Mode_t1081683921,
	RuntimeInvoker_Navigation_t1571958496,
	RuntimeInvoker_Boolean_t3825574718_Navigation_t1571958496,
	RuntimeInvoker_Direction_t3696775921,
	RuntimeInvoker_Void_t1841601450_Single_t2076509932_SByte_t454417549,
	RuntimeInvoker_Axis_t2427050347,
	RuntimeInvoker_MovementType_t905360158,
	RuntimeInvoker_ScrollbarVisibility_t3834843475,
	RuntimeInvoker_Void_t1841601450_Single_t2076509932_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_SByte_t454417549_SByte_t454417549_Int32_t2071877448_Il2CppObject,
	RuntimeInvoker_Void_t1841601450_BoundsU26_t1084128289_Vector2U26_t3911752445_Vector3U26_t425862308_Vector3U26_t425862308,
	RuntimeInvoker_Bounds_t3033363703,
	RuntimeInvoker_Bounds_t3033363703_Il2CppObject_Matrix4x4U26_t266301477,
	RuntimeInvoker_Vector2_t2243707579_BoundsU26_t1084128289_BoundsU26_t1084128289_SByte_t454417549_SByte_t454417549_Int32_t2071877448_Vector2U26_t3911752445,
	RuntimeInvoker_Void_t1841601450_Navigation_t1571958496,
	RuntimeInvoker_Transition_t605142169,
	RuntimeInvoker_Void_t1841601450_ColorBlock_t2652774230,
	RuntimeInvoker_SpriteState_t1353336012,
	RuntimeInvoker_Void_t1841601450_SpriteState_t1353336012,
	RuntimeInvoker_SelectionState_t3187567897,
	RuntimeInvoker_Vector3_t2243707580_Il2CppObject_Vector2_t2243707579,
	RuntimeInvoker_Void_t1841601450_Color_t2020392075_SByte_t454417549,
	RuntimeInvoker_Boolean_t3825574718_ColorU26_t3402129837_Color_t2020392075,
	RuntimeInvoker_Direction_t1525323322,
	RuntimeInvoker_Axis_t375128448,
	RuntimeInvoker_Boolean_t3825574718_SpriteState_t1353336012,
	RuntimeInvoker_Il2CppObject_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Il2CppObject_Il2CppObject_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_TextGenerationSettings_t2543476768_Vector2_t2243707579,
	RuntimeInvoker_Vector2_t2243707579_Int32_t2071877448,
	RuntimeInvoker_Rect_t3681755626_Il2CppObject_BooleanU26_t3168250738,
	RuntimeInvoker_Rect_t3681755626_Rect_t3681755626_Rect_t3681755626,
	RuntimeInvoker_AspectMode_t1166448724,
	RuntimeInvoker_Single_t2076509932_Single_t2076509932_Int32_t2071877448,
	RuntimeInvoker_ScaleMode_t987318053,
	RuntimeInvoker_ScreenMatchMode_t1916789528,
	RuntimeInvoker_Unit_t3220761768,
	RuntimeInvoker_FitMode_t4030874534,
	RuntimeInvoker_Corner_t1077473318,
	RuntimeInvoker_Axis_t1431825778,
	RuntimeInvoker_Constraint_t3558160636,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Int32_t2071877448_SByte_t454417549_SByte_t454417549_SingleU26_t4173844468_SingleU26_t4173844468_SingleU26_t4173844468,
	RuntimeInvoker_Single_t2076509932_Int32_t2071877448_Single_t2076509932,
	RuntimeInvoker_Void_t1841601450_Single_t2076509932_Single_t2076509932_Single_t2076509932_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Int32_t2071877448_Single_t2076509932,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Int32_t2071877448_Single_t2076509932_Single_t2076509932,
	RuntimeInvoker_Single_t2076509932_Il2CppObject_Il2CppObject_Single_t2076509932,
	RuntimeInvoker_Single_t2076509932_Il2CppObject_Il2CppObject_Single_t2076509932_ILayoutElementU26_t440254879,
	RuntimeInvoker_Il2CppObject_Ray_t2469606224_RaycastHitU26_t1969197280_Single_t2076509932_Int32_t2071877448_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Boolean_t3825574718_RaycastHitU26_t1969197280_Il2CppObject,
	RuntimeInvoker_Il2CppObject_Vector2_t2243707579_Vector2_t2243707579_Single_t2076509932_Int32_t2071877448_Il2CppObject_Il2CppObject,
	RuntimeInvoker_RaycastHit2D_t4063908774_Il2CppObject,
	RuntimeInvoker_Il2CppObject_Ray_t2469606224_Single_t2076509932_Int32_t2071877448_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Void_t1841601450_UIVertexU26_t1130679118_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_UIVertex_t1204258818_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_Vector3_t2243707580_Color32_t874517518_Vector2_t2243707579_Vector2_t2243707579_Vector3_t2243707580_Vector4_t2243707581,
	RuntimeInvoker_Void_t1841601450_Vector3_t2243707580_Color32_t874517518_Vector2_t2243707579,
	RuntimeInvoker_Void_t1841601450_UIVertex_t1204258818,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Color32_t874517518_Int32_t2071877448_Int32_t2071877448_Single_t2076509932_Single_t2076509932,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_ObjectU26_t597476745,
	RuntimeInvoker_Void_t1841601450_ObjectU5BU5DU26_t3223402458_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_ObjectU5BU5DU26_t3223402458_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_KeyValuePair_2_t38854645,
	RuntimeInvoker_Boolean_t3825574718_KeyValuePair_2_t38854645,
	RuntimeInvoker_KeyValuePair_2_t38854645_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Boolean_t3825574718_Il2CppObject_ObjectU26_t597476745,
	RuntimeInvoker_Enumerator_t3601534125,
	RuntimeInvoker_DictionaryEntry_t3048875398_Il2CppObject_Il2CppObject,
	RuntimeInvoker_KeyValuePair_2_t38854645,
	RuntimeInvoker_Enumerator_t3968042187,
	RuntimeInvoker_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Il2CppObject,
	RuntimeInvoker_Enumerator_t1593300101,
	RuntimeInvoker_Il2CppObject_ObjectU26_t597476745_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Boolean_t3825574718_ArraySegment_1_t1600562341,
	RuntimeInvoker_Enumerator_t132208513,
	RuntimeInvoker_Boolean_t3825574718_Int32_t2071877448_Int32_t2071877448_Il2CppObject,
	RuntimeInvoker_Enumerator_t3806193287,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Int32_t2071877448_Int32_t2071877448_Il2CppObject,
	RuntimeInvoker_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Boolean_t3825574718_ObjectU26_t597476745_Il2CppObject,
	RuntimeInvoker_Void_t1841601450_ObjectU26_t597476745_Il2CppObject,
	RuntimeInvoker_Void_t1841601450_Il2CppObject_Il2CppObject_Single_t2076509932,
	RuntimeInvoker_Void_t1841601450_Playable_t3667545548,
	RuntimeInvoker_Boolean_t3825574718_Int32_t2071877448_ObjectU26_t597476745,
	RuntimeInvoker_RaycastResult_t21186376_Int32_t2071877448,
	RuntimeInvoker_Enumerator_t3383807694,
	RuntimeInvoker_Enumerator_t3017299632,
	RuntimeInvoker_KeyValuePair_2_t3749587448,
	RuntimeInvoker_Boolean_t3825574718_AspectModeU26_t218518220_Int32_t2071877448,
	RuntimeInvoker_Boolean_t3825574718_SingleU26_t4173844468_Single_t2076509932,
	RuntimeInvoker_Boolean_t3825574718_FitModeU26_t1633941322_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_FloatTween_t2986189219,
	RuntimeInvoker_Void_t1841601450_ColorTween_t3438117476,
	RuntimeInvoker_Void_t1841601450_CornerU26_t4129226442_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_AxisU26_t4174374750_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_Vector2U26_t3911752445_Vector2_t2243707579,
	RuntimeInvoker_Void_t1841601450_ConstraintU26_t2775779428_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_Int32U26_t455636984_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_SingleU26_t4173844468_Single_t2076509932,
	RuntimeInvoker_Void_t1841601450_BooleanU26_t3168250738_SByte_t454417549,
	RuntimeInvoker_Boolean_t3825574718_TypeU26_t1535498077_Int32_t2071877448,
	RuntimeInvoker_Boolean_t3825574718_BooleanU26_t3168250738_SByte_t454417549,
	RuntimeInvoker_Boolean_t3825574718_FillMethodU26_t21572965_Int32_t2071877448,
	RuntimeInvoker_Boolean_t3825574718_ContentTypeU26_t1802785839_Int32_t2071877448,
	RuntimeInvoker_Boolean_t3825574718_LineTypeU26_t3325440292_Int32_t2071877448,
	RuntimeInvoker_Boolean_t3825574718_InputTypeU26_t4050577942_Int32_t2071877448,
	RuntimeInvoker_Boolean_t3825574718_TouchScreenKeyboardTypeU26_t2194866306_Int32_t2071877448,
	RuntimeInvoker_Boolean_t3825574718_CharacterValidationU26_t193398694_Int32_t2071877448,
	RuntimeInvoker_Boolean_t3825574718_CharU26_t1894467670_Int16_t4041245914,
	RuntimeInvoker_Void_t1841601450_TextAnchorU26_t200487962_Int32_t2071877448,
	RuntimeInvoker_Boolean_t3825574718_DirectionU26_t2846495799_Int32_t2071877448,
	RuntimeInvoker_Boolean_t3825574718_NavigationU26_t3929175072_Navigation_t1571958496,
	RuntimeInvoker_Boolean_t3825574718_TransitionU26_t3012618447_Int32_t2071877448,
	RuntimeInvoker_Boolean_t3825574718_ColorBlockU26_t1586591514_ColorBlock_t2652774230,
	RuntimeInvoker_Boolean_t3825574718_SpriteStateU26_t1330646292_SpriteState_t1353336012,
	RuntimeInvoker_UIVertex_t1204258818_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_UIVertex_t1204258818,
	RuntimeInvoker_Boolean_t3825574718_DirectionU26_t743901654_Int32_t2071877448,
	RuntimeInvoker_Vector3_t2243707580_Int32_t2071877448,
	RuntimeInvoker_Color32_t874517518_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Vector3_t2243707580,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Color32_t874517518,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Vector2_t2243707579,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Vector4_t2243707581,
	RuntimeInvoker_Void_t1841601450_Color32_t874517518,
	RuntimeInvoker_Void_t1841601450_Vector4_t2243707581,
	RuntimeInvoker_Boolean_t3825574718_TableRange_t2011406615,
	RuntimeInvoker_Boolean_t3825574718_ArraySegment_1_t2594217482,
	RuntimeInvoker_Boolean_t3825574718_DictionaryEntry_t3048875398,
	RuntimeInvoker_Boolean_t3825574718_Link_t865133271,
	RuntimeInvoker_Boolean_t3825574718_KeyValuePair_2_t3749587448,
	RuntimeInvoker_Boolean_t3825574718_KeyValuePair_2_t1174980068,
	RuntimeInvoker_Boolean_t3825574718_KeyValuePair_2_t3716250094,
	RuntimeInvoker_Boolean_t3825574718_Link_t2723257478,
	RuntimeInvoker_Boolean_t3825574718_Slot_t2022531261,
	RuntimeInvoker_Boolean_t3825574718_Slot_t2267560602,
	RuntimeInvoker_Boolean_t3825574718_CustomAttributeNamedArgument_t94157543,
	RuntimeInvoker_Boolean_t3825574718_CustomAttributeTypedArgument_t1498197914,
	RuntimeInvoker_Boolean_t3825574718_LabelData_t3712112744,
	RuntimeInvoker_Boolean_t3825574718_LabelFixup_t4090909514,
	RuntimeInvoker_Boolean_t3825574718_ILTokenInfo_t149559338,
	RuntimeInvoker_Boolean_t3825574718_ParameterModifier_t1820634920,
	RuntimeInvoker_Boolean_t3825574718_ResourceCacheItem_t333236149,
	RuntimeInvoker_Boolean_t3825574718_ResourceInfo_t3933049236,
	RuntimeInvoker_Boolean_t3825574718_Byte_t3683104436,
	RuntimeInvoker_Boolean_t3825574718_X509ChainStatus_t4278378721,
	RuntimeInvoker_Boolean_t3825574718_Mark_t2724874473,
	RuntimeInvoker_Boolean_t3825574718_UriScheme_t1876590943,
	RuntimeInvoker_Boolean_t3825574718_Color32_t874517518,
	RuntimeInvoker_Boolean_t3825574718_ContactPoint_t1376425630,
	RuntimeInvoker_Boolean_t3825574718_ContactPoint2D_t3659330976,
	RuntimeInvoker_Boolean_t3825574718_RaycastResult_t21186376,
	RuntimeInvoker_Boolean_t3825574718_Keyframe_t1449471340,
	RuntimeInvoker_Boolean_t3825574718_RaycastHit_t87180320,
	RuntimeInvoker_Boolean_t3825574718_RaycastHit2D_t4063908774,
	RuntimeInvoker_Boolean_t3825574718_UICharInfo_t3056636800,
	RuntimeInvoker_Boolean_t3825574718_UILineInfo_t3621277874,
	RuntimeInvoker_Boolean_t3825574718_UIVertex_t1204258818,
	RuntimeInvoker_Boolean_t3825574718_Vector4_t2243707581,
	RuntimeInvoker_Int32_t2071877448_CustomAttributeNamedArgument_t94157543_CustomAttributeNamedArgument_t94157543_Il2CppObject,
	RuntimeInvoker_Int32_t2071877448_CustomAttributeTypedArgument_t1498197914_CustomAttributeTypedArgument_t1498197914_Il2CppObject,
	RuntimeInvoker_Int32_t2071877448_Color32_t874517518_Color32_t874517518_Il2CppObject,
	RuntimeInvoker_Int32_t2071877448_RaycastResult_t21186376_RaycastResult_t21186376_Il2CppObject,
	RuntimeInvoker_Int32_t2071877448_Playable_t3667545548_Playable_t3667545548_Il2CppObject,
	RuntimeInvoker_Int32_t2071877448_UICharInfo_t3056636800_UICharInfo_t3056636800_Il2CppObject,
	RuntimeInvoker_Int32_t2071877448_UILineInfo_t3621277874_UILineInfo_t3621277874_Il2CppObject,
	RuntimeInvoker_Int32_t2071877448_UIVertex_t1204258818_UIVertex_t1204258818_Il2CppObject,
	RuntimeInvoker_Int32_t2071877448_Vector2_t2243707579_Vector2_t2243707579_Il2CppObject,
	RuntimeInvoker_Int32_t2071877448_Vector3_t2243707580_Vector3_t2243707580_Il2CppObject,
	RuntimeInvoker_Int32_t2071877448_Vector4_t2243707581_Vector4_t2243707581_Il2CppObject,
	RuntimeInvoker_Int32_t2071877448_Il2CppObject_CustomAttributeNamedArgument_t94157543,
	RuntimeInvoker_Int32_t2071877448_Il2CppObject_CustomAttributeNamedArgument_t94157543_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Int32_t2071877448_Il2CppObject_CustomAttributeTypedArgument_t1498197914,
	RuntimeInvoker_Int32_t2071877448_Il2CppObject_CustomAttributeTypedArgument_t1498197914_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Int32_t2071877448_Il2CppObject_Color32_t874517518_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Int32_t2071877448_Il2CppObject_RaycastResult_t21186376_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Int32_t2071877448_Il2CppObject_Playable_t3667545548_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Int32_t2071877448_Il2CppObject_UICharInfo_t3056636800_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Int32_t2071877448_Il2CppObject_UILineInfo_t3621277874_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Int32_t2071877448_Il2CppObject_UIVertex_t1204258818_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Int32_t2071877448_Il2CppObject_Vector2_t2243707579_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Int32_t2071877448_Il2CppObject_Vector3_t2243707580_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Int32_t2071877448_Il2CppObject_Vector4_t2243707581_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Int32_t2071877448_TableRange_t2011406615,
	RuntimeInvoker_Int32_t2071877448_ArraySegment_1_t2594217482,
	RuntimeInvoker_Int32_t2071877448_DictionaryEntry_t3048875398,
	RuntimeInvoker_Int32_t2071877448_Link_t865133271,
	RuntimeInvoker_Int32_t2071877448_KeyValuePair_2_t3749587448,
	RuntimeInvoker_Int32_t2071877448_KeyValuePair_2_t1174980068,
	RuntimeInvoker_Int32_t2071877448_KeyValuePair_2_t3716250094,
	RuntimeInvoker_Int32_t2071877448_KeyValuePair_2_t38854645,
	RuntimeInvoker_Int32_t2071877448_Link_t2723257478,
	RuntimeInvoker_Int32_t2071877448_Slot_t2022531261,
	RuntimeInvoker_Int32_t2071877448_Slot_t2267560602,
	RuntimeInvoker_Int32_t2071877448_CustomAttributeNamedArgument_t94157543,
	RuntimeInvoker_Int32_t2071877448_CustomAttributeTypedArgument_t1498197914,
	RuntimeInvoker_Int32_t2071877448_LabelData_t3712112744,
	RuntimeInvoker_Int32_t2071877448_LabelFixup_t4090909514,
	RuntimeInvoker_Int32_t2071877448_ILTokenInfo_t149559338,
	RuntimeInvoker_Int32_t2071877448_ParameterModifier_t1820634920,
	RuntimeInvoker_Int32_t2071877448_ResourceCacheItem_t333236149,
	RuntimeInvoker_Int32_t2071877448_ResourceInfo_t3933049236,
	RuntimeInvoker_Int32_t2071877448_Byte_t3683104436,
	RuntimeInvoker_Int32_t2071877448_X509ChainStatus_t4278378721,
	RuntimeInvoker_Int32_t2071877448_Mark_t2724874473,
	RuntimeInvoker_Int32_t2071877448_UriScheme_t1876590943,
	RuntimeInvoker_Int32_t2071877448_Color32_t874517518,
	RuntimeInvoker_Int32_t2071877448_ContactPoint_t1376425630,
	RuntimeInvoker_Int32_t2071877448_ContactPoint2D_t3659330976,
	RuntimeInvoker_Int32_t2071877448_RaycastResult_t21186376,
	RuntimeInvoker_Int32_t2071877448_Keyframe_t1449471340,
	RuntimeInvoker_Int32_t2071877448_RaycastHit_t87180320,
	RuntimeInvoker_Int32_t2071877448_RaycastHit2D_t4063908774,
	RuntimeInvoker_Int32_t2071877448_HitInfo_t1761367055,
	RuntimeInvoker_Int32_t2071877448_UICharInfo_t3056636800,
	RuntimeInvoker_Int32_t2071877448_UILineInfo_t3621277874,
	RuntimeInvoker_Int32_t2071877448_UIVertex_t1204258818,
	RuntimeInvoker_Int32_t2071877448_Vector3_t2243707580,
	RuntimeInvoker_Int32_t2071877448_Vector4_t2243707581,
	RuntimeInvoker_Void_t1841601450_TableRange_t2011406615,
	RuntimeInvoker_Void_t1841601450_ArraySegment_1_t2594217482,
	RuntimeInvoker_Void_t1841601450_DictionaryEntry_t3048875398,
	RuntimeInvoker_Void_t1841601450_Link_t865133271,
	RuntimeInvoker_Void_t1841601450_KeyValuePair_2_t3749587448,
	RuntimeInvoker_Void_t1841601450_KeyValuePair_2_t1174980068,
	RuntimeInvoker_Void_t1841601450_KeyValuePair_2_t3716250094,
	RuntimeInvoker_Void_t1841601450_Link_t2723257478,
	RuntimeInvoker_Void_t1841601450_Slot_t2022531261,
	RuntimeInvoker_Void_t1841601450_Slot_t2267560602,
	RuntimeInvoker_Void_t1841601450_Decimal_t724701077,
	RuntimeInvoker_Void_t1841601450_CustomAttributeNamedArgument_t94157543,
	RuntimeInvoker_Void_t1841601450_CustomAttributeTypedArgument_t1498197914,
	RuntimeInvoker_Void_t1841601450_LabelData_t3712112744,
	RuntimeInvoker_Void_t1841601450_LabelFixup_t4090909514,
	RuntimeInvoker_Void_t1841601450_ILTokenInfo_t149559338,
	RuntimeInvoker_Void_t1841601450_ParameterModifier_t1820634920,
	RuntimeInvoker_Void_t1841601450_ResourceCacheItem_t333236149,
	RuntimeInvoker_Void_t1841601450_ResourceInfo_t3933049236,
	RuntimeInvoker_Void_t1841601450_X509ChainStatus_t4278378721,
	RuntimeInvoker_Void_t1841601450_Mark_t2724874473,
	RuntimeInvoker_Void_t1841601450_UriScheme_t1876590943,
	RuntimeInvoker_Void_t1841601450_ContactPoint_t1376425630,
	RuntimeInvoker_Void_t1841601450_ContactPoint2D_t3659330976,
	RuntimeInvoker_Void_t1841601450_Keyframe_t1449471340,
	RuntimeInvoker_Void_t1841601450_RaycastHit_t87180320,
	RuntimeInvoker_Void_t1841601450_RaycastHit2D_t4063908774,
	RuntimeInvoker_Void_t1841601450_HitInfo_t1761367055,
	RuntimeInvoker_Void_t1841601450_UICharInfo_t3056636800,
	RuntimeInvoker_Void_t1841601450_UILineInfo_t3621277874,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_TableRange_t2011406615,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_ArraySegment_1_t2594217482,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_DictionaryEntry_t3048875398,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Link_t865133271,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_KeyValuePair_2_t3749587448,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_KeyValuePair_2_t1174980068,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_KeyValuePair_2_t3716250094,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_KeyValuePair_2_t38854645,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Link_t2723257478,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Slot_t2022531261,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Slot_t2267560602,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_DateTime_t693205669,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Decimal_t724701077,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Double_t4078015681,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_CustomAttributeNamedArgument_t94157543,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_CustomAttributeTypedArgument_t1498197914,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_LabelData_t3712112744,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_LabelFixup_t4090909514,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_ILTokenInfo_t149559338,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_ParameterModifier_t1820634920,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_ResourceCacheItem_t333236149,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_ResourceInfo_t3933049236,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Byte_t3683104436,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_X509ChainStatus_t4278378721,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Mark_t2724874473,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_TimeSpan_t3430258949,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_UriScheme_t1876590943,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_ContactPoint_t1376425630,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_ContactPoint2D_t3659330976,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_RaycastResult_t21186376,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Playable_t3667545548,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_Keyframe_t1449471340,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_RaycastHit_t87180320,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_RaycastHit2D_t4063908774,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_UICharInfo_t3056636800,
	RuntimeInvoker_Void_t1841601450_Int32_t2071877448_UILineInfo_t3621277874,
	RuntimeInvoker_Void_t1841601450_Int32U5BU5DU26_t1341332175_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_Int32U5BU5DU26_t1341332175_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_CustomAttributeNamedArgumentU5BU5DU26_t2117536786_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_CustomAttributeNamedArgumentU5BU5DU26_t2117536786_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_CustomAttributeTypedArgumentU5BU5DU26_t4216645529_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_CustomAttributeTypedArgumentU5BU5DU26_t4216645529_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_Color32U5BU5DU26_t1617488829_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_Color32U5BU5DU26_t1617488829_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_RaycastResultU5BU5DU26_t2399554255_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_RaycastResultU5BU5DU26_t2399554255_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_PlayableU5BU5DU26_t2309105347_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_PlayableU5BU5DU26_t2309105347_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_UICharInfoU5BU5DU26_t454909735_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_UICharInfoU5BU5DU26_t454909735_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_UILineInfoU5BU5DU26_t11034961_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_UILineInfoU5BU5DU26_t11034961_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_UIVertexU5BU5DU26_t2990985569_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_UIVertexU5BU5DU26_t2990985569_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_Vector2U5BU5DU26_t1595685398_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_Vector2U5BU5DU26_t1595685398_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_Vector3U5BU5DU26_t3129387507_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_Vector3U5BU5DU26_t3129387507_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_Vector4U5BU5DU26_t368122320_Int32_t2071877448,
	RuntimeInvoker_Void_t1841601450_Vector4U5BU5DU26_t368122320_Int32_t2071877448_Int32_t2071877448,
	RuntimeInvoker_TableRange_t2011406615_Int32_t2071877448,
	RuntimeInvoker_ClientCertificateType_t4001384466_Int32_t2071877448,
	RuntimeInvoker_ArraySegment_1_t2594217482_Int32_t2071877448,
	RuntimeInvoker_DictionaryEntry_t3048875398_Int32_t2071877448,
	RuntimeInvoker_Link_t865133271_Int32_t2071877448,
	RuntimeInvoker_KeyValuePair_2_t3749587448_Int32_t2071877448,
	RuntimeInvoker_KeyValuePair_2_t1174980068_Int32_t2071877448,
	RuntimeInvoker_KeyValuePair_2_t3716250094_Int32_t2071877448,
	RuntimeInvoker_KeyValuePair_2_t38854645_Int32_t2071877448,
	RuntimeInvoker_Link_t2723257478_Int32_t2071877448,
	RuntimeInvoker_Slot_t2022531261_Int32_t2071877448,
	RuntimeInvoker_Slot_t2267560602_Int32_t2071877448,
	RuntimeInvoker_CustomAttributeNamedArgument_t94157543_Int32_t2071877448,
	RuntimeInvoker_CustomAttributeTypedArgument_t1498197914_Int32_t2071877448,
	RuntimeInvoker_LabelData_t3712112744_Int32_t2071877448,
	RuntimeInvoker_LabelFixup_t4090909514_Int32_t2071877448,
	RuntimeInvoker_ILTokenInfo_t149559338_Int32_t2071877448,
	RuntimeInvoker_ParameterModifier_t1820634920_Int32_t2071877448,
	RuntimeInvoker_ResourceCacheItem_t333236149_Int32_t2071877448,
	RuntimeInvoker_ResourceInfo_t3933049236_Int32_t2071877448,
	RuntimeInvoker_TypeTag_t141209596_Int32_t2071877448,
	RuntimeInvoker_X509ChainStatus_t4278378721_Int32_t2071877448,
	RuntimeInvoker_Mark_t2724874473_Int32_t2071877448,
	RuntimeInvoker_TimeSpan_t3430258949_Int32_t2071877448,
	RuntimeInvoker_UriScheme_t1876590943_Int32_t2071877448,
	RuntimeInvoker_ContactPoint_t1376425630_Int32_t2071877448,
	RuntimeInvoker_ContactPoint2D_t3659330976_Int32_t2071877448,
	RuntimeInvoker_Keyframe_t1449471340_Int32_t2071877448,
	RuntimeInvoker_RaycastHit_t87180320_Int32_t2071877448,
	RuntimeInvoker_RaycastHit2D_t4063908774_Int32_t2071877448,
	RuntimeInvoker_HitInfo_t1761367055_Int32_t2071877448,
	RuntimeInvoker_ContentType_t1028629049_Int32_t2071877448,
	RuntimeInvoker_UICharInfo_t3056636800_Int32_t2071877448,
	RuntimeInvoker_UILineInfo_t3621277874_Int32_t2071877448,
	RuntimeInvoker_CustomAttributeNamedArgument_t94157543,
	RuntimeInvoker_CustomAttributeTypedArgument_t1498197914,
	RuntimeInvoker_TableRange_t2011406615,
	RuntimeInvoker_ClientCertificateType_t4001384466,
	RuntimeInvoker_ArraySegment_1_t2594217482,
	RuntimeInvoker_Link_t865133271,
	RuntimeInvoker_KeyValuePair_2_t1174980068,
	RuntimeInvoker_KeyValuePair_2_t3716250094,
	RuntimeInvoker_Link_t2723257478,
	RuntimeInvoker_Slot_t2022531261,
	RuntimeInvoker_Slot_t2267560602,
	RuntimeInvoker_LabelData_t3712112744,
	RuntimeInvoker_LabelFixup_t4090909514,
	RuntimeInvoker_ILTokenInfo_t149559338,
	RuntimeInvoker_ParameterModifier_t1820634920,
	RuntimeInvoker_ResourceCacheItem_t333236149,
	RuntimeInvoker_ResourceInfo_t3933049236,
	RuntimeInvoker_TypeTag_t141209596,
	RuntimeInvoker_X509ChainStatus_t4278378721,
	RuntimeInvoker_Mark_t2724874473,
	RuntimeInvoker_UriScheme_t1876590943,
	RuntimeInvoker_Color32_t874517518,
	RuntimeInvoker_ContactPoint_t1376425630,
	RuntimeInvoker_ContactPoint2D_t3659330976,
	RuntimeInvoker_Keyframe_t1449471340,
	RuntimeInvoker_RaycastHit_t87180320,
	RuntimeInvoker_RaycastHit2D_t4063908774,
	RuntimeInvoker_HitInfo_t1761367055,
	RuntimeInvoker_UICharInfo_t3056636800,
	RuntimeInvoker_UILineInfo_t3621277874,
	RuntimeInvoker_UIVertex_t1204258818,
	RuntimeInvoker_Int32_t2071877448_DateTimeOffset_t1362988906_DateTimeOffset_t1362988906,
	RuntimeInvoker_Int32_t2071877448_Guid_t2533601593_Guid_t2533601593,
	RuntimeInvoker_Int32_t2071877448_CustomAttributeNamedArgument_t94157543_CustomAttributeNamedArgument_t94157543,
	RuntimeInvoker_Int32_t2071877448_CustomAttributeTypedArgument_t1498197914_CustomAttributeTypedArgument_t1498197914,
	RuntimeInvoker_Int32_t2071877448_Color32_t874517518_Color32_t874517518,
	RuntimeInvoker_Int32_t2071877448_Playable_t3667545548_Playable_t3667545548,
	RuntimeInvoker_Int32_t2071877448_UICharInfo_t3056636800_UICharInfo_t3056636800,
	RuntimeInvoker_Int32_t2071877448_UILineInfo_t3621277874_UILineInfo_t3621277874,
	RuntimeInvoker_Int32_t2071877448_UIVertex_t1204258818_UIVertex_t1204258818,
	RuntimeInvoker_Int32_t2071877448_Vector2_t2243707579_Vector2_t2243707579,
	RuntimeInvoker_Int32_t2071877448_Vector3_t2243707580_Vector3_t2243707580,
	RuntimeInvoker_Int32_t2071877448_Vector4_t2243707581_Vector4_t2243707581,
	RuntimeInvoker_DictionaryEntry_t3048875398_Int32_t2071877448_Il2CppObject,
	RuntimeInvoker_DictionaryEntry_t3048875398_Il2CppObject,
	RuntimeInvoker_KeyValuePair_2_t3749587448_Int32_t2071877448_Il2CppObject,
	RuntimeInvoker_KeyValuePair_2_t3749587448_Il2CppObject,
	RuntimeInvoker_DictionaryEntry_t3048875398_Il2CppObject_SByte_t454417549,
	RuntimeInvoker_KeyValuePair_2_t1174980068_Il2CppObject_SByte_t454417549,
	RuntimeInvoker_KeyValuePair_2_t1174980068_Il2CppObject,
	RuntimeInvoker_DictionaryEntry_t3048875398_Il2CppObject_Int32_t2071877448,
	RuntimeInvoker_KeyValuePair_2_t3716250094_Il2CppObject_Int32_t2071877448,
	RuntimeInvoker_KeyValuePair_2_t3716250094_Il2CppObject,
	RuntimeInvoker_KeyValuePair_2_t38854645_Il2CppObject,
	RuntimeInvoker_Enumerator_t809200314,
	RuntimeInvoker_Enumerator_t3350470340,
	RuntimeInvoker_Boolean_t3825574718_Il2CppObject_BooleanU26_t3168250738,
	RuntimeInvoker_Enumerator_t442692252,
	RuntimeInvoker_Enumerator_t2983962278,
	RuntimeInvoker_Boolean_t3825574718_SByte_t454417549_SByte_t454417549,
	RuntimeInvoker_Boolean_t3825574718_Int16_t4041245914_Int16_t4041245914,
	RuntimeInvoker_Boolean_t3825574718_DateTimeOffset_t1362988906_DateTimeOffset_t1362988906,
	RuntimeInvoker_Boolean_t3825574718_Guid_t2533601593_Guid_t2533601593,
	RuntimeInvoker_Boolean_t3825574718_CustomAttributeNamedArgument_t94157543_CustomAttributeNamedArgument_t94157543,
	RuntimeInvoker_Boolean_t3825574718_CustomAttributeTypedArgument_t1498197914_CustomAttributeTypedArgument_t1498197914,
	RuntimeInvoker_Boolean_t3825574718_Color32_t874517518_Color32_t874517518,
	RuntimeInvoker_Boolean_t3825574718_RaycastResult_t21186376_RaycastResult_t21186376,
	RuntimeInvoker_Boolean_t3825574718_Playable_t3667545548_Playable_t3667545548,
	RuntimeInvoker_Int32_t2071877448_ColorBlock_t2652774230,
	RuntimeInvoker_Int32_t2071877448_Navigation_t1571958496,
	RuntimeInvoker_Boolean_t3825574718_Navigation_t1571958496_Navigation_t1571958496,
	RuntimeInvoker_Int32_t2071877448_SpriteState_t1353336012,
	RuntimeInvoker_Boolean_t3825574718_SpriteState_t1353336012_SpriteState_t1353336012,
	RuntimeInvoker_Boolean_t3825574718_UICharInfo_t3056636800_UICharInfo_t3056636800,
	RuntimeInvoker_Boolean_t3825574718_UILineInfo_t3621277874_UILineInfo_t3621277874,
	RuntimeInvoker_Boolean_t3825574718_UIVertex_t1204258818_UIVertex_t1204258818,
	RuntimeInvoker_Enumerator_t975728254,
	RuntimeInvoker_CustomAttributeNamedArgument_t94157543_Il2CppObject,
	RuntimeInvoker_Enumerator_t3292975645,
	RuntimeInvoker_CustomAttributeTypedArgument_t1498197914_Il2CppObject,
	RuntimeInvoker_Enumerator_t402048720,
	RuntimeInvoker_Color32_t874517518_Il2CppObject,
	RuntimeInvoker_Enumerator_t4073335620,
	RuntimeInvoker_Enumerator_t3220004478,
	RuntimeInvoker_Enumerator_t2571396354,
	RuntimeInvoker_UICharInfo_t3056636800_Il2CppObject,
	RuntimeInvoker_Enumerator_t1960487606,
	RuntimeInvoker_UILineInfo_t3621277874_Il2CppObject,
	RuntimeInvoker_Enumerator_t2525128680,
	RuntimeInvoker_UIVertex_t1204258818_Il2CppObject,
	RuntimeInvoker_Enumerator_t108109624,
	RuntimeInvoker_Enumerator_t1147558385,
	RuntimeInvoker_Vector3_t2243707580_Il2CppObject,
	RuntimeInvoker_Enumerator_t1147558386,
	RuntimeInvoker_Enumerator_t1147558387,
	RuntimeInvoker_Il2CppObject_CustomAttributeNamedArgument_t94157543_CustomAttributeNamedArgument_t94157543_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Il2CppObject_CustomAttributeTypedArgument_t1498197914_CustomAttributeTypedArgument_t1498197914_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Il2CppObject_Color32_t874517518_Color32_t874517518_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Il2CppObject_RaycastResult_t21186376_RaycastResult_t21186376_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Il2CppObject_Playable_t3667545548_Playable_t3667545548_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Il2CppObject_RaycastHit_t87180320_RaycastHit_t87180320_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Il2CppObject_UICharInfo_t3056636800_UICharInfo_t3056636800_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Il2CppObject_UILineInfo_t3621277874_UILineInfo_t3621277874_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Il2CppObject_UIVertex_t1204258818_UIVertex_t1204258818_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Il2CppObject_Vector2_t2243707579_Vector2_t2243707579_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Il2CppObject_Vector3_t2243707580_Vector3_t2243707580_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Il2CppObject_Vector4_t2243707581_Vector4_t2243707581_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Boolean_t3825574718_Nullable_1_t1693325264,
	RuntimeInvoker_Il2CppObject_CustomAttributeNamedArgument_t94157543_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Il2CppObject_CustomAttributeTypedArgument_t1498197914_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Il2CppObject_Color32_t874517518_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Il2CppObject_RaycastResult_t21186376_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Il2CppObject_Playable_t3667545548_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Il2CppObject_UICharInfo_t3056636800_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Il2CppObject_UILineInfo_t3621277874_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Il2CppObject_UIVertex_t1204258818_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Il2CppObject_Vector2_t2243707579_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Il2CppObject_Vector3_t2243707580_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Il2CppObject_Vector4_t2243707581_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Il2CppObject_Single_t2076509932_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Il2CppObject_Color_t2020392075_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Il2CppObject_Scene_t1684909666_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Il2CppObject_Scene_t1684909666_Int32_t2071877448_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Il2CppObject_Scene_t1684909666_Scene_t1684909666_Il2CppObject_Il2CppObject,
	RuntimeInvoker_Il2CppObject_ColorTween_t3438117476,
	RuntimeInvoker_Il2CppObject_FloatTween_t2986189219,
};
