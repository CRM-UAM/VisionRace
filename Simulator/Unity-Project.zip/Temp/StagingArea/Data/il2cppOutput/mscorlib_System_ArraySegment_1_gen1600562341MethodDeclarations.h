﻿#pragma once

#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <stdint.h>
#include <assert.h>
#include <exception>

// System.Object[]
struct ObjectU5BU5D_t3614634134;
// System.Object
struct Il2CppObject;

#include "codegen/il2cpp-codegen.h"
#include "mscorlib_System_ArraySegment_1_gen1600562341.h"
#include "mscorlib_System_Object2689449295.h"

// T[] System.ArraySegment`1<System.Object>::get_Array()
extern "C"  ObjectU5BU5D_t3614634134* ArraySegment_1_get_Array_m1808599309_gshared (ArraySegment_1_t1600562341 * __this, const MethodInfo* method);
#define ArraySegment_1_get_Array_m1808599309(__this, method) ((  ObjectU5BU5D_t3614634134* (*) (ArraySegment_1_t1600562341 *, const MethodInfo*))ArraySegment_1_get_Array_m1808599309_gshared)(__this, method)
// System.Int32 System.ArraySegment`1<System.Object>::get_Offset()
extern "C"  int32_t ArraySegment_1_get_Offset_m28425256_gshared (ArraySegment_1_t1600562341 * __this, const MethodInfo* method);
#define ArraySegment_1_get_Offset_m28425256(__this, method) ((  int32_t (*) (ArraySegment_1_t1600562341 *, const MethodInfo*))ArraySegment_1_get_Offset_m28425256_gshared)(__this, method)
// System.Int32 System.ArraySegment`1<System.Object>::get_Count()
extern "C"  int32_t ArraySegment_1_get_Count_m570182236_gshared (ArraySegment_1_t1600562341 * __this, const MethodInfo* method);
#define ArraySegment_1_get_Count_m570182236(__this, method) ((  int32_t (*) (ArraySegment_1_t1600562341 *, const MethodInfo*))ArraySegment_1_get_Count_m570182236_gshared)(__this, method)
// System.Boolean System.ArraySegment`1<System.Object>::Equals(System.Object)
extern "C"  bool ArraySegment_1_Equals_m2027598521_gshared (ArraySegment_1_t1600562341 * __this, Il2CppObject * ___obj0, const MethodInfo* method);
#define ArraySegment_1_Equals_m2027598521(__this, ___obj0, method) ((  bool (*) (ArraySegment_1_t1600562341 *, Il2CppObject *, const MethodInfo*))ArraySegment_1_Equals_m2027598521_gshared)(__this, ___obj0, method)
// System.Boolean System.ArraySegment`1<System.Object>::Equals(System.ArraySegment`1<T>)
extern "C"  bool ArraySegment_1_Equals_m2459999213_gshared (ArraySegment_1_t1600562341 * __this, ArraySegment_1_t1600562341  ___obj0, const MethodInfo* method);
#define ArraySegment_1_Equals_m2459999213(__this, ___obj0, method) ((  bool (*) (ArraySegment_1_t1600562341 *, ArraySegment_1_t1600562341 , const MethodInfo*))ArraySegment_1_Equals_m2459999213_gshared)(__this, ___obj0, method)
// System.Int32 System.ArraySegment`1<System.Object>::GetHashCode()
extern "C"  int32_t ArraySegment_1_GetHashCode_m163176103_gshared (ArraySegment_1_t1600562341 * __this, const MethodInfo* method);
#define ArraySegment_1_GetHashCode_m163176103(__this, method) ((  int32_t (*) (ArraySegment_1_t1600562341 *, const MethodInfo*))ArraySegment_1_GetHashCode_m163176103_gshared)(__this, method)
