﻿#pragma once

#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <stdint.h>

// System.Threading.ManualResetEvent
struct ManualResetEvent_t926074657;
// System.String
struct String_t;

#include "mscorlib_System_Object2689449295.h"

#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// AsynchronousClient
struct  AsynchronousClient_t317815987  : public Il2CppObject
{
public:

public:
};

struct AsynchronousClient_t317815987_StaticFields
{
public:
	// System.Threading.ManualResetEvent AsynchronousClient::connectDone
	ManualResetEvent_t926074657 * ___connectDone_1;
	// System.Threading.ManualResetEvent AsynchronousClient::sendDone
	ManualResetEvent_t926074657 * ___sendDone_2;
	// System.Threading.ManualResetEvent AsynchronousClient::receiveDone
	ManualResetEvent_t926074657 * ___receiveDone_3;
	// System.String AsynchronousClient::response
	String_t* ___response_4;

public:
	inline static int32_t get_offset_of_connectDone_1() { return static_cast<int32_t>(offsetof(AsynchronousClient_t317815987_StaticFields, ___connectDone_1)); }
	inline ManualResetEvent_t926074657 * get_connectDone_1() const { return ___connectDone_1; }
	inline ManualResetEvent_t926074657 ** get_address_of_connectDone_1() { return &___connectDone_1; }
	inline void set_connectDone_1(ManualResetEvent_t926074657 * value)
	{
		___connectDone_1 = value;
		Il2CppCodeGenWriteBarrier(&___connectDone_1, value);
	}

	inline static int32_t get_offset_of_sendDone_2() { return static_cast<int32_t>(offsetof(AsynchronousClient_t317815987_StaticFields, ___sendDone_2)); }
	inline ManualResetEvent_t926074657 * get_sendDone_2() const { return ___sendDone_2; }
	inline ManualResetEvent_t926074657 ** get_address_of_sendDone_2() { return &___sendDone_2; }
	inline void set_sendDone_2(ManualResetEvent_t926074657 * value)
	{
		___sendDone_2 = value;
		Il2CppCodeGenWriteBarrier(&___sendDone_2, value);
	}

	inline static int32_t get_offset_of_receiveDone_3() { return static_cast<int32_t>(offsetof(AsynchronousClient_t317815987_StaticFields, ___receiveDone_3)); }
	inline ManualResetEvent_t926074657 * get_receiveDone_3() const { return ___receiveDone_3; }
	inline ManualResetEvent_t926074657 ** get_address_of_receiveDone_3() { return &___receiveDone_3; }
	inline void set_receiveDone_3(ManualResetEvent_t926074657 * value)
	{
		___receiveDone_3 = value;
		Il2CppCodeGenWriteBarrier(&___receiveDone_3, value);
	}

	inline static int32_t get_offset_of_response_4() { return static_cast<int32_t>(offsetof(AsynchronousClient_t317815987_StaticFields, ___response_4)); }
	inline String_t* get_response_4() const { return ___response_4; }
	inline String_t** get_address_of_response_4() { return &___response_4; }
	inline void set_response_4(String_t* value)
	{
		___response_4 = value;
		Il2CppCodeGenWriteBarrier(&___response_4, value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
