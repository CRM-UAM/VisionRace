﻿#pragma once

#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <stdint.h>

// UnityEngine.GUIText
struct GUIText_t2411476300;
// UnityEngine.UI.Text
struct Text_t356221433;
// System.Byte[]
struct ByteU5BU5D_t3397334013;
// UnityEngine.Texture2D
struct Texture2D_t3542995729;
// System.Net.Sockets.TcpClient
struct TcpClient_t408947970;
// UnityEngine.UI.Slider
struct Slider_t297367283;
// UnityEngine.UI.InputField
struct InputField_t1631627530;

#include "UnityEngine_UnityEngine_MonoBehaviour1158329972.h"
#include "UnityEngine_UnityEngine_Vector32243707580.h"

#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// ClientTCP
struct  ClientTCP_t343911830  : public MonoBehaviour_t1158329972
{
public:
	// UnityEngine.GUIText ClientTCP::txt
	GUIText_t2411476300 * ___txt_2;
	// System.Boolean ClientTCP::start
	bool ___start_3;
	// System.Boolean ClientTCP::lap
	bool ___lap_4;
	// System.Single ClientTCP::LapTime
	float ___LapTime_5;
	// System.Single ClientTCP::speed
	float ___speed_6;
	// UnityEngine.UI.Text ClientTCP::laptimeText
	Text_t356221433 * ___laptimeText_7;
	// System.Byte[] ClientTCP::ba
	ByteU5BU5D_t3397334013* ___ba_8;
	// UnityEngine.Vector3 ClientTCP::iniPos
	Vector3_t2243707580  ___iniPos_9;
	// UnityEngine.Texture2D ClientTCP::ScreenShot
	Texture2D_t3542995729 * ___ScreenShot_10;
	// System.Net.Sockets.TcpClient ClientTCP::tcpclnt
	TcpClient_t408947970 * ___tcpclnt_11;
	// System.Int32 ClientTCP::dir
	int32_t ___dir_12;
	// UnityEngine.UI.Slider ClientTCP::sld
	Slider_t297367283 * ___sld_13;
	// UnityEngine.UI.InputField ClientTCP::ip
	InputField_t1631627530 * ___ip_14;
	// UnityEngine.UI.InputField ClientTCP::port
	InputField_t1631627530 * ___port_15;

public:
	inline static int32_t get_offset_of_txt_2() { return static_cast<int32_t>(offsetof(ClientTCP_t343911830, ___txt_2)); }
	inline GUIText_t2411476300 * get_txt_2() const { return ___txt_2; }
	inline GUIText_t2411476300 ** get_address_of_txt_2() { return &___txt_2; }
	inline void set_txt_2(GUIText_t2411476300 * value)
	{
		___txt_2 = value;
		Il2CppCodeGenWriteBarrier(&___txt_2, value);
	}

	inline static int32_t get_offset_of_start_3() { return static_cast<int32_t>(offsetof(ClientTCP_t343911830, ___start_3)); }
	inline bool get_start_3() const { return ___start_3; }
	inline bool* get_address_of_start_3() { return &___start_3; }
	inline void set_start_3(bool value)
	{
		___start_3 = value;
	}

	inline static int32_t get_offset_of_lap_4() { return static_cast<int32_t>(offsetof(ClientTCP_t343911830, ___lap_4)); }
	inline bool get_lap_4() const { return ___lap_4; }
	inline bool* get_address_of_lap_4() { return &___lap_4; }
	inline void set_lap_4(bool value)
	{
		___lap_4 = value;
	}

	inline static int32_t get_offset_of_LapTime_5() { return static_cast<int32_t>(offsetof(ClientTCP_t343911830, ___LapTime_5)); }
	inline float get_LapTime_5() const { return ___LapTime_5; }
	inline float* get_address_of_LapTime_5() { return &___LapTime_5; }
	inline void set_LapTime_5(float value)
	{
		___LapTime_5 = value;
	}

	inline static int32_t get_offset_of_speed_6() { return static_cast<int32_t>(offsetof(ClientTCP_t343911830, ___speed_6)); }
	inline float get_speed_6() const { return ___speed_6; }
	inline float* get_address_of_speed_6() { return &___speed_6; }
	inline void set_speed_6(float value)
	{
		___speed_6 = value;
	}

	inline static int32_t get_offset_of_laptimeText_7() { return static_cast<int32_t>(offsetof(ClientTCP_t343911830, ___laptimeText_7)); }
	inline Text_t356221433 * get_laptimeText_7() const { return ___laptimeText_7; }
	inline Text_t356221433 ** get_address_of_laptimeText_7() { return &___laptimeText_7; }
	inline void set_laptimeText_7(Text_t356221433 * value)
	{
		___laptimeText_7 = value;
		Il2CppCodeGenWriteBarrier(&___laptimeText_7, value);
	}

	inline static int32_t get_offset_of_ba_8() { return static_cast<int32_t>(offsetof(ClientTCP_t343911830, ___ba_8)); }
	inline ByteU5BU5D_t3397334013* get_ba_8() const { return ___ba_8; }
	inline ByteU5BU5D_t3397334013** get_address_of_ba_8() { return &___ba_8; }
	inline void set_ba_8(ByteU5BU5D_t3397334013* value)
	{
		___ba_8 = value;
		Il2CppCodeGenWriteBarrier(&___ba_8, value);
	}

	inline static int32_t get_offset_of_iniPos_9() { return static_cast<int32_t>(offsetof(ClientTCP_t343911830, ___iniPos_9)); }
	inline Vector3_t2243707580  get_iniPos_9() const { return ___iniPos_9; }
	inline Vector3_t2243707580 * get_address_of_iniPos_9() { return &___iniPos_9; }
	inline void set_iniPos_9(Vector3_t2243707580  value)
	{
		___iniPos_9 = value;
	}

	inline static int32_t get_offset_of_ScreenShot_10() { return static_cast<int32_t>(offsetof(ClientTCP_t343911830, ___ScreenShot_10)); }
	inline Texture2D_t3542995729 * get_ScreenShot_10() const { return ___ScreenShot_10; }
	inline Texture2D_t3542995729 ** get_address_of_ScreenShot_10() { return &___ScreenShot_10; }
	inline void set_ScreenShot_10(Texture2D_t3542995729 * value)
	{
		___ScreenShot_10 = value;
		Il2CppCodeGenWriteBarrier(&___ScreenShot_10, value);
	}

	inline static int32_t get_offset_of_tcpclnt_11() { return static_cast<int32_t>(offsetof(ClientTCP_t343911830, ___tcpclnt_11)); }
	inline TcpClient_t408947970 * get_tcpclnt_11() const { return ___tcpclnt_11; }
	inline TcpClient_t408947970 ** get_address_of_tcpclnt_11() { return &___tcpclnt_11; }
	inline void set_tcpclnt_11(TcpClient_t408947970 * value)
	{
		___tcpclnt_11 = value;
		Il2CppCodeGenWriteBarrier(&___tcpclnt_11, value);
	}

	inline static int32_t get_offset_of_dir_12() { return static_cast<int32_t>(offsetof(ClientTCP_t343911830, ___dir_12)); }
	inline int32_t get_dir_12() const { return ___dir_12; }
	inline int32_t* get_address_of_dir_12() { return &___dir_12; }
	inline void set_dir_12(int32_t value)
	{
		___dir_12 = value;
	}

	inline static int32_t get_offset_of_sld_13() { return static_cast<int32_t>(offsetof(ClientTCP_t343911830, ___sld_13)); }
	inline Slider_t297367283 * get_sld_13() const { return ___sld_13; }
	inline Slider_t297367283 ** get_address_of_sld_13() { return &___sld_13; }
	inline void set_sld_13(Slider_t297367283 * value)
	{
		___sld_13 = value;
		Il2CppCodeGenWriteBarrier(&___sld_13, value);
	}

	inline static int32_t get_offset_of_ip_14() { return static_cast<int32_t>(offsetof(ClientTCP_t343911830, ___ip_14)); }
	inline InputField_t1631627530 * get_ip_14() const { return ___ip_14; }
	inline InputField_t1631627530 ** get_address_of_ip_14() { return &___ip_14; }
	inline void set_ip_14(InputField_t1631627530 * value)
	{
		___ip_14 = value;
		Il2CppCodeGenWriteBarrier(&___ip_14, value);
	}

	inline static int32_t get_offset_of_port_15() { return static_cast<int32_t>(offsetof(ClientTCP_t343911830, ___port_15)); }
	inline InputField_t1631627530 * get_port_15() const { return ___port_15; }
	inline InputField_t1631627530 ** get_address_of_port_15() { return &___port_15; }
	inline void set_port_15(InputField_t1631627530 * value)
	{
		___port_15 = value;
		Il2CppCodeGenWriteBarrier(&___port_15, value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
