﻿#pragma once

#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif

#include <stdint.h>
#include <assert.h>
#include <exception>

// StateObject
struct StateObject_t1293687898;

#include "codegen/il2cpp-codegen.h"

// System.Void StateObject::.ctor()
extern "C"  void StateObject__ctor_m1285744273 (StateObject_t1293687898 * __this, const MethodInfo* method) IL2CPP_METHOD_ATTR;
